# ALMANAL 14.30 → Python Runtime 0.30 Mapping

| ALMANAL 14.30 concept | Runtime 0.30 | status |
|---|---|---|
| compact operational contract | `spec/ALMANAL.md` | executable contract surface |
| algorithm lifecycle objective | `spec/ALMANAL.md` + `TaskSemantics.task_class` | SYNTHESIZE/IMPROVE/REPAIR/OPTIMIZE/CONSOLIDATE semantics |
| baseline-dominance output floor | `orchestrator.py` + PLANNING capsule | optional frozen `baseline_candidate`; dominated/unverified enhanced output falls back |
| bounded final artifact simplification | PLANNING capsule + verification contract | intermediate reuse/algebraic collapse/dead-duplicate removal then affected re-verification |
| Feedback ↔ SCA cross-trigger | shared Generic Revision contract | conceptual coupling; separate WARM residency |
| epistemic claim validation | `verification.py` | required generic invariant |
| cognitive/resource economy | `economy.py` | componentwise hard-resource logic |
| measurement integrity / feedback | `feedback.py` | WARM |
| localized experiment engine | `experiment.py` | WARM |
| objective/evidence/checkpoint | `improvement.py` | WARM; bounded no-progress/epoch lease for autonomous work |
| subjective outcome preference | `preference.py` | WARM |
| structural consolidation audit | `consolidation.py` | checkpoint-only WARM |
| PASSIVE automatic consolidation | `execute_structural_consolidation_audit` | apply→verify→remeasure→rollback-on-failure |
| ACTIVE consolidation | SCA `PROPOSE_TRIAL` / review | never auto-applied |
| lazy public facade | package `__getattr__` export map | ordinary residency reduction |
| StepBudget | runtime-local `StepBudget` | merged private leaf |
| 14.17 self-design / legacy prior | `design_direction.py` | checkpoint-only DDS, witnessed legacy prior cards, provisional subsystem admission |
| Claim identity freeze | `verification.py` | post-outcome proposition/scope/conditions/mode change -> new claim |
| Causal witness integrity | `feedback.py` | execution receipt + host/runtime receipt validator before strong causal support |
| Multi-step VOC | `economy.py` | dependency-closed package-level VOC wired into cognitive routing; contained resources charged once |
| Shadow exploration reserve | `experiment.py` | label-independent reserve before decisive early stop; not proof of unknown-risk coverage |
| Serialized shared commit | `runtime.py` | parallel compute allowed; shared ledger mutation serialized and rollback-safe |
| Public CLI witness | `tests/test_14_17_hardening.py` | `python -m almanal_runtime demo/selftest` smoke coverage |


| inherited witnessed legacy prior validation | `design_direction.py` | retrieval/unavailability claims require host validators |
| inherited concrete architecture trade study | `design_direction.py` | protected-filtered, non-scalarized set/Pareto frontier |

| 14.19 witnessed alternative analysis | `design_direction.py` | concrete DDS winner requires host/runtime alternative validator |
| 14.19 design decision trace | `design_direction.py` | deterministic `DesignDecisionRecord` binds evidence/rationale/revisit/exit |
| 14.19 SCA rollback integrity | `consolidation.py` | rollback failure -> integrity compromised + stop auto-apply |
| 14.19 strong verification attestation | `verification.py`, `certificate.py` | MACHINE/EXTERNAL basis and scoped independence require witness validators |
| 14.19 witnessed experiment metering | `experiment.py` | actual cost settlement only after meter witness validation |
| 14.19 portable bootstrap witness | `portable.py` | strong capability labels cannot self-promote backend/assurance ceiling |

| 14.24 decision-frontier lease | `improvement.py` | ordinary activity and frontier progress are separately bounded |
| 14.24 mechanism-first benchmark | `evaluator.py` + PLANNING capsule | benchmark requires static screen, mechanism, unresolved empirical axis, decision relevance |
| 14.24 HOT economy SCA | `economy.py` + `economy_cold.py` | lifecycle/meta/formalism helpers lazy WARM; common worker path unchanged public surface |

| 14.28 practical code Pareto core | `spec/ALMANAL.md` + PLANNING capsule | correctness/stability protected; runtime-work/memory/source/artifact axes default |
| 14.28 structural runtime evidence | `evaluator.AnalyticCostVector` | exact/proved structural work may establish analytic cost reduction without fabricated time |
| 14.28 SCA practical footprint | `consolidation.StructuralComplexityFootprint` | execution work + peak live memory + artifact bytes |
| 14.28 audit payload split | release packaging | operational Runtime ZIP excludes audit-only tests/examples/full specs |

| 14.28 local I/O bottleneck closure | compact spec + PLANNING semantics | I/O audit only after cheap core; lightweight buffering before custom I/O; source/memory rent preserved |


## 14.28 convergence mapping
- `evaluator.plan_representation_race`: cheap representation feasibility/Pareto/dominance screen, bounded active beam, reserve, representation lock.
- `prompting.PLANNING`: compact operational reminder; detailed policy remains WARM in spec/runtime.
- Finalization/reopen limits are policy bounds, not evidence that the chosen representation is globally optimal.

| 14.28 proof-obligation bundling | `evaluator.plan_representation_race` + PLANNING | scheduling prefers one representation/invariant that closes multiple mandatory obligations; no evidence-grade promotion |
| 14.28 pre-implementation footprint | `evaluator.AnalyticCostVector` + representation race | nonempty frozen-axis structural footprint required before materialization |
| 14.28 cheap falsifier | `evaluator.cheap_falsifier_is_decision_relevant` + PLANNING | bounded counterexample search only when decision-relevant and cheaper than next deep reasoning batch; passing non-exhaustive test is not proof |

## 14.29 residual execution-compression mapping

| concept | runtime | status |
|---|---|---|
| post-lock residual closure | `evaluator.residual_execution_closure_complete` + PLANNING | finalization gate for material performance/resource tasks |
| proved arithmetic narrowing | `evaluator.delayed_reduction_safe` | static safety bound; no sample-based width guessing |
| transition-class aggregation / minimal state | compact spec + PLANNING | bounded within-family audit; no new subsystem |


## 14.30 witnessed closure mapping

Representation candidates require explicit feasibility; lock is emitted only for a unique witnessed non-dominated lock survivor. Multiple witnessed Pareto lock candidates remain a frontier.

| concept | runtime | status |
|---|---|---|
| validated representation lock | `evaluator.plan_representation_race` | lock evidence is validated before dominance/selection; unvalidated lock claims cannot prune a witnessed lock candidate |
| scheduler metadata non-elimination | `evaluator.plan_representation_race` | optimistic peer bounds/obligation metadata rank the bounded beam but do not reject unwitnessed peers; rejection needs proved frontier or witnessed lock dominance |
| witnessed residual completion | `evaluator.residual_execution_closure_complete` | all seven material audit classes require validated refs; an immaterial-resource skip also requires validated evidence |
| residual-before-finalization binding | `evaluator.finalization_pass_allowed` | caller cannot inject a completion boolean; residual evidence is checked inside the finalization gate |
| fresh lease witnesses | `WitnessLeaseLedger`, reserve/falsifier/finalization gates | run-scoped serialized validation+consumption rejects sequential or concurrent witness reuse |
| ledger-owned transition budgets | `WitnessLeaseLedger`, finalization/reserve gates | repeating caller pass/reopen counters cannot refresh bounded work |
| bounded candidate contract | `RepresentationCandidate`, `plan_representation_race` | mechanism + reasoning bound + nonempty mandatory obligations required |
| full arithmetic range | `evaluator.delayed_reduction_safe` | target type must contain the proved lower and upper intermediate bounds |
| benchmark-last fail closed | `evaluator.benchmark_is_decision_relevant` | mechanism/static-screen prerequisites default false and must be explicit |
