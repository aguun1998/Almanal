from enum import Enum, auto
from .errors import InvalidTransition, RuntimeStopped

class Stage(Enum):
    PRESEAL = auto()
    AUTOTUNE = auto()
    SCOPE = auto()
    MOUNT = auto()
    FORMALIZE = auto()
    COMPOSE = auto()
    GENERATE = auto()
    CHALLENGE = auto()
    REPAIR = auto()
    VALIDATE = auto()
    CONSOLIDATE = auto()
    REGRESSION = auto()
    OUTPUT = auto()
    STOP = auto()
    INVALIDATED = auto()

_TERMINAL = {Stage.STOP, Stage.INVALIDATED}
_ALLOWED = {
    (Stage.PRESEAL, Stage.AUTOTUNE),
    (Stage.AUTOTUNE, Stage.SCOPE),
    (Stage.SCOPE, Stage.MOUNT),
    (Stage.MOUNT, Stage.FORMALIZE),
    (Stage.FORMALIZE, Stage.COMPOSE),
    (Stage.FORMALIZE, Stage.GENERATE),
    (Stage.COMPOSE, Stage.GENERATE),
    (Stage.FORMALIZE, Stage.VALIDATE),
    (Stage.FORMALIZE, Stage.REGRESSION),
    (Stage.GENERATE, Stage.VALIDATE),
    (Stage.GENERATE, Stage.REGRESSION),
    (Stage.CHALLENGE, Stage.REGRESSION),
    (Stage.REPAIR, Stage.REGRESSION),
    (Stage.GENERATE, Stage.CHALLENGE),
    (Stage.CHALLENGE, Stage.REPAIR),
    (Stage.CHALLENGE, Stage.VALIDATE),
    (Stage.REPAIR, Stage.CHALLENGE),
    (Stage.REPAIR, Stage.VALIDATE),
    (Stage.VALIDATE, Stage.CONSOLIDATE),
    (Stage.VALIDATE, Stage.REGRESSION),
    (Stage.VALIDATE, Stage.REPAIR),
    (Stage.CONSOLIDATE, Stage.REGRESSION),
    (Stage.REGRESSION, Stage.OUTPUT),
    (Stage.REGRESSION, Stage.REPAIR),
    (Stage.OUTPUT, Stage.STOP),
}

def check_transition(current: Stage, nxt: Stage) -> None:
    if current in _TERMINAL:
        raise RuntimeStopped(f"terminal stage: {current.name}")
    if nxt is Stage.INVALIDATED:
        return
    if (current, nxt) not in _ALLOWED:
        raise InvalidTransition(f"{current.name} -> {nxt.name}")
