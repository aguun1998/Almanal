from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction
from math import ceil

from .errors import AlmanalError
from .economy import ResourceVector, UtilityEstimate, RiskRule

@dataclass(frozen=True, slots=True)
class LifecycleImprovement:
    """Economics of a persistent self-improvement on one commensurate utility scale.

    `discounted_expected_uses` is an explicitly supplied exposure estimate, not a
    theorem. Resource costs remain separately constrained by the caller.
    """
    improvement_id: str
    one_time_decision_cost_utility: Fraction
    per_use_utility_gain: UtilityEstimate
    per_use_decision_cost_utility: Fraction
    discounted_expected_uses: Fraction
    one_time_resources: ResourceVector = ResourceVector()
    recurring_resources_per_use: ResourceVector = ResourceVector()
    mandatory: bool = False
    evidence_ref: str = ""

    def __post_init__(self) -> None:
        if self.one_time_decision_cost_utility < 0:
            raise AlmanalError("one_time_decision_cost_utility must be nonnegative")
        if self.per_use_decision_cost_utility < 0:
            raise AlmanalError("per_use_decision_cost_utility must be nonnegative")
        if self.discounted_expected_uses < 0:
            raise AlmanalError("discounted_expected_uses must be nonnegative")

    def lifecycle_npv_expected(self) -> Fraction:
        return (
            self.discounted_expected_uses
            * (
                self.per_use_utility_gain.expected
                - self.per_use_decision_cost_utility
            )
            - self.one_time_decision_cost_utility
        )

    def lifecycle_npv_lower(self) -> Fraction:
        return (
            self.discounted_expected_uses
            * (
                self.per_use_utility_gain.lower
                - self.per_use_decision_cost_utility
            )
            - self.one_time_decision_cost_utility
        )


@dataclass(frozen=True, slots=True)
class LifecycleDecision:
    execute: bool
    npv: Fraction
    reason: str


def decide_lifecycle_improvement(
    proposal: LifecycleImprovement,
    *,
    risk_rule: RiskRule = RiskRule.EXPECTED_VALUE,
    minimum_margin: Fraction = Fraction(0),
) -> LifecycleDecision:
    npv = (
        proposal.lifecycle_npv_lower()
        if risk_rule is RiskRule.LOWER_BOUND
        else proposal.lifecycle_npv_expected()
    )
    if proposal.mandatory:
        return LifecycleDecision(
            True, npv, "mandatory persistent repair; economics is recorded but not a skip gate"
        )
    if npv <= minimum_margin:
        return LifecycleDecision(
            False, npv,
            "improvement may be possible but is not worth doing under the frozen lifecycle policy"
        )
    return LifecycleDecision(
        True, npv, "expected lifecycle marginal value exceeds lifecycle decision cost"
    )


@dataclass(frozen=True, slots=True)
class TokenInvestment:
    """Separate token-only break-even accounting; never mixed with utility."""
    one_time_tokens: int
    per_use_tokens_saved: int

    def __post_init__(self) -> None:
        if self.one_time_tokens < 0 or self.per_use_tokens_saved < 0:
            raise AlmanalError("token investment values must be nonnegative")

    def break_even_uses(self) -> int | None:
        if self.per_use_tokens_saved == 0:
            return 0 if self.one_time_tokens == 0 else None
        return ceil(self.one_time_tokens / self.per_use_tokens_saved)


def exact_myopic_voc_from_outcomes(
    *,
    current_stop_utility: Fraction,
    outcome_probabilities_and_stop_utilities: tuple[tuple[Fraction, Fraction], ...],
    decision_cost_utility: Fraction,
) -> Fraction:
    """Exact finite one-step VOC when outcome probabilities/utilities are supplied.

    Probabilities must sum exactly to 1. This is useful for proofs/tests and does
    not imply that real LLM outcome probabilities are known exactly.
    """
    if decision_cost_utility < 0:
        raise AlmanalError("decision_cost_utility must be nonnegative")
    total_p = sum((p for p, _ in outcome_probabilities_and_stop_utilities), Fraction(0))
    if total_p != 1:
        raise AlmanalError("outcome probabilities must sum exactly to 1")
    if any(p < 0 for p, _ in outcome_probabilities_and_stop_utilities):
        raise AlmanalError("outcome probabilities must be nonnegative")
    expected_after = sum(
        (p * u for p, u in outcome_probabilities_and_stop_utilities),
        Fraction(0),
    )
    return expected_after - current_stop_utility - decision_cost_utility


@dataclass(frozen=True, slots=True)
class MetaTransition:
    probability: Fraction
    next_state: str

    def __post_init__(self) -> None:
        if self.probability < 0:
            raise AlmanalError("transition probability must be nonnegative")


@dataclass(frozen=True, slots=True)
class MetaAction:
    action_id: str
    state: str
    decision_cost_utility: Fraction
    transitions: tuple[MetaTransition, ...]
    resources: ResourceVector = ResourceVector()

    def __post_init__(self) -> None:
        if self.decision_cost_utility < 0:
            raise AlmanalError("meta-action cost must be nonnegative")
        if sum((t.probability for t in self.transitions), Fraction(0)) != 1:
            raise AlmanalError("meta-action transition probabilities must sum to 1")


@dataclass(frozen=True, slots=True)
class FiniteMetaProblem:
    """Finite-horizon metareasoning problem on one calibrated utility scale."""
    stop_utilities: tuple[tuple[str, Fraction], ...]
    actions: tuple[MetaAction, ...]

    def stop_utility_map(self) -> dict[str, Fraction]:
        out = dict(self.stop_utilities)
        if len(out) != len(self.stop_utilities):
            raise AlmanalError("duplicate meta-state in stop_utilities")
        return out


@dataclass(frozen=True, slots=True)
class MetaSolution:
    horizon: int
    values: tuple[tuple[str, Fraction], ...]
    policy: tuple[tuple[str, str], ...]  # state -> STOP or action_id


def solve_finite_horizon_metareasoning(
    problem: FiniteMetaProblem,
    *,
    horizon: int,
    budget: ResourceVector = ResourceVector(),
) -> MetaSolution:
    """Exact finite-horizon Bellman solver using Fraction arithmetic.

    V_0(s,b) = U_stop(s)
    V_h(s,b) = max(
        U_stop(s),
        max_{a:r(a)<=b}[
            -c(a) + Σ_o P(o|s,a) V_{h-1}(T(s,a,o), b-r(a))
        ]
    )

    The returned values/policy are for the supplied *initial* budget.
    This solves the declared finite model exactly. It does NOT claim that a real
    LLM's probabilities, utilities, or calibrated costs are known exactly.
    """
    if horizon < 0:
        raise AlmanalError("horizon must be nonnegative")

    stop = problem.stop_utility_map()
    actions_by_state: dict[str, list[MetaAction]] = {state: [] for state in stop}
    for action in problem.actions:
        if action.state not in stop:
            raise AlmanalError(f"unknown action state: {action.state}")
        for tr in action.transitions:
            if tr.next_state not in stop:
                raise AlmanalError(f"unknown transition state: {tr.next_state}")
        actions_by_state[action.state].append(action)

    memo: dict[tuple[str, int, tuple[int, int, int, int, int, int]], Fraction] = {}
    first_policy: dict[str, str] = {}

    def value(state: str, h: int, remaining: ResourceVector) -> Fraction:
        key = (state, h, remaining.key())
        if key in memo:
            return memo[key]

        stop_value = stop[state]
        if h == 0:
            memo[key] = stop_value
            return stop_value

        best_value = stop_value
        best_action = "STOP"

        for action in actions_by_state.get(state, ()):
            if not action.resources.fits(remaining):
                continue
            next_budget = remaining.subtract(action.resources)
            action_value = -action.decision_cost_utility + sum(
                (
                    tr.probability * value(tr.next_state, h - 1, next_budget)
                    for tr in action.transitions
                ),
                Fraction(0),
            )
            # Exact tie policy: STOP / earlier lower-cognition choice remains.
            if action_value > best_value:
                best_value = action_value
                best_action = action.action_id

        memo[key] = best_value
        if h == horizon and remaining == budget:
            first_policy[state] = best_action
        return best_value

    initial_values = {
        state: value(state, horizon, budget)
        for state in stop
    }

    return MetaSolution(
        horizon=horizon,
        values=tuple(sorted(initial_values.items())),
        policy=tuple(
            sorted(
                (state, first_policy.get(state, "STOP"))
                for state in stop
            )
        ),
    )


class FormalResidency(Enum):
    """Where a formal object belongs after economic/hygiene review."""
    HOT = auto()      # always-active runtime contract
    WARM = auto()     # task-conditional mount
    COLD = auto()     # source/audit/proof only
    DELETE = auto()   # no current justification to retain


@dataclass(frozen=True, slots=True)
class FormalObjectProfile:
    """Economic profile for a definition/rule/invariant/theorem/type/protocol field.

    Character counts are exact storage/context-size measures, not token billing.
    Booleans are evidence-bearing keep criteria, not scalar utility weights.
    """
    object_id: str
    source_chars: int
    active_context_chars: int
    runtime_required: bool = False
    protected_defect_guard: bool = False
    task_conditional: bool = False
    proof_only: bool = False
    compression_chars_saved: int = 0
    empirical_value_witnessed: bool = False
    evidence_ref: str = ""

    def __post_init__(self) -> None:
        if min(
            self.source_chars,
            self.active_context_chars,
            self.compression_chars_saved,
        ) < 0:
            raise AlmanalError("formalism character counts must be nonnegative")
        if self.active_context_chars > self.source_chars and self.source_chars > 0:
            # This may happen with expanded renderings, but must be explicit rather than accidental.
            raise AlmanalError(
                "active_context_chars cannot exceed source_chars in this compact profile"
            )

    @property
    def net_active_char_cost(self) -> int:
        """Same-unit context burden after any explicit compression saving."""
        return max(0, self.active_context_chars - self.compression_chars_saved)


@dataclass(frozen=True, slots=True)
class FormalismDecision:
    residency: FormalResidency
    keep: bool
    reason: str
    net_active_char_cost: int


def classify_formal_object(profile: FormalObjectProfile) -> FormalismDecision:
    """Apply 'keep requires justification' without inventing a scalar score.

    Priority:
    - always-active runtime semantics -> HOT
    - task-conditional protected/empirical/compact operational value -> WARM
    - proof/audit-only value -> COLD
    - otherwise -> DELETE

    This is a policy classifier, not a theorem that these categories are globally optimal.
    """
    net = profile.net_active_char_cost

    if profile.runtime_required and not profile.task_conditional:
        return FormalismDecision(
            FormalResidency.HOT,
            True,
            "required for always-active runtime semantics",
            net,
        )

    if profile.protected_defect_guard:
        residency = (
            FormalResidency.WARM
            if profile.task_conditional
            else FormalResidency.HOT
        )
        return FormalismDecision(
            residency,
            True,
            "guards a protected defect class",
            net,
        )

    if profile.runtime_required and profile.task_conditional:
        return FormalismDecision(
            FormalResidency.WARM,
            True,
            "runtime-relevant only for a task-conditional path",
            net,
        )

    if profile.empirical_value_witnessed:
        return FormalismDecision(
            FormalResidency.WARM,
            True,
            "retained by witnessed task value; mount only when relevant",
            net,
        )

    if profile.compression_chars_saved > profile.active_context_chars:
        return FormalismDecision(
            FormalResidency.WARM,
            True,
            "formal object compresses more active-context material than it costs",
            net,
        )

    if profile.proof_only:
        return FormalismDecision(
            FormalResidency.COLD,
            True,
            "useful for source/audit proof but not active runtime context",
            0,
        )

    return FormalismDecision(
        FormalResidency.DELETE,
        False,
        "no runtime, protected-defect, compression, proof, or witnessed empirical justification",
        0,
    )


@dataclass(frozen=True, slots=True)
class FormalismFootprint:
    hot_chars: int = 0
    warm_chars: int = 0
    cold_chars: int = 0
    deleted_chars: int = 0

    @property
    def active_floor_chars(self) -> int:
        return self.hot_chars


def summarize_formalism(
    profiles: tuple[FormalObjectProfile, ...],
) -> FormalismFootprint:
    hot = warm = cold = deleted = 0
    for profile in profiles:
        decision = classify_formal_object(profile)
        if decision.residency is FormalResidency.HOT:
            hot += decision.net_active_char_cost
        elif decision.residency is FormalResidency.WARM:
            warm += decision.net_active_char_cost
        elif decision.residency is FormalResidency.COLD:
            cold += profile.source_chars
        else:
            deleted += profile.source_chars
    return FormalismFootprint(hot, warm, cold, deleted)
