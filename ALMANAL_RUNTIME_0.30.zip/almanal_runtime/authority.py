from enum import Enum, auto
from .model import ObjectId
from .errors import AuthorityViolation

class Permission(Enum):
    READ = auto()
    PROPOSE = auto()
    ROUTE = auto()
    EVALUATE = auto()
    COMMIT_SCOPED = auto()
    GOVERNANCE = auto()

AuthoritySet = frozenset[Permission]

class AuthorityLedger:
    def __init__(self) -> None:
        self.__object_authority: dict[ObjectId, AuthoritySet] = {}
        self.__operator_grants: dict[str, AuthoritySet] = {}

    def contains_object(self, object_id: ObjectId) -> bool:
        return object_id in self.__object_authority

    def discard_object(self, object_id: ObjectId) -> None:
        self.__object_authority.pop(object_id, None)

    def set_operator_grant(self, operator: str, grant: AuthoritySet) -> None:
        self.__operator_grants[operator] = frozenset(grant)

    def register_object(self, object_id: ObjectId, authority: AuthoritySet) -> None:
        if object_id in self.__object_authority:
            raise AuthorityViolation(f"authority already registered: {object_id}")
        self.__object_authority[object_id] = frozenset(authority)

    def authority_of(self, object_id: ObjectId) -> AuthoritySet:
        try:
            return self.__object_authority[object_id]
        except KeyError:
            raise AuthorityViolation(f"missing authority for {object_id}") from None

    def envelope(self, operator: str, inputs: tuple[ObjectId, ...]) -> AuthoritySet:
        result = set(self.__operator_grants.get(operator, frozenset()))
        for object_id in inputs:
            result.update(self.authority_of(object_id))
        return frozenset(result)

    def validate_output(
        self,
        operator: str,
        inputs: tuple[ObjectId, ...],
        requested: AuthoritySet,
    ) -> None:
        envelope = self.envelope(operator, inputs)
        if not requested <= envelope:
            extra = requested - envelope
            raise AuthorityViolation(
                f"authority outside envelope: {[p.name for p in sorted(extra, key=lambda x: x.name)]}"
            )
