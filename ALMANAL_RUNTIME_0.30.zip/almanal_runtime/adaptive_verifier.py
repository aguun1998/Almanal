from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping

from .assurance import (
    AssuranceSelection,
    ChangeSet,
    ImpactGraph,
    VerificationAction,
    VerificationCache,
    VerificationTier,
    plan_verification,
    escalate_verification,
)
from .errors import AssuranceViolation


@dataclass(frozen=True, slots=True)
class VerificationCase:
    action: VerificationAction
    run: Callable[[], bool]


@dataclass(frozen=True, slots=True)
class ExecutedCheck:
    action_name: str
    tier: VerificationTier
    passed: bool
    planned_token_cost: int


@dataclass(frozen=True, slots=True)
class AdaptiveVerificationResult:
    passed: bool
    initial_plan: AssuranceSelection
    executed: tuple[ExecutedCheck, ...]
    cache_hits: tuple[str, ...]
    escalations: int
    planned_tokens_spent: int
    full_regression_tokens: int
    planned_tokens_avoided: int
    residual: tuple[str, ...] = ()


def run_adaptive_verification(
    cases: tuple[VerificationCase, ...],
    *,
    change: ChangeSet,
    impact_graph: ImpactGraph,
    token_budget: int,
    fingerprints: Mapping[str, str] | None = None,
    cache: VerificationCache | None = None,
    max_escalations: int = 3,
) -> AdaptiveVerificationResult:
    """Execute only the verification justified by current impact/risk.

    This runner is deliberately sequential:
      1. plan the cheapest justified impacted set;
      2. execute it;
      3. if everything passes, STOP verification;
      4. only failures open the next tier.

    The token fields are planned/declared costs. A real LLM adapter should replace
    them with measured token usage for empirical accounting.
    """
    if max_escalations < 0:
        raise AssuranceViolation("max_escalations must be >= 0")

    fingerprints = fingerprints or {}
    action_to_case = {c.action.name: c for c in cases}
    actions = tuple(c.action for c in cases)

    plan = plan_verification(
        actions,
        change=change,
        impact_graph=impact_graph,
        token_budget=token_budget,
        fingerprints=fingerprints,
        cache=cache,
    )

    executed: list[ExecutedCheck] = []
    spent = 0
    failed_names: set[str] = set()
    already_executed: set[str] = set()

    def execute_batch(batch: tuple[VerificationAction, ...] | list[VerificationAction]) -> set[str]:
        nonlocal spent
        failed: set[str] = set()
        for action in sorted(batch, key=lambda a: (int(a.tier), a.token_cost, a.name)):
            if action.name in already_executed:
                continue
            case = action_to_case.get(action.name)
            if case is None:
                raise AssuranceViolation(f"no executable case for {action.name}")
            passed = False
            try:
                passed = bool(case.run())
            except Exception:
                passed = False
            spent += action.token_cost
            already_executed.add(action.name)
            executed.append(
                ExecutedCheck(action.name, action.tier, passed, action.token_cost)
            )
            if passed:
                if cache is not None:
                    cache.record(action, fingerprints, passed=True)
            else:
                failed.add(action.name)
        return failed

    failed_names = execute_batch(plan.selected)

    escalations = 0
    remaining = token_budget - spent
    current_tier = plan.max_initial_tier

    while failed_names and escalations < max_escalations and remaining > 0:
        batch = escalate_verification(
            plan,
            actions,
            failed_action_names=frozenset(failed_names),
            token_budget_remaining=remaining,
            current_tier=current_tier,
        )
        # Remove already executed names because plan itself doesn't mutate.
        batch = tuple(a for a in batch if a.name not in already_executed)
        if not batch:
            break
        escalations += 1
        current_tier = VerificationTier(
            min(int(current_tier) + 1, int(VerificationTier.FULL))
        )
        failed_names = execute_batch(batch)
        remaining = token_budget - spent

    passed = not failed_names and all(x.passed for x in executed)

    residual: list[str] = []
    if failed_names:
        residual.append(f"unresolved_failed_checks={sorted(failed_names)}")
    if spent >= token_budget and failed_names:
        residual.append("verification_budget_exhausted_after_failure")
    if change.materiality >= 2 and not impact_graph.coverage_verified:
        residual.append("impact_graph_coverage_unverified")
    if plan.skipped:
        residual.append(f"skipped_checks={len(plan.skipped)}")

    return AdaptiveVerificationResult(
        passed=passed,
        initial_plan=plan,
        executed=tuple(executed),
        cache_hits=tuple(a.name for a in plan.cache_hits),
        escalations=escalations,
        planned_tokens_spent=spent,
        full_regression_tokens=plan.full_token_cost,
        planned_tokens_avoided=max(0, plan.full_token_cost - spent),
        residual=tuple(residual),
    )
