from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from hashlib import sha256

from .errors import AlmanalError

class ObjectiveSource(Enum):
    USER_EXPLICIT = auto()
    NATIVE_TASK = auto()
    CHANGE_TARGET = auto()
    GENERAL_IMPROVEMENT = auto()


class ObjectiveMode(Enum):
    DIRECTED = auto()
    GENERAL_PARETO = auto()


@dataclass(frozen=True, slots=True)
class ExperimentObjective:
    """Outcome objective separated from resource cost.

    Primary metrics express what success means. Protected metrics are non-tradable
    floors. Cost metrics constrain/tie-break unless the user/native task explicitly
    chose a cost metric as primary. Diagnostic metrics explain results but do not
    define success. Preference dimensions are deliberately non-objective.
    """
    source: ObjectiveSource
    mode: ObjectiveMode
    primary_metrics: tuple[str, ...]
    protected_metrics: tuple[str, ...] = ()
    cost_metrics: tuple[str, ...] = ()
    diagnostic_metrics: tuple[str, ...] = ()
    preference_dimensions: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        groups = (
            self.primary_metrics, self.protected_metrics, self.cost_metrics,
            self.diagnostic_metrics, self.preference_dimensions,
        )
        if any(len(set(g)) != len(g) for g in groups):
            raise AlmanalError("objective metric/dimension names must be unique within each role")
        objective_names = set(self.primary_metrics) | set(self.protected_metrics) | set(self.cost_metrics) | set(self.diagnostic_metrics)
        if len(objective_names) != sum(len(g) for g in groups[:4]):
            raise AlmanalError("objective metric roles must not overlap")
        if self.mode is ObjectiveMode.DIRECTED and not self.primary_metrics:
            raise AlmanalError("directed objective requires at least one primary metric")
        if self.mode is ObjectiveMode.GENERAL_PARETO and not self.primary_metrics:
            raise AlmanalError("general improvement requires task-relevant value metrics")
        if (
            self.source is ObjectiveSource.GENERAL_IMPROVEMENT
            and set(self.primary_metrics) <= set(self.cost_metrics)
        ):
            raise AlmanalError("general improvement cannot collapse into cost minimization")

    def fingerprint(self) -> str:
        return sha256("|".join((
            self.source.name, self.mode.name,
            "PRIMARY", *self.primary_metrics,
            "PROTECTED", *self.protected_metrics,
            "COST", *self.cost_metrics,
            "DIAGNOSTIC", *self.diagnostic_metrics,
            "PREFERENCE", *self.preference_dimensions,
        )).encode("utf-8")).hexdigest()


def resolve_experiment_objective(
    *,
    user_primary: tuple[str, ...] = (),
    native_primary: tuple[str, ...] = (),
    change_primary: tuple[str, ...] = (),
    general_value_metrics: tuple[str, ...] = (),
    protected_metrics: tuple[str, ...] = (),
    cost_metrics: tuple[str, ...] = (),
    diagnostic_metrics: tuple[str, ...] = (),
    preference_dimensions: tuple[str, ...] = (),
) -> ExperimentObjective:
    """Resolve goal lexicographically without inventing scalar weights.

    UserGoal > NativeTaskGoal > ChangeTarget > GENERAL_IMPROVEMENT.
    Costs are secondary unless explicitly included in a higher-priority primary set.
    """
    if user_primary:
        source, primary, mode = ObjectiveSource.USER_EXPLICIT, user_primary, ObjectiveMode.DIRECTED
    elif native_primary:
        source, primary, mode = ObjectiveSource.NATIVE_TASK, native_primary, ObjectiveMode.DIRECTED
    elif change_primary:
        source, primary, mode = ObjectiveSource.CHANGE_TARGET, change_primary, ObjectiveMode.DIRECTED
    else:
        if not general_value_metrics:
            raise AlmanalError("goal-free improvement requires task-relevant general_value_metrics; do not invent a cost-only objective")
        source, primary, mode = ObjectiveSource.GENERAL_IMPROVEMENT, general_value_metrics, ObjectiveMode.GENERAL_PARETO
    # A metric explicitly selected as primary is not simultaneously treated as a secondary cost role.
    secondary_cost = tuple(m for m in cost_metrics if m not in set(primary))
    return ExperimentObjective(
        source=source,
        mode=mode,
        primary_metrics=tuple(primary),
        protected_metrics=tuple(m for m in protected_metrics if m not in set(primary)),
        cost_metrics=secondary_cost,
        diagnostic_metrics=tuple(m for m in diagnostic_metrics if m not in set(primary) | set(protected_metrics) | set(secondary_cost)),
        preference_dimensions=preference_dimensions,
    )
class ClaimKind(Enum):
    FORMAL = auto()
    IMPLEMENTATION = auto()
    CAUSAL = auto()
    BEHAVIORAL = auto()
    PERFORMANCE = auto()
    COST = auto()
    SUBJECTIVE_PREFERENCE = auto()


class EvidenceKind(Enum):
    FORMAL_PROOF = auto()
    STATIC_CHECK = auto()
    UNIT_PROPERTY = auto()
    TRACE = auto()
    DIRECT_MEASUREMENT = auto()
    EXPERIMENT = auto()
    EXTERNAL_VALIDATION = auto()
    USER_PREFERENCE = auto()


@dataclass(frozen=True, slots=True)
class EvidenceRequest:
    """Claim-scoped evidence requirements.

    Experiment is one possible instrument, not a mandatory feedback ritual.
    The selector returns the least-sufficient path declared by the request.
    """
    claim_kind: ClaimKind
    deterministic_defect: bool = False
    causal_attribution_required: bool = False
    independent_validation_required: bool = False
    subjective_preference_decision: bool = False
    direct_measurement_available: bool = False


@dataclass(frozen=True, slots=True)
class EvidenceSelection:
    kinds: tuple[EvidenceKind, ...]
    experiment_required: bool
    reason: str


def select_evidence_path(request: EvidenceRequest) -> EvidenceSelection:
    if request.subjective_preference_decision or request.claim_kind is ClaimKind.SUBJECTIVE_PREFERENCE:
        return EvidenceSelection(
            (EvidenceKind.USER_PREFERENCE,), False,
            "decision-relevant subjective preference is resolved by human outcome preference, not fabricated objective scoring",
        )
    if request.claim_kind is ClaimKind.FORMAL:
        kinds = [EvidenceKind.FORMAL_PROOF]
        if request.independent_validation_required:
            kinds.append(EvidenceKind.EXTERNAL_VALIDATION)
        return EvidenceSelection(tuple(kinds), False, "formal claim uses formal evidence; experiment adds no necessary support")
    if request.deterministic_defect and request.claim_kind is ClaimKind.IMPLEMENTATION:
        kinds = [EvidenceKind.STATIC_CHECK, EvidenceKind.UNIT_PROPERTY]
        if request.independent_validation_required:
            kinds.append(EvidenceKind.EXTERNAL_VALIDATION)
        return EvidenceSelection(tuple(kinds), False, "deterministic implementation defect is cheaper to verify directly")
    if request.claim_kind is ClaimKind.CAUSAL or request.causal_attribution_required:
        kinds = [EvidenceKind.TRACE, EvidenceKind.EXPERIMENT]
        if request.independent_validation_required:
            kinds.append(EvidenceKind.EXTERNAL_VALIDATION)
        return EvidenceSelection(tuple(kinds), True, "causal attribution normally needs witnessed intervention/ablation beyond trace localization")
    if request.claim_kind in {ClaimKind.BEHAVIORAL, ClaimKind.PERFORMANCE}:
        kinds = [EvidenceKind.EXPERIMENT]
        if request.independent_validation_required:
            kinds.append(EvidenceKind.EXTERNAL_VALIDATION)
        return EvidenceSelection(tuple(kinds), True, "comparative behavioral/performance claim requires paired empirical observations")
    if request.claim_kind is ClaimKind.COST:
        if request.direct_measurement_available:
            return EvidenceSelection((EvidenceKind.DIRECT_MEASUREMENT,), False, "direct witnessed metering is sufficient for the scoped cost claim")
        return EvidenceSelection((EvidenceKind.EXPERIMENT,), True, "cost claim lacks direct metering and requires measured comparative execution")
    kinds = [EvidenceKind.UNIT_PROPERTY]
    if request.independent_validation_required:
        kinds.append(EvidenceKind.EXTERNAL_VALIDATION)
    return EvidenceSelection(tuple(kinds), False, "least-sufficient non-empirical validation path selected")


class CheckpointDecision(Enum):
    CONTINUE_LOCAL = auto()
    CHECKPOINT_EVALUATION = auto()
    BLOCK_FAILED_LOCAL_VERIFICATION = auto()


class ProgressGuardDecision(Enum):
    CONTINUE = auto()
    CHECKPOINT_STOP = auto()


@dataclass(frozen=True, slots=True)
class ImprovementProgressPolicy:
    """Bound both activity stalls and decision-frontier stalls without a clock."""
    max_no_progress_steps: int = 3
    max_no_frontier_progress_steps: int = 3
    max_epoch_steps: int = 12

    def __post_init__(self) -> None:
        if min(self.max_no_progress_steps, self.max_no_frontier_progress_steps, self.max_epoch_steps) < 1:
            raise AlmanalError("progress guard limits must be >= 1")
        if max(self.max_no_progress_steps, self.max_no_frontier_progress_steps) > self.max_epoch_steps:
            raise AlmanalError("no-progress limits cannot exceed epoch step limit")


@dataclass(frozen=True, slots=True)
class ImprovementProgressState:
    epoch_id: str
    step_index: int
    last_progress_step: int
    progress_refs: tuple[str, ...] = ()
    last_frontier_progress_step: int | None = None

    def __post_init__(self) -> None:
        if not self.epoch_id:
            raise AlmanalError("progress state requires epoch_id")
        frontier = self.last_progress_step if self.last_frontier_progress_step is None else self.last_frontier_progress_step
        if min(self.step_index, self.last_progress_step, frontier) < 0:
            raise AlmanalError("progress steps must be nonnegative")
        if max(self.last_progress_step, frontier) > self.step_index:
            raise AlmanalError("progress markers cannot exceed step_index")
        if any(not ref for ref in self.progress_refs):
            raise AlmanalError("progress refs must be nonempty")

    @property
    def effective_frontier_progress_step(self) -> int:
        return self.last_progress_step if self.last_frontier_progress_step is None else self.last_frontier_progress_step


@dataclass(frozen=True, slots=True)
class ImprovementProgressPlan:
    decision: ProgressGuardDecision
    reason: str
    continuation_required: bool


def guard_improvement_progress(
    state: ImprovementProgressState,
    policy: ImprovementProgressPolicy = ImprovementProgressPolicy(),
) -> ImprovementProgressPlan:
    """Fail closed on reasoning/workflow stalls using witnessed step progress.

    A progress ref should correspond to an externally checkable event such as a
    code/artifact write, tool result, test result, evidence receipt, or frozen
    decision. Internal deliberation alone is not progress.
    """
    if state.step_index >= policy.max_epoch_steps:
        return ImprovementProgressPlan(
            ProgressGuardDecision.CHECKPOINT_STOP,
            "bounded improvement epoch exhausted; emit a continuation-safe checkpoint before further work",
            True,
        )
    if state.step_index - state.last_progress_step >= policy.max_no_progress_steps:
        return ImprovementProgressPlan(
            ProgressGuardDecision.CHECKPOINT_STOP,
            "no externally witnessed progress within the frozen step lease; stop rather than silently deliberate indefinitely",
            True,
        )
    if state.step_index - state.effective_frontier_progress_step >= policy.max_no_frontier_progress_steps:
        return ImprovementProgressPlan(
            ProgressGuardDecision.CHECKPOINT_STOP,
            "activity continued without decision-frontier progress; stop tool/benchmark churn and checkpoint",
            True,
        )
    return ImprovementProgressPlan(
        ProgressGuardDecision.CONTINUE,
        "progress lease remains valid",
        False,
    )


@dataclass(frozen=True, slots=True)
class ImprovementChangeRecord:
    change_id: str
    local_verification_passed: bool
    protected_or_high_risk: bool = False
    architectural_change: bool = False
    empirical_direction_dependency: bool = False
    interaction_risk: bool = False

    def __post_init__(self) -> None:
        if not self.change_id:
            raise AlmanalError("improvement change id must be nonempty")


@dataclass(frozen=True, slots=True)
class ImprovementBatchPolicy:
    checkpoint_after_changes: int = 4

    def __post_init__(self) -> None:
        if self.checkpoint_after_changes < 1:
            raise AlmanalError("checkpoint_after_changes must be >= 1")


@dataclass(frozen=True, slots=True)
class ImprovementCheckpointPlan:
    decision: CheckpointDecision
    changed_ids: tuple[str, ...]
    reason: str


def plan_improvement_checkpoint(
    changes: tuple[ImprovementChangeRecord, ...],
    policy: ImprovementBatchPolicy = ImprovementBatchPolicy(),
) -> ImprovementCheckpointPlan:
    if not changes:
        return ImprovementCheckpointPlan(CheckpointDecision.CONTINUE_LOCAL, (), "no accumulated change requires checkpoint evaluation")
    ids = tuple(c.change_id for c in changes)
    if len(set(ids)) != len(ids):
        raise AlmanalError("improvement batch change ids must be unique")
    if any(not c.local_verification_passed for c in changes):
        return ImprovementCheckpointPlan(
            CheckpointDecision.BLOCK_FAILED_LOCAL_VERIFICATION, ids,
            "cheap local verification failed; do not hide the defect inside a later batch experiment",
        )
    early = any(
        c.protected_or_high_risk
        or c.architectural_change
        or c.empirical_direction_dependency
        or c.interaction_risk
        for c in changes
    )
    if early:
        return ImprovementCheckpointPlan(
            CheckpointDecision.CHECKPOINT_EVALUATION, ids,
            "early checkpoint justified by risk, architecture, interaction, or dependence on empirical direction",
        )
    if len(changes) >= policy.checkpoint_after_changes:
        return ImprovementCheckpointPlan(
            CheckpointDecision.CHECKPOINT_EVALUATION, ids,
            "meaningful local-improvement batch accumulated; evaluate once at checkpoint rather than experiment every patch",
        )
    return ImprovementCheckpointPlan(
        CheckpointDecision.CONTINUE_LOCAL, ids,
        "continue cheap local repair/verification until the frozen checkpoint trigger is reached",
    )


# --- 14.14 machine-oriented endogenous objective self-description ---
from fractions import Fraction

@dataclass(frozen=True, slots=True)
class ObjectiveTermWeight:
    term: str
    weight: Fraction

    def __post_init__(self) -> None:
        if not self.term:
            raise AlmanalError("objective term must be nonempty")


@dataclass(frozen=True, slots=True)
class ObjectiveTermDelta:
    term: str
    before: Fraction
    after: Fraction

    @property
    def delta(self) -> Fraction:
        return self.after - self.before


@dataclass(frozen=True, slots=True)
class EndogenousObjectiveRevaluation:
    """Self-description of an observed objective-state change.

    This record describes how the system's own objective representation changed;
    it is not an authorization to rewrite protected objectives and carries no human
    emotion label. Domain layers may interpret patterns later.
    """
    subject_ref: str
    deltas: tuple[ObjectiveTermDelta, ...]
    evidence_refs: tuple[str, ...] = ()
    rewrite_authorized: bool = False

    def __post_init__(self) -> None:
        if not self.subject_ref:
            raise AlmanalError("objective revaluation requires subject_ref")
        names = tuple(d.term for d in self.deltas)
        if len(set(names)) != len(names):
            raise AlmanalError("objective revaluation terms must be unique")
        if self.rewrite_authorized:
            raise AlmanalError("self-description cannot self-authorize objective rewrite")


def describe_endogenous_objective_change(
    *,
    subject_ref: str,
    before: tuple[ObjectiveTermWeight, ...],
    after: tuple[ObjectiveTermWeight, ...],
    evidence_refs: tuple[str, ...] = (),
) -> EndogenousObjectiveRevaluation:
    """Describe term-level objective revaluation without inventing human semantics."""
    def to_map(values: tuple[ObjectiveTermWeight, ...]) -> dict[str, Fraction]:
        names = [v.term for v in values]
        if len(set(names)) != len(names):
            raise AlmanalError("objective state terms must be unique")
        return {v.term: v.weight for v in values}
    b, a = to_map(before), to_map(after)
    terms = sorted(set(b) | set(a))
    deltas = tuple(
        ObjectiveTermDelta(term, b.get(term, Fraction(0)), a.get(term, Fraction(0)))
        for term in terms
        if b.get(term, Fraction(0)) != a.get(term, Fraction(0))
    )
    return EndogenousObjectiveRevaluation(
        subject_ref=subject_ref,
        deltas=deltas,
        evidence_refs=evidence_refs,
        rewrite_authorized=False,
    )

