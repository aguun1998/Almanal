from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from .errors import AlmanalError

# --- checkpoint-only structural consolidation audit --------------------------


class ConsolidationOperation(Enum):
    KEEP = auto()
    DELETE = auto()
    MERGE = auto()
    COMPILE_AWAY = auto()
    MOVE_WARM = auto()   # keep capability, remove ordinary residency; load on demand
    MOVE_COLD = auto()   # proof/audit/history only; no runtime path
    GENERALIZE_REPLACE = auto()


class ConsolidationAuditClass(Enum):
    """Risk/authority class, not importance.

    PASSIVE means an obvious, reversible, evidence-backed Pareto simplification
    that may be applied automatically when an executable apply/verify/rollback
    binding is supplied. ACTIVE means judgement or broader evidence is still
    required; SCA may propose a trial but never auto-apply it.
    """
    PASSIVE = auto()
    ACTIVE = auto()


class ConsolidationDecision(Enum):
    AUTO_APPLY = auto()
    PROPOSE_TRIAL = auto()
    KEEP = auto()
    BLOCKED = auto()
    UNRESOLVED_TRADEOFF = auto()


class ConsolidationEquivalence(Enum):
    UNPROVED = auto()
    DERIVABLE = auto()
    REGRESSION_EQUIVALENT_SCOPED = auto()
    FORMALLY_PROVED = auto()


_EQUIVALENCE_RANK = {
    ConsolidationEquivalence.UNPROVED: 0,
    ConsolidationEquivalence.DERIVABLE: 1,
    ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED: 2,
    ConsolidationEquivalence.FORMALLY_PROVED: 3,
}


@dataclass(frozen=True, slots=True)
class StructuralComplexityFootprint:
    """Non-commensurate structural burdens; never silently scalarized."""
    active_context_chars: int = 0
    source_chars: int = 0
    module_count: int = 0
    type_count: int = 0
    decision_branch_count: int = 0
    dependency_edge_count: int = 0
    persistent_artifact_count: int = 0
    maintenance_surface_count: int = 0
    execution_work_units: int = 0
    peak_live_memory_bytes: int = 0
    artifact_bytes: int = 0

    def __post_init__(self) -> None:
        if min(self.key()) < 0:
            raise AlmanalError("structural complexity coordinates must be nonnegative")

    def key(self) -> tuple[int, ...]:
        return (
            self.active_context_chars, self.source_chars, self.module_count,
            self.type_count, self.decision_branch_count, self.dependency_edge_count,
            self.persistent_artifact_count, self.maintenance_surface_count,
            self.execution_work_units, self.peak_live_memory_bytes, self.artifact_bytes,
        )

    def strictly_smaller_than(self, other: "StructuralComplexityFootprint") -> bool:
        return all(a <= b for a, b in zip(self.key(), other.key())) and any(
            a < b for a, b in zip(self.key(), other.key())
        )

    def changed_coordinates_from(self, before: "StructuralComplexityFootprint") -> tuple[tuple[str, int], ...]:
        names = (
            "active_context_chars", "source_chars", "module_count", "type_count",
            "decision_branch_count", "dependency_edge_count",
            "persistent_artifact_count", "maintenance_surface_count",
            "execution_work_units", "peak_live_memory_bytes", "artifact_bytes",
        )
        return tuple(
            (name, after - prior)
            for name, prior, after in zip(names, before.key(), self.key())
            if after != prior
        )


@dataclass(frozen=True, slots=True)
class StructuralConsolidationCandidate:
    """Evidence-bearing proposal. PASSIVE candidates may be auto-applied only
    through a reversible apply/verify/rollback binding; ACTIVE candidates never are.
    """
    target_ref: str
    operation: ConsolidationOperation
    before: StructuralComplexityFootprint
    after: StructuralComplexityFootprint
    unique_capabilities: frozenset[str] = frozenset()
    protected_roles: frozenset[str] = frozenset()
    replacement_ref: str = ""
    replacement_capabilities: frozenset[str] = frozenset()
    replacement_protected_roles: frozenset[str] = frozenset()
    equivalence: ConsolidationEquivalence = ConsolidationEquivalence.UNPROVED
    evidence_refs: tuple[str, ...] = ()
    measurement_contract_ref: str = ""
    before_measurement_ref: str = ""
    rollback_ref: str = ""
    audit_history_ref: str = ""
    obsolete_or_unreachable: bool = False
    runtime_state_required: bool = False
    static_invariant_equivalent: bool = False
    proof_or_audit_only: bool = False
    load_on_demand_supported: bool = False
    residency_semantics_preserved: bool = False
    interface_compatibility_verified: bool = False
    residency_only_change: bool = False
    private_or_leaf: bool = False
    semantic_boundary_compatible: bool = True
    authority_boundary_compatible: bool = True
    new_coupling_risk: bool = False
    local_verification_passed: bool = True
    behavioral_regression_observed: bool = False
    high_impact_or_shared: bool = False
    reverse_dependency_refs: tuple[str, ...] = ()
    footprint_includes_reverse_dependency_closure: bool = True

    def __post_init__(self) -> None:
        if not self.target_ref:
            raise AlmanalError("structural consolidation target_ref must be nonempty")
        if len(set(self.reverse_dependency_refs)) != len(self.reverse_dependency_refs):
            raise AlmanalError("reverse dependency refs must be unique")
        if len(set(self.evidence_refs)) != len(self.evidence_refs):
            raise AlmanalError("structural consolidation evidence refs must be unique")


@dataclass(frozen=True, slots=True)
class StructuralConsolidationAssessment:
    target_ref: str
    operation: ConsolidationOperation
    audit_class: ConsolidationAuditClass
    decision: ConsolidationDecision
    trial_eligible: bool
    auto_apply_eligible: bool
    complexity_delta: tuple[tuple[str, int], ...]
    required_verification: tuple[str, ...]
    reason: str


@dataclass(frozen=True, slots=True)
class StructuralConsolidationAuditReport:
    assessments: tuple[StructuralConsolidationAssessment, ...]

    def by_decision(self, decision: ConsolidationDecision) -> tuple[StructuralConsolidationAssessment, ...]:
        return tuple(a for a in self.assessments if a.decision is decision)

    @property
    def passive_auto_apply(self) -> tuple[StructuralConsolidationAssessment, ...]:
        return self.by_decision(ConsolidationDecision.AUTO_APPLY)

    @property
    def trial_candidates(self) -> tuple[StructuralConsolidationAssessment, ...]:
        return self.by_decision(ConsolidationDecision.PROPOSE_TRIAL)

    @property
    def active_review(self) -> tuple[StructuralConsolidationAssessment, ...]:
        return tuple(a for a in self.assessments if a.audit_class is ConsolidationAuditClass.ACTIVE)

    @property
    def unresolved(self) -> tuple[StructuralConsolidationAssessment, ...]:
        return self.by_decision(ConsolidationDecision.UNRESOLVED_TRADEOFF)

    @property
    def blocked(self) -> tuple[StructuralConsolidationAssessment, ...]:
        return self.by_decision(ConsolidationDecision.BLOCKED)


class ConsolidationApplyOutcome(Enum):
    AUTO_APPLIED = auto()
    ROLLED_BACK = auto()
    APPLY_FAILED = auto()
    ROLLBACK_FAILED = auto()
    REVIEW_REQUIRED = auto()
    NOT_APPLICABLE = auto()
    MISSING_BINDING = auto()


@dataclass(frozen=True, slots=True)
class ConsolidationApplyBinding:
    target_ref: str
    operation: ConsolidationOperation
    apply: object
    verify: object
    rollback: object
    measurement_contract_ref: str = ""
    measure_after: object | None = None

    def __post_init__(self) -> None:
        if not self.target_ref:
            raise AlmanalError("apply binding target_ref must be nonempty")
        if not callable(self.apply) or not callable(self.verify) or not callable(self.rollback):
            raise AlmanalError("apply/verify/rollback must be callable")
        if self.measure_after is not None and not callable(self.measure_after):
            raise AlmanalError("measure_after must be callable when supplied")


@dataclass(frozen=True, slots=True)
class ConsolidationApplyRecord:
    target_ref: str
    operation: ConsolidationOperation
    outcome: ConsolidationApplyOutcome
    reason: str
    observed_after: StructuralComplexityFootprint | None = None


@dataclass(frozen=True, slots=True)
class StructuralConsolidationExecutionReport:
    audit: StructuralConsolidationAuditReport
    applications: tuple[ConsolidationApplyRecord, ...]

    @property
    def auto_applied(self) -> tuple[ConsolidationApplyRecord, ...]:
        return tuple(r for r in self.applications if r.outcome is ConsolidationApplyOutcome.AUTO_APPLIED)

    @property
    def integrity_compromised(self) -> bool:
        return any(r.outcome is ConsolidationApplyOutcome.ROLLBACK_FAILED for r in self.applications)


_DESTRUCTIVE = frozenset({
    ConsolidationOperation.DELETE,
    ConsolidationOperation.MERGE,
    ConsolidationOperation.COMPILE_AWAY,
    ConsolidationOperation.MOVE_WARM,
    ConsolidationOperation.MOVE_COLD,
    ConsolidationOperation.GENERALIZE_REPLACE,
})


def _equivalence_at_least(c: StructuralConsolidationCandidate, level: ConsolidationEquivalence) -> bool:
    return _EQUIVALENCE_RANK[c.equivalence] >= _EQUIVALENCE_RANK[level]


def _consolidation_checks(c: StructuralConsolidationCandidate) -> tuple[str, ...]:
    checks = ["STATIC_CONTRACT_CHECK", "REVERSE_DEPENDENCY_CHECK"]
    if c.replacement_ref:
        checks.append("SEMANTIC_AUTHORITY_BOUNDARY_REGRESSION")
    if c.operation is ConsolidationOperation.COMPILE_AWAY:
        checks.append("STATIC_INVARIANT_EQUIVALENCE_CHECK")
    if c.operation is ConsolidationOperation.MOVE_WARM:
        checks.extend(("LAZY_RESIDENCY_PARITY_CHECK", "PUBLIC_INTERFACE_COMPATIBILITY_CHECK"))
    if c.high_impact_or_shared and not (c.operation is ConsolidationOperation.MOVE_WARM and c.residency_only_change):
        checks.append("TARGETED_ABLATION_OR_INTERVENTION")
    checks.append("POST_CHANGE_LOCAL_REGRESSION")
    if c.operation in {ConsolidationOperation.DELETE, ConsolidationOperation.MERGE, ConsolidationOperation.COMPILE_AWAY}:
        checks.append("TEST_ADEQUACY_OR_MUTATION_SENSITIVITY_WHEN_SEMANTIC_EQUIVALENCE_IS_EMPIRICAL")
    return tuple(dict.fromkeys(checks))


def _passive_safe(c: StructuralConsolidationCandidate) -> bool:
    """Narrow automatic lane. False means ACTIVE review, not necessarily unsafe."""
    if c.operation is ConsolidationOperation.KEEP:
        return True
    if not c.measurement_contract_ref or not c.before_measurement_ref:
        return False
    if c.operation not in _DESTRUCTIVE:
        return False
    if not c.after.strictly_smaller_than(c.before):
        return False
    if c.behavioral_regression_observed or not c.local_verification_passed:
        return False
    if c.new_coupling_risk or not c.semantic_boundary_compatible or not c.authority_boundary_compatible:
        return False
    if c.high_impact_or_shared and not (
        c.operation is ConsolidationOperation.MOVE_WARM
        and c.residency_only_change
        and c.interface_compatibility_verified
        and c.residency_semantics_preserved
    ):
        return False
    if c.protected_roles and not c.protected_roles.issubset(c.replacement_protected_roles):
        return False
    if c.unique_capabilities:
        if not c.replacement_ref or not c.unique_capabilities.issubset(c.replacement_capabilities):
            if c.operation not in {ConsolidationOperation.MOVE_WARM, ConsolidationOperation.MOVE_COLD}:
                return False

    if c.operation is ConsolidationOperation.MOVE_WARM:
        return (
            c.load_on_demand_supported
            and c.residency_semantics_preserved
            and c.interface_compatibility_verified
            and c.residency_only_change
            and _equivalence_at_least(c, ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED)
        )
    if c.operation is ConsolidationOperation.MOVE_COLD:
        return c.proof_or_audit_only and not c.runtime_state_required
    if c.operation is ConsolidationOperation.DELETE:
        # Semantic deletion is PASSIVE only when mechanically dead/unreachable or formally proved.
        # Scoped regression alone is finite evidence and cannot license auto-amputation.
        if c.replacement_ref:
            return c.private_or_leaf and _equivalence_at_least(c, ConsolidationEquivalence.FORMALLY_PROVED)
        return c.private_or_leaf and c.obsolete_or_unreachable
    if c.operation is ConsolidationOperation.MERGE:
        return c.private_or_leaf and _equivalence_at_least(c, ConsolidationEquivalence.FORMALLY_PROVED)
    if c.operation is ConsolidationOperation.COMPILE_AWAY:
        return (
            c.private_or_leaf and not c.runtime_state_required and c.static_invariant_equivalent
            and _equivalence_at_least(c, ConsolidationEquivalence.FORMALLY_PROVED)
        )
    # Generalization changes abstraction/ownership and is deliberately ACTIVE.
    return False


def assess_structural_consolidation(c: StructuralConsolidationCandidate) -> StructuralConsolidationAssessment:
    delta = c.after.changed_coordinates_from(c.before)
    required = _consolidation_checks(c)

    def out(decision: ConsolidationDecision, reason: str, *, cls: ConsolidationAuditClass | None = None):
        audit_class = cls or (ConsolidationAuditClass.PASSIVE if _passive_safe(c) else ConsolidationAuditClass.ACTIVE)
        return StructuralConsolidationAssessment(
            c.target_ref, c.operation, audit_class, decision,
            decision in {ConsolidationDecision.AUTO_APPLY, ConsolidationDecision.PROPOSE_TRIAL},
            decision is ConsolidationDecision.AUTO_APPLY,
            delta, required, reason,
        )

    if c.operation is ConsolidationOperation.KEEP:
        return out(ConsolidationDecision.KEEP, "explicit KEEP candidate", cls=ConsolidationAuditClass.PASSIVE)

    if c.operation in _DESTRUCTIVE:
        if not c.evidence_refs:
            return out(ConsolidationDecision.BLOCKED, "destructive consolidation requires evidence provenance")
        if not c.rollback_ref or not c.audit_history_ref:
            return out(ConsolidationDecision.BLOCKED, "destructive consolidation requires rollback and retained audit history")
        if not c.local_verification_passed or c.behavioral_regression_observed:
            return out(ConsolidationDecision.BLOCKED, "local verification failed or behavioral regression already observed")
        if c.reverse_dependency_refs and not c.footprint_includes_reverse_dependency_closure:
            return out(ConsolidationDecision.BLOCKED, "reverse dependency closure is missing from the complexity footprint")

    replacement_based = bool(c.replacement_ref)
    if c.unique_capabilities and c.operation not in {ConsolidationOperation.MOVE_WARM, ConsolidationOperation.MOVE_COLD}:
        if not replacement_based or not c.unique_capabilities.issubset(c.replacement_capabilities):
            return out(ConsolidationDecision.BLOCKED, "unique capabilities are not preserved by the replacement")
    if c.protected_roles:
        if c.operation in {ConsolidationOperation.MOVE_WARM, ConsolidationOperation.MOVE_COLD}:
            pass  # same capability moves residency; roles remain attached to the object
        elif not replacement_based or not c.protected_roles.issubset(c.replacement_protected_roles):
            return out(ConsolidationDecision.BLOCKED, "protected role is not preserved by the replacement")

    if replacement_based and (
        not c.semantic_boundary_compatible
        or not c.authority_boundary_compatible
        or c.new_coupling_risk
    ):
        return out(ConsolidationDecision.BLOCKED, "replacement crosses semantic/authority boundary or adds coupling risk")

    if c.operation in {ConsolidationOperation.MERGE, ConsolidationOperation.GENERALIZE_REPLACE}:
        if not replacement_based or c.equivalence is ConsolidationEquivalence.UNPROVED:
            return out(ConsolidationDecision.BLOCKED, "merge/generalize-replace requires explicit replacement and supported equivalence")
    elif c.operation is ConsolidationOperation.DELETE:
        if replacement_based and c.equivalence is ConsolidationEquivalence.UNPROVED:
            return out(ConsolidationDecision.BLOCKED, "replacement-based deletion requires supported equivalence")
        if not replacement_based and not c.obsolete_or_unreachable:
            return out(ConsolidationDecision.BLOCKED, "deletion without replacement requires obsolete/unreachable evidence")
    elif c.operation is ConsolidationOperation.COMPILE_AWAY:
        if c.runtime_state_required or not c.static_invariant_equivalent or c.equivalence is ConsolidationEquivalence.UNPROVED:
            return out(ConsolidationDecision.BLOCKED, "compile-away requires no essential runtime state and supported static equivalence")
    elif c.operation is ConsolidationOperation.MOVE_WARM:
        if not c.load_on_demand_supported or not c.residency_semantics_preserved:
            return out(ConsolidationDecision.BLOCKED, "WARM move requires on-demand loading and preserved runtime semantics")
        if not c.interface_compatibility_verified:
            return out(ConsolidationDecision.BLOCKED, "WARM move requires verified interface compatibility")
        if not _equivalence_at_least(c, ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED):
            return out(ConsolidationDecision.BLOCKED, "WARM move requires scoped regression-equivalent or stronger evidence")
    elif c.operation is ConsolidationOperation.MOVE_COLD:
        if c.runtime_state_required or not c.proof_or_audit_only:
            return out(ConsolidationDecision.BLOCKED, "COLD is restricted to non-runtime proof/audit/history material")

    if c.after.strictly_smaller_than(c.before):
        if _passive_safe(c):
            return out(
                ConsolidationDecision.AUTO_APPLY,
                "PASSIVE: obvious reversible strict-Pareto simplification with sufficient safety evidence; auto-apply only through apply/verify/rollback binding",
                cls=ConsolidationAuditClass.PASSIVE,
            )
        return out(
            ConsolidationDecision.PROPOSE_TRIAL,
            "ACTIVE: structurally promising but judgement/broader evidence remains; trial/review before persistent KEEP",
            cls=ConsolidationAuditClass.ACTIVE,
        )
    if c.after.key() == c.before.key():
        return out(ConsolidationDecision.KEEP, "no structural coordinate improves; avoid churn")
    return out(
        ConsolidationDecision.UNRESOLVED_TRADEOFF,
        "mixed structural delta; resolve under an explicit frozen objective rather than inventing an exchange rate",
        cls=ConsolidationAuditClass.ACTIVE,
    )


def audit_structural_consolidation(
    candidates: tuple[StructuralConsolidationCandidate, ...],
) -> StructuralConsolidationAuditReport:
    """Checkpoint audit; same target may have distinct alternative operations."""
    keys = tuple((c.target_ref, c.operation) for c in candidates)
    if len(set(keys)) != len(keys):
        raise AlmanalError("duplicate target+operation structural consolidation candidate")
    return StructuralConsolidationAuditReport(tuple(assess_structural_consolidation(c) for c in candidates))


def execute_structural_consolidation_audit(
    candidates: tuple[StructuralConsolidationCandidate, ...],
    bindings: tuple[ConsolidationApplyBinding, ...],
) -> StructuralConsolidationExecutionReport:
    """Audit and auto-apply PASSIVE candidates only.

    ACTIVE candidates are never executed here. A PASSIVE mutation is reversible and
    becomes AUTO_APPLIED only after its supplied verifier returns truthy. Verification
    failure/exception triggers rollback. This is a host binding, not self-certification.
    """
    audit = audit_structural_consolidation(candidates)
    binding_map = {(b.target_ref, b.operation): b for b in bindings}
    if len(binding_map) != len(bindings):
        raise AlmanalError("duplicate structural consolidation apply binding")

    records: list[ConsolidationApplyRecord] = []
    for a in audit.assessments:
        if a.decision is ConsolidationDecision.PROPOSE_TRIAL:
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.REVIEW_REQUIRED, "ACTIVE candidate is never auto-applied"))
            continue
        if a.decision is not ConsolidationDecision.AUTO_APPLY:
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.NOT_APPLICABLE, a.reason))
            continue
        binding = binding_map.get((a.target_ref, a.operation))
        if binding is None:
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.MISSING_BINDING, "PASSIVE auto-apply requires explicit executable apply/verify/rollback binding"))
            continue
        candidate = next(c for c in candidates if c.target_ref == a.target_ref and c.operation is a.operation)
        if (
            not binding.measurement_contract_ref
            or binding.measurement_contract_ref != candidate.measurement_contract_ref
            or binding.measure_after is None
        ):
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.MISSING_BINDING, "PASSIVE auto-apply requires same-contract post-change structural measurement"))
            continue
        measured_after = None
        try:
            binding.apply()
            verified = bool(binding.verify())
            measured_after = binding.measure_after()
            if not isinstance(measured_after, StructuralComplexityFootprint):
                raise AlmanalError("measure_after must return StructuralComplexityFootprint")
            measured_ok = measured_after.key() == candidate.after.key() and measured_after.strictly_smaller_than(candidate.before)
        except Exception as exc:  # host failure must not leave an unverified mutation silently accepted
            try:
                binding.rollback()
            except Exception as rollback_exc:
                records.append(ConsolidationApplyRecord(
                    a.target_ref, a.operation, ConsolidationApplyOutcome.ROLLBACK_FAILED,
                    f"apply/verify/measure raised {type(exc).__name__}; rollback raised {type(rollback_exc).__name__}; mutation integrity is uncertain",
                    measured_after,
                ))
                break
            records.append(ConsolidationApplyRecord(
                a.target_ref, a.operation, ConsolidationApplyOutcome.APPLY_FAILED,
                f"apply/verify/measure raised {type(exc).__name__}; rollback completed", measured_after,
            ))
            continue
        if verified and measured_ok:
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.AUTO_APPLIED, "PASSIVE change applied; verifier and same-contract structural remeasurement passed", measured_after))
        else:
            try:
                binding.rollback()
            except Exception as rollback_exc:
                records.append(ConsolidationApplyRecord(
                    a.target_ref, a.operation, ConsolidationApplyOutcome.ROLLBACK_FAILED,
                    f"PASSIVE verification/remeasure failed and rollback raised {type(rollback_exc).__name__}; mutation integrity is uncertain",
                    measured_after,
                ))
                break
            records.append(ConsolidationApplyRecord(a.target_ref, a.operation, ConsolidationApplyOutcome.ROLLED_BACK, "PASSIVE change failed verifier or same-contract structural remeasurement and was rolled back", measured_after))

    return StructuralConsolidationExecutionReport(audit, tuple(records))
