from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

from .errors import AlmanalError
from .portable import ALMANAL_RUNTIME_PROTOCOL, Capability


BEGIN = "<!-- ALMANAL_MANIFEST_BEGIN -->"
END = "<!-- ALMANAL_MANIFEST_END -->"


@dataclass(frozen=True, slots=True)
class AlmanalSpecInfo:
    artifact: str
    version: str
    runtime_protocol: str
    runtime_mandatory: bool
    backend_substitutable: bool
    minimum_capabilities: tuple[str, ...]
    required_runtime_fields: tuple[str, ...]
    required_operators: tuple[str, ...]
    conditional_operators: tuple[str, ...]
    resident_capsules: tuple[str, ...]
    sha256: str


def extract_manifest(text: str) -> dict:
    if BEGIN not in text or END not in text:
        raise AlmanalError("portable manifest markers missing")
    payload = text.split(BEGIN, 1)[1].split(END, 1)[0]
    m = re.search(r"```json\s*(\{.*?\})\s*```", payload, flags=re.S)
    if not m:
        raise AlmanalError("portable JSON manifest block missing")
    try:
        data = json.loads(m.group(1))
    except json.JSONDecodeError as e:
        raise AlmanalError(f"portable manifest is invalid JSON: {e}") from e
    return data


def lint_almanal_text(text: str) -> AlmanalSpecInfo:
    data = extract_manifest(text)

    if data.get("artifact") != "ALMANAL":
        raise AlmanalError("wrong ALMANAL artifact id")
    if data.get("runtime_protocol") != ALMANAL_RUNTIME_PROTOCOL:
        raise AlmanalError("runtime protocol mismatch")
    if data.get("runtime_mandatory") is not True:
        raise AlmanalError("ALMANAL artifact must require runtime semantics")
    if data.get("backend_substitutable") is not True:
        raise AlmanalError("runtime backend must remain substitutable")

    if data.get("external_files_required") is not False:
        raise AlmanalError("ALMANAL distribution must not require external ALMANAL files")
    if data.get("formal_source_equivalence_claimed") is not False:
        raise AlmanalError(
            "ALMANAL distribution may not claim full formal-source equivalence without a proof"
        )

    minimum = tuple(data.get("minimum_capabilities", ()))
    expected_minimum = {"REASON", "CONTEXT_STATE", "STRUCTURED_OUTPUT"}
    if set(minimum) != expected_minimum:
        raise AlmanalError("minimum capability set mismatch")

    required_ops = tuple(data.get("required_operators", ()))
    expected_ops = {
        "FREEZE_TASK_AND_CRITERION",
        "TRACK_RUNTIME_STATE",
        "ECONOMY_GATE",
        "GENERATE_CANDIDATE",
        "CHALLENGE_CANDIDATE",
        "REPAIR_CANDIDATE",
        "EVALUATE_CANDIDATE",
        "SCHEDULE_VERIFICATION",
        "BUDGET_AND_STOP",
        "VALIDATE_EPISTEMIC_CLAIM",
    }
    if not expected_ops <= set(required_ops):
        raise AlmanalError("portable required operator set incomplete")

    conditional_ops = tuple(data.get("conditional_operators", ()))
    if "CAUSAL_MEASUREMENT_FEEDBACK" not in conditional_ops:
        raise AlmanalError("causal measurement feedback must be declared task-conditional")
    if "EXPERIMENT_DESIGN_EXECUTION" not in conditional_ops:
        raise AlmanalError("experiment design/execution must be declared task-conditional")
    if "OBJECTIVE_SELF_REVALUATION" not in conditional_ops:
        raise AlmanalError("objective self-revaluation must be declared task-conditional")
    if set(required_ops) & set(conditional_ops):
        raise AlmanalError("operator cannot be both universal-required and task-conditional")

    required_fields = tuple(data.get("required_runtime_fields", ()))
    if not {
        "task_ref", "baseline_ref", "criterion_ref", "stage",
        "verification_status", "terminal_status"
    } <= set(required_fields):
        raise AlmanalError("portable runtime state fields incomplete")

    capsules = tuple(data.get("resident_capsules", ()))
    if set(capsules) != {
        "HUMAN_CULTURE", "DEFENSE", "SOCIAL",
        "MORAL", "PLANNING", "LEARNING"
    }:
        raise AlmanalError("resident capsule set mismatch")

    required_sections = tuple(data.get("required_sections", ()))
    if not required_sections:
        raise AlmanalError("portable required section list missing")

    # The manifest is not allowed to satisfy its own body-presence claims.
    operational_text = text.split(BEGIN, 1)[0]
    missing_sections = [
        section for section in required_sections
        if section not in operational_text
    ]
    if missing_sections:
        raise AlmanalError(
            f"portable operational sections missing: {missing_sections}"
        )

    version = str(data.get("version", ""))
    if f"ALMANAL {version}" not in operational_text:
        raise AlmanalError("ALMANAL title/version mismatch")

    # Brand-agnostic distribution: common vendor/product names must not occur in
    # normative portable text. The artifact should describe capabilities only.
    forbidden_brand_tokens = (
        "OpenAI", "Anthropic", "Google Gemini", "ChatGPT", "Claude", "Grok"
    )
    hits = [token for token in forbidden_brand_tokens if token.lower() in text.lower()]
    if hits:
        raise AlmanalError(f"brand-specific portability dependency found: {hits}")

    return AlmanalSpecInfo(
        artifact=data["artifact"],
        version=str(data["version"]),
        runtime_protocol=data["runtime_protocol"],
        runtime_mandatory=bool(data["runtime_mandatory"]),
        backend_substitutable=bool(data["backend_substitutable"]),
        minimum_capabilities=minimum,
        required_runtime_fields=required_fields,
        required_operators=required_ops,
        conditional_operators=conditional_ops,
        resident_capsules=capsules,
        sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
    )


def lint_almanal_file(path: str | Path) -> AlmanalSpecInfo:
    return lint_almanal_text(Path(path).read_text(encoding="utf-8"))

# Compatibility aliases; portability remains a property, not the product name.
PortableSpecInfo = AlmanalSpecInfo
lint_portable_text = lint_almanal_text
lint_portable_file = lint_almanal_file
