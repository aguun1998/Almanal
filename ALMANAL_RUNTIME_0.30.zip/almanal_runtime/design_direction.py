from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from enum import Enum, IntEnum, auto
from typing import Callable

from .errors import AlmanalError


class DesignPressure(Enum):
    SEMANTIC_WITNESS_GAP = auto()
    STRUCTURAL_COMPLEXITY = auto()
    LONG_HORIZON_SEARCH = auto()
    EXPLORATION_GAP = auto()
    EXECUTION_ATOMICITY = auto()
    TEST_SURFACE_GAP = auto()
    COMPONENT_CHURN = auto()
    MEASUREMENT_GAP = auto()


class DesignDirection(Enum):
    HARDEN_SEMANTIC_WITNESSING = auto()
    SIMPLIFY = auto()
    GENERALIZE = auto()
    DECOUPLE = auto()
    IMPROVE_ACTIVE_CONTEXT = auto()
    IMPROVE_MEASUREMENT = auto()
    IMPROVE_EXPLORATION = auto()
    IMPROVE_LONG_HORIZON_SEARCH = auto()
    IMPROVE_EXECUTION_ASSURANCE = auto()
    STABILIZE_COMPONENT_LIFECYCLE = auto()
    STOP = auto()


class DesignSeverity(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass(frozen=True, slots=True)
class DesignSignal:
    signal_id: str
    pressure: DesignPressure
    severity: DesignSeverity
    evidence_ref: str
    protected_impact: bool = False
    observed_defect: bool = False

    def __post_init__(self) -> None:
        if not self.signal_id or not self.evidence_ref:
            raise AlmanalError("design signal requires id and evidence provenance")


class LegacySourceBasis(Enum):
    DECLARED_ONLY = auto()
    RETRIEVED_PRIMARY = auto()
    RETRIEVED_AUTHORITATIVE = auto()
    EXTERNAL_ATTESTED = auto()


@dataclass(frozen=True, slots=True)
class LegacyPriorCard:
    """Retrieved legacy theory compressed into a design prior, never authority.

    `source_basis` and `retrieval_evidence_ref` are claims about provenance. They do
    not become witnessed facts merely because the caller populated the fields.
    Direction selection therefore requires a host/runtime validator before a card
    can influence any design record.
    """
    prior_id: str
    source_ref: str
    problem_classes: frozenset[DesignPressure]
    principles: tuple[str, ...]
    limitations: tuple[str, ...] = ()
    source_basis: LegacySourceBasis = LegacySourceBasis.DECLARED_ONLY
    retrieval_evidence_ref: str = ""

    def __post_init__(self) -> None:
        if not self.prior_id or not self.source_ref or not self.problem_classes or not self.principles:
            raise AlmanalError("legacy prior card requires id/source/problem classes/principles")
        if self.source_basis is not LegacySourceBasis.DECLARED_ONLY and not self.retrieval_evidence_ref:
            raise AlmanalError("retrieval-claimed legacy prior requires retrieval/attestation evidence reference")

    @property
    def claims_retrieved_source(self) -> bool:
        return self.source_basis is not LegacySourceBasis.DECLARED_ONLY and bool(self.retrieval_evidence_ref)

    @property
    def witnessed_source(self) -> bool:
        """A card cannot witness itself. Use the validated DDS plan attachment."""
        return False


LegacyPriorValidator = Callable[[LegacyPriorCard], bool]
LegacySearchValidator = Callable[[str], bool]
LegacyUnavailableValidator = Callable[[str], bool]


@dataclass(frozen=True, slots=True)
class DesignDirectionCandidate:
    direction: DesignDirection
    supporting_signal_ids: tuple[str, ...]
    legacy_prior_ids: tuple[str, ...]
    severity: DesignSeverity
    protected_impact: bool
    observed_defect: bool
    reason: str


@dataclass(frozen=True, slots=True)
class DesignDirectionPlan:
    frontier: tuple[DesignDirectionCandidate, ...]
    selected: DesignDirection | None
    unresolved_tradeoff: bool
    reason: str


_PRESSURE_DIRECTION = {
    DesignPressure.SEMANTIC_WITNESS_GAP: DesignDirection.HARDEN_SEMANTIC_WITNESSING,
    DesignPressure.STRUCTURAL_COMPLEXITY: DesignDirection.SIMPLIFY,
    DesignPressure.LONG_HORIZON_SEARCH: DesignDirection.IMPROVE_LONG_HORIZON_SEARCH,
    DesignPressure.EXPLORATION_GAP: DesignDirection.IMPROVE_EXPLORATION,
    DesignPressure.EXECUTION_ATOMICITY: DesignDirection.IMPROVE_EXECUTION_ASSURANCE,
    DesignPressure.TEST_SURFACE_GAP: DesignDirection.IMPROVE_EXECUTION_ASSURANCE,
    DesignPressure.COMPONENT_CHURN: DesignDirection.STABILIZE_COMPONENT_LIFECYCLE,
    DesignPressure.MEASUREMENT_GAP: DesignDirection.IMPROVE_MEASUREMENT,
}


def _validated_prior_ids(
    priors: tuple[LegacyPriorCard, ...],
    signals: tuple[DesignSignal, ...],
    prior_validator: LegacyPriorValidator | None,
) -> tuple[str, ...]:
    if prior_validator is None:
        return ()
    validated: list[str] = []
    for prior in priors:
        if not prior.claims_retrieved_source:
            continue
        if not any(s.pressure in prior.problem_classes for s in signals):
            continue
        try:
            ok = bool(prior_validator(prior))
        except Exception:
            ok = False
        if ok:
            validated.append(prior.prior_id)
    return tuple(validated)


def select_design_direction(
    signals: tuple[DesignSignal, ...],
    legacy_priors: tuple[LegacyPriorCard, ...] = (),
    *,
    prior_validator: LegacyPriorValidator | None = None,
) -> DesignDirectionPlan:
    """Checkpoint-only direction selection; no architectural mutation authority.

    Highest evidenced severity is considered first. Protected impact dominates
    same-severity non-protected signals. Legacy priors remain advisory and are
    attached only when an external/runtime validator confirms their retrieval
    evidence; a source-basis enum or string reference alone never witnesses a
    source. A prior never creates a direction unsupported by a current signal.
    """
    if not signals:
        stop = DesignDirectionCandidate(
            DesignDirection.STOP, (), (), DesignSeverity.LOW, False, False,
            "no evidenced design pressure; architectural churn is not justified",
        )
        return DesignDirectionPlan((stop,), DesignDirection.STOP, False, stop.reason)
    ids = [s.signal_id for s in signals]
    if len(set(ids)) != len(ids):
        raise AlmanalError("design signal ids must be unique")
    prior_ids = [p.prior_id for p in legacy_priors]
    if len(set(prior_ids)) != len(prior_ids):
        raise AlmanalError("legacy prior ids must be unique")

    max_sev = max(s.severity for s in signals)
    tier = tuple(s for s in signals if s.severity == max_sev)
    if any(s.protected_impact for s in tier):
        tier = tuple(s for s in tier if s.protected_impact)

    grouped: dict[DesignDirection, list[DesignSignal]] = {}
    for signal in tier:
        grouped.setdefault(_PRESSURE_DIRECTION[signal.pressure], []).append(signal)

    candidates: list[DesignDirectionCandidate] = []
    for direction, ss in grouped.items():
        applicable = _validated_prior_ids(legacy_priors, tuple(ss), prior_validator)
        candidates.append(DesignDirectionCandidate(
            direction=direction,
            supporting_signal_ids=tuple(s.signal_id for s in ss),
            legacy_prior_ids=applicable,
            severity=max(s.severity for s in ss),
            protected_impact=any(s.protected_impact for s in ss),
            observed_defect=any(s.observed_defect for s in ss),
            reason="highest-severity evidenced design pressure; host-validated legacy priors are advisory only",
        ))
    candidates.sort(key=lambda c: c.direction.name)
    frontier = tuple(candidates)
    if len(frontier) == 1:
        return DesignDirectionPlan(frontier, frontier[0].direction, False, frontier[0].reason)
    return DesignDirectionPlan(
        frontier, None, True,
        "multiple non-dominated design directions remain; resolve with frozen objective/trade study rather than scalarizing silently",
    )


# --- design alternative trade study -----------------------------------------


class DesignBenefitAxis(Enum):
    SEMANTIC_ASSURANCE = auto()
    STRUCTURAL_SIMPLICITY = auto()
    ACTIVE_CONTEXT = auto()
    LONG_HORIZON_SEARCH = auto()
    EXPLORATION = auto()
    EXECUTION_ASSURANCE = auto()
    MEASUREMENT_VALIDITY = auto()
    COMPONENT_STABILITY = auto()


class DesignBurdenAxis(Enum):
    SOURCE_COMPLEXITY = auto()
    ACTIVE_RESIDENCY = auto()
    COUPLING = auto()
    MAINTENANCE_SURFACE = auto()
    IMPLEMENTATION_COST = auto()
    EVIDENCE_COST = auto()
    BEHAVIOR_CHANGE_RISK = auto()


@dataclass(frozen=True, slots=True)
class DesignAlternative:
    """One concrete architecture strategy under a coarse design direction.

    Benefit/burden sets are *hypotheses*, not measurements. The trade study uses
    set dominance only; it never invents exchange rates between incomparable
    axes. Every option needs evidence/design-analysis references so a later
    revision can audit why it was considered.
    """
    alternative_id: str
    direction: DesignDirection
    supporting_signal_ids: tuple[str, ...]
    hypothesized_benefits: frozenset[DesignBenefitAxis]
    hypothesized_burdens: frozenset[DesignBurdenAxis]
    evidence_refs: tuple[str, ...]
    protected_safe: bool = True
    reversible: bool = True
    introduces_new_subsystem: bool = False
    legacy_prior_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.alternative_id or not self.supporting_signal_ids or not self.evidence_refs:
            raise AlmanalError("design alternative requires id, supporting signals, and evidence/design-analysis refs")
        if len(set(self.supporting_signal_ids)) != len(self.supporting_signal_ids):
            raise AlmanalError("design alternative signal ids must be unique")
        if len(set(self.legacy_prior_ids)) != len(self.legacy_prior_ids):
            raise AlmanalError("design alternative legacy prior ids must be unique")


@dataclass(frozen=True, slots=True)
class DesignTradeStudyPlan:
    frontier: tuple[DesignAlternative, ...]
    selected_alternative_id: str | None
    unresolved_tradeoff: bool
    reason: str
    analysis_witnessed: bool = False


DesignAlternativeValidator = Callable[[DesignAlternative], bool]


def _alternative_dominates(a: DesignAlternative, b: DesignAlternative) -> bool:
    """Conservative set/Pareto dominance; no scalar weights or hidden exchange rate."""
    if not a.protected_safe and b.protected_safe:
        return False
    if not a.reversible and b.reversible:
        return False
    if a.introduces_new_subsystem and not b.introduces_new_subsystem:
        return False
    if not a.hypothesized_benefits.issuperset(b.hypothesized_benefits):
        return False
    if not a.hypothesized_burdens.issubset(b.hypothesized_burdens):
        return False
    strict = (
        a.protected_safe != b.protected_safe
        or a.reversible != b.reversible
        or a.introduces_new_subsystem != b.introduces_new_subsystem
        or a.hypothesized_benefits != b.hypothesized_benefits
        or a.hypothesized_burdens != b.hypothesized_burdens
    )
    return strict


def trade_study_design_alternatives(
    direction_plan: DesignDirectionPlan,
    alternatives: tuple[DesignAlternative, ...],
    *,
    alternative_validator: DesignAlternativeValidator | None = None,
) -> DesignTradeStudyPlan:
    """Compare concrete strategies for the current DDS frontier.

    This is a planning trade study, not empirical proof. Protected-impact
    directions reject alternatives that declare protected safety unresolved.
    Benefit/burden metadata is also self-declared design analysis: it can form a
    hypothesis frontier, but it cannot produce an automatic concrete winner
    unless a host/runtime validator accepts every admitted alternative analysis.
    Once witnessed, the frontier is formed by conservative set dominance; if more
    than one option remains, DDS stops with an unresolved tradeoff instead of
    choosing by an arbitrary score.
    """
    if not alternatives:
        return DesignTradeStudyPlan((), None, True, "no concrete design alternatives supplied")
    ids = [a.alternative_id for a in alternatives]
    if len(set(ids)) != len(ids):
        raise AlmanalError("design alternative ids must be unique")

    candidate_by_direction = {c.direction: c for c in direction_plan.frontier}
    valid_signal_ids = {sid for c in direction_plan.frontier for sid in c.supporting_signal_ids}
    valid_prior_ids = {pid for c in direction_plan.frontier for pid in c.legacy_prior_ids}
    admitted: list[DesignAlternative] = []
    for alt in alternatives:
        candidate = candidate_by_direction.get(alt.direction)
        if candidate is None:
            raise AlmanalError("design alternative direction is outside the current DDS frontier")
        if not set(alt.supporting_signal_ids).issubset(valid_signal_ids):
            raise AlmanalError("design alternative references a signal outside the frozen DDS frontier")
        if not set(alt.supporting_signal_ids) & set(candidate.supporting_signal_ids):
            raise AlmanalError("design alternative does not address a signal supporting its direction")
        if not set(alt.legacy_prior_ids).issubset(valid_prior_ids):
            raise AlmanalError("design alternative references an unvalidated/unattached legacy prior")
        if candidate.protected_impact and not alt.protected_safe:
            continue
        admitted.append(alt)

    if not admitted:
        return DesignTradeStudyPlan((), None, True, "all design alternatives violate protected-impact constraints")

    witnessed = alternative_validator is not None
    if witnessed:
        for alt in admitted:
            try:
                ok = bool(alternative_validator(alt))
            except Exception:
                ok = False
            if not ok:
                witnessed = False
                break

    frontier = tuple(
        alt for alt in admitted
        if not any(other is not alt and _alternative_dominates(other, alt) for other in admitted)
    )
    frontier = tuple(sorted(frontier, key=lambda a: a.alternative_id))
    if not witnessed:
        return DesignTradeStudyPlan(
            frontier, None, True,
            "design benefit/burden analysis is not host/runtime witnessed; preserve the hypothesis frontier and gather/validate analysis evidence",
            False,
        )
    if len(frontier) == 1:
        return DesignTradeStudyPlan(
            frontier, frontier[0].alternative_id, False,
            "one host/runtime-witnessed concrete alternative Pareto-dominates the admitted design set under frozen qualitative axes",
            True,
        )
    return DesignTradeStudyPlan(
        frontier, None, True,
        "multiple host/runtime-witnessed non-dominated concrete alternatives remain; gather evidence or preserve the tradeoff",
        True,
    )


class DesignRevisitTrigger(Enum):
    NEW_COUNTEREVIDENCE = auto()
    PROTECTED_REGRESSION = auto()
    LIFECYCLE_RENT_GROWTH = auto()
    LEGACY_PRIOR_INVALIDATED = auto()
    OBJECTIVE_OR_SCOPE_CHANGE = auto()


@dataclass(frozen=True, slots=True)
class DesignDecisionRecord:
    """Frozen rationale/trace record for one concrete architecture decision.

    This is a trace artifact, not authority. It binds the selected direction and
    alternative to the exact DDS signals/validated priors that supported it, plus
    protected-constraint/evidence/exit/revisit references for later SCA/Feedback.
    """
    decision_id: str
    direction: DesignDirection
    selected_alternative_id: str
    supporting_signal_ids: tuple[str, ...]
    legacy_prior_ids: tuple[str, ...]
    protected_constraints_ref: str
    evidence_plan_refs: tuple[str, ...]
    revisit_triggers: frozenset[DesignRevisitTrigger]
    exit_or_reversal_path: str
    rationale: str
    fingerprint: str


def record_design_decision(
    direction_plan: DesignDirectionPlan,
    trade_plan: DesignTradeStudyPlan,
    *,
    decision_id: str,
    protected_constraints_ref: str,
    evidence_plan_refs: tuple[str, ...],
    revisit_triggers: frozenset[DesignRevisitTrigger],
    exit_or_reversal_path: str,
    rationale: str,
) -> DesignDecisionRecord:
    """Freeze a selected witnessed trade study into a traceable decision record."""
    if not decision_id or not protected_constraints_ref or not evidence_plan_refs:
        raise AlmanalError("design decision record requires id, protected constraints, and evidence plan refs")
    if not revisit_triggers or not exit_or_reversal_path or not rationale:
        raise AlmanalError("design decision record requires revisit triggers, exit/reversal path, and rationale")
    if direction_plan.selected is None or direction_plan.unresolved_tradeoff:
        raise AlmanalError("cannot record a concrete decision from an unresolved direction frontier")
    if not trade_plan.analysis_witnessed or trade_plan.unresolved_tradeoff or not trade_plan.selected_alternative_id:
        raise AlmanalError("cannot record a concrete decision from unwitnessed or unresolved alternative analysis")
    selected = next((a for a in trade_plan.frontier if a.alternative_id == trade_plan.selected_alternative_id), None)
    if selected is None:
        raise AlmanalError("selected design alternative is absent from the frozen trade-study frontier")
    if selected.direction is not direction_plan.selected:
        raise AlmanalError("selected design alternative does not match the frozen design direction")
    candidate = next((c for c in direction_plan.frontier if c.direction is direction_plan.selected), None)
    if candidate is None:
        raise AlmanalError("selected design direction is absent from the frozen DDS frontier")
    signal_ids = tuple(sorted(candidate.supporting_signal_ids))
    prior_ids = tuple(sorted(set(candidate.legacy_prior_ids) | set(selected.legacy_prior_ids)))
    payload = {
        "decision_id": decision_id,
        "direction": direction_plan.selected.name,
        "selected_alternative_id": selected.alternative_id,
        "supporting_signal_ids": signal_ids,
        "legacy_prior_ids": prior_ids,
        "protected_constraints_ref": protected_constraints_ref,
        "evidence_plan_refs": sorted(evidence_plan_refs),
        "revisit_triggers": sorted(x.name for x in revisit_triggers),
        "exit_or_reversal_path": exit_or_reversal_path,
        "rationale": rationale,
    }
    fp = sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return DesignDecisionRecord(
        decision_id=decision_id,
        direction=direction_plan.selected,
        selected_alternative_id=selected.alternative_id,
        supporting_signal_ids=signal_ids,
        legacy_prior_ids=prior_ids,
        protected_constraints_ref=protected_constraints_ref,
        evidence_plan_refs=tuple(sorted(evidence_plan_refs)),
        revisit_triggers=revisit_triggers,
        exit_or_reversal_path=exit_or_reversal_path,
        rationale=rationale,
        fingerprint=fp,
    )


class SubsystemAdmissionDecision(Enum):
    USE_EXISTING_COMPOSITION = auto()
    PROVISIONAL_COMPONENT = auto()
    BLOCKED = auto()


@dataclass(frozen=True, slots=True)
class SubsystemProposal:
    component_ref: str
    unique_persistent_state: bool = False
    independent_lifecycle: bool = False
    independent_authority_boundary: bool = False
    existing_primitive_insufficient: bool = False
    legacy_search_ref: str = ""
    legacy_search_unavailable_reason: str = ""
    legacy_search_unavailable_evidence_ref: str = ""
    legacy_pattern_ref: str = ""
    expected_lifecycle_value_ref: str = ""
    exit_or_compile_away_path: str = ""

    def __post_init__(self) -> None:
        if not self.component_ref:
            raise AlmanalError("component_ref must be nonempty")
        if self.legacy_search_ref and self.legacy_search_unavailable_reason:
            raise AlmanalError("declare either legacy-search evidence or unavailability, not both")
        if self.legacy_search_unavailable_reason and not self.legacy_search_unavailable_evidence_ref:
            raise AlmanalError("retrieval-unavailable claim requires an evidence reference")
        if self.legacy_search_unavailable_evidence_ref and not self.legacy_search_unavailable_reason:
            raise AlmanalError("unavailability evidence requires an unavailability reason")


@dataclass(frozen=True, slots=True)
class SubsystemAdmissionAssessment:
    decision: SubsystemAdmissionDecision
    reason: str


def assess_subsystem_admission(
    p: SubsystemProposal,
    *,
    legacy_search_validator: LegacySearchValidator | None = None,
    legacy_unavailable_validator: LegacyUnavailableValidator | None = None,
) -> SubsystemAdmissionAssessment:
    if not p.existing_primitive_insufficient:
        return SubsystemAdmissionAssessment(
            SubsystemAdmissionDecision.USE_EXISTING_COMPOSITION,
            "existing primitive/contract/composition has not been shown insufficient",
        )
    separation_reasons = sum((
        p.unique_persistent_state,
        p.independent_lifecycle,
        p.independent_authority_boundary,
    ))
    if separation_reasons < 1:
        return SubsystemAdmissionAssessment(
            SubsystemAdmissionDecision.USE_EXISTING_COMPOSITION,
            "no independent state/lifecycle/authority reason justifies a new subsystem",
        )
    if not p.legacy_search_ref and not p.legacy_search_unavailable_reason:
        return SubsystemAdmissionAssessment(
            SubsystemAdmissionDecision.BLOCKED,
            "nontrivial subsystem invention requires a legacy-pattern search or a witnessed retrieval-unavailable record",
        )
    if p.legacy_search_ref:
        if legacy_search_validator is None:
            return SubsystemAdmissionAssessment(
                SubsystemAdmissionDecision.BLOCKED,
                "legacy-search reference is self-declared; a host/runtime retrieval validator is required",
            )
        try:
            validated = bool(legacy_search_validator(p.legacy_search_ref))
        except Exception:
            validated = False
        if not validated:
            return SubsystemAdmissionAssessment(
                SubsystemAdmissionDecision.BLOCKED,
                "legacy-search retrieval evidence was not validated",
            )
    else:
        if legacy_unavailable_validator is None:
            return SubsystemAdmissionAssessment(
                SubsystemAdmissionDecision.BLOCKED,
                "legacy-search unavailability is self-declared; a host/capability witness is required",
            )
        try:
            unavailable_validated = bool(legacy_unavailable_validator(p.legacy_search_unavailable_evidence_ref))
        except Exception:
            unavailable_validated = False
        if not unavailable_validated:
            return SubsystemAdmissionAssessment(
                SubsystemAdmissionDecision.BLOCKED,
                "legacy-search unavailability evidence was not validated",
            )
    if not p.expected_lifecycle_value_ref or not p.exit_or_compile_away_path:
        return SubsystemAdmissionAssessment(
            SubsystemAdmissionDecision.BLOCKED,
            "new subsystem requires lifecycle-value evidence and an explicit merge/compile-away/retire path",
        )
    suffix = "legacy search host-validated" if p.legacy_search_ref else "legacy retrieval unavailability host-validated; assurance remains reduced"
    return SubsystemAdmissionAssessment(
        SubsystemAdmissionDecision.PROVISIONAL_COMPONENT,
        f"separation is justified provisionally ({suffix}); later SCA must re-evaluate KEEP/MERGE/COMPILE_AWAY/MOVE/DELETE",
    )
