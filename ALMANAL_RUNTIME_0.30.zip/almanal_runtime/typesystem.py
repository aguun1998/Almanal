from __future__ import annotations
from dataclasses import replace
from .model import ObjectId, ObjectType, TypedObject
from .errors import DuplicateObject, ObjectNotFound, TypePromotionNotRegistered

class ObjectStore:
    def __init__(self) -> None:
        self.__objects: dict[ObjectId, TypedObject] = {}

    def insert(self, obj: TypedObject) -> None:
        if obj.id in self.__objects:
            raise DuplicateObject(str(obj.id))
        self.__objects[obj.id] = obj

    def contains(self, object_id: ObjectId) -> bool:
        return object_id in self.__objects

    def discard(self, object_id: ObjectId) -> None:
        self.__objects.pop(object_id, None)

    def get(self, object_id: ObjectId) -> TypedObject:
        try:
            return self.__objects[object_id]
        except KeyError:
            raise ObjectNotFound(str(object_id)) from None

    def values(self) -> tuple[TypedObject, ...]:
        return tuple(self.__objects.values())

    def __len__(self) -> int:
        return len(self.__objects)

class PromotionRegistry:
    def __init__(self) -> None:
        self.__rules: set[tuple[ObjectType, ObjectType]] = set()

    def register(self, source: ObjectType, target: ObjectType) -> None:
        self.__rules.add((source, target))

    def is_registered(self, source: ObjectType, target: ObjectType) -> bool:
        return source is target or (source, target) in self.__rules

    def promote(
        self,
        source: TypedObject,
        *,
        new_id: str,
        target_type: ObjectType,
        transformed_content: str,
    ) -> TypedObject:
        if not self.is_registered(source.object_type, target_type):
            raise TypePromotionNotRegistered(
                f"{source.object_type.name} -> {target_type.name}"
            )
        return TypedObject(
            id=ObjectId(new_id),
            object_type=target_type,
            content=transformed_content,
            scope=source.scope,
            semantic_referent=source.semantic_referent,
            version=source.version + 1,
        )
