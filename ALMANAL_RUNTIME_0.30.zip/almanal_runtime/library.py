from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from .errors import LibraryViolation

class ClaimStatus(Enum):
    DEF = auto()
    RULE = auto()
    TYPE_GUARD = auto()
    INVARIANT = auto()
    THEOREM = auto()
    POLICY = auto()
    EMPIRICAL = auto()
    ASSUMPTION = auto()

@dataclass(frozen=True, slots=True)
class LibraryClaim:
    claim_id: str
    status: ClaimStatus
    statement: str
    proof_ref: str | None = None
    evidence_refs: tuple[str, ...] = ()

    def validate(self) -> None:
        if self.status is ClaimStatus.THEOREM and not self.proof_ref:
            raise LibraryViolation("THEOREM requires proof_ref")
        if self.status is ClaimStatus.EMPIRICAL and not self.evidence_refs:
            raise LibraryViolation("EMPIRICAL requires evidence")

@dataclass(frozen=True, slots=True)
class ResidentRecipeContract:
    recipe_id: str
    required_operators: frozenset[str]
    exec_requested: bool = False

class LibraryRegistry:
    def __init__(self) -> None:
        self.__claims: dict[str, LibraryClaim] = {}
        self.__recipes: dict[str, ResidentRecipeContract] = {}
        self.__realizations: dict[str, str] = {}

    def register_claim(self, claim: LibraryClaim) -> None:
        claim.validate()
        self.__claims[claim.claim_id] = claim

    def register_recipe(self, recipe: ResidentRecipeContract) -> None:
        self.__recipes[recipe.recipe_id] = recipe

    def realize_operator(self, operator: str, implementation_ref: str) -> None:
        self.__realizations[operator] = implementation_ref

    def check_exec_ready(self, recipe_id: str) -> None:
        try:
            recipe = self.__recipes[recipe_id]
        except KeyError:
            raise LibraryViolation(f"unknown recipe: {recipe_id}") from None
        if not recipe.exec_requested:
            raise LibraryViolation(f"recipe not marked EXEC: {recipe_id}")
        missing = sorted(recipe.required_operators - self.__realizations.keys())
        if missing:
            raise LibraryViolation(f"missing operator realizations: {missing}")
