from .model import TaskSemantics, EvaluationCriterion, EpochSnapshot
from .runtime import Runtime
from .worker import DeterministicDemoWorker
from .orchestrator import run_worker_cycle
from .evaluator import QualityVector

def demo_snapshot() -> EpochSnapshot:
    return EpochSnapshot(
        task_semantics=TaskSemantics(
            task_class="OPTIMIZE",
            current_state_schema="demo",
            goal_or_target_delta="produce a better bounded candidate",
            preservation_contract="do not regress protected metric 0",
            allowed_change_set="candidate body",
            realization_space="finite demo space",
            evidence_or_oracle_contract="deterministic evaluator",
            perturbation_model="none",
            cost_model="step budget",
            scope="demo",
        ),
        evaluation_criterion=EvaluationCriterion(
            metrics=("quality", "negative_cost"),
            protected_metric_indexes=(0, 1),
            thresholds=(0, 0),
            tolerances=(0, 0),
            scope="demo",
        ),
        protected_invariants=("frozen_snapshot", "authority_envelope"),
        scope="demo",
        protocol_version="ALMANAL-14.24/PY-RUNTIME-0.24",
    )

def run_demo() -> str:
    rt = Runtime(demo_snapshot(), step_budget=20)
    worker = DeterministicDemoWorker()
    result = run_worker_cycle(
        rt,
        worker,
        evaluator=lambda c: QualityVector((len(c.body), -len(c.id))),
        baseline_quality=QualityVector((0, -100)),
    )
    return (
        f"status={rt.status.name}; stop={rt.stop_reason.name if rt.stop_reason else None}; "
        f"steps_left={rt.remaining_steps}; selected="
        f"{result.selected.id if result.selected else None}; "
        f"quality={result.quality.values if result.quality else None}"
    )
