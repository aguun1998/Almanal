from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
from .model import EpochSnapshot

@dataclass(frozen=True, slots=True)
class CandidateDraft:
    id: str
    body: str

@dataclass(frozen=True, slots=True)
class ChallengeDraft:
    target_id: str
    counterexample_or_failure: str

class Worker(Protocol):
    def generate(self, snapshot: EpochSnapshot) -> list[CandidateDraft]: ...
    def challenge(
        self, snapshot: EpochSnapshot, candidates: list[CandidateDraft]
    ) -> list[ChallengeDraft]: ...
    def repair(
        self,
        snapshot: EpochSnapshot,
        candidate: CandidateDraft,
        challenges: list[ChallengeDraft],
    ) -> CandidateDraft: ...

class DeterministicDemoWorker:
    def generate(self, snapshot: EpochSnapshot) -> list[CandidateDraft]:
        return [
            CandidateDraft(
                "candidate-1",
                f"candidate for {snapshot.task_semantics.goal_or_target_delta} "
                f"within {snapshot.scope}",
            )
        ]

    def challenge(
        self, snapshot: EpochSnapshot, candidates: list[CandidateDraft]
    ) -> list[ChallengeDraft]:
        return [
            ChallengeDraft(
                c.id,
                "demo challenge: verify protected invariants",
            )
            for c in candidates
        ]

    def repair(
        self,
        snapshot: EpochSnapshot,
        candidate: CandidateDraft,
        challenges: list[ChallengeDraft],
    ) -> CandidateDraft:
        return CandidateDraft(
            f"{candidate.id}-repaired",
            f"{candidate.body} | repaired against {len(challenges)} challenge(s)",
        )
