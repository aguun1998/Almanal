from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from time import perf_counter_ns
from typing import Callable

from .worker import Worker, CandidateDraft, ChallengeDraft
from .runtime import Runtime, StopReason
from .stage import Stage
from .evaluator import QualityVector
from .errors import AlmanalError
from .economy import (
    CognitiveActionKind,
    CognitiveOffer,
    CognitiveActionPackage,
    CognitiveDecisionRecord,
    EconomyDecision,
    EconomyGovernor,
    ResourceVector,
)


@dataclass(frozen=True, slots=True)
class ScoredCandidate:
    candidate: CandidateDraft
    quality: QualityVector


@dataclass(frozen=True, slots=True)
class RunCost:
    worker_direct_calls: int
    worker_generate_calls: int
    worker_challenge_calls: int
    worker_repair_calls: int
    evaluator_calls: int
    elapsed_ns: int


class CognitiveRouteKind(Enum):
    """Observed execution shape, not a separate 'brain'."""

    DIRECT = auto()
    DIRECT_VERIFY = auto()
    GENERATE_ONLY = auto()
    GENERATE_VERIFY = auto()
    GENERATE_CHALLENGE = auto()
    GENERATE_CHALLENGE_VERIFY = auto()
    FULL_REPAIR_LOOP = auto()
    FULL_REPAIR_LOOP_UNVERIFIED = auto()


@dataclass(frozen=True, slots=True)
class CognitiveRoutePlan:
    """Frozen minimum-sufficient cognitive execution plan.

    Presence of a capability does not imply execution. Optional actions are admitted
    individually by the Economy Governor before the route is frozen.
    """

    generate: bool
    challenge: bool
    repair: bool
    verify: bool
    economy_records: tuple[CognitiveDecisionRecord, ...] = ()
    remaining_resources: ResourceVector | None = None
    blocked: bool = False
    reason: str = ""

    def __post_init__(self) -> None:
        if self.repair and not self.challenge:
            raise AlmanalError("repair route requires challenge")
        if self.challenge and not self.generate:
            raise AlmanalError("challenge route requires generation")

    @property
    def kind(self) -> CognitiveRouteKind:
        if not self.generate:
            return CognitiveRouteKind.DIRECT_VERIFY if self.verify else CognitiveRouteKind.DIRECT
        if self.repair:
            return (
                CognitiveRouteKind.FULL_REPAIR_LOOP
                if self.verify else CognitiveRouteKind.FULL_REPAIR_LOOP_UNVERIFIED
            )
        if self.challenge:
            return (
                CognitiveRouteKind.GENERATE_CHALLENGE_VERIFY
                if self.verify else CognitiveRouteKind.GENERATE_CHALLENGE
            )
        return CognitiveRouteKind.GENERATE_VERIFY if self.verify else CognitiveRouteKind.GENERATE_ONLY


@dataclass(frozen=True, slots=True)
class OrchestrationResult:
    candidates: tuple[CandidateDraft, ...]
    challenges: tuple[ChallengeDraft, ...]
    repaired: tuple[CandidateDraft, ...]
    baseline_quality: QualityVector
    admissible: tuple[ScoredCandidate, ...]
    pareto_front: tuple[ScoredCandidate, ...]
    selected: CandidateDraft | None
    quality: QualityVector | None
    failure: str | None = None
    cost: RunCost | None = None
    route: CognitiveRouteKind | None = None
    used_baseline_fallback: bool = False


def _is_execute(decision: EconomyDecision) -> bool:
    return decision in {EconomyDecision.EXECUTE, EconomyDecision.MANDATORY_EXECUTE}


def plan_cognitive_route(
    governor: EconomyGovernor,
    offers: tuple[CognitiveOffer, ...],
    packages: tuple[CognitiveActionPackage, ...] = (),
) -> CognitiveRoutePlan:
    """Economically admit only the next useful cognitive operators.

    Dependencies are structural: challenge requires generation; repair requires
    challenge. A mandatory downstream action whose prerequisite was not admitted is
    BLOCKED rather than silently forcing unrelated cognition after the fact.
    """
    supported = {
        CognitiveActionKind.GENERATE,
        CognitiveActionKind.CHALLENGE,
        CognitiveActionKind.REPAIR,
        CognitiveActionKind.VERIFY,
    }
    offer_map: dict[CognitiveActionKind, CognitiveOffer] = {}
    for offer in offers:
        if offer.kind not in supported:
            continue
        if offer.kind in offer_map:
            raise AlmanalError(f"duplicate cognitive route offer: {offer.kind.name}")
        offer_map[offer.kind] = offer

    start_record = len(governor.records())
    blocked = False
    reasons: list[str] = []

    offer_by_id = {offer.action_id: offer for offer in offer_map.values()}
    preadmitted_ids: set[str] = set()
    seen_package_actions: set[str] = set()
    for package in packages:
        if any(action_id not in offer_by_id for action_id in package.action_ids):
            raise AlmanalError("cognitive route package references an absent/unsupported offer")
        if seen_package_actions.intersection(package.action_ids):
            raise AlmanalError("cognitive route packages may not double-charge/overlap actions")
        seen_package_actions.update(package.action_ids)
        package_offers = tuple(offer_by_id[action_id] for action_id in package.action_ids)
        kinds = {offer.kind for offer in package_offers}
        if CognitiveActionKind.CHALLENGE in kinds and CognitiveActionKind.GENERATE not in kinds:
            raise AlmanalError("challenge package must include its generation prerequisite")
        if CognitiveActionKind.REPAIR in kinds and not {CognitiveActionKind.GENERATE, CognitiveActionKind.CHALLENGE} <= kinds:
            raise AlmanalError("repair package must include generate+challenge prerequisites")
        expected_resources = ResourceVector()
        for offer in package_offers:
            expected_resources = expected_resources.add(offer.resources)
        if package.resources != expected_resources:
            raise AlmanalError("package resources must equal the frozen sum of contained offers")
        if any(offer.mandatory for offer in package_offers) and not package.mandatory:
            raise AlmanalError("package containing a mandatory action must itself be mandatory")
        result = governor.consider_package(package)
        reasons.append(f"PACKAGE:{package.package_id}:{result.decision.name}")
        if _is_execute(result.decision):
            preadmitted_ids.update(package.action_ids)
        elif package.mandatory and result.decision is EconomyDecision.BLOCKED_MANDATORY_BUDGET:
            blocked = True

    def consider(kind: CognitiveActionKind, prereq: bool = True) -> bool:
        nonlocal blocked
        offer = offer_map.get(kind)
        if offer is None:
            return False
        if not prereq:
            if offer.mandatory or offer.action_id in preadmitted_ids:
                blocked = True
                reasons.append(f"{kind.name} prerequisite not admitted")
            return False
        if offer.action_id in preadmitted_ids:
            reasons.append(f"{kind.name}:PACKAGE_EXECUTE")
            return True
        result = governor.consider(offer)
        if result.decision is EconomyDecision.BLOCKED_MANDATORY_BUDGET:
            blocked = True
        reasons.append(f"{kind.name}:{result.decision.name}")
        return _is_execute(result.decision)

    generate = consider(CognitiveActionKind.GENERATE)
    challenge = consider(CognitiveActionKind.CHALLENGE, prereq=generate)
    repair = consider(CognitiveActionKind.REPAIR, prereq=challenge)
    # VERIFY can apply to either a direct answer or a generated candidate.
    verify = consider(CognitiveActionKind.VERIFY)

    return CognitiveRoutePlan(
        generate=generate,
        challenge=challenge,
        repair=repair,
        verify=verify,
        economy_records=governor.records()[start_record:],
        remaining_resources=governor.remaining,
        blocked=blocked,
        reason="; ".join(reasons) or "no optional cognition admitted",
    )


def _default_minimal_candidate_route() -> CognitiveRoutePlan:
    # A caller that explicitly enters the candidate worker cycle needs generation
    # and comparison, but challenge/repair are no longer free default rituals.
    return CognitiveRoutePlan(
        generate=True,
        challenge=False,
        repair=False,
        verify=True,
        reason="default minimum candidate path: generate + verify",
    )


def _legacy_route(repair: bool) -> CognitiveRoutePlan:
    return CognitiveRoutePlan(
        generate=True,
        challenge=True,
        repair=repair,
        verify=True,
        reason="legacy compatibility route",
    )


def _pareto_front(
    scored: list[ScoredCandidate], comparison_indexes: tuple[int, ...]
) -> list[ScoredCandidate]:
    front: list[ScoredCandidate] = []
    for i, item in enumerate(scored):
        if not any(
            j != i and other.quality.strictly_dominates(item.quality, comparison_indexes)
            for j, other in enumerate(scored)
        ):
            front.append(item)
    return front


def _transition_prefix(runtime: Runtime) -> None:
    for stage in (Stage.AUTOTUNE, Stage.SCOPE, Stage.MOUNT, Stage.FORMALIZE):
        runtime.transition(stage)


def _finish_from_current(runtime: Runtime, reason: StopReason) -> None:
    if runtime.stage is Stage.VALIDATE:
        runtime.transition(Stage.REGRESSION)
    elif runtime.stage in {Stage.FORMALIZE, Stage.GENERATE, Stage.CHALLENGE, Stage.REPAIR}:
        runtime.transition(Stage.REGRESSION)
    if runtime.stage is Stage.REGRESSION:
        runtime.transition(Stage.OUTPUT)
    runtime.finish(reason)


def _score_candidates(
    *,
    runtime: Runtime,
    candidates: list[CandidateDraft],
    evaluator: Callable[[CandidateDraft], QualityVector],
    baseline_quality: QualityVector,
    require_strict_improvement: bool,
    selection_policy: Callable[[tuple[ScoredCandidate, ...]], ScoredCandidate] | None,
    evaluator_counter: list[int],
    comparison_indexes: tuple[int, ...] | None,
) -> tuple[list[ScoredCandidate], list[ScoredCandidate], ScoredCandidate | None]:
    protected = runtime.snapshot.evaluation_criterion.protected_metric_indexes
    comparison = protected if comparison_indexes is None else comparison_indexes
    scored: list[ScoredCandidate] = []
    for candidate in candidates:
        evaluator_counter[0] += 1
        try:
            quality = evaluator(candidate)
        except Exception as exc:
            raise AlmanalError("EVALUATOR_CALL_FAILED") from exc
        scored.append(ScoredCandidate(candidate, quality))

    admissible = [
        item for item in scored
        if item.quality.protected_non_regression(baseline_quality, protected)
        and item.quality.protected_non_regression(baseline_quality, comparison)
        and (
            not require_strict_improvement
            or item.quality.strictly_dominates(baseline_quality, comparison)
        )
    ]
    front = _pareto_front(admissible, comparison)

    selected_item: ScoredCandidate | None = None
    if len(front) == 1:
        selected_item = front[0]
    elif len(front) > 1 and selection_policy is not None:
        chosen = selection_policy(tuple(front))
        if chosen not in front:
            raise ValueError("selection_policy must return a member of Pareto front")
        selected_item = chosen
    return admissible, front, selected_item


def run_worker_cycle(
    runtime: Runtime,
    worker: Worker,
    evaluator: Callable[[CandidateDraft], QualityVector],
    *,
    baseline_quality: QualityVector,
    route_plan: CognitiveRoutePlan | None = None,
    direct_answer: Callable[[object], CandidateDraft] | None = None,
    repair: bool | None = None,
    require_strict_improvement: bool = True,
    selection_policy: Callable[[tuple[ScoredCandidate, ...]], ScoredCandidate] | None = None,
    baseline_candidate: CandidateDraft | None = None,
    comparison_indexes: tuple[int, ...] | None = None,
) -> OrchestrationResult:
    """Execute only the cognitive stages admitted by a frozen route.

    `repair=` is retained only for 0.9 compatibility. With no explicit route and
    no legacy argument, the 0.11 default is GENERATE+VERIFY; challenge and repair
    must be explicitly admitted rather than always running.
    """
    started = perf_counter_ns()
    direct_calls = 0
    gen_calls = 0
    challenge_calls = 0
    repair_calls = 0
    evaluator_counter = [0]

    if route_plan is not None and repair is not None:
        raise AlmanalError("use route_plan or legacy repair flag, not both")
    plan = route_plan or (_legacy_route(repair) if repair is not None else _default_minimal_candidate_route())

    def cost() -> RunCost:
        return RunCost(
            direct_calls,
            gen_calls,
            challenge_calls,
            repair_calls,
            evaluator_counter[0],
            perf_counter_ns() - started,
        )

    if plan.blocked:
        _transition_prefix(runtime)
        _finish_from_current(runtime, StopReason.BLOCKED)
        return OrchestrationResult(
            (), (), (), baseline_quality, (), (), None, None,
            "cognitive route blocked by mandatory/budget constraint", cost(), plan.kind,
        )

    _transition_prefix(runtime)

    candidates: list[CandidateDraft] = []
    challenges: list[ChallengeDraft] = []
    repaired_candidates: list[CandidateDraft] = []

    # DIRECT path: no candidate-generation/challenge/repair machinery at all.
    if not plan.generate:
        if direct_answer is None:
            _finish_from_current(runtime, StopReason.BLOCKED)
            return OrchestrationResult(
                (), (), (), baseline_quality, (), (), None, None,
                "DIRECT route requires direct_answer callback", cost(), plan.kind,
            )
        try:
            direct_calls += 1
            direct = direct_answer(runtime.snapshot)
            if not isinstance(direct, CandidateDraft):
                raise AlmanalError("direct_answer must return CandidateDraft")
        except Exception:
            runtime.invalidate(StopReason.WORKER_FAILURE)
            return OrchestrationResult(
                (), (), (), baseline_quality, (), (), None, None,
                "direct answer failed", cost(), plan.kind,
            )
        candidates = [direct]
        if not plan.verify:
            if baseline_candidate is not None:
                _finish_from_current(runtime, StopReason.NO_CERTIFIED_IMPROVEMENT)
                return OrchestrationResult(
                    tuple(candidates), (), (), baseline_quality, (), (), baseline_candidate,
                    baseline_quality, None, cost(), plan.kind, True,
                )
            _finish_from_current(runtime, StopReason.COMPLETED)
            return OrchestrationResult(
                tuple(candidates), (), (), baseline_quality, (), (), direct, None,
                None, cost(), plan.kind,
            )
        runtime.transition(Stage.VALIDATE)
        try:
            admissible, front, selected_item = _score_candidates(
                runtime=runtime,
                candidates=candidates,
                evaluator=evaluator,
                baseline_quality=baseline_quality,
                require_strict_improvement=require_strict_improvement,
                selection_policy=selection_policy,
                evaluator_counter=evaluator_counter,
                comparison_indexes=comparison_indexes,
            )
        except Exception as exc:
            runtime.invalidate(StopReason.EVALUATOR_FAILURE)
            failure = "evaluator failed" if str(exc) == "EVALUATOR_CALL_FAILED" else "evaluation/selection failed"
            return OrchestrationResult(
                tuple(candidates), (), (), baseline_quality, (), (), None, None,
                failure, cost(), plan.kind,
            )
        fallback = selected_item is None and baseline_candidate is not None
        reason = StopReason.COMPLETED if selected_item else StopReason.NO_CERTIFIED_IMPROVEMENT
        _finish_from_current(runtime, reason)
        return OrchestrationResult(
            tuple(candidates), (), (), baseline_quality,
            tuple(admissible), tuple(front),
            selected_item.candidate if selected_item else baseline_candidate,
            selected_item.quality if selected_item else (baseline_quality if fallback else None),
            None, cost(), plan.kind, fallback,
        )

    runtime.transition(Stage.GENERATE)
    try:
        gen_calls += 1
        candidates = list(worker.generate(runtime.snapshot))
    except Exception:
        runtime.invalidate(StopReason.WORKER_FAILURE)
        return OrchestrationResult(
            (), (), (), baseline_quality, (), (), None, None,
            "worker.generate failed", cost(), plan.kind,
        )

    if not candidates:
        _finish_from_current(runtime, StopReason.NO_NEW_CANDIDATE)
        fallback = baseline_candidate is not None
        return OrchestrationResult(
            (), (), (), baseline_quality, (), (), baseline_candidate,
            baseline_quality if fallback else None, None, cost(), plan.kind, fallback,
        )

    if plan.challenge:
        runtime.transition(Stage.CHALLENGE)
        try:
            challenge_calls += 1
            challenges = list(worker.challenge(runtime.snapshot, candidates))
        except Exception:
            runtime.invalidate(StopReason.WORKER_FAILURE)
            return OrchestrationResult(
                tuple(candidates), (), (), baseline_quality, (), (), None, None,
                "worker.challenge failed", cost(), plan.kind,
            )

    evaluation_pool = candidates
    if plan.repair:
        runtime.transition(Stage.REPAIR)
        try:
            for candidate in candidates:
                relevant = [c for c in challenges if c.target_id == candidate.id]
                repair_calls += 1
                repaired_candidates.append(
                    worker.repair(runtime.snapshot, candidate, relevant)
                )
        except Exception:
            runtime.invalidate(StopReason.WORKER_FAILURE)
            return OrchestrationResult(
                tuple(candidates), tuple(challenges), tuple(repaired_candidates),
                baseline_quality, (), (), None, None,
                "worker.repair failed", cost(), plan.kind,
            )
        evaluation_pool = repaired_candidates

    if not plan.verify:
        # A supplied frozen baseline is the safe output floor. Without verification,
        # an enhanced candidate cannot displace it merely because more cognition ran.
        if baseline_candidate is not None:
            _finish_from_current(runtime, StopReason.NO_CERTIFIED_IMPROVEMENT)
            return OrchestrationResult(
                tuple(candidates), tuple(challenges), tuple(repaired_candidates),
                baseline_quality, (), (), baseline_candidate, baseline_quality,
                None, cost(), plan.kind, True,
            )
        # Never invent a winner among multiple unverified candidates.
        selected = evaluation_pool[0] if len(evaluation_pool) == 1 else None
        reason = StopReason.COMPLETED if selected is not None else StopReason.UNRESOLVED_TRADEOFF
        _finish_from_current(runtime, reason)
        return OrchestrationResult(
            tuple(candidates), tuple(challenges), tuple(repaired_candidates),
            baseline_quality, (), (), selected, None, None, cost(), plan.kind,
        )

    runtime.transition(Stage.VALIDATE)
    try:
        admissible, front, selected_item = _score_candidates(
            runtime=runtime,
            candidates=evaluation_pool,
            evaluator=evaluator,
            baseline_quality=baseline_quality,
            require_strict_improvement=require_strict_improvement,
            selection_policy=selection_policy,
            evaluator_counter=evaluator_counter,
            comparison_indexes=comparison_indexes,
        )
    except Exception as exc:
        runtime.invalidate(StopReason.EVALUATOR_FAILURE)
        failure = "evaluator failed" if str(exc) == "EVALUATOR_CALL_FAILED" else "evaluation/selection failed"
        return OrchestrationResult(
            tuple(candidates), tuple(challenges), tuple(repaired_candidates),
            baseline_quality, (), (), None, None,
            failure, cost(), plan.kind,
        )

    fallback = selected_item is None and baseline_candidate is not None
    if selected_item is not None:
        reason = StopReason.COMPLETED
    elif front:
        reason = StopReason.UNRESOLVED_TRADEOFF
    else:
        reason = StopReason.NO_CERTIFIED_IMPROVEMENT
    _finish_from_current(runtime, reason)
    runtime.check_trace_invariants()

    return OrchestrationResult(
        tuple(candidates), tuple(challenges), tuple(repaired_candidates), baseline_quality,
        tuple(admissible), tuple(front),
        selected_item.candidate if selected_item else baseline_candidate,
        selected_item.quality if selected_item else (baseline_quality if fallback else None),
        None, cost(), plan.kind, fallback,
    )
