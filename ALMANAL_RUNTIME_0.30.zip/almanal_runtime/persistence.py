from __future__ import annotations
from dataclasses import dataclass
from .certificate import Certificate
from .errors import PersistenceViolation

@dataclass(frozen=True, slots=True)
class VersionedValue:
    value: str
    version: int

@dataclass(frozen=True, slots=True)
class RevisionProposal:
    key: str
    base_version: int
    candidate_ref: object
    candidate_value: str
    criterion_snapshot_ref: str
    trial_scope: str
    rollback_plan: str
    certificate: Certificate

@dataclass(frozen=True, slots=True)
class CommitRecord:
    key: str
    before: VersionedValue
    after: VersionedValue
    rollback_plan: str

class PersistentStore:
    def __init__(self) -> None:
        self.__values: dict[str, VersionedValue] = {}
        self.__history: list[CommitRecord] = []

    def seed(self, key: str, value: str) -> None:
        if key in self.__values:
            raise PersistenceViolation(f"already seeded: {key}")
        self.__values[key] = VersionedValue(value, 1)

    def get(self, key: str) -> VersionedValue | None:
        return self.__values.get(key)

    def history(self) -> tuple[CommitRecord, ...]:
        return tuple(self.__history)

    def commit(self, proposal: RevisionProposal, frozen_criterion_ref: str) -> CommitRecord:
        current = self.__values.get(proposal.key)
        if current is None:
            raise PersistenceViolation(f"missing persistent key: {proposal.key}")
        if current.version != proposal.base_version:
            raise PersistenceViolation(
                f"base version mismatch: expected {current.version}, got {proposal.base_version}"
            )
        if proposal.criterion_snapshot_ref != frozen_criterion_ref:
            raise PersistenceViolation("criterion snapshot mismatch")
        if not proposal.trial_scope.strip():
            raise PersistenceViolation("trial_scope required")
        if not proposal.rollback_plan.strip():
            raise PersistenceViolation("rollback_plan required")
        proposal.certificate.validate()
        if proposal.certificate.subject_ref != proposal.candidate_ref:
            raise PersistenceViolation("certificate subject does not match revision candidate")
        if not proposal.certificate.is_positive_for_persistence():
            raise PersistenceViolation("positive complete certificate required")
        if proposal.certificate.criterion_snapshot_ref != frozen_criterion_ref:
            raise PersistenceViolation("certificate not bound to frozen criterion")

        after = VersionedValue(proposal.candidate_value, current.version + 1)
        record = CommitRecord(proposal.key, current, after, proposal.rollback_plan)
        self.__values[proposal.key] = after
        self.__history.append(record)
        return record

    def rollback_last(self) -> CommitRecord:
        if not self.__history:
            raise PersistenceViolation("no commit to rollback")
        record = self.__history.pop()
        self.__values[record.key] = record.before
        return record
