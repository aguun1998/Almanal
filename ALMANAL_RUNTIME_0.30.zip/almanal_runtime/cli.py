from __future__ import annotations
import argparse
import unittest
from pathlib import Path
from .demo import run_demo

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="almanal")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("demo", help="run deterministic reference demo")
    sub.add_parser("selftest", help="run bundled unit tests")
    args = parser.parse_args(argv)

    if args.command == "demo":
        print(run_demo())
        return 0

    if args.command == "selftest":
        root = Path(__file__).resolve().parent.parent
        suite = unittest.defaultTestLoader.discover(str(root / "tests"))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        return 0 if result.wasSuccessful() else 1

    return 2

if __name__ == "__main__":
    raise SystemExit(main())
