from __future__ import annotations
from dataclasses import dataclass
from threading import RLock
from .errors import InvalidQualityVector

@dataclass(frozen=True, slots=True)
class QualityVector:
    values: tuple[int, ...]

    def _check(self, other: "QualityVector") -> None:
        if len(self.values) != len(other.values):
            raise InvalidQualityVector(
                f"dimension mismatch: {len(self.values)} vs {len(other.values)}"
            )

    def protected_non_regression(
        self, baseline: "QualityVector", protected_indexes: tuple[int, ...]
    ) -> bool:
        self._check(baseline)
        for idx in protected_indexes:
            if idx < 0 or idx >= len(self.values):
                raise InvalidQualityVector(f"protected index {idx} out of bounds")
            if self.values[idx] < baseline.values[idx]:
                return False
        return True

    def strictly_dominates(
        self, baseline: "QualityVector", protected_indexes: tuple[int, ...]
    ) -> bool:
        if not self.protected_non_regression(baseline, protected_indexes):
            return False
        return any(self.values[i] > baseline.values[i] for i in protected_indexes)


@dataclass(frozen=True, slots=True)
class AnalyticCostVector:
    """Optimistic or exact values on frozen minimization axes.

    Static minimization axes: exact/proved structural costs or lower bounds.
    Wall time is numeric only when measured; work counts are not milliseconds.
    """
    values: tuple[int, ...]

    def __post_init__(self) -> None:
        if not self.values or any(v < 0 for v in self.values):
            raise InvalidQualityVector("analytic cost coordinates must be nonempty and nonnegative")

    def _check(self, other: "AnalyticCostVector") -> None:
        if len(self.values) != len(other.values):
            raise InvalidQualityVector(
                f"dimension mismatch: {len(self.values)} vs {len(other.values)}"
            )

    def strictly_dominates(self, other: "AnalyticCostVector") -> bool:
        """Pareto dominance for exact/proved minimization coordinates."""
        self._check(other)
        return all(a <= b for a, b in zip(self.values, other.values)) and any(
            a < b for a, b in zip(self.values, other.values)
        )


@dataclass(frozen=True, slots=True)
class AnalyticParetoDecision:
    materialize: bool
    reason: str


def analytic_pareto_prescreen(
    optimistic: AnalyticCostVector,
    frontier: tuple[AnalyticCostVector, ...],
    *,
    feasible: bool,
    require_strict_frontier_gain: bool = True,
) -> AnalyticParetoDecision:
    """Reject a hypothesis before implementation when static bounds already settle it.

    All coordinates are frozen minimization axes. `optimistic` must be a proved/exact
    lower bound, never an invented runtime measurement.  If an existing exact/proved
    frontier point is no worse than that optimistic bound on every axis, materializing
    the candidate has no decision value (equality also cannot supply strict gain).
    """
    if not feasible:
        return AnalyticParetoDecision(False, "static feasibility/protected-floor failure")
    for point in frontier:
        optimistic._check(point)
        if all(f <= c for c, f in zip(optimistic.values, point.values)):
            strict = any(f < c for c, f in zip(optimistic.values, point.values))
            if strict or require_strict_frontier_gain:
                return AnalyticParetoDecision(
                    False,
                    "current frontier dominates the candidate's optimistic static bound",
                )
    return AnalyticParetoDecision(
        True,
        "static bounds leave a possible Pareto-front advance; materialization may be decision-relevant",
    )



@dataclass(frozen=True, slots=True)
class RepresentationCandidate:
    candidate_id: str
    optimistic_cost: AnalyticCostVector
    closed_obligations: frozenset[str] = frozenset()
    reasoning_work_upper_bound: int|None = None
    lower_bound_match: bool = False
    feasible: bool|None = None
    mechanism_ref: str = ""
    def __post_init__(self):
        if not self.candidate_id or not self.mechanism_ref or self.reasoning_work_upper_bound is None or self.reasoning_work_upper_bound < 0 or self.feasible is None:
            raise InvalidQualityVector("representation candidate requires id, mechanism, explicit feasibility, and nonnegative reasoning-work bound")

@dataclass(frozen=True, slots=True)
class RepresentationRacePolicy:
    max_hypotheses: int = 4
    active_beam_width: int = 2
    max_reopen_batches: int = 1
    finalization_pass_limit: int = 1
    def __post_init__(self):
        if min(self.max_hypotheses,self.active_beam_width,self.finalization_pass_limit)<1 or self.active_beam_width>self.max_hypotheses or self.max_reopen_batches<0:
            raise InvalidQualityVector("invalid representation-race limits")

@dataclass(frozen=True, slots=True)
class RepresentationRacePlan:
    active_ids: tuple[str,...]
    reserve_ids: tuple[str,...]
    rejected_ids: tuple[str,...]
    locked_id: str|None
    reason: str

def plan_representation_race(candidates: tuple[RepresentationCandidate,...], *, mandatory_obligations:frozenset[str]=frozenset(), frontier:tuple[AnalyticCostVector,...]=(), lock_validator=None, policy:RepresentationRacePolicy=RepresentationRacePolicy())->RepresentationRacePlan:
    """Cheap static representation screen; scheduling priority is not evidence."""
    if not mandatory_obligations:
        raise InvalidQualityVector("representation race requires frozen mandatory obligations")
    if len(candidates)>policy.max_hypotheses or len({c.candidate_id for c in candidates})!=len(candidates):
        raise InvalidQualityVector("representation hypothesis budget/id violation")
    ok=[c for c in candidates if analytic_pareto_prescreen(c.optimistic_cost,frontier,feasible=bool(c.feasible)).materialize]
    witnessed_lock:dict[str,bool]={}
    for c in ok:
        witnessed_lock[c.candidate_id]=False
        if mandatory_obligations<=c.closed_obligations and c.lower_bound_match and lock_validator is not None:
            try: witnessed_lock[c.candidate_id]=bool(lock_validator(c,mandatory_obligations))
            except Exception: pass
    def dom(a,b):
        # Optimistic candidate bounds are scheduling hints, not pairwise elimination
        # evidence.  Only a witnessed lock survivor may reject another hypothesis.
        if not witnessed_lock[a.candidate_id]: return False
        a.optimistic_cost._check(b.optimistic_cost)
        av,bv=a.optimistic_cost.values,b.optimistic_cost.values
        return all(x<=y for x,y in zip(av,bv)) and a.reasoning_work_upper_bound<=b.reasoning_work_upper_bound and (not witnessed_lock[b.candidate_id] or av!=bv or a.reasoning_work_upper_bound<b.reasoning_work_upper_bound)
    keep=[b for b in ok if not any(a is not b and dom(a,b) for a in ok)]
    rejected={c.candidate_id for c in candidates if c not in keep}
    keep.sort(key=lambda c:(not witnessed_lock[c.candidate_id],not mandatory_obligations<=c.closed_obligations,not c.lower_bound_match,-len(c.closed_obligations&mandatory_obligations),c.reasoning_work_upper_bound,c.candidate_id))
    active=tuple(c.candidate_id for c in keep[:policy.active_beam_width]); reserve=tuple(c.candidate_id for c in keep[policy.active_beam_width:])
    witnessed_survivors=[c for c in keep if witnessed_lock[c.candidate_id]]
    locked=witnessed_survivors[0].candidate_id if len(witnessed_survivors)==1 else None
    metadata_lock_candidate=next((c for c in keep if mandatory_obligations<=c.closed_obligations and c.lower_bound_match),None)
    reason=("representation lock: unique witnessed non-dominated survivor; residual-compress then finalize once" if locked else "multiple witnessed non-dominated lock candidates; preserve Pareto frontier" if len(witnessed_survivors)>1 else "lock candidate exists but closure/bound evidence is not validated" if metadata_lock_candidate else "bounded beam; reserve only on failure/counterexample/frontier witness" if reserve else "bounded representation frontier")
    return RepresentationRacePlan(active,reserve,tuple(sorted(rejected)),locked,reason)

def _validated_evidence(ref:str,validator)->bool:
    if validator is None or not ref: return False
    try: return bool(validator(ref))
    except Exception: return False

class WitnessLeaseLedger:
    """Run-scoped one-shot witness + bounded-transition ledger."""
    def __init__(self) -> None:
        self._consumed:set[str]=set(); self._counts:dict[str,int]={}; self._lock=RLock()
    def _claim(self,*,ref:str="",key:str="",limit:int=0)->bool:
        if key and limit<1: return False
        with self._lock:
            if ref and ref in self._consumed: return False
            if key and self._counts.get(key,0)>=limit: return False
            if ref: self._consumed.add(ref)
            if key: self._counts[key]=self._counts.get(key,0)+1
            return True
    def consume(self,ref:str,validator)->bool:
        return _validated_evidence(ref,validator) and self._claim(ref=ref)
    def claim_budget(self,key:str,limit:int)->bool:
        return bool(key) and self._claim(key=key,limit=limit)
    def consume_with_budget(self,ref:str,validator,key:str,limit:int)->bool:
        return bool(key) and _validated_evidence(ref,validator) and self._claim(ref=ref,key=key,limit=limit)
    def consumed(self,ref:str)->bool:
        with self._lock: return ref in self._consumed
    def count(self,key:str)->int:
        with self._lock: return self._counts.get(key,0)

def _consume_validated_witness(ref:str,ledger:WitnessLeaseLedger|None,validator)->bool:
    return isinstance(ledger,WitnessLeaseLedger) and ledger.consume(ref,validator)

def representation_reserve_reopen_allowed(*,reopen_batches_used:int,active_failed:bool=False,counterexample:bool=False,proved_frontier_opportunity:bool=False,trigger_witness_ref:str="",witness_ledger:WitnessLeaseLedger|None=None,witness_validator=None,policy:RepresentationRacePolicy=RepresentationRacePolicy())->bool:
    if reopen_batches_used<0: raise InvalidQualityVector("negative reopen count")
    trigger=active_failed or counterexample or proved_frontier_opportunity
    if reopen_batches_used>=policy.max_reopen_batches or not trigger or not isinstance(witness_ledger,WitnessLeaseLedger): return False
    return witness_ledger.consume_with_budget(trigger_witness_ref,witness_validator,"reserve_reopen",policy.max_reopen_batches)

_RESIDUAL_AUDITS=frozenset({"minimal_state","transition_native","class_aggregation","narrow_sparse_storage","arithmetic_bounds","selective_specialization","io_bottleneck"})

def residual_execution_closure_complete(*, resource_material: bool=True, audit_evidence_refs: tuple[tuple[str,str],...]=(), audit_validator=None, nonmaterial_evidence_ref:str="", materiality_validator=None) -> bool:
    """Fail closed on post-lock residual closure, including the audit-skip decision."""
    if not resource_material:
        return _validated_evidence(nonmaterial_evidence_ref,materiality_validator)
    if audit_validator is None or len(audit_evidence_refs)!=len({k for k,_ in audit_evidence_refs}): return False
    refs=dict(audit_evidence_refs)
    if set(refs)!=set(_RESIDUAL_AUDITS) or any(not r for r in refs.values()): return False
    try: return all(bool(audit_validator(k,refs[k])) for k in _RESIDUAL_AUDITS)
    except Exception: return False

def delayed_reduction_safe(*, min_intermediate:int, max_intermediate:int, type_min:int, type_max:int) -> bool:
    """Check the full proved intermediate interval against the target type interval."""
    if min_intermediate>max_intermediate or type_min>type_max:
        raise InvalidQualityVector("invalid arithmetic interval")
    return type_min <= min_intermediate and max_intermediate <= type_max

def finalization_pass_allowed(*,passes_used:int,resource_material:bool=True,residual_audit_evidence_refs:tuple[tuple[str,str],...]=(),residual_audit_validator=None,nonmaterial_evidence_ref:str="",materiality_validator=None,defect_or_frontier_witness_ref:str="",witness_ledger:WitnessLeaseLedger|None=None,witness_validator=None,policy:RepresentationRacePolicy=RepresentationRacePolicy())->bool:
    """Claim one finalization lease after witnessed residual closure; ledger owns the ordinary-pass budget."""
    if passes_used<0: raise InvalidQualityVector("negative finalization count")
    if not residual_execution_closure_complete(resource_material=resource_material,audit_evidence_refs=residual_audit_evidence_refs,audit_validator=residual_audit_validator,nonmaterial_evidence_ref=nonmaterial_evidence_ref,materiality_validator=materiality_validator): return False
    if not isinstance(witness_ledger,WitnessLeaseLedger): return False
    if passes_used<policy.finalization_pass_limit and witness_ledger.claim_budget("ordinary_finalization",policy.finalization_pass_limit): return True
    return witness_ledger.consume(defect_or_frontier_witness_ref,witness_validator)

def cheap_falsifier_is_decision_relevant(
    *,
    counterexample_would_reject: bool,
    falsifier_work_upper_bound: int,
    next_deep_reasoning_work_upper_bound: int,
    representation_locked: bool,
    defect_or_frontier_witness_ref: str = "",
    witness_ledger: WitnessLeaseLedger|None = None,
    witness_validator = None,
) -> bool:
    """Admit a bounded counterexample search; post-lock use needs fresh validated evidence."""
    if min(falsifier_work_upper_bound, next_deep_reasoning_work_upper_bound) < 0:
        raise InvalidQualityVector("negative falsifier/reasoning work bound")
    if not counterexample_would_reject or falsifier_work_upper_bound >= next_deep_reasoning_work_upper_bound:
        return False
    return not representation_locked or _consume_validated_witness(defect_or_frontier_witness_ref,witness_ledger,witness_validator)

def benchmark_is_decision_relevant(
    *,
    unresolved_empirical_axis: bool,
    can_change_selection: bool,
    mechanism_identified: bool = False,
    static_screen_complete: bool = False,
) -> bool:
    """Benchmark is an uncertainty resolver, never a substitute for a mechanism."""
    return (
        unresolved_empirical_axis
        and can_change_selection
        and mechanism_identified
        and static_screen_complete
    )
