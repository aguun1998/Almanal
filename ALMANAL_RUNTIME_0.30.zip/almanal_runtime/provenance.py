from __future__ import annotations
from dataclasses import dataclass
from .model import ObjectId
from .errors import ProvenanceViolation

@dataclass(frozen=True, order=True, slots=True)
class SourceRoot:
    value: str

class ProvenanceGraph:
    def __init__(self) -> None:
        self.__roots: dict[ObjectId, frozenset[SourceRoot]] = {}
        self.__parents: dict[ObjectId, frozenset[ObjectId]] = {}

    def contains(self, object_id: ObjectId) -> bool:
        return object_id in self.__roots

    def discard(self, object_id: ObjectId) -> None:
        self.__roots.pop(object_id, None)
        self.__parents.pop(object_id, None)

    def register_source_object(
        self, object_id: ObjectId, roots: frozenset[SourceRoot]
    ) -> None:
        if object_id in self.__roots:
            raise ProvenanceViolation(f"already registered: {object_id}")
        self.__roots[object_id] = roots
        self.__parents[object_id] = frozenset()

    def preview_derived_roots(
        self,
        inputs: tuple[ObjectId, ...],
        new_roots: frozenset[SourceRoot],
    ) -> frozenset[SourceRoot]:
        expected: set[SourceRoot] = set()
        for object_id in inputs:
            if object_id not in self.__roots:
                raise ProvenanceViolation(f"missing provenance for {object_id}")
            expected.update(self.__roots[object_id])
        expected.update(new_roots)
        return frozenset(expected)

    def derive(
        self,
        output: ObjectId,
        inputs: tuple[ObjectId, ...],
        new_roots: frozenset[SourceRoot],
    ) -> frozenset[SourceRoot]:
        if output in self.__roots:
            raise ProvenanceViolation(f"already registered: {output}")
        roots = self.preview_derived_roots(inputs, new_roots)
        self.__roots[output] = roots
        self.__parents[output] = frozenset(inputs)
        return roots

    def roots_of(self, object_id: ObjectId) -> frozenset[SourceRoot]:
        if object_id not in self.__roots:
            raise ProvenanceViolation(f"missing provenance for {object_id}")
        return self.__roots[object_id]

    def parents_of(self, object_id: ObjectId) -> frozenset[ObjectId]:
        return self.__parents.get(object_id, frozenset())
