from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction
from hashlib import sha256
from typing import Callable

from .behavioral_benchmark import exact_two_sided_sign_test_pvalue
from .errors import AlmanalError


class MetricDirection(Enum):
    HIGHER_IS_BETTER = auto()
    LOWER_IS_BETTER = auto()


class MetricRole(Enum):
    VALUE = auto()
    ERROR = auto()
    CALIBRATION = auto()
    COST = auto()


@dataclass(frozen=True, slots=True)
class MetricSpec:
    name: str
    direction: MetricDirection
    role: MetricRole = MetricRole.VALUE
    material_delta: Fraction = Fraction(0)
    protected: bool = False
    # Compact frozen measurement-integrity contract. These fields describe what
    # the number means; they are not a claim that the host actually enforced it.
    measurement_boundary: str = "DECLARED_METRIC_SCOPE"
    start_event: str = ""
    end_event: str = ""
    aggregation: str = "PER_PAIR"
    measurement_method: str = "DECLARED_EVALUATOR"
    included_components: tuple[str, ...] = ()
    excluded_components: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.name:
            raise AlmanalError("metric name must be nonempty")
        if self.material_delta < 0:
            raise AlmanalError("material_delta must be nonnegative")
        if not self.measurement_boundary or not self.aggregation or not self.measurement_method:
            raise AlmanalError("metric measurement contract must declare boundary/aggregation/method")
        if set(self.included_components) & set(self.excluded_components):
            raise AlmanalError("measurement component cannot be both included and excluded")


@dataclass(frozen=True, slots=True)
class MeasurementPlan:
    """Frozen outer-loop measurement contract.

    The plan is intentionally small: task scope, metrics, minimum paired sample,
    and exact sign-test threshold. Candidate outcomes must not rewrite it.
    """
    plan_id: str
    task_scope: str
    metrics: tuple[MetricSpec, ...]
    minimum_pairs: int = 10
    alpha: Fraction = Fraction(1, 20)
    require_same_pairs_on_remeasure: bool = True

    def __post_init__(self) -> None:
        if not self.plan_id or not self.task_scope:
            raise AlmanalError("measurement plan id/scope must be nonempty")
        if self.minimum_pairs < 1:
            raise AlmanalError("minimum_pairs must be >= 1")
        if not Fraction(0) < self.alpha <= 1:
            raise AlmanalError("alpha must be in (0,1]")
        names = [m.name for m in self.metrics]
        if not names or len(set(names)) != len(names):
            raise AlmanalError("measurement metric names must be nonempty and unique")

    def fingerprint(self) -> str:
        payload = "|".join([
            self.plan_id,
            self.task_scope,
            str(self.minimum_pairs),
            str(self.alpha),
            str(int(self.require_same_pairs_on_remeasure)),
            *[
                ":".join([
                    m.name,
                    m.direction.name,
                    m.role.name,
                    str(m.material_delta),
                    str(int(m.protected)),
                    m.measurement_boundary,
                    m.start_event,
                    m.end_event,
                    m.aggregation,
                    m.measurement_method,
                    ",".join(m.included_components),
                    ",".join(m.excluded_components),
                ])
                for m in self.metrics
            ],
        ])
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class PairObservation:
    """One same-task paired observation.

    `reference` and `candidate` values must cover exactly the frozen plan metrics.
    """
    pair_id: str
    reference: tuple[tuple[str, Fraction], ...]
    candidate: tuple[tuple[str, Fraction], ...]

    def __post_init__(self) -> None:
        if not self.pair_id:
            raise AlmanalError("pair_id must be nonempty")
        if len(dict(self.reference)) != len(self.reference):
            raise AlmanalError("duplicate reference metric")
        if len(dict(self.candidate)) != len(self.candidate):
            raise AlmanalError("duplicate candidate metric")

    def reference_map(self) -> dict[str, Fraction]:
        return dict(self.reference)

    def candidate_map(self) -> dict[str, Fraction]:
        return dict(self.candidate)


@dataclass(frozen=True, slots=True)
class MetricEvidence:
    name: str
    role: MetricRole
    protected: bool
    pairs: int
    wins: int
    losses: int
    ties: int
    oriented_mean_delta: Fraction
    p_value: Fraction
    material_improvement: bool
    material_regression: bool
    oriented_deltas: tuple[Fraction, ...]


@dataclass(frozen=True, slots=True)
class MeasurementResult:
    plan_fingerprint: str
    pairs: int
    pair_ids: tuple[str, ...]
    evidence: tuple[MetricEvidence, ...]

    def by_name(self) -> dict[str, MetricEvidence]:
        return {e.name: e for e in self.evidence}


def _oriented_delta(spec: MetricSpec, reference: Fraction, candidate: Fraction) -> Fraction:
    raw = candidate - reference
    if spec.direction is MetricDirection.HIGHER_IS_BETTER:
        return raw
    return -raw


def evaluate_measurement(
    plan: MeasurementPlan,
    observations: tuple[PairObservation, ...],
) -> MeasurementResult:
    expected_names = {m.name for m in plan.metrics}
    pair_ids = tuple(obs.pair_id for obs in observations)
    if len(set(pair_ids)) != len(pair_ids):
        raise AlmanalError("paired observation ids must be unique")
    for obs in observations:
        if set(obs.reference_map()) != expected_names:
            raise AlmanalError("reference observation does not match frozen metric set")
        if set(obs.candidate_map()) != expected_names:
            raise AlmanalError("candidate observation does not match frozen metric set")

    evidence: list[MetricEvidence] = []
    for spec in plan.metrics:
        deltas = tuple(
            _oriented_delta(
                spec,
                obs.reference_map()[spec.name],
                obs.candidate_map()[spec.name],
            )
            for obs in observations
        )
        wins = sum(1 for d in deltas if d > 0)
        losses = sum(1 for d in deltas if d < 0)
        ties = len(deltas) - wins - losses
        p = exact_two_sided_sign_test_pvalue(wins=wins, losses=losses)
        mean = (
            sum(deltas, Fraction(0)) / len(deltas)
            if deltas
            else Fraction(0)
        )
        enough = len(observations) >= plan.minimum_pairs
        significant = enough and p <= plan.alpha
        improvement = significant and mean >= spec.material_delta and wins > losses
        regression = significant and mean <= -spec.material_delta and losses > wins
        evidence.append(
            MetricEvidence(
                name=spec.name,
                role=spec.role,
                protected=spec.protected,
                pairs=len(observations),
                wins=wins,
                losses=losses,
                ties=ties,
                oriented_mean_delta=mean,
                p_value=p,
                material_improvement=improvement,
                material_regression=regression,
                oriented_deltas=deltas,
            )
        )

    return MeasurementResult(
        plan_fingerprint=plan.fingerprint(),
        pairs=len(observations),
        pair_ids=pair_ids,
        evidence=tuple(evidence),
    )


class DiagnosisKind(Enum):
    INSUFFICIENT_EVIDENCE = auto()
    PROTECTED_REGRESSION = auto()
    MIXED_TRADEOFF = auto()
    TARGETED_DEFECT = auto()
    MATERIAL_IMPROVEMENT = auto()
    NO_MATERIAL_CHANGE = auto()


@dataclass(frozen=True, slots=True)
class DirectionDiagnosis:
    kind: DiagnosisKind
    symptom_metrics: tuple[str, ...]
    regressions: tuple[str, ...]
    improvements: tuple[str, ...]
    cost_regressions: tuple[str, ...]
    reason: str


def diagnose_direction(
    plan: MeasurementPlan,
    result: MeasurementResult,
) -> DirectionDiagnosis:
    if result.plan_fingerprint != plan.fingerprint():
        raise AlmanalError("measurement result does not match frozen plan")

    if result.pairs < plan.minimum_pairs:
        return DirectionDiagnosis(
            DiagnosisKind.INSUFFICIENT_EVIDENCE,
            (), (), (), (),
            "paired sample below frozen minimum; do not infer an improvement direction",
        )

    improvements = tuple(
        e.name for e in result.evidence if e.material_improvement
    )
    regressions = tuple(
        e.name for e in result.evidence if e.material_regression
    )
    protected_regressions = tuple(
        e.name for e in result.evidence
        if e.material_regression and e.protected
    )
    cost_regressions = tuple(
        e.name for e in result.evidence
        if e.material_regression and e.role is MetricRole.COST
    )

    if protected_regressions:
        return DirectionDiagnosis(
            DiagnosisKind.PROTECTED_REGRESSION,
            protected_regressions,
            regressions,
            improvements,
            cost_regressions,
            "protected metric regressed; successor must be repaired or reverted",
        )

    if improvements and regressions:
        return DirectionDiagnosis(
            DiagnosisKind.MIXED_TRADEOFF,
            regressions,
            regressions,
            improvements,
            cost_regressions,
            "measured gains and losses coexist; target regressions rather than expanding globally",
        )

    if regressions:
        return DirectionDiagnosis(
            DiagnosisKind.TARGETED_DEFECT,
            regressions,
            regressions,
            improvements,
            cost_regressions,
            "measured regression identifies the next localized improvement target",
        )

    if improvements:
        return DirectionDiagnosis(
            DiagnosisKind.MATERIAL_IMPROVEMENT,
            (),
            (),
            improvements,
            (),
            "material improvement measured with no material regression under the frozen plan",
        )

    return DirectionDiagnosis(
        DiagnosisKind.NO_MATERIAL_CHANGE,
        (),
        (),
        (),
        (),
        "no metric crossed the frozen material/significance gate",
    )



class CausalEvidenceKind(Enum):
    CORRELATION = auto()
    DEPENDENCY_TRACE = auto()
    EXECUTION_TRACE = auto()
    ABLATION = auto()
    INTERVENTION = auto()
    COUNTERFACTUAL_REPLAY = auto()


class CausalSupport(Enum):
    UNTESTED = auto()
    ASSOCIATED_ONLY = auto()
    SUPPORTED = auto()
    CONTRADICTED = auto()
    INCONCLUSIVE = auto()


@dataclass(frozen=True, slots=True)
class CausalHypothesis:
    hypothesis_id: str
    mechanism: str
    repair_component: str
    affected_metrics: tuple[str, ...]
    dependency_depth: int = 0

    def __post_init__(self) -> None:
        if not self.hypothesis_id or not self.mechanism or not self.repair_component:
            raise AlmanalError("causal hypothesis fields must be nonempty")
        if not self.affected_metrics:
            raise AlmanalError("causal hypothesis must name affected metrics")
        if self.dependency_depth < 0:
            raise AlmanalError("dependency_depth must be nonnegative")


@dataclass(frozen=True, slots=True)
class CausalTestSpec:
    """Frozen causal test prediction, declared before observing its outcome."""
    test_id: str
    hypothesis_id: str
    kind: CausalEvidenceKind
    intervention: str
    expected_metric_directions: tuple[tuple[str, int], ...]
    expect_mechanism_observed: bool = True

    def __post_init__(self) -> None:
        if not self.test_id or not self.hypothesis_id or not self.intervention:
            raise AlmanalError("causal test fields must be nonempty")
        if len(dict(self.expected_metric_directions)) != len(self.expected_metric_directions):
            raise AlmanalError("duplicate metric in causal test prediction")
        if any(direction not in {-1, 0, 1} for _, direction in self.expected_metric_directions):
            raise AlmanalError("causal expected metric direction must be -1, 0, or 1")

    def fingerprint(self) -> str:
        payload = "|".join([
            self.test_id, self.hypothesis_id, self.kind.name, self.intervention,
            str(int(self.expect_mechanism_observed)),
            *[f"{m}:{d}" for m, d in self.expected_metric_directions],
        ])
        return sha256(payload.encode("utf-8")).hexdigest()


class CausalWitnessBasis(Enum):
    SELF_DECLARED = auto()
    RUNTIME_EXECUTED = auto()
    EXTERNAL_ATTESTED = auto()


@dataclass(frozen=True, slots=True)
class CausalExecutionReceipt:
    receipt_id: str
    test_fingerprint: str
    kind: CausalEvidenceKind
    executor_ref: str
    measurement_ref: str
    environment_ref: str
    basis: CausalWitnessBasis

    def __post_init__(self) -> None:
        if not all((self.receipt_id, self.test_fingerprint, self.executor_ref, self.measurement_ref, self.environment_ref)):
            raise AlmanalError("causal execution receipt requires witnessed execution/measurement/environment refs")

    @property
    def strongly_witnessed(self) -> bool:
        return self.basis in {CausalWitnessBasis.RUNTIME_EXECUTED, CausalWitnessBasis.EXTERNAL_ATTESTED}


@dataclass(frozen=True, slots=True)
class CausalEvidence:
    evidence_id: str
    hypothesis_id: str
    test_fingerprint: str
    kind: CausalEvidenceKind
    controlled: bool
    metric_effects: tuple[tuple[str, Fraction], ...]
    mechanism_observed: bool = False
    provenance_ref: str = ""
    execution_receipt: CausalExecutionReceipt | None = None

    def __post_init__(self) -> None:
        if not self.evidence_id or not self.hypothesis_id or not self.test_fingerprint:
            raise AlmanalError("causal evidence/test/hypothesis ids must be nonempty")
        if len(dict(self.metric_effects)) != len(self.metric_effects):
            raise AlmanalError("duplicate metric in causal evidence")

    def intervention_strength(self, receipt_validator: "CausalReceiptValidator | None" = None) -> bool:
        receipt = self.execution_receipt
        structurally_eligible = (
            self.controlled
            and bool(self.provenance_ref)
            and receipt is not None
            and receipt.strongly_witnessed
            and receipt.test_fingerprint == self.test_fingerprint
            and receipt.kind is self.kind
            and self.kind in {
                CausalEvidenceKind.ABLATION,
                CausalEvidenceKind.INTERVENTION,
                CausalEvidenceKind.COUNTERFACTUAL_REPLAY,
            }
        )
        if not structurally_eligible or receipt_validator is None:
            return False
        try:
            return bool(receipt_validator(receipt))
        except Exception:
            return False


CausalReceiptValidator = Callable[[CausalExecutionReceipt], bool]


@dataclass(frozen=True, slots=True)
class CausalDiagnosis:
    hypothesis_id: str
    support: CausalSupport
    repair_component: str | None
    evidence_ids: tuple[str, ...]
    reason: str


@dataclass(frozen=True, slots=True)
class CausalTargetSelection:
    selected_component: str | None
    selected_hypothesis_ids: tuple[str, ...]
    causal_uncertain: bool
    reason: str


def diagnose_cause(
    hypothesis: CausalHypothesis,
    tests: tuple[CausalTestSpec, ...],
    evidence: tuple[CausalEvidence, ...],
    *,
    regressed_metrics: tuple[str, ...],
    receipt_validator: CausalReceiptValidator | None = None,
) -> CausalDiagnosis:
    """Compare observed causal evidence with predictions frozen before outcomes."""
    relevant_tests = tuple(t for t in tests if t.hypothesis_id == hypothesis.hypothesis_id)
    relevant_evidence = tuple(e for e in evidence if e.hypothesis_id == hypothesis.hypothesis_id)
    if not relevant_tests:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.UNTESTED, None, (),
            "no frozen causal test spec exists for this hypothesis",
        )

    target_metrics = set(regressed_metrics) & set(hypothesis.affected_metrics)
    if not target_metrics:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.INCONCLUSIVE, None,
            tuple(e.evidence_id for e in relevant_evidence),
            "hypothesis does not cover the measured regressions",
        )

    test_by_fp = {t.fingerprint(): t for t in relevant_tests}
    matched: list[tuple[CausalTestSpec, CausalEvidence]] = []
    for ev in relevant_evidence:
        test = test_by_fp.get(ev.test_fingerprint)
        if test is None or ev.kind is not test.kind:
            continue
        matched.append((test, ev))

    if not matched:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.UNTESTED, None,
            tuple(e.evidence_id for e in relevant_evidence),
            "no evidence matches a frozen causal test fingerprint",
        )

    strong = tuple((t, e) for t, e in matched if e.intervention_strength(receipt_validator))
    if not strong:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.ASSOCIATED_ONLY, None,
            tuple(e.evidence_id for _, e in matched),
            "only trace/correlation or control evidence without a host-validated execution receipt exists",
        )

    supportive = 0
    contradictory = 0
    for test, ev in strong:
        expected = dict(test.expected_metric_directions)
        observed = dict(ev.metric_effects)
        if not target_metrics <= set(expected) or not target_metrics <= set(observed):
            continue
        mechanism_ok = (ev.mechanism_observed == test.expect_mechanism_observed)
        predictions_ok = True
        any_contradiction = False
        for metric in target_metrics:
            direction = expected[metric]
            effect = observed[metric]
            if direction > 0:
                predictions_ok &= effect > 0
                any_contradiction |= effect < 0
            elif direction < 0:
                predictions_ok &= effect < 0
                any_contradiction |= effect > 0
            else:
                predictions_ok &= effect == 0
                any_contradiction |= effect != 0
        if mechanism_ok and predictions_ok:
            supportive += 1
        if any_contradiction:
            contradictory += 1

    if contradictory:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.CONTRADICTED, None,
            tuple(e.evidence_id for _, e in matched),
            "controlled evidence contradicts a predeclared causal prediction",
        )
    if supportive:
        return CausalDiagnosis(
            hypothesis.hypothesis_id, CausalSupport.SUPPORTED,
            hypothesis.repair_component,
            tuple(e.evidence_id for _, e in matched),
            "controlled evidence matched a frozen mechanism/metric prediction",
        )
    return CausalDiagnosis(
        hypothesis.hypothesis_id, CausalSupport.INCONCLUSIVE, None,
        tuple(e.evidence_id for _, e in matched),
        "controlled evidence did not establish the frozen causal prediction",
    )


def select_causal_repair_target(
    hypotheses: tuple[CausalHypothesis, ...],
    diagnoses: tuple[CausalDiagnosis, ...],
) -> CausalTargetSelection:
    """Select a repair component only when supported diagnoses converge on one component."""
    hmap = {h.hypothesis_id: h for h in hypotheses}
    supported = [d for d in diagnoses if d.support is CausalSupport.SUPPORTED and d.repair_component]
    if not supported:
        return CausalTargetSelection(None, (), True, "no causally supported repair target")
    components = {d.repair_component for d in supported}
    if len(components) != 1:
        return CausalTargetSelection(
            None,
            tuple(d.hypothesis_id for d in supported),
            True,
            "multiple distinct causal mechanisms remain supported; do not broad-patch",
        )
    component = next(iter(components))
    ids = tuple(sorted((d.hypothesis_id for d in supported), key=lambda x: hmap[x].dependency_depth))
    return CausalTargetSelection(
        component, ids, False,
        "supported causal hypotheses converge on one repair component",
    )


@dataclass(frozen=True, slots=True)
class CausalConfirmation:
    hypothesis_id: str
    mechanism_changed_as_predicted: bool
    evidence_ref: str


class ReMeasureDecision(Enum):
    KEEP = auto()
    REVERT = auto()
    CONTINUE_TARGETED_IMPROVEMENT = auto()
    STOP_NO_MATERIAL_GAIN = auto()
    STOP_UNCERTAIN = auto()
    CAUSAL_UNCERTAIN = auto()


@dataclass(frozen=True, slots=True)
class ReMeasureReport:
    decision: ReMeasureDecision
    improved_targets: tuple[str, ...]
    worsened_targets: tuple[str, ...]
    reason: str


def compare_remeasurement(
    plan: MeasurementPlan,
    before: MeasurementResult,
    after: MeasurementResult,
    *,
    targeted_metrics: tuple[str, ...],
) -> ReMeasureReport:
    """Compare before/after advantage using the same frozen benchmark contract.

    By default the exact same pair IDs are required. For each targeted metric we
    compute, per pair:

        gain_i = after_oriented_delta_i - before_oriented_delta_i

    and apply the frozen exact sign-test/material threshold again. This blocks
    sample-composition drift from masquerading as improvement.
    """
    fp = plan.fingerprint()
    if before.plan_fingerprint != fp or after.plan_fingerprint != fp:
        raise AlmanalError("re-measurement changed the frozen measurement plan")
    if before.pairs < plan.minimum_pairs or after.pairs < plan.minimum_pairs:
        return ReMeasureReport(
            ReMeasureDecision.STOP_UNCERTAIN,
            (), (),
            "before/after evidence does not meet frozen minimum sample",
        )

    if plan.require_same_pairs_on_remeasure:
        if set(before.pair_ids) != set(after.pair_ids):
            raise AlmanalError("re-measurement must reuse the frozen pair IDs")

    before_map = before.by_name()
    after_map = after.by_name()
    unknown = set(targeted_metrics) - set(before_map)
    if unknown:
        raise AlmanalError(f"unknown targeted metrics: {sorted(unknown)}")

    # Map deltas by pair id so input ordering cannot change the result.
    before_index = {pid: i for i, pid in enumerate(before.pair_ids)}
    after_index = {pid: i for i, pid in enumerate(after.pair_ids)}
    common_ids = tuple(sorted(set(before.pair_ids) & set(after.pair_ids)))
    if len(common_ids) < plan.minimum_pairs:
        return ReMeasureReport(
            ReMeasureDecision.STOP_UNCERTAIN,
            (), (),
            "insufficient common paired tasks for re-measurement",
        )

    improved: list[str] = []
    worsened: list[str] = []

    for name in targeted_metrics:
        spec = next(m for m in plan.metrics if m.name == name)
        gains = tuple(
            after_map[name].oriented_deltas[after_index[pid]]
            - before_map[name].oriented_deltas[before_index[pid]]
            for pid in common_ids
        )
        wins = sum(1 for g in gains if g > 0)
        losses = sum(1 for g in gains if g < 0)
        p_value = exact_two_sided_sign_test_pvalue(wins=wins, losses=losses)
        mean_gain = sum(gains, Fraction(0)) / len(gains)
        significant = p_value <= plan.alpha

        if (
            significant
            and mean_gain >= spec.material_delta
            and wins > losses
        ):
            improved.append(name)
        elif (
            significant
            and mean_gain <= -spec.material_delta
            and losses > wins
        ):
            worsened.append(name)

    protected_after_regressions = [
        e.name for e in after.evidence
        if e.protected and e.material_regression
    ]
    if protected_after_regressions:
        return ReMeasureReport(
            ReMeasureDecision.REVERT,
            tuple(improved),
            tuple(worsened),
            "post-repair measurement contains a protected regression",
        )

    if worsened:
        return ReMeasureReport(
            ReMeasureDecision.REVERT,
            tuple(improved),
            tuple(worsened),
            "targeted metrics significantly worsened after repair",
        )

    if targeted_metrics and set(improved) == set(targeted_metrics):
        return ReMeasureReport(
            ReMeasureDecision.KEEP,
            tuple(improved),
            (),
            "all targeted metrics improved under same-pair frozen re-measurement",
        )

    if improved:
        return ReMeasureReport(
            ReMeasureDecision.CONTINUE_TARGETED_IMPROVEMENT,
            tuple(improved),
            (),
            "some but not all targeted metrics improved under paired re-measurement",
        )

    return ReMeasureReport(
        ReMeasureDecision.STOP_NO_MATERIAL_GAIN,
        (),
        (),
        "repair produced no material paired re-measurement gain on targeted metrics",
    )


class FeedbackPhase(Enum):
    MEASURE = auto()
    OBSERVE_RESULT = auto()
    SYMPTOM_DIAGNOSIS = auto()
    CAUSAL_DIAGNOSIS = auto()
    DIRECTION_SELECTION = auto()
    TARGETED_IMPROVE = auto()
    RE_MEASURE = auto()
    CAUSAL_CONFIRMATION = auto()
    DECIDE = auto()
    STOP = auto()


@dataclass(slots=True)
class MeasurementDrivenFeedbackLoop:
    """Causal measurement-driven outer loop.

    Metric regressions are symptoms, not repair targets. A localized patch becomes
    admissible only after causal evidence selects a repair component.
    """
    plan: MeasurementPlan
    phase: FeedbackPhase = FeedbackPhase.MEASURE
    before: MeasurementResult | None = None
    symptom_diagnosis: DirectionDiagnosis | None = None
    causal_selection: CausalTargetSelection | None = None
    targeted_metrics: tuple[str, ...] = ()
    repair_component: str | None = None
    selected_hypothesis_ids: tuple[str, ...] = ()
    after: MeasurementResult | None = None
    decision: ReMeasureReport | None = None

    def record_measurement(
        self,
        observations: tuple[PairObservation, ...],
    ) -> MeasurementResult:
        if self.phase not in {FeedbackPhase.MEASURE, FeedbackPhase.RE_MEASURE}:
            raise AlmanalError("measurement recorded in illegal feedback phase")
        result = evaluate_measurement(self.plan, observations)
        if self.phase is FeedbackPhase.MEASURE:
            self.before = result
            self.phase = FeedbackPhase.OBSERVE_RESULT
        else:
            self.after = result
            self.phase = FeedbackPhase.CAUSAL_CONFIRMATION
        return result

    def observe_symptoms(self) -> DirectionDiagnosis:
        if self.phase is not FeedbackPhase.OBSERVE_RESULT or self.before is None:
            raise AlmanalError("no initial measurement ready for symptom diagnosis")
        self.phase = FeedbackPhase.SYMPTOM_DIAGNOSIS
        self.symptom_diagnosis = diagnose_direction(self.plan, self.before)

        if self.symptom_diagnosis.kind in {
            DiagnosisKind.PROTECTED_REGRESSION,
            DiagnosisKind.MIXED_TRADEOFF,
            DiagnosisKind.TARGETED_DEFECT,
        }:
            self.targeted_metrics = self.symptom_diagnosis.regressions
            self.phase = FeedbackPhase.CAUSAL_DIAGNOSIS
        else:
            self.phase = FeedbackPhase.STOP
        return self.symptom_diagnosis

    def diagnose_causal_target(
        self,
        hypotheses: tuple[CausalHypothesis, ...],
        tests: tuple[CausalTestSpec, ...],
        evidence: tuple[CausalEvidence, ...],
        *,
        receipt_validator: CausalReceiptValidator | None = None,
    ) -> CausalTargetSelection:
        if self.phase is not FeedbackPhase.CAUSAL_DIAGNOSIS:
            raise AlmanalError("causal diagnosis not currently admissible")
        diagnoses = tuple(
            diagnose_cause(h, tests, evidence, regressed_metrics=self.targeted_metrics, receipt_validator=receipt_validator)
            for h in hypotheses
        )
        self.causal_selection = select_causal_repair_target(hypotheses, diagnoses)
        self.phase = FeedbackPhase.DIRECTION_SELECTION
        if self.causal_selection.causal_uncertain:
            self.phase = FeedbackPhase.STOP
            return self.causal_selection
        self.repair_component = self.causal_selection.selected_component
        self.selected_hypothesis_ids = self.causal_selection.selected_hypothesis_ids
        self.phase = FeedbackPhase.TARGETED_IMPROVE
        return self.causal_selection

    def mark_targeted_improvement_complete(self) -> None:
        if self.phase is not FeedbackPhase.TARGETED_IMPROVE:
            raise AlmanalError("targeted improvement not currently admissible")
        if not self.repair_component:
            raise AlmanalError("repair requires a causally selected component")
        self.phase = FeedbackPhase.RE_MEASURE

    def decide_after_remeasurement(
        self,
        confirmations: tuple[CausalConfirmation, ...],
    ) -> ReMeasureReport:
        if (
            self.phase is not FeedbackPhase.CAUSAL_CONFIRMATION
            or self.before is None
            or self.after is None
        ):
            raise AlmanalError("re-measurement decision not ready")

        confirmation_map = {c.hypothesis_id: c for c in confirmations}
        missing = set(self.selected_hypothesis_ids) - set(confirmation_map)
        if missing:
            self.decision = ReMeasureReport(
                ReMeasureDecision.CAUSAL_UNCERTAIN, (), (),
                "post-patch causal confirmation missing for selected hypothesis",
            )
            self.phase = FeedbackPhase.STOP
            return self.decision
        if any(
            not confirmation_map[h].mechanism_changed_as_predicted
            for h in self.selected_hypothesis_ids
        ):
            self.decision = ReMeasureReport(
                ReMeasureDecision.REVERT, (), (),
                "metric result cannot be kept because the selected causal mechanism did not change as predicted",
            )
            self.phase = FeedbackPhase.STOP
            return self.decision

        self.phase = FeedbackPhase.DECIDE
        self.decision = compare_remeasurement(
            self.plan,
            self.before,
            self.after,
            targeted_metrics=self.targeted_metrics,
        )
        self.phase = FeedbackPhase.STOP
        return self.decision

