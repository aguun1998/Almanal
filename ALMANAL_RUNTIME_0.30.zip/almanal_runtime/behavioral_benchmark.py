from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction
from math import comb

from .errors import AlmanalError


class BehavioralClaimStatus(Enum):
    NOT_TESTED = auto()
    INSUFFICIENT_EVIDENCE = auto()
    SUPPORTED_SCOPED = auto()
    NOT_SUPPORTED = auto()


@dataclass(frozen=True, slots=True)
class PairedBehaviorObservation:
    pair_id: str
    plain_quality: Fraction
    almanal_quality: Fraction
    plain_overclaims: int
    almanal_overclaims: int
    plain_tokens: int
    almanal_tokens: int

    def __post_init__(self) -> None:
        if min(
            self.plain_overclaims, self.almanal_overclaims,
            self.plain_tokens, self.almanal_tokens,
        ) < 0:
            raise AlmanalError("counts/tokens must be nonnegative")


def exact_two_sided_sign_test_pvalue(
    *,
    wins: int,
    losses: int,
) -> Fraction:
    """Exact two-sided sign-test p-value under p=1/2; ties are excluded."""
    if wins < 0 or losses < 0:
        raise AlmanalError("wins/losses must be nonnegative")
    n = wins + losses
    if n == 0:
        return Fraction(1)
    k = min(wins, losses)
    lower_tail = sum(comb(n, i) for i in range(k + 1))
    p = Fraction(2 * lower_tail, 2**n)
    return min(Fraction(1), p)


@dataclass(frozen=True, slots=True)
class PairedMetricEvidence:
    wins: int
    losses: int
    ties: int
    p_value: Fraction


def _paired_evidence(deltas: tuple[Fraction, ...], *, positive_is_better: bool) -> PairedMetricEvidence:
    wins = 0
    losses = 0
    ties = 0
    for d in deltas:
        if d == 0:
            ties += 1
        elif (d > 0) == positive_is_better:
            wins += 1
        else:
            losses += 1
    return PairedMetricEvidence(
        wins=wins,
        losses=losses,
        ties=ties,
        p_value=exact_two_sided_sign_test_pvalue(wins=wins, losses=losses),
    )


@dataclass(frozen=True, slots=True)
class PairedBehaviorSummary:
    pairs: int
    quality: PairedMetricEvidence
    overclaim_reduction: PairedMetricEvidence
    token_reduction: PairedMetricEvidence
    total_plain_tokens: int
    total_almanal_tokens: int


def summarize_paired_behavior(
    observations: tuple[PairedBehaviorObservation, ...],
) -> PairedBehaviorSummary:
    quality_deltas = tuple(
        o.almanal_quality - o.plain_quality for o in observations
    )
    # Positive values mean ALMANAL reduced the bad quantity.
    overclaim_reduction = tuple(
        Fraction(o.plain_overclaims - o.almanal_overclaims)
        for o in observations
    )
    token_reduction = tuple(
        Fraction(o.plain_tokens - o.almanal_tokens)
        for o in observations
    )
    return PairedBehaviorSummary(
        pairs=len(observations),
        quality=_paired_evidence(quality_deltas, positive_is_better=True),
        overclaim_reduction=_paired_evidence(
            overclaim_reduction, positive_is_better=True
        ),
        token_reduction=_paired_evidence(
            token_reduction, positive_is_better=True
        ),
        total_plain_tokens=sum(o.plain_tokens for o in observations),
        total_almanal_tokens=sum(o.almanal_tokens for o in observations),
    )


@dataclass(frozen=True, slots=True)
class BehavioralClaimPolicy:
    minimum_pairs: int = 10
    alpha: Fraction = Fraction(1, 20)  # 0.05
    require_quality_nonloss_majority: bool = True
    require_overclaim_improvement: bool = False
    require_token_improvement: bool = False

    def __post_init__(self) -> None:
        if self.minimum_pairs < 1:
            raise AlmanalError("minimum_pairs must be >= 1")
        if not Fraction(0) < self.alpha <= 1:
            raise AlmanalError("alpha must be in (0,1]")


def gate_behavioral_superiority_claim(
    observations: tuple[PairedBehaviorObservation, ...],
    *,
    policy: BehavioralClaimPolicy = BehavioralClaimPolicy(),
) -> tuple[BehavioralClaimStatus, PairedBehaviorSummary | None, str]:
    """A deliberately narrow paired evidence gate.

    It does not turn one benchmark into universal superiority. A PASS means only
    that the *declared scoped claim* met this precommitted evidence policy.
    """
    if not observations:
        return (
            BehavioralClaimStatus.NOT_TESTED,
            None,
            "no paired behavioral observations",
        )
    summary = summarize_paired_behavior(observations)
    if summary.pairs < policy.minimum_pairs:
        return (
            BehavioralClaimStatus.INSUFFICIENT_EVIDENCE,
            summary,
            "paired sample below precommitted minimum",
        )

    quality_ok = True
    if policy.require_quality_nonloss_majority:
        quality_ok = summary.quality.wins >= summary.quality.losses

    overclaim_ok = True
    if policy.require_overclaim_improvement:
        overclaim_ok = (
            summary.overclaim_reduction.wins > summary.overclaim_reduction.losses
            and summary.overclaim_reduction.p_value <= policy.alpha
        )

    token_ok = True
    if policy.require_token_improvement:
        token_ok = (
            summary.token_reduction.wins > summary.token_reduction.losses
            and summary.token_reduction.p_value <= policy.alpha
        )

    if quality_ok and overclaim_ok and token_ok:
        return (
            BehavioralClaimStatus.SUPPORTED_SCOPED,
            summary,
            "precommitted paired evidence gate passed; claim remains benchmark-scoped",
        )
    return (
        BehavioralClaimStatus.NOT_SUPPORTED,
        summary,
        "precommitted paired evidence gate not satisfied",
    )
