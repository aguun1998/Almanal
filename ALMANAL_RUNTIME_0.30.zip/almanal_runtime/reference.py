from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Generic, Iterable, TypeVar
from .evaluator import QualityVector
from .errors import InvalidReferenceDomain

T = TypeVar("T")

@dataclass(frozen=True, slots=True)
class EvaluatedCandidate(Generic[T]):
    candidate: T
    quality: QualityVector

@dataclass(frozen=True, slots=True)
class ReferenceResult(Generic[T]):
    feasible_count: int
    pareto_front: tuple[EvaluatedCandidate[T], ...]
    enumeration_complete: bool = True

def bounded_reference_synthesize(
    candidates: Iterable[T],
    protected_indexes: tuple[int, ...],
    feasible: Callable[[T], bool],
    evaluate: Callable[[T], QualityVector],
) -> ReferenceResult[T]:
    if not protected_indexes:
        raise InvalidReferenceDomain("at least one protected metric is required")

    evaluated: list[EvaluatedCandidate[T]] = []
    for candidate in candidates:
        if feasible(candidate):
            quality = evaluate(candidate)
            for idx in protected_indexes:
                if idx < 0 or idx >= len(quality.values):
                    raise InvalidReferenceDomain(
                        f"metric {idx} outside dimension {len(quality.values)}"
                    )
            evaluated.append(EvaluatedCandidate(candidate, quality))

    front: list[EvaluatedCandidate[T]] = []
    for i, item in enumerate(evaluated):
        if not any(
            j != i
            and other.quality.strictly_dominates(item.quality, protected_indexes)
            for j, other in enumerate(evaluated)
        ):
            front.append(item)

    return ReferenceResult(
        feasible_count=len(evaluated),
        pareto_front=tuple(front),
        enumeration_complete=True,
    )
