from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from threading import RLock

from .authority import AuthorityLedger, AuthoritySet
from .certificate import Certificate
from .conformance import ConformanceProfile, OperatorRealization, OperatorRegistry
from .errors import (
    AlmanalError, BudgetExhausted, RuntimeStopped, SnapshotViolation, VerificationViolation
)
from .library import LibraryClaim, LibraryRegistry, ResidentRecipeContract
from .model import EpochSnapshot, ObjectId, ObjectType, TypedObject
from .ontology import ConceptLicense, OntologyRegistry
from .persistence import CommitRecord, PersistentStore, RevisionProposal, VersionedValue
from .provenance import ProvenanceGraph, SourceRoot
from .stage import Stage, check_transition
from .typesystem import ObjectStore, PromotionRegistry
from .verification import VerificationBasis, VerificationReceipt, verify_certificate


class StepBudget:
    """Runtime-local step counter; no independent module boundary is required."""
    def __init__(self, steps: int) -> None:
        if steps < 0:
            raise ValueError("steps must be >= 0")
        self.__initial = steps
        self.__remaining = steps

    @property
    def initial(self) -> int:
        return self.__initial

    @property
    def remaining(self) -> int:
        return self.__remaining

    @property
    def consumed(self) -> int:
        return self.__initial - self.__remaining

    def consume(self) -> None:
        if self.__remaining <= 0:
            raise BudgetExhausted("step budget exhausted")
        self.__remaining -= 1

class StopReason(Enum):
    BUDGET_EXHAUSTED = auto()
    NO_NEW_CANDIDATE = auto()
    NO_CERTIFIED_IMPROVEMENT = auto()
    MARGINAL_VALUE_EXHAUSTED = auto()
    STOP_WITH_KNOWN_RESIDUAL = auto()
    NO_MATERIAL_MEASURED_DEFECT = auto()
    NO_MATERIAL_MEASURED_GAIN = auto()
    MEASUREMENT_UNCERTAIN = auto()
    CAUSAL_UNCERTAIN = auto()
    UNRESOLVED_TRADEOFF = auto()
    WORKER_FAILURE = auto()
    EVALUATOR_FAILURE = auto()
    LOCAL_SPACE_EXHAUSTED = auto()
    GLOBAL_SPACE_EXHAUSTED = auto()
    BLOCKED = auto()
    INVALIDATED = auto()
    COMPLETED = auto()

class RuntimeStatus(Enum):
    RUNNING = auto()
    COMPLETE = auto()
    DEGRADED = auto()
    INCOMPLETE = auto()
    BLOCKED = auto()
    INVALIDATED = auto()

@dataclass(frozen=True, slots=True)
class TransitionRecord:
    from_stage: Stage
    to_stage: Stage
    budget_before: int
    budget_after: int
    snapshot_identity: str

class Runtime:
    """
    Reference enforcement runtime.

    Python cannot provide Rust-like memory encapsulation against hostile local code,
    but protected ledgers are name-mangled and are only mutated through gate methods.
    Conformance is an API/runtime property, not a sandbox/security boundary.
    """
    def __init__(self, snapshot: EpochSnapshot, step_budget: int) -> None:
        self.__snapshot = snapshot
        self.__frozen_identity = snapshot.canonical_encode()
        self.__stage = Stage.PRESEAL
        self.__budget = StepBudget(step_budget)
        self.__objects = ObjectStore()
        self.__promotions = PromotionRegistry()
        self.__provenance = ProvenanceGraph()
        self.__authority = AuthorityLedger()
        self.__certificates: dict[str, Certificate] = {}
        self.__verification_receipts: dict[str, VerificationReceipt] = {}
        self.__persistence = PersistentStore()
        self.__ontology = OntologyRegistry()
        self.__library = LibraryRegistry()
        self.__operators = OperatorRegistry()
        self.__history: list[TransitionRecord] = []
        self.__status = RuntimeStatus.RUNNING
        self.__stop_reason: StopReason | None = None
        self.__commit_lock = RLock()

    @property
    def snapshot(self) -> EpochSnapshot:
        return self.__snapshot

    @property
    def stage(self) -> Stage:
        return self.__stage

    @property
    def remaining_steps(self) -> int:
        return self.__budget.remaining

    @property
    def status(self) -> RuntimeStatus:
        return self.__status

    @property
    def stop_reason(self) -> StopReason | None:
        return self.__stop_reason

    def object(self, object_id: ObjectId) -> TypedObject:
        return self.__objects.get(object_id)

    def objects(self) -> tuple[TypedObject, ...]:
        return self.__objects.values()

    def provenance_roots(self, object_id: ObjectId) -> frozenset[SourceRoot]:
        return self.__provenance.roots_of(object_id)

    def authority_of(self, object_id: ObjectId) -> AuthoritySet:
        return self.__authority.authority_of(object_id)

    def certificates(self) -> tuple[Certificate, ...]:
        return tuple(self.__certificates.values())

    def verification_receipts(self) -> tuple[VerificationReceipt, ...]:
        return tuple(self.__verification_receipts.values())

    def persistent_value(self, key: str) -> VersionedValue | None:
        return self.__persistence.get(key)

    def commit_history(self) -> tuple[CommitRecord, ...]:
        return self.__persistence.history()

    def transition_history(self) -> tuple[TransitionRecord, ...]:
        return tuple(self.__history)

    def _assert_snapshot_frozen(self) -> None:
        if self.__snapshot.canonical_encode() != self.__frozen_identity:
            self.__status = RuntimeStatus.INVALIDATED
            self.__stop_reason = StopReason.INVALIDATED
            raise SnapshotViolation("epoch snapshot mutated")

    # ----- configuration/governance gates -----

    def register_promotion(self, source: ObjectType, target: ObjectType) -> None:
        self.__promotions.register(source, target)

    def promote_object(
        self,
        source: TypedObject,
        *,
        new_id: str,
        target_type: ObjectType,
        transformed_content: str,
    ) -> TypedObject:
        return self.__promotions.promote(
            source,
            new_id=new_id,
            target_type=target_type,
            transformed_content=transformed_content,
        )

    def set_operator_grant(self, operator: str, grant: AuthoritySet) -> None:
        self.__authority.set_operator_grant(operator, grant)

    def register_operator_realization(
        self, name: str, realization: OperatorRealization
    ) -> None:
        self.__operators.register(name, realization)

    def verify_profile(
        self, profile: ConformanceProfile, required_operators: frozenset[str]
    ) -> None:
        self.__operators.verify_profile(profile, required_operators)

    def register_library_claim(self, claim: LibraryClaim) -> None:
        self.__library.register_claim(claim)

    def register_library_recipe(self, recipe: ResidentRecipeContract) -> None:
        self.__library.register_recipe(recipe)

    def realize_library_operator(self, operator: str, implementation_ref: str) -> None:
        self.__library.realize_operator(operator, implementation_ref)

    def check_library_exec_ready(self, recipe_id: str) -> None:
        self.__library.check_exec_ready(recipe_id)

    def register_concept_license(self, subject: str, license: ConceptLicense) -> None:
        self.__ontology.register(subject, license)

    def seed_persistent(self, key: str, value: str) -> None:
        self.__persistence.seed(key, value)

    # ----- state machine -----

    def transition(self, nxt: Stage) -> None:
        if self.__status is not RuntimeStatus.RUNNING:
            raise RuntimeStopped(f"runtime status is {self.__status.name}")
        self._assert_snapshot_frozen()
        check_transition(self.__stage, nxt)
        before = self.__budget.remaining

        if nxt is Stage.INVALIDATED:
            frm = self.__stage
            self.__stage = nxt
            self.__status = RuntimeStatus.INVALIDATED
            self.__stop_reason = StopReason.INVALIDATED
            self.__history.append(
                TransitionRecord(frm, nxt, before, before, self.__frozen_identity)
            )
            return

        try:
            self.__budget.consume()
        except BudgetExhausted:
            self.__status = RuntimeStatus.INCOMPLETE
            self.__stop_reason = StopReason.BUDGET_EXHAUSTED
            raise

        frm = self.__stage
        self.__stage = nxt
        after = self.__budget.remaining
        self.__history.append(
            TransitionRecord(frm, nxt, before, after, self.__frozen_identity)
        )

    def finish(self, reason: StopReason = StopReason.COMPLETED) -> None:
        if self.__stage is not Stage.OUTPUT:
            from .errors import InvalidTransition
            raise InvalidTransition(f"{self.__stage.name} -> STOP")
        self.transition(Stage.STOP)
        self.__status = RuntimeStatus.COMPLETE
        self.__stop_reason = reason

    def invalidate(self, reason: StopReason = StopReason.INVALIDATED) -> None:
        if self.__status is not RuntimeStatus.RUNNING:
            raise RuntimeStopped(f"runtime status is {self.__status.name}")
        self._assert_snapshot_frozen()
        before = self.__budget.remaining
        frm = self.__stage
        self.__stage = Stage.INVALIDATED
        self.__status = RuntimeStatus.INVALIDATED
        self.__stop_reason = reason
        self.__history.append(
            TransitionRecord(frm, Stage.INVALIDATED, before, before, self.__frozen_identity)
        )

    # ----- atomic object gates -----

    def ingest_object(
        self,
        obj: TypedObject,
        roots: frozenset[SourceRoot],
        authority: AuthoritySet,
    ) -> ObjectId:
        # Parallel compute is allowed, but shared-ledger commit is serialized and rollback-safe.
        with self.__commit_lock:
            if self.__objects.contains(obj.id):
                from .errors import DuplicateObject
                raise DuplicateObject(str(obj.id))
            if self.__provenance.contains(obj.id) or self.__authority.contains_object(obj.id):
                raise AlmanalError("cross-ledger duplicate detected before commit")
            inserted = prov = auth = False
            try:
                self.__objects.insert(obj); inserted = True
                self.__provenance.register_source_object(obj.id, roots); prov = True
                self.__authority.register_object(obj.id, authority); auth = True
            except Exception:
                if auth: self.__authority.discard_object(obj.id)
                if prov: self.__provenance.discard(obj.id)
                if inserted: self.__objects.discard(obj.id)
                self.__status = RuntimeStatus.INVALIDATED
                self.__stop_reason = StopReason.INVALIDATED
                raise
            return obj.id

    def derive_object(
        self,
        *,
        obj: TypedObject,
        input_ids: tuple[ObjectId, ...],
        new_roots: frozenset[SourceRoot],
        operator: str,
        requested_authority: AuthoritySet,
    ) -> ObjectId:
        with self.__commit_lock:
            if self.__objects.contains(obj.id):
                from .errors import DuplicateObject
                raise DuplicateObject(str(obj.id))
            if self.__provenance.contains(obj.id) or self.__authority.contains_object(obj.id):
                raise AlmanalError("cross-ledger duplicate detected before commit")
            _ = self.__provenance.preview_derived_roots(input_ids, new_roots)
            self.__authority.validate_output(operator, input_ids, requested_authority)
            for input_id in input_ids:
                self.__objects.get(input_id)
            inserted = prov = auth = False
            try:
                self.__objects.insert(obj); inserted = True
                self.__provenance.derive(obj.id, input_ids, new_roots); prov = True
                self.__authority.register_object(obj.id, requested_authority); auth = True
            except Exception:
                if auth: self.__authority.discard_object(obj.id)
                if prov: self.__provenance.discard(obj.id)
                if inserted: self.__objects.discard(obj.id)
                self.__status = RuntimeStatus.INVALIDATED
                self.__stop_reason = StopReason.INVALIDATED
                raise
            return obj.id

    def verify_and_add_certificate(
        self,
        certificate: Certificate,
        *,
        verifier_ref: str,
        basis: VerificationBasis,
        verifier,
        basis_attestation_ref: str = "",
        basis_validator=None,
        independence_validator=None,
    ) -> VerificationReceipt:
        self._assert_snapshot_frozen()
        if certificate.criterion_snapshot_ref != self.__frozen_identity:
            from .errors import CertificateViolation
            raise CertificateViolation("certificate criterion does not match frozen epoch")
        if not self.__objects.contains(certificate.subject_ref):
            from .errors import CertificateViolation
            raise CertificateViolation("certificate subject not in object store")
        if certificate.certificate_id in self.__certificates:
            raise VerificationViolation(f"duplicate certificate id: {certificate.certificate_id}")
        receipt = verify_certificate(
            certificate, verifier_ref=verifier_ref, basis=basis, verifier=verifier,
            basis_attestation_ref=basis_attestation_ref, basis_validator=basis_validator,
            independence_validator=independence_validator,
        )
        self.__certificates[certificate.certificate_id] = certificate
        self.__verification_receipts[certificate.certificate_id] = receipt
        return receipt

    def commit_revision(self, proposal: RevisionProposal) -> CommitRecord:
        self._assert_snapshot_frozen()
        if self.__status is not RuntimeStatus.RUNNING or self.__stage is not Stage.REGRESSION:
            from .errors import PersistenceViolation
            raise PersistenceViolation(
                "persistent commit is only allowed while RUNNING in REGRESSION stage"
            )
        # Candidate must be a runtime-known object, and its validating certificate
        # must have passed the Runtime certificate gate already.
        self.__objects.get(proposal.candidate_ref)
        admitted = self.__certificates.get(proposal.certificate.certificate_id)
        receipt = self.__verification_receipts.get(proposal.certificate.certificate_id)
        if admitted != proposal.certificate or receipt is None or not receipt.passed:
            from .errors import PersistenceViolation
            raise PersistenceViolation("revision requires Runtime-verified certificate receipt")
        return self.__persistence.commit(proposal, self.__frozen_identity)

    def rollback_last(self) -> CommitRecord:
        return self.__persistence.rollback_last()

    def check_trace_invariants(self) -> None:
        for rec in self.__history:
            if rec.snapshot_identity != self.__frozen_identity:
                raise SnapshotViolation("transition used non-frozen snapshot")
            if rec.to_stage is not Stage.INVALIDATED:
                if rec.budget_after != rec.budget_before - 1:
                    raise AlmanalError("nonterminal transition did not consume exactly one step")
