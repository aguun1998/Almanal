from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction

from .errors import AlmanalError


class CognitiveActionKind(Enum):
    GENERATE = auto()
    CHALLENGE = auto()
    REPAIR = auto()
    VERIFY = auto()
    SEARCH = auto()
    RETRIEVE = auto()
    FORMALIZE = auto()
    COMPRESS = auto()
    CHECKPOINT = auto()
    TOOL = auto()
    SELF_IMPROVE = auto()
    EXTERNALIZE_RUNTIME = auto()
    MEASURE = auto()
    OBSERVE_RESULT = auto()
    DIAGNOSE_DIRECTION = auto()
    CAUSAL_DIAGNOSIS = auto()
    CAUSAL_TEST = auto()
    RE_MEASURE = auto()
    CAUSAL_CONFIRMATION = auto()
    FORMALISM_AUDIT = auto()
    ARTIFACT_AUDIT = auto()
    STRUCTURAL_CONSOLIDATION_AUDIT = auto()
    DESIGN_EXPERIMENT = auto()
    PRECOMMIT_EXPERIMENT = auto()
    RUN_EXPERIMENT = auto()
    EVALUATE_EXPERIMENT = auto()
    EXPERIMENT_BATCH = auto()
    RESOLVE_OBJECTIVE = auto()
    SELECT_EVIDENCE = auto()
    ELICIT_PREFERENCE = auto()
    OTHER = auto()


class EconomyDecision(Enum):
    MANDATORY_EXECUTE = auto()
    EXECUTE = auto()
    SKIP_NONPOSITIVE_VOC = auto()
    SKIP_INSUFFICIENT_MARGIN = auto()
    SKIP_BUDGET = auto()
    BLOCKED_MANDATORY_BUDGET = auto()


class RiskRule(Enum):
    EXPECTED_VALUE = auto()
    LOWER_BOUND = auto()


@dataclass(frozen=True, slots=True)
class ResourceVector:
    """Directly budgetable non-commensurate resources.

    Non-commensurate budget coordinates. Numeric elapsed time needs a witnessed
    clock; structural work belongs in analytic evaluation axes, not fake milliseconds.
    Storage bytes and artifact count remain separate.
    """
    tokens: int = 0
    tool_calls: int = 0
    money_micros: int = 0
    steps: int = 0
    context_bytes: int = 0
    persistent_storage_bytes: int = 0
    working_storage_bytes: int = 0
    artifact_count: int = 0
    io_bytes: int = 0

    def __post_init__(self) -> None:
        if min(self.key()) < 0:
            raise AlmanalError("resource coordinates must be nonnegative")

    def fits(self, remaining: "ResourceVector") -> bool:
        return all(a <= b for a, b in zip(self.key(), remaining.key()))

    def subtract(self, used: "ResourceVector") -> "ResourceVector":
        if not used.fits(self):
            raise AlmanalError("resource subtraction would go negative")
        return ResourceVector(*(a - b for a, b in zip(self.key(), used.key())))

    def add(self, other: "ResourceVector") -> "ResourceVector":
        return ResourceVector(*(a + b for a, b in zip(self.key(), other.key())))

    def scale(self, n: int) -> "ResourceVector":
        if n < 0:
            raise AlmanalError("resource scale must be nonnegative")
        return ResourceVector(*(a * n for a in self.key()))

    def consumed_to(self, remaining: "ResourceVector") -> "ResourceVector":
        if not remaining.fits(self):
            raise AlmanalError("remaining resources exceed earlier budget")
        return ResourceVector(*(a - b for a, b in zip(self.key(), remaining.key())))

    def key(self) -> tuple[int, ...]:
        return (
            self.tokens, self.tool_calls, self.money_micros, self.steps,
            self.context_bytes, self.persistent_storage_bytes,
            self.working_storage_bytes, self.artifact_count, self.io_bytes,
        )


@dataclass(frozen=True, slots=True)
class UtilityEstimate:
    """Utility values must already be on one explicitly chosen decision-utility scale."""
    lower: Fraction
    expected: Fraction
    upper: Fraction

    def __post_init__(self) -> None:
        if not self.lower <= self.expected <= self.upper:
            raise AlmanalError("utility estimate must satisfy lower <= expected <= upper")


@dataclass(frozen=True, slots=True)
class CognitiveOffer:
    """One contemplated cognitive action.

    `post_action_stop_utility` estimates the terminal decision utility available
    after performing this action and then stopping. This is a *myopic* VOC offer;
    it does not pretend to solve the full metalevel Bellman problem.

    `decision_cost_utility` is commensurate with the utility estimate.
    ResourceVector remains a separate hard-budget object.
    """
    action_id: str
    kind: CognitiveActionKind
    current_stop_utility: Fraction
    post_action_stop_utility: UtilityEstimate
    decision_cost_utility: Fraction
    resources: ResourceVector
    mandatory: bool = False
    evidence_ref: str = ""
    affected_by: frozenset[str] = frozenset()

    def __post_init__(self) -> None:
        if self.decision_cost_utility < 0:
            raise AlmanalError("decision_cost_utility must be nonnegative")

    @property
    def voc_expected(self) -> Fraction:
        return (
            self.post_action_stop_utility.expected
            - self.current_stop_utility
            - self.decision_cost_utility
        )

    @property
    def voc_lower(self) -> Fraction:
        return (
            self.post_action_stop_utility.lower
            - self.current_stop_utility
            - self.decision_cost_utility
        )

    @property
    def voc_upper(self) -> Fraction:
        return (
            self.post_action_stop_utility.upper
            - self.current_stop_utility
            - self.decision_cost_utility
        )


@dataclass(frozen=True, slots=True)
class EconomyPolicy:
    risk_rule: RiskRule = RiskRule.EXPECTED_VALUE
    minimum_voc_margin: Fraction = Fraction(0)
    require_evidence_for_optional: bool = False

    def __post_init__(self) -> None:
        if self.minimum_voc_margin < 0:
            raise AlmanalError("minimum_voc_margin must be nonnegative")

    def score(self, offer: CognitiveOffer) -> Fraction:
        if self.risk_rule is RiskRule.LOWER_BOUND:
            return offer.voc_lower
        return offer.voc_expected


@dataclass(frozen=True, slots=True)
class EconomyGateResult:
    decision: EconomyDecision
    score: Fraction
    resources_after: ResourceVector
    reason: str


def gate_cognitive_action(
    offer: CognitiveOffer,
    *,
    remaining: ResourceVector,
    policy: EconomyPolicy = EconomyPolicy(),
) -> EconomyGateResult:
    """Apply mandatory floor first, then marginal value-of-computation gate."""
    if offer.mandatory:
        if not offer.resources.fits(remaining):
            return EconomyGateResult(
                EconomyDecision.BLOCKED_MANDATORY_BUDGET,
                policy.score(offer),
                remaining,
                "mandatory cognitive action exceeds hard resource budget",
            )
        return EconomyGateResult(
            EconomyDecision.MANDATORY_EXECUTE,
            policy.score(offer),
            remaining.subtract(offer.resources),
            "mandatory floor overrides optional VOC gate",
        )

    if not offer.resources.fits(remaining):
        return EconomyGateResult(
            EconomyDecision.SKIP_BUDGET,
            policy.score(offer),
            remaining,
            "optional cognitive action exceeds hard resource budget",
        )

    if policy.require_evidence_for_optional and not offer.evidence_ref:
        return EconomyGateResult(
            EconomyDecision.SKIP_INSUFFICIENT_MARGIN,
            policy.score(offer),
            remaining,
            "optional action has no evidence basis for its value estimate",
        )

    score = policy.score(offer)
    if score <= 0:
        return EconomyGateResult(
            EconomyDecision.SKIP_NONPOSITIVE_VOC,
            score,
            remaining,
            "STOP weakly dominates this optional cognitive action",
        )
    if score <= policy.minimum_voc_margin:
        return EconomyGateResult(
            EconomyDecision.SKIP_INSUFFICIENT_MARGIN,
            score,
            remaining,
            "positive VOC does not exceed the precommitted execution margin",
        )
    return EconomyGateResult(
        EconomyDecision.EXECUTE,
        score,
        remaining.subtract(offer.resources),
        "estimated marginal decision value exceeds marginal decision cost",
    )


@dataclass(frozen=True, slots=True)
class CognitiveActionPackage:
    """Frozen multi-step instrumental chain valued as one decision package.

    Intermediate steps may have low standalone VOC, but every admitted step must lie
    on a declared dependency path to the terminal action. This prevents a package
    from laundering unrelated negative-VOC cognition behind one favorable total.
    """
    package_id: str
    action_ids: tuple[str, ...]
    resources: ResourceVector
    voc: UtilityEstimate
    evidence_ref: str
    dependency_edges: tuple[tuple[str, str], ...] = ()
    terminal_action_id: str = ""
    mandatory: bool = False

    def __post_init__(self) -> None:
        if not self.package_id or not self.action_ids or not self.evidence_ref:
            raise AlmanalError("cognitive package requires id/actions/evidence")
        if len(set(self.action_ids)) != len(self.action_ids):
            raise AlmanalError("cognitive package action ids must be unique")
        terminal = self.terminal_action_id or self.action_ids[-1]
        if terminal not in self.action_ids:
            raise AlmanalError("cognitive package terminal action must be in the package")
        edges = self.effective_dependency_edges()
        nodes = set(self.action_ids)
        if any(a not in nodes or b not in nodes or a == b for a, b in edges):
            raise AlmanalError("cognitive package dependency edge references invalid/self action")
        graph = {a: [] for a in self.action_ids}
        indegree = {a: 0 for a in self.action_ids}
        for a, b in edges:
            graph[a].append(b); indegree[b] += 1
        queue = [a for a, d in indegree.items() if d == 0]
        seen = 0
        while queue:
            a = queue.pop(); seen += 1
            for b in graph[a]:
                indegree[b] -= 1
                if indegree[b] == 0: queue.append(b)
        if seen != len(self.action_ids):
            raise AlmanalError("cognitive package dependency graph must be acyclic")
        reverse = {a: [] for a in self.action_ids}
        for a, b in edges: reverse[b].append(a)
        reaches_terminal = {terminal}
        stack = [terminal]
        while stack:
            b = stack.pop()
            for a in reverse[b]:
                if a not in reaches_terminal:
                    reaches_terminal.add(a); stack.append(a)
        if reaches_terminal != nodes:
            raise AlmanalError("every package action must be an instrumental prerequisite of the terminal action")

    def effective_dependency_edges(self) -> tuple[tuple[str, str], ...]:
        if self.dependency_edges:
            return self.dependency_edges
        return tuple(zip(self.action_ids, self.action_ids[1:]))

    @property
    def terminal(self) -> str:
        return self.terminal_action_id or self.action_ids[-1]


def gate_cognitive_package(
    package: CognitiveActionPackage,
    *,
    remaining: ResourceVector,
    policy: EconomyPolicy = EconomyPolicy(),
) -> EconomyGateResult:
    offer = CognitiveOffer(
        action_id=f"package:{package.package_id}",
        kind=CognitiveActionKind.SEARCH,
        current_stop_utility=Fraction(0),
        post_action_stop_utility=package.voc,
        decision_cost_utility=Fraction(0),
        resources=package.resources,
        mandatory=package.mandatory,
        evidence_ref=package.evidence_ref,
    )
    result = gate_cognitive_action(offer, remaining=remaining, policy=policy)
    if result.decision in {EconomyDecision.EXECUTE, EconomyDecision.MANDATORY_EXECUTE}:
        return EconomyGateResult(result.decision, result.score, result.resources_after, "multi-step instrumental package admitted on package-level VOC; do not re-gate prerequisites myopically")
    return result


@dataclass(frozen=True, slots=True)
class CognitiveDecisionRecord:
    action_id: str
    kind: CognitiveActionKind
    decision: EconomyDecision
    score: Fraction
    resources_before: ResourceVector
    resources_after: ResourceVector
    reason: str


class EconomySettlementStatus(Enum):
    SETTLED = auto()
    BUDGET_OVERRUN = auto()


@dataclass(frozen=True, slots=True)
class CognitiveSettlementRecord:
    action_id: str
    estimated_resources: ResourceVector
    actual_resources: ResourceVector
    status: EconomySettlementStatus
    remaining_after: ResourceVector
    reason: str


class EconomyGovernor:
    """Thin stateful gate. The governor itself does not recursively deliberate."""

    def __init__(
        self,
        *,
        budget: ResourceVector,
        policy: EconomyPolicy = EconomyPolicy(),
    ) -> None:
        self._initial_budget = budget
        self._remaining = budget
        self._policy = policy
        self._records: list[CognitiveDecisionRecord] = []
        self._settlements: list[CognitiveSettlementRecord] = []

    @property
    def initial_budget(self) -> ResourceVector:
        return self._initial_budget

    @property
    def remaining(self) -> ResourceVector:
        return self._remaining

    @property
    def policy(self) -> EconomyPolicy:
        return self._policy

    def consider(self, offer: CognitiveOffer) -> EconomyGateResult:
        before = self._remaining
        result = gate_cognitive_action(
            offer,
            remaining=before,
            policy=self._policy,
        )
        self._remaining = result.resources_after
        self._records.append(
            CognitiveDecisionRecord(
                action_id=offer.action_id,
                kind=offer.kind,
                decision=result.decision,
                score=result.score,
                resources_before=before,
                resources_after=result.resources_after,
                reason=result.reason,
            )
        )
        return result

    def consider_package(self, package: CognitiveActionPackage) -> EconomyGateResult:
        """Admit one frozen dependency package and charge its resources exactly once."""
        before = self._remaining
        result = gate_cognitive_package(package, remaining=before, policy=self._policy)
        self._remaining = result.resources_after
        self._records.append(
            CognitiveDecisionRecord(
                action_id=f"package:{package.package_id}",
                kind=CognitiveActionKind.OTHER,
                decision=result.decision,
                score=result.score,
                resources_before=before,
                resources_after=result.resources_after,
                reason=result.reason,
            )
        )
        return result

    def records(self) -> tuple[CognitiveDecisionRecord, ...]:
        return tuple(self._records)

    def settlements(self) -> tuple[CognitiveSettlementRecord, ...]:
        return tuple(self._settlements)

    def settle_last(self, actual_resources: ResourceVector) -> CognitiveSettlementRecord:
        """Reconcile the latest executed estimate with witnessed actual usage.

        Settlement must happen before another offer is considered. Overestimates are
        refunded componentwise; underestimates consume the additional resources. If
        actual usage exceeded the pre-action hard budget, the overrun is explicit and
        the remaining budget is conservatively zeroed.
        """
        if not self._records:
            raise AlmanalError("no cognitive action exists to settle")
        record = self._records[-1]
        if record.decision not in {EconomyDecision.EXECUTE, EconomyDecision.MANDATORY_EXECUTE}:
            raise AlmanalError("latest cognitive action was not executed")
        if self._settlements and self._settlements[-1].action_id == record.action_id:
            raise AlmanalError("latest cognitive action already settled")
        estimated = record.resources_before.consumed_to(record.resources_after)
        if actual_resources.fits(record.resources_before):
            self._remaining = record.resources_before.subtract(actual_resources)
            settlement = CognitiveSettlementRecord(
                record.action_id, estimated, actual_resources,
                EconomySettlementStatus.SETTLED, self._remaining,
                "actual resource usage reconciled against frozen estimate",
            )
        else:
            self._remaining = ResourceVector()
            settlement = CognitiveSettlementRecord(
                record.action_id, estimated, actual_resources,
                EconomySettlementStatus.BUDGET_OVERRUN, self._remaining,
                "actual resource usage exceeded the pre-action hard budget",
            )
        self._settlements.append(settlement)
        return settlement
_COLD_NAMES = frozenset({
    "LifecycleImprovement", "LifecycleDecision", "decide_lifecycle_improvement",
    "TokenInvestment", "exact_myopic_voc_from_outcomes", "MetaTransition", "MetaAction",
    "FiniteMetaProblem", "MetaSolution", "solve_finite_horizon_metareasoning",
    "FormalResidency", "FormalObjectProfile", "FormalismDecision", "classify_formal_object",
    "FormalismFootprint", "summarize_formalism",
})

def __getattr__(name):
    if name not in _COLD_NAMES:
        raise AttributeError(name)
    from . import economy_cold
    value = getattr(economy_cold, name)
    globals()[name] = value
    return value

