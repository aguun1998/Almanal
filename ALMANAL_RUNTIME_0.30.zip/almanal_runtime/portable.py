from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, IntEnum, auto
from collections.abc import Callable

from .errors import AlmanalError


ALMANAL_RUNTIME_PROTOCOL = "ALMANAL-RUNTIME-CONTRACT/1"


class Capability(Enum):
    REASON = auto()
    CONTEXT_STATE = auto()
    STRUCTURED_OUTPUT = auto()
    RETRIEVAL = auto()
    CODE_EXECUTION = auto()
    TOOL_CALLING = auto()
    PERSISTENCE = auto()
    EXTERNAL_VERIFICATION = auto()
    PARALLEL_EXECUTION = auto()
    TOKEN_COUNT = auto()
    EXTERNAL_RUNTIME = auto()
    PROCESS_ISOLATION = auto()
    MACHINE_PROOF = auto()


class Availability(Enum):
    AVAILABLE = auto()
    UNAVAILABLE = auto()
    UNKNOWN = auto()


class Enforcement(Enum):
    INTERNAL = auto()
    TOOL = auto()
    EXTERNAL = auto()
    HARDENED = auto()


class WitnessBasis(Enum):
    SELF_DECLARED = auto()
    OBSERVED_INTERFACE = auto()
    EXECUTED = auto()
    EXTERNAL_ATTESTATION = auto()


class BackendProfile(IntEnum):
    # Start at 1 so a valid NATIVE profile is never falsey in serializers/callers.
    NATIVE = 1
    TOOL_AUGMENTED = 2
    REFERENCE_EXEC = 3
    HARDENED = 4


class BootstrapStatus(Enum):
    READY = auto()
    DEGRADED = auto()
    BLOCKED = auto()


class ValidationGrade(IntEnum):
    SELF_CHECKED = 0
    TOOL_GROUNDED = 1
    EXTERNAL_VERIFIED = 2
    MACHINE_VERIFIED = 3


@dataclass(frozen=True, slots=True)
class CapabilityRecord:
    capability: Capability
    availability: Availability
    enforcement: Enforcement
    witness_basis: WitnessBasis
    witness_ref: str
    protocols: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()

    @property
    def bindable(self) -> bool:
        # UNKNOWN never silently promotes to AVAILABLE.
        return self.availability is Availability.AVAILABLE

    @property
    def claims_strong_witness(self) -> bool:
        return bool(self.witness_ref) and self.witness_basis in {
            WitnessBasis.OBSERVED_INTERFACE,
            WitnessBasis.EXECUTED,
            WitnessBasis.EXTERNAL_ATTESTATION,
        }

    @property
    def strongly_witnessed(self) -> bool:
        """A capability record cannot attest its own witness basis."""
        return False


@dataclass(frozen=True, slots=True)
class CapabilityManifest:
    host_ref: str
    records: tuple[CapabilityRecord, ...]
    scope: str = "current-session"
    version: str = "1"

    def record(self, capability: Capability) -> CapabilityRecord | None:
        for r in self.records:
            if r.capability is capability:
                return r
        return None

    def available(self, capability: Capability) -> bool:
        r = self.record(capability)
        return bool(r and r.bindable)

    def strongly_available(self, capability: Capability, witness_validator: "CapabilityWitnessValidator | None" = None) -> bool:
        r = self.record(capability)
        return bool(r and r.bindable and _record_strongly_witnessed(r, witness_validator))

    def enforcement_of(self, capability: Capability) -> Enforcement | None:
        r = self.record(capability)
        return r.enforcement if r and r.bindable else None

    def supports_protocol(self, capability: Capability, protocol: str) -> bool:
        r = self.record(capability)
        return bool(r and r.bindable and protocol in r.protocols)


CapabilityWitnessValidator = Callable[[CapabilityRecord], bool]


def _record_strongly_witnessed(
    record: CapabilityRecord,
    witness_validator: CapabilityWitnessValidator | None,
) -> bool:
    if not record.claims_strong_witness or witness_validator is None:
        return False
    try:
        return bool(witness_validator(record))
    except Exception:
        return False


@dataclass(frozen=True, slots=True)
class RuntimeOperatorBinding:
    operator: str
    required_capabilities: frozenset[Capability]
    realization: str
    enforcement: Enforcement
    external_independence: bool = False


@dataclass(frozen=True, slots=True)
class PortableBootstrapResult:
    status: BootstrapStatus
    profile: BackendProfile | None
    bindings: tuple[RuntimeOperatorBinding, ...]
    missing_required_capabilities: tuple[Capability, ...]
    optional_available: tuple[Capability, ...]
    residuals: tuple[str, ...]
    can_claim_external_enforcement: bool
    can_claim_independent_verification: bool
    validation_ceiling: ValidationGrade


MINIMUM_PORTABLE_CAPABILITIES = frozenset({
    Capability.REASON,
    Capability.CONTEXT_STATE,
    Capability.STRUCTURED_OUTPUT,
})

OPTIONAL_PORTABLE_CAPABILITIES = frozenset({
    Capability.RETRIEVAL,
    Capability.CODE_EXECUTION,
    Capability.TOOL_CALLING,
    Capability.PERSISTENCE,
    Capability.EXTERNAL_VERIFICATION,
    Capability.PARALLEL_EXECUTION,
    Capability.TOKEN_COUNT,
    Capability.EXTERNAL_RUNTIME,
    Capability.PROCESS_ISOLATION,
    Capability.MACHINE_PROOF,
})


def _conformant_external_runtime(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> bool:
    r = manifest.record(Capability.EXTERNAL_RUNTIME)
    return bool(
        r
        and r.bindable
        and _record_strongly_witnessed(r, witness_validator)
        and r.enforcement in {Enforcement.EXTERNAL, Enforcement.HARDENED}
        and ALMANAL_RUNTIME_PROTOCOL in r.protocols
    )


def _strong_external_verifier(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> bool:
    r = manifest.record(Capability.EXTERNAL_VERIFICATION)
    return bool(
        r
        and r.bindable
        and _record_strongly_witnessed(r, witness_validator)
        and r.enforcement in {Enforcement.EXTERNAL, Enforcement.HARDENED}
    )


def _strong_effect_capability(
    manifest: CapabilityManifest,
    capability: Capability,
    witness_validator: CapabilityWitnessValidator | None = None,
) -> bool:
    r = manifest.record(capability)
    return bool(
        r
        and r.bindable
        and _record_strongly_witnessed(r, witness_validator)
        and r.enforcement in {Enforcement.TOOL, Enforcement.EXTERNAL, Enforcement.HARDENED}
    )


def _strong_isolation(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> bool:
    r = manifest.record(Capability.PROCESS_ISOLATION)
    return bool(
        r
        and r.bindable
        and _record_strongly_witnessed(r, witness_validator)
        and r.enforcement in {Enforcement.EXTERNAL, Enforcement.HARDENED}
    )


def _strong_machine_proof(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> bool:
    r = manifest.record(Capability.MACHINE_PROOF)
    return bool(
        r
        and r.bindable
        and _record_strongly_witnessed(r, witness_validator)
        and r.enforcement in {Enforcement.EXTERNAL, Enforcement.HARDENED, Enforcement.TOOL}
    )


def _profile_for(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> BackendProfile:
    ext_runtime = _conformant_external_runtime(manifest, witness_validator)
    isolated = _strong_isolation(manifest, witness_validator)
    if ext_runtime and isolated:
        return BackendProfile.HARDENED
    if ext_runtime:
        return BackendProfile.REFERENCE_EXEC
    if any(
        _strong_effect_capability(manifest, c, witness_validator)
        for c in (
            Capability.RETRIEVAL,
            Capability.CODE_EXECUTION,
            Capability.TOOL_CALLING,
            Capability.PERSISTENCE,
        )
    ) or _strong_external_verifier(manifest, witness_validator):
        return BackendProfile.TOOL_AUGMENTED
    return BackendProfile.NATIVE


def _validation_ceiling(manifest: CapabilityManifest, witness_validator: CapabilityWitnessValidator | None = None) -> ValidationGrade:
    if _strong_machine_proof(manifest, witness_validator):
        return ValidationGrade.MACHINE_VERIFIED
    if _strong_external_verifier(manifest, witness_validator):
        return ValidationGrade.EXTERNAL_VERIFIED
    if any(
        _strong_effect_capability(manifest, c, witness_validator)
        for c in (
            Capability.RETRIEVAL,
            Capability.CODE_EXECUTION,
            Capability.TOOL_CALLING,
        )
    ):
        return ValidationGrade.TOOL_GROUNDED
    return ValidationGrade.SELF_CHECKED


def bootstrap_portable(manifest: CapabilityManifest, *, capability_witness_validator: CapabilityWitnessValidator | None = None) -> PortableBootstrapResult:
    """Bind a brand-agnostic host to the mandatory ALMANAL runtime contract.

    Minimum NATIVE boot requires:
      REASON + CONTEXT_STATE + STRUCTURED_OUTPUT.

    Stronger backend labels are licensed only by witnessed, protocol-compatible
    capabilities. Product/model names are irrelevant.
    """

    missing = tuple(
        sorted(
            (c for c in MINIMUM_PORTABLE_CAPABILITIES if not manifest.available(c)),
            key=lambda c: c.name,
        )
    )
    if missing:
        return PortableBootstrapResult(
            status=BootstrapStatus.BLOCKED,
            profile=None,
            bindings=(),
            missing_required_capabilities=missing,
            optional_available=tuple(
                sorted(
                    (c for c in OPTIONAL_PORTABLE_CAPABILITIES if manifest.available(c)),
                    key=lambda c: c.name,
                )
            ),
            residuals=(
                "minimum portable runtime cannot be instantiated",
                "UNKNOWN capabilities are treated as unavailable",
            ),
            can_claim_external_enforcement=False,
            can_claim_independent_verification=False,
            validation_ceiling=ValidationGrade.SELF_CHECKED,
        )

    profile = _profile_for(manifest, capability_witness_validator)
    external_runtime = profile >= BackendProfile.REFERENCE_EXEC
    state_enforcement = Enforcement.EXTERNAL if external_runtime else Enforcement.INTERNAL

    bindings = [
        RuntimeOperatorBinding(
            "FREEZE_TASK_AND_CRITERION",
            frozenset({Capability.REASON, Capability.CONTEXT_STATE}),
            "portable runtime ledger",
            state_enforcement,
        ),
        RuntimeOperatorBinding(
            "TRACK_RUNTIME_STATE",
            frozenset({Capability.CONTEXT_STATE, Capability.STRUCTURED_OUTPUT}),
            "portable runtime card/checkpoint",
            state_enforcement,
        ),
        RuntimeOperatorBinding(
            "ECONOMY_GATE",
            frozenset({Capability.REASON, Capability.CONTEXT_STATE}),
            "thin cognitive value-of-computation gate",
            state_enforcement,
        ),
        RuntimeOperatorBinding(
            "VALIDATE_EPISTEMIC_CLAIM",
            frozenset({Capability.REASON, Capability.CONTEXT_STATE}),
            "typed epistemic claim-validation invariant",
            state_enforcement,
        ),
        RuntimeOperatorBinding(
            "GENERATE_CANDIDATE",
            frozenset({Capability.REASON}),
            "host reasoning",
            Enforcement.INTERNAL,
        ),
        RuntimeOperatorBinding(
            "CHALLENGE_CANDIDATE",
            frozenset({Capability.REASON}),
            "host reasoning in distinct adversarial role",
            Enforcement.INTERNAL,
            external_independence=False,
        ),
        RuntimeOperatorBinding(
            "REPAIR_CANDIDATE",
            frozenset({Capability.REASON}),
            "host reasoning",
            Enforcement.INTERNAL,
        ),
        RuntimeOperatorBinding(
            "EVALUATE_CANDIDATE",
            frozenset({Capability.REASON}),
            "frozen evaluation contract",
            Enforcement.INTERNAL,
        ),
        RuntimeOperatorBinding(
            "SCHEDULE_VERIFICATION",
            frozenset({Capability.REASON, Capability.CONTEXT_STATE}),
            "impact-local staged verifier",
            state_enforcement,
        ),
        RuntimeOperatorBinding(
            "BUDGET_AND_STOP",
            frozenset({Capability.CONTEXT_STATE}),
            "portable runtime ledger",
            state_enforcement,
        ),
    ]

    optional_available = tuple(
        sorted(
            (c for c in OPTIONAL_PORTABLE_CAPABILITIES if manifest.available(c)),
            key=lambda c: c.name,
        )
    )

    if _strong_effect_capability(manifest, Capability.RETRIEVAL, capability_witness_validator):
        bindings.append(
            RuntimeOperatorBinding(
                "RETRIEVE_EVIDENCE",
                frozenset({Capability.RETRIEVAL}),
                "host retrieval interface",
                manifest.enforcement_of(Capability.RETRIEVAL) or Enforcement.TOOL,
            )
        )
    if _strong_effect_capability(manifest, Capability.CODE_EXECUTION, capability_witness_validator):
        bindings.append(
            RuntimeOperatorBinding(
                "EXECUTE_COMPUTATION",
                frozenset({Capability.CODE_EXECUTION}),
                "host code execution interface",
                manifest.enforcement_of(Capability.CODE_EXECUTION) or Enforcement.TOOL,
            )
        )
    if _strong_effect_capability(manifest, Capability.PERSISTENCE, capability_witness_validator):
        bindings.append(
            RuntimeOperatorBinding(
                "PERSIST_ARTIFACT",
                frozenset({Capability.PERSISTENCE}),
                "host persistence interface",
                manifest.enforcement_of(Capability.PERSISTENCE) or Enforcement.TOOL,
            )
        )
    if _strong_effect_capability(manifest, Capability.TOKEN_COUNT, capability_witness_validator):
        bindings.append(
            RuntimeOperatorBinding(
                "COUNT_TOKENS",
                frozenset({Capability.TOKEN_COUNT}),
                "host tokenizer/counter",
                manifest.enforcement_of(Capability.TOKEN_COUNT) or Enforcement.TOOL,
            )
        )
    if _strong_external_verifier(manifest, capability_witness_validator):
        bindings.append(
            RuntimeOperatorBinding(
                "EXTERNAL_VERIFY",
                frozenset({Capability.EXTERNAL_VERIFICATION}),
                "witnessed external verifier",
                manifest.enforcement_of(Capability.EXTERNAL_VERIFICATION)
                or Enforcement.EXTERNAL,
                external_independence=True,
            )
        )

    external_verification = _strong_external_verifier(manifest, capability_witness_validator)

    residuals: list[str] = []
    status = BootstrapStatus.READY
    if profile is BackendProfile.NATIVE:
        status = BootstrapStatus.DEGRADED
        residuals.extend([
            "runtime enforcement is internal to the same reasoning host",
            "same-host challenge is not independent validation",
            "persistent revision cannot be described as externally enforced",
        ])
    elif profile is BackendProfile.TOOL_AUGMENTED:
        status = BootstrapStatus.DEGRADED
        residuals.append(
            "tools are available, but core runtime invariants remain internally enforced"
        )

    ext_record = manifest.record(Capability.EXTERNAL_RUNTIME)
    if ext_record and ext_record.bindable and not external_runtime:
        residuals.append(
            "external runtime claim was not promoted: missing strong witness, "
            "external enforcement, or ALMANAL runtime protocol conformance"
        )

    verifier_record = manifest.record(Capability.EXTERNAL_VERIFICATION)
    if verifier_record and verifier_record.bindable and not external_verification:
        residuals.append(
            "external verifier claim was not promoted to independence: insufficient witness/enforcement"
        )

    if not external_verification:
        residuals.append("no independently witnessed external verification bound")
    if not _strong_effect_capability(manifest, Capability.TOKEN_COUNT, capability_witness_validator):
        residuals.append("exact provider token counting unavailable")
    if not _strong_effect_capability(manifest, Capability.PERSISTENCE, capability_witness_validator):
        residuals.append("durable persistence unavailable; result is session-scoped")

    return PortableBootstrapResult(
        status=status,
        profile=profile,
        bindings=tuple(bindings),
        missing_required_capabilities=(),
        optional_available=optional_available,
        residuals=tuple(residuals),
        can_claim_external_enforcement=external_runtime,
        can_claim_independent_verification=external_verification,
        validation_ceiling=_validation_ceiling(manifest, capability_witness_validator),
    )


def validate_binding_claims(
    result: PortableBootstrapResult,
    *,
    claims_external_enforcement: bool,
    claims_independent_verification: bool,
    claimed_validation_grade: ValidationGrade | None = None,
) -> None:
    if claims_external_enforcement and not result.can_claim_external_enforcement:
        raise AlmanalError(
            "portable host cannot claim external runtime enforcement under this profile"
        )
    if claims_independent_verification and not result.can_claim_independent_verification:
        raise AlmanalError(
            "portable host cannot claim independent verification without a strongly witnessed external capability"
        )
    if claimed_validation_grade is not None and claimed_validation_grade > result.validation_ceiling:
        raise AlmanalError(
            f"claimed validation grade {claimed_validation_grade.name} exceeds "
            f"bootstrap ceiling {result.validation_ceiling.name}"
        )


def compact_runtime_card(
    *,
    epoch_id: str,
    profile: BackendProfile,
    validation_grade: ValidationGrade,
    task_ref: str,
    baseline_ref: str,
    criterion_ref: str,
    stage: str,
    steps_remaining: int,
    verification_status: str,
    status: str,
    mounted_capsules: tuple[str, ...] = (),
    residuals: tuple[str, ...] = (),
) -> dict[str, object]:
    """Small continuation-safe checkpoint representation without chain-of-thought."""
    if steps_remaining < 0:
        raise AlmanalError("steps_remaining must be >= 0")
    if not epoch_id or not task_ref or not baseline_ref or not criterion_ref:
        raise AlmanalError("runtime card requires epoch/task/baseline/criterion identity")
    return {
        "epoch_id": epoch_id,
        "profile": profile.name,
        "validation_grade": validation_grade.name,
        "task_ref": task_ref,
        "baseline_ref": baseline_ref,
        "criterion_ref": criterion_ref,
        "stage": stage,
        "steps_remaining": steps_remaining,
        "verification_status": verification_status,
        "status": status,
        "mounted_capsules": list(mounted_capsules),
        "residuals": list(residuals),
    }
