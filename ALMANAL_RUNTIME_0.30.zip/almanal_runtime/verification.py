from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from enum import Enum, auto
from typing import Callable
from .certificate import Certificate, FormalStatus, EmpiricalStatus, IndependenceStatus
from .model import ObjectId
from .errors import VerificationViolation

class VerificationBasis(Enum):
    STRUCTURE_ONLY = auto()
    RUNTIME_EVALUATOR = auto()
    MACHINE_PROOF = auto()
    EXTERNAL_REVIEW = auto()

@dataclass(frozen=True, slots=True)
class VerificationReceipt:
    receipt_id: str
    certificate_id: str
    subject_ref: ObjectId
    criterion_snapshot_ref: str
    verifier_ref: str
    basis: VerificationBasis
    passed: bool
    basis_attestation_ref: str = ""

Verifier = Callable[[Certificate], bool]
VerificationBasisValidator = Callable[[str, VerificationBasis, str], bool]
IndependenceAuditValidator = Callable[[Certificate], bool]

def verify_certificate(
    certificate: Certificate,
    *,
    verifier_ref: str,
    basis: VerificationBasis,
    verifier: Verifier,
    basis_attestation_ref: str = "",
    basis_validator: VerificationBasisValidator | None = None,
    independence_validator: IndependenceAuditValidator | None = None,
) -> VerificationReceipt:
    certificate.validate_structure()
    try:
        passed = bool(verifier(certificate))
    except Exception as exc:
        raise VerificationViolation(f"verifier {verifier_ref} failed: {exc}") from exc
    if not passed:
        raise VerificationViolation(f"verifier {verifier_ref} rejected certificate")

    if certificate.formal_status is FormalStatus.PROVED:
        if basis not in {VerificationBasis.MACHINE_PROOF, VerificationBasis.EXTERNAL_REVIEW}:
            raise VerificationViolation(
                "FormalStatus.PROVED requires MACHINE_PROOF or EXTERNAL_REVIEW receipt"
            )
    if certificate.empirical_status is EmpiricalStatus.SUPPORTED:
        if basis not in {VerificationBasis.RUNTIME_EVALUATOR, VerificationBasis.EXTERNAL_REVIEW}:
            raise VerificationViolation(
                "EmpiricalStatus.SUPPORTED requires RUNTIME_EVALUATOR or EXTERNAL_REVIEW receipt"
            )

    if certificate.independence_status is IndependenceStatus.INDEPENDENCE_SUPPORTED_SCOPED:
        if independence_validator is None:
            raise VerificationViolation("scoped independence requires a host/runtime dependency-overlap audit validator")
        try:
            independent_ok = bool(independence_validator(certificate))
        except Exception:
            independent_ok = False
        if not independent_ok:
            raise VerificationViolation("dependency-overlap audit did not validate scoped independence")

    # Strong basis names are claims about an external/machine trust boundary; the
    # enum and verifier callback cannot attest themselves. A host/runtime validator
    # must bind the verifier identity+basis to an actual attestation witness.
    if basis in {VerificationBasis.MACHINE_PROOF, VerificationBasis.EXTERNAL_REVIEW}:
        if not basis_attestation_ref or basis_validator is None:
            raise VerificationViolation(
                "MACHINE_PROOF/EXTERNAL_REVIEW basis requires host-validated attestation evidence"
            )
        try:
            basis_ok = bool(basis_validator(verifier_ref, basis, basis_attestation_ref))
        except Exception:
            basis_ok = False
        if not basis_ok:
            raise VerificationViolation("verification basis attestation was not validated")

    return VerificationReceipt(
        receipt_id=f"vr:{certificate.certificate_id}:{verifier_ref}:{basis.name}",
        certificate_id=certificate.certificate_id,
        subject_ref=certificate.subject_ref,
        criterion_snapshot_ref=certificate.criterion_snapshot_ref,
        verifier_ref=verifier_ref,
        basis=basis,
        passed=True,
        basis_attestation_ref=basis_attestation_ref if basis in {VerificationBasis.MACHINE_PROOF, VerificationBasis.EXTERNAL_REVIEW} else "",
    )

# ---- Compact epistemic invariants (14.14) ---------------------------------
# Validation primitives, not a standalone Truth Axis/subsystem. String tags keep
# the HOT surface smaller than a parallel hierarchy of truth-specific objects.

VALID_CLAIM_MODES = frozenset({"UNIVERSAL", "EXISTENTIAL", "GENERIC", "STATISTICAL", "OTHER"})

@dataclass(frozen=True, slots=True)
class EpistemicClaimIdentity:
    proposition: str
    scope: str
    conditions: tuple[str, ...] = ()
    mode: str = "OTHER"

    def __post_init__(self) -> None:
        if not self.proposition or not self.scope or self.mode not in VALID_CLAIM_MODES:
            raise VerificationViolation("claim identity requires proposition/scope/valid mode")

    def fingerprint(self) -> str:
        return sha256("|".join((self.proposition, self.scope, self.mode, *self.conditions)).encode("utf-8")).hexdigest()


class ClaimRevisionStatus(Enum):
    SAME_CLAIM = auto()
    NEW_CLAIM_REQUIRED = auto()


def assess_claim_revision(
    before: EpistemicClaimIdentity,
    after: EpistemicClaimIdentity,
    *,
    outcome_seen: bool,
) -> tuple[ClaimRevisionStatus, str]:
    if before.fingerprint() == after.fingerprint():
        return ClaimRevisionStatus.SAME_CLAIM, "claim identity unchanged"
    if outcome_seen:
        return ClaimRevisionStatus.NEW_CLAIM_REQUIRED, "post-outcome proposition/scope/conditions/mode change creates a new claim; it cannot launder the old claim"
    return ClaimRevisionStatus.NEW_CLAIM_REQUIRED, "claim identity changed before outcome; freeze the new claim separately"

VALID_EVIDENCE_INPUT_CLASSES = frozenset({"OBJECTIVE_EVIDENCE_CANDIDATE", "SUBJECTIVE_STATE"})


def admissible_objective_evidence(input_class: str) -> bool:
    if input_class not in VALID_EVIDENCE_INPUT_CLASSES:
        raise VerificationViolation("unknown evidence input class")
    return input_class == "OBJECTIVE_EVIDENCE_CANDIDATE"


def validate_epistemic_claim(
    *,
    proposition: str,
    scope: str,
    mode: str = "OTHER",
    known_in_scope_contradiction: bool = False,
    valid_counterexample_found: bool = False,
    internal_contradiction: bool = False,
    verified_proof: bool = False,
    supporting_objective_evidence: bool = False,
    checks_performed: bool = True,
) -> tuple[str, bool, str]:
    """Return (status, absolute_promotion_allowed, reason).

    One counterexample falsifies UNIVERSAL claims only. Generic/statistical claims
    expect possible exceptions. Passing the guard is never itself proof.
    """
    if not proposition or not scope or mode not in VALID_CLAIM_MODES:
        raise VerificationViolation("claim requires proposition/scope/valid mode")
    if internal_contradiction:
        return "CONTRADICTORY", False, "internal contradiction blocks claim promotion"
    if known_in_scope_contradiction:
        return "FALSE", False, "known reality inside declared scope contradicts claim"
    if valid_counterexample_found and mode == "UNIVERSAL":
        return "FALSE", False, "valid in-domain counterexample falsifies universal claim"
    if verified_proof:
        return "PROVED", True, "verified proof/closed-scope witness licenses proved status"
    if supporting_objective_evidence:
        return "SUPPORTED", False, "objective evidence supports claim without absolute proof"
    if checks_performed:
        return "NOT_FALSIFIED", False, "absence of blocking contradiction is not proof"
    return "UNKNOWN", False, "insufficient checked evidence"
