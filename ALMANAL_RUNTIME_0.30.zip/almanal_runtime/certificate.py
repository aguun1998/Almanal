from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional
from .model import ObjectId
from .errors import CertificateViolation

class TriState(Enum):
    YES = auto()
    NO = auto()
    UNKNOWN = auto()

@dataclass(frozen=True, slots=True)
class SeparationVector:
    role: TriState = TriState.UNKNOWN
    execution: TriState = TriState.UNKNOWN
    model_root: TriState = TriState.UNKNOWN
    evidence_root: TriState = TriState.UNKNOWN
    organization: TriState = TriState.UNKNOWN

class IndependenceStatus(Enum):
    NOT_INDEPENDENT = auto()
    SEPARATED_BUT_DEPENDENCE_UNKNOWN = auto()
    INDEPENDENCE_SUPPORTED_SCOPED = auto()
    UNKNOWN = auto()

class FormalStatus(Enum):
    PROVED = auto()
    DISPROVED = auto()
    UNPROVED = auto()
    NOT_APPLICABLE = auto()

class EmpiricalStatus(Enum):
    SUPPORTED = auto()
    REFUTED = auto()
    INCONCLUSIVE = auto()
    NOT_TESTED = auto()
    NOT_APPLICABLE = auto()

class ProcedureStatus(Enum):
    COMPLETE = auto()
    DEGRADED = auto()
    INCOMPLETE = auto()
    BLOCKED = auto()
    INVALIDATED = auto()

@dataclass(frozen=True, slots=True)
class Certificate:
    certificate_id: str
    subject_ref: ObjectId
    criterion_snapshot_ref: str
    scope: str
    assumptions: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    proof_ref: Optional[str] = None
    assessor_refs: tuple[str, ...] = ()
    separation: SeparationVector = SeparationVector()
    independence_status: IndependenceStatus = IndependenceStatus.UNKNOWN
    independence_audit_ref: Optional[str] = None
    formal_status: FormalStatus = FormalStatus.UNPROVED
    empirical_status: EmpiricalStatus = EmpiricalStatus.NOT_TESTED
    procedure_status: ProcedureStatus = ProcedureStatus.INCOMPLETE
    confidence_basis_points: Optional[int] = None
    residual: tuple[str, ...] = ()
    version: int = 1

    def validate_structure(self) -> None:
        if self.formal_status is FormalStatus.PROVED and not self.proof_ref:
            raise CertificateViolation("FormalStatus.PROVED requires proof_ref")
        if (
            self.empirical_status is EmpiricalStatus.SUPPORTED
            and not self.evidence_refs
        ):
            raise CertificateViolation("EmpiricalStatus.SUPPORTED requires evidence")
        if self.independence_status is IndependenceStatus.INDEPENDENCE_SUPPORTED_SCOPED:
            if not self.independence_audit_ref:
                raise CertificateViolation("scoped independence requires a dependency-overlap audit reference")
            if self.separation.model_root is not TriState.YES:
                raise CertificateViolation("scoped independence requires witnessed model-root separation")
            if self.separation.evidence_root is not TriState.YES:
                raise CertificateViolation("scoped independence requires witnessed evidence-root separation")
        if self.confidence_basis_points is not None:
            if not 0 <= self.confidence_basis_points <= 10_000:
                raise CertificateViolation("confidence must be 0..10000 bp")

    def validate(self) -> None:
        # Backward-compatible structural validation only. Runtime persistence
        # requires a separate VerificationReceipt.
        self.validate_structure()

    def is_positive_for_persistence(self) -> bool:
        if self.procedure_status is not ProcedureStatus.COMPLETE:
            return False
        return (
            self.formal_status is FormalStatus.PROVED
            or self.empirical_status is EmpiricalStatus.SUPPORTED
        )
