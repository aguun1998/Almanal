from dataclasses import dataclass
from enum import Enum, auto
from .errors import OntologyViolation

class ConceptCategory(Enum):
    META_ALGORITHM = auto()
    ALGORITHM = auto()
    PROOF = auto()
    THEOREM = auto()
    VALIDATION = auto()
    IMPROVEMENT = auto()
    OPTIMUM = auto()
    INDEPENDENCE = auto()

@dataclass(frozen=True, slots=True)
class ConceptLicense:
    category: ConceptCategory
    necessary_conditions: tuple[str, ...]
    witnesses: tuple[str, ...]
    licensed: bool = True

    def validate(self) -> None:
        if self.licensed and set(self.necessary_conditions) - set(self.witnesses):
            missing = sorted(set(self.necessary_conditions) - set(self.witnesses))
            raise OntologyViolation(
                f"licensed {self.category.name} missing witnesses: {missing}"
            )

class OntologyRegistry:
    def __init__(self) -> None:
        self.__licenses: dict[tuple[str, ConceptCategory], ConceptLicense] = {}

    def register(self, subject: str, license: ConceptLicense) -> None:
        license.validate()
        self.__licenses[(subject, license.category)] = license

    def get(self, subject: str, category: ConceptCategory) -> ConceptLicense | None:
        return self.__licenses.get((subject, category))
