from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Callable, Generic, TypeVar

from .economy import (
    CognitiveOffer, EconomyDecision, EconomyGateResult, EconomyGovernor,
)


T = TypeVar("T")


class GovernedStatus(Enum):
    EXECUTED = auto()
    SKIPPED = auto()
    BLOCKED = auto()
    FAILED = auto()


@dataclass(frozen=True, slots=True)
class GovernedExecution(Generic[T]):
    status: GovernedStatus
    gate: EconomyGateResult
    value: T | None = None
    error: str | None = None


def execute_governed(
    governor: EconomyGovernor,
    offer: CognitiveOffer,
    fn: Callable[[], T],
) -> GovernedExecution[T]:
    """Execute a cognitive operator only if the global economy gate admits it."""
    gate = governor.consider(offer)

    if gate.decision is EconomyDecision.BLOCKED_MANDATORY_BUDGET:
        return GovernedExecution(
            GovernedStatus.BLOCKED,
            gate,
            error="mandatory cognitive action could not be funded",
        )

    if gate.decision in {
        EconomyDecision.SKIP_NONPOSITIVE_VOC,
        EconomyDecision.SKIP_INSUFFICIENT_MARGIN,
        EconomyDecision.SKIP_BUDGET,
    }:
        return GovernedExecution(GovernedStatus.SKIPPED, gate)

    try:
        return GovernedExecution(
            GovernedStatus.EXECUTED,
            gate,
            value=fn(),
        )
    except Exception as exc:
        return GovernedExecution(
            GovernedStatus.FAILED,
            gate,
            error=f"{type(exc).__name__}: {exc}",
        )
