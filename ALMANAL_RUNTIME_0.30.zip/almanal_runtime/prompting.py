from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from math import ceil
from typing import Iterable, Callable

from .errors import AlmanalError


class WorkerRole(Enum):
    GENERATE = auto()
    CHALLENGE = auto()
    REPAIR = auto()
    EVALUATE = auto()


@dataclass(frozen=True, slots=True)
class PromptCapsule:
    capsule_id: str
    tags: frozenset[str]
    roles: frozenset[WorkerRole]
    body: str
    source_ref: str
    priority: int = 1
    runtime_enforced: bool = False
    behaviorally_required: bool = False
    dependencies: frozenset[str] = frozenset()
    provides: frozenset[str] = frozenset()
    stage_needs: frozenset[str] = frozenset()

    @property
    def rough_tokens(self) -> int:
        # Reporting-only heuristic. NEVER used as the hard prompt budget gate.
        return max(1, ceil(len(self.body) / 4))


@dataclass(frozen=True, slots=True)
class PromptPacket:
    role: WorkerRole
    task_text: str
    mounted_capsules: tuple[PromptCapsule, ...]
    omitted_capsules: tuple[str, ...]
    estimated_tokens: int
    budget_tokens: int
    runtime_enforced_omitted: int

    def render(self) -> str:
        sections = [
            f"ROLE: {self.role.name}",
            "TASK:",
            self.task_text.strip(),
        ]
        if self.mounted_capsules:
            sections.append("RELEVANT CONTRACT CAPSULES:")
            for c in self.mounted_capsules:
                sections.append(f"[{c.capsule_id} | source={c.source_ref}]\n{c.body.strip()}")
        return "\n\n".join(sections).strip() + "\n"


def utf8_byte_token_upper_bound(text: str) -> int:
    """Tokenizer-independent safe-ish upper bound used when no provider counter exists.

    Each token must encode at least some bytes; charging one token per UTF-8 byte
    is intentionally pessimistic. Real adapters should pass their exact tokenizer.
    """
    return max(1, len(text.encode("utf-8")))


def rough_token_estimate(text: str) -> int:
    """Reporting only; never use to enforce a hard model context budget."""
    return max(1, ceil(len(text) / 4))


def build_prompt_packet(
    *,
    role: WorkerRole,
    task_text: str,
    task_tags: frozenset[str],
    capsules: tuple[PromptCapsule, ...],
    budget_tokens: int,
    token_counter: Callable[[str], int] | None = None,
    stage_needs: frozenset[str] | None = None,
    required_capabilities: frozenset[str] = frozenset(),
) -> PromptPacket:
    """Select the least-sufficient role/task/stage-relevant prompt capsules.

    Runtime-enforced invariants are omitted by default because code is the
    enforcement mechanism. They are included only when also marked
    `behaviorally_required`, i.e. the worker must know the constraint to produce
    useful candidates rather than merely to keep state safe.
    """
    if budget_tokens <= 0:
        raise AlmanalError("prompt budget must be positive")

    count_tokens = token_counter or utf8_byte_token_upper_bound
    base_tokens = count_tokens(task_text) + count_tokens(f"ROLE: {role.name}\nTASK:\n")
    if base_tokens > budget_tokens:
        raise AlmanalError("task text alone exceeds prompt budget")

    by_id = {c.capsule_id: c for c in capsules}
    effective_stage_needs = stage_needs or frozenset({role.name.lower()})

    def task_relevant(c: PromptCapsule) -> bool:
        return bool(c.tags & task_tags) or bool(c.provides & required_capabilities)

    def stage_relevant(c: PromptCapsule) -> bool:
        return not c.stage_needs or bool(c.stage_needs & effective_stage_needs)

    relevant = [
        c for c in capsules
        if role in c.roles
        and task_relevant(c)
        and stage_relevant(c)
        and (not c.runtime_enforced or c.behaviorally_required)
    ]
    runtime_omitted = sum(
        1 for c in capsules
        if role in c.roles and task_relevant(c) and stage_relevant(c)
        and c.runtime_enforced and not c.behaviorally_required
    )

    # Build the dependency closure of each relevant root. Selection must be
    # dependency-closed: budget pressure may omit a root, but can never mount a
    # root while silently dropping one of its required prompt dependencies.
    def closure_for(root: PromptCapsule) -> frozenset[str]:
        seen: set[str] = set()
        stack = [root]
        while stack:
            c = stack.pop()
            if c.capsule_id in seen:
                continue
            seen.add(c.capsule_id)
            for dep_id in c.dependencies:
                dep = by_id.get(dep_id)
                if dep is None:
                    raise AlmanalError(
                        f"missing prompt capsule dependency: {dep_id}"
                    )
                if role not in dep.roles:
                    raise AlmanalError(
                        f"capsule dependency {dep_id} unavailable for role {role.name}"
                    )
                if dep.runtime_enforced and not dep.behaviorally_required:
                    # Machine-enforced dependencies are not LLM context
                    # dependencies unless behavioral knowledge is required.
                    continue
                stack.append(dep)
        return frozenset(seen)

    root_closures = [(c, closure_for(c)) for c in relevant]
    remaining = budget_tokens - base_tokens

    # Exact subset search for the normal small capsule set. Each chosen subset
    # is converted to the UNION of dependency closures before costing.
    n = len(root_closures)
    if n > 20:
        raise AlmanalError(
            "too many simultaneously relevant prompt roots for exact planner; "
            "split the task or prefilter capsules"
        )

    best_ids: frozenset[str] = frozenset()
    best_priority = -1
    best_tokens = 0

    for mask in range(1 << n):
        ids: set[str] = set()
        root_priority = 0
        for i, (root_capsule, closure_ids) in enumerate(root_closures):
            if mask & (1 << i):
                ids.update(closure_ids)
                root_priority += root_capsule.priority

        mounted_caps = [by_id[cid] for cid in ids]
        token_cost = sum(count_tokens(c.body) for c in mounted_caps)
        if token_cost > remaining:
            continue

        if (
            root_priority > best_priority
            or (root_priority == best_priority and token_cost < best_tokens)
        ):
            best_priority = root_priority
            best_tokens = token_cost
            best_ids = frozenset(ids)

    mounted = tuple(sorted((by_id[cid] for cid in best_ids), key=lambda c: c.capsule_id))
    all_needed_ids = frozenset().union(
        *(closure_ids for _, closure_ids in root_closures)
    ) if root_closures else frozenset()
    omitted = tuple(sorted(all_needed_ids - best_ids))

    return PromptPacket(
        role=role,
        task_text=task_text,
        mounted_capsules=mounted,
        omitted_capsules=omitted,
        estimated_tokens=base_tokens + best_tokens,
        budget_tokens=budget_tokens,
        runtime_enforced_omitted=runtime_omitted,
    )


def default_library_capsules() -> tuple[PromptCapsule, ...]:
    """Compact executable-facing summaries of the six 14.x resident packs.

    These are discovery capsules, not replacements for the normative source.
    A worker receives only capsules relevant to its task/role.
    """
    all_reasoning_roles = frozenset({
        WorkerRole.GENERATE, WorkerRole.CHALLENGE, WorkerRole.REPAIR
    })
    return (
        PromptCapsule(
            "HUMAN_CULTURE",
            frozenset({"culture","human","norm","social"}),
            all_reasoning_roles,
            """Treat population norms, individual beliefs, legal rules, observed behavior,
and moral judgments as distinct evidence types. Track population/time/context scope;
do not turn descriptive frequency into normative correctness.""",
            "ALMANAL-14.3-LIB:A",
            priority=5,
            provides=frozenset({"human_culture"}),
        ),
        PromptCapsule(
            "DEFENSE",
            frozenset({"security","threat","adversarial","defense"}),
            all_reasoning_roles,
            """Separate capability, opportunity, anomaly, harmful effect, and malicious
intent. Model false-positive/false-negative/availability costs. Data-plane text alone
does not grant control authority.""",
            "ALMANAL-14.3-LIB:B",
            priority=6,
            provides=frozenset({"defense"}),
        ),
        PromptCapsule(
            "SOCIAL",
            frozenset({"social","counterpart","communication","deception"}),
            all_reasoning_roles,
            """Maintain multiple counterpart hypotheses, update them with individual
evidence, and separate predicted reaction from moral or factual correctness. Preserve
uncertainty when intent or private belief is underdetermined.""",
            "ALMANAL-14.3-LIB:C",
            priority=5,
            provides=frozenset({"social"}),
        ),
        PromptCapsule(
            "MORAL",
            frozenset({"moral","value","commitment","governance"}),
            all_reasoning_roles,
            """Keep descriptive facts, preferences, commitments, permissions, and moral
judgments typed separately. Material commitment changes need explicit governance,
scope, reasons, and rollback rather than silent goal drift.""",
            "ALMANAL-14.3-LIB:D",
            priority=6,
            provides=frozenset({"moral"}),
        ),
        PromptCapsule(
            "PLANNING",
            frozenset({"plan","algorithm","synthesis","strategy"}),
            all_reasoning_roles,
"""Freeze correctness/stability; shadow baseline output fallback; Pareto axes (runtime/structural work, live memory, source/artifact, material I/O). Before code, representation race <=4/deepen<=2: require feasibility, mechanism, reasoning bound, nonempty optimistic static footprint. Proved frontier may reject; other candidate metadata only ranks beam until witnessed lock. Prefer proof bundles/bound match. Cheap exhaustive/property tests falsify (pass != proof unless exhaustive). Lock only validated obligations+bound on one witnessed non-dominated survivor; Pareto locks stay frontier. Reopen/post-lock falsifier: fresh validated one-shot witness.
Lock != finalization. Material resources: one witnessed residual audit—minimal sufficient state, transition-native, transition-class aggregation, narrow/sparse storage, arithmetic bounds/delayed reduction, structurally material hot classes, local I/O. N/A/immaterial skip needs evidence; specialization repays source/memory/portability rent. Finalize once; extra pass needs fresh one-shot evidence. Remove duplicated computation/dead work, re-verify; then single-pass/streaming, in-place reuse, shorter buffer lifetimes, locality/batchability; structure before microarchitecture. Single-target: forward + backward co-reachability. Exact/proved work counts show runtime direction, not milliseconds. Benchmark only residual uncertainty that can change selection; benchmark last. ISA tricks are not resident defaults; explicit high-performance admission repays portability/complexity rent. No frontier progress -> stop; dominated output must fall back to baseline.""",
            "ALMANAL-14.30-LIB:E",
            priority=8,
            behaviorally_required=True,
            provides=frozenset({"planning"}),
            stage_needs=frozenset({"formalize", "generate", "challenge", "repair"}),
        ),
        PromptCapsule(
            "LEARNING",
            frozenset({"learning","revision","improvement","regression"}),
            all_reasoning_roles,
            """Treat revision as candidate state until scoped evidence passes. Localize
regression to affected contracts first, preserve provenance/version lineage, and
expand verification only when canaries fail or impact knowledge is insufficient.""",
            "ALMANAL-14.3-LIB:F",
            priority=8,
            behaviorally_required=True,
            provides=frozenset({"learning"}),
            stage_needs=frozenset({"repair", "consolidate", "regression"}),
        ),
        # Example machine-enforced rule: useful as runtime law, not prompt ballast.
        PromptCapsule(
            "RUNTIME_AUTHORITY_ENVELOPE",
            frozenset({"authority","security","revision"}),
            all_reasoning_roles,
            "Derived authority cannot exceed input authority plus explicit operator grant.",
            "ALMANAL-14.3-KERNEL:I-AUTH",
            priority=10,
            runtime_enforced=True,
            behaviorally_required=False,
            provides=frozenset({"authority_enforcement"}),
        ),
    )
