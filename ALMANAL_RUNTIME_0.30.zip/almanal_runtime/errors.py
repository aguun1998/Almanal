class AlmanalError(Exception):
    """Base runtime error."""

class DuplicateObject(AlmanalError): pass
class ObjectNotFound(AlmanalError): pass
class TypePromotionNotRegistered(AlmanalError): pass
class InvalidTransition(AlmanalError): pass
class RuntimeStopped(AlmanalError): pass
class BudgetExhausted(AlmanalError): pass
class ProvenanceViolation(AlmanalError): pass
class AuthorityViolation(AlmanalError): pass
class CertificateViolation(AlmanalError): pass
class PersistenceViolation(AlmanalError): pass
class ConformanceViolation(AlmanalError): pass
class LibraryViolation(AlmanalError): pass
class OntologyViolation(AlmanalError): pass
class InvalidQualityVector(AlmanalError): pass
class InvalidReferenceDomain(AlmanalError): pass
class SnapshotViolation(AlmanalError): pass

class VerificationViolation(AlmanalError): pass

class AssuranceViolation(AlmanalError): pass
