from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum, auto
from hashlib import sha256
from typing import Iterable, Mapping

from .errors import AssuranceViolation


class Materiality(IntEnum):
    TRIVIAL = 0
    ROUTINE = 1
    MATERIAL = 2
    HIGH_RISK = 3
    PROTECTED = 4


class VerificationTier(IntEnum):
    STATIC = 0
    CANARY = 1
    TARGETED = 2
    FULL = 3


@dataclass(frozen=True, slots=True)
class VerificationAction:
    """One verification option.

    `token_cost` is the resource-budget quantity.
    `decision_cost_utility` and `expected_loss_avoided_utility` are deliberately
    in the SAME decision-utility unit. This avoids comparing token counts
    directly with epistemic/decision value.

    `affected_by` lists semantic/runtime tags whose change can invalidate this
    verification result.
    """
    name: str
    token_cost: int
    decision_cost_utility: int
    expected_loss_avoided_utility: int
    affected_by: frozenset[str] = frozenset()
    tier: VerificationTier = VerificationTier.CANARY
    mandatory_when_impacted: bool = False
    always_run: bool = False
    version: str = "1"

    @property
    def net_decision_value(self) -> int:
        return self.expected_loss_avoided_utility - self.decision_cost_utility


@dataclass(frozen=True, slots=True)
class ChangeSet:
    changed_tags: frozenset[str]
    materiality: Materiality
    uncertainty_bp: int = 0
    release_gate: bool = False

    def __post_init__(self) -> None:
        if not 0 <= self.uncertainty_bp <= 10_000:
            raise AssuranceViolation("uncertainty_bp must be 0..10000")


@dataclass(frozen=True, slots=True)
class ImpactCoverageReceipt:
    graph_version: str
    verifier_ref: str
    scope: str
    passed: bool


class ImpactGraph:
    """Directed dependency graph: source tag -> dependent tag.

    Coverage is UNKNOWN by default. A MATERIAL/HIGH_RISK change may use targeted
    narrowing instead of FULL only after a scoped coverage verifier has issued a
    passed receipt for this graph version.
    """

    def __init__(
        self,
        edges: Mapping[str, Iterable[str]] | None = None,
        *,
        version: str = "1",
        _coverage_receipt: ImpactCoverageReceipt | None = None,
    ) -> None:
        self._edges: dict[str, frozenset[str]] = {
            k: frozenset(v) for k, v in (edges or {}).items()
        }
        self._version = version
        self._coverage_receipt = _coverage_receipt

    @property
    def version(self) -> str:
        return self._version

    @property
    def coverage_verified(self) -> bool:
        r = self._coverage_receipt
        return bool(r and r.passed and r.graph_version == self._version)

    @property
    def coverage_receipt(self) -> ImpactCoverageReceipt | None:
        return self._coverage_receipt

    def _copy_with_receipt(self, receipt: ImpactCoverageReceipt) -> "ImpactGraph":
        return ImpactGraph(
            self._edges, version=self._version, _coverage_receipt=receipt
        )

    def affected_closure(self, changed: frozenset[str]) -> frozenset[str]:
        seen = set(changed)
        stack = list(changed)
        while stack:
            current = stack.pop()
            for dep in self._edges.get(current, frozenset()):
                if dep not in seen:
                    seen.add(dep)
                    stack.append(dep)
        return frozenset(seen)


def verify_impact_graph(
    graph: ImpactGraph,
    *,
    verifier_ref: str,
    scope: str,
    verifier,
) -> ImpactGraph:
    """Issue a scoped coverage receipt only through an executed verifier."""
    passed = False
    try:
        passed = bool(verifier(graph))
    except Exception:
        passed = False
    receipt = ImpactCoverageReceipt(
        graph_version=graph.version,
        verifier_ref=verifier_ref,
        scope=scope,
        passed=passed,
    )
    return graph._copy_with_receipt(receipt)



@dataclass(frozen=True, slots=True)
class CacheReceipt:
    action_name: str
    action_version: str
    dependency_fingerprint: str
    passed: bool


class VerificationCache:
    """Cache only exact scoped verification results.

    Reuse is allowed only when action version and the fingerprints of every
    relevant dependency are identical.
    """

    def __init__(self) -> None:
        self._receipts: dict[tuple[str, str, str], CacheReceipt] = {}

    @staticmethod
    def dependency_fingerprint(
        action: VerificationAction,
        fingerprints: Mapping[str, str],
    ) -> str | None:
        if not action.affected_by:
            return None
        missing = sorted(tag for tag in action.affected_by if tag not in fingerprints)
        if missing:
            return None
        payload = "|".join(
            f"{tag}={fingerprints[tag]}" for tag in sorted(action.affected_by)
        )
        return sha256(payload.encode("utf-8")).hexdigest()

    def record(
        self,
        action: VerificationAction,
        fingerprints: Mapping[str, str],
        *,
        passed: bool,
    ) -> None:
        fp = self.dependency_fingerprint(action, fingerprints)
        if fp is None:
            return
        receipt = CacheReceipt(action.name, action.version, fp, passed)
        self._receipts[(action.name, action.version, fp)] = receipt

    def reusable_pass(
        self,
        action: VerificationAction,
        fingerprints: Mapping[str, str],
    ) -> bool:
        fp = self.dependency_fingerprint(action, fingerprints)
        if fp is None:
            return False
        r = self._receipts.get((action.name, action.version, fp))
        return bool(r and r.passed)


@dataclass(frozen=True, slots=True)
class AssuranceSelection:
    selected: tuple[VerificationAction, ...]
    skipped: tuple[VerificationAction, ...]
    cache_hits: tuple[VerificationAction, ...]
    affected_tags: frozenset[str]
    total_token_cost: int
    full_token_cost: int
    token_cost_avoided: int
    max_initial_tier: VerificationTier

    @property
    def selected_names(self) -> tuple[str, ...]:
        return tuple(a.name for a in self.selected)


def _max_initial_tier(
    change: ChangeSet, impact_graph: ImpactGraph
) -> VerificationTier:
    # PROTECTED/release changes always open FULL.
    if change.materiality is Materiality.PROTECTED or change.release_gate:
        return VerificationTier.FULL

    # MATERIAL/HIGH_RISK narrowing requires verified graph coverage. This
    # prevents a self-asserted "complete=True" flag from laundering away broad
    # verification.
    if change.materiality >= Materiality.MATERIAL:
        if not impact_graph.coverage_verified:
            return VerificationTier.FULL
        return VerificationTier.TARGETED

    if change.uncertainty_bp >= 5_000:
        return VerificationTier.TARGETED
    if change.materiality >= Materiality.ROUTINE:
        return VerificationTier.CANARY
    return VerificationTier.STATIC


def _optimal_optional_subset(
    actions: list[VerificationAction],
    token_budget: int,
) -> list[VerificationAction]:
    """Sparse 0/1 knapsack maximizing net decision utility under token budget."""
    if token_budget < 0 or not actions:
        return []

    # cost -> (net value, tuple(indices))
    states: dict[int, tuple[int, tuple[int, ...]]] = {0: (0, ())}
    for i, action in enumerate(actions):
        if action.net_decision_value <= 0:
            continue
        current = list(states.items())
        for cost, (value, chosen) in current:
            new_cost = cost + action.token_cost
            if new_cost > token_budget:
                continue
            new_value = value + action.net_decision_value
            incumbent = states.get(new_cost)
            candidate = (new_value, chosen + (i,))
            if incumbent is None or candidate[0] > incumbent[0]:
                states[new_cost] = candidate

    best_cost, (best_value, best_indices) = max(
        states.items(),
        key=lambda kv: (kv[1][0], -kv[0], tuple(-x for x in kv[1][1])),
    )
    return [actions[i] for i in best_indices]


def plan_verification(
    actions: tuple[VerificationAction, ...],
    *,
    change: ChangeSet,
    impact_graph: ImpactGraph,
    token_budget: int,
    fingerprints: Mapping[str, str] | None = None,
    cache: VerificationCache | None = None,
) -> AssuranceSelection:
    """Impact-local, staged verification planner.

    Pipeline:
      changed tags -> transitive affected closure
      -> mandatory impacted floor
      -> cheapest useful stage allowed by materiality/uncertainty
      -> exact optional selection under token budget.

    Full regression is opened only by explicit escalation triggers:
      PROTECTED change, release gate, or incomplete dependency graph.
    """
    if token_budget < 0:
        raise AssuranceViolation("token_budget must be >= 0")

    fingerprints = fingerprints or {}
    affected = impact_graph.affected_closure(change.changed_tags)
    max_tier = _max_initial_tier(change, impact_graph)

    impacted: list[VerificationAction] = []
    for action in actions:
        if not action.affected_by and not action.always_run:
            raise AssuranceViolation(
                f"verification action {action.name!r} is unscoped; "
                "declare affected_by tags or explicitly mark always_run"
            )
        if action.always_run or action.affected_by & affected:
            impacted.append(action)

    full_token_cost = sum(a.token_cost for a in actions)

    # Reuse exact scoped passes before spending new tokens.
    cache_hits: list[VerificationAction] = []
    runnable: list[VerificationAction] = []
    for action in impacted:
        if cache is not None and cache.reusable_pass(action, fingerprints):
            cache_hits.append(action)
        else:
            runnable.append(action)

    mandatory = [
        a for a in runnable
        if (
            a.always_run
            or (a.mandatory_when_impacted and bool(a.affected_by & affected))
        )
        and a.tier <= max_tier
    ]

    mandatory_cost = sum(a.token_cost for a in mandatory)
    if mandatory_cost > token_budget:
        raise AssuranceViolation("mandatory impacted assurance floor exceeds token budget")

    remaining = token_budget - mandatory_cost

    optional = [
        a for a in runnable
        if a not in mandatory
        and a.tier <= max_tier
        and a.net_decision_value > 0
    ]
    chosen_optional = _optimal_optional_subset(optional, remaining)
    selected = mandatory + chosen_optional

    skipped = [a for a in actions if a not in selected and a not in cache_hits]
    total = sum(a.token_cost for a in selected)

    return AssuranceSelection(
        selected=tuple(selected),
        skipped=tuple(skipped),
        cache_hits=tuple(cache_hits),
        affected_tags=affected,
        total_token_cost=total,
        full_token_cost=full_token_cost,
        token_cost_avoided=max(0, full_token_cost - total),
        max_initial_tier=max_tier,
    )


def escalate_verification(
    previous: AssuranceSelection,
    actions: tuple[VerificationAction, ...],
    *,
    failed_action_names: frozenset[str],
    token_budget_remaining: int,
    current_tier: VerificationTier | None = None,
) -> tuple[VerificationAction, ...]:
    """Escalate only after failure.

    Selects the next higher tier actions that overlap the failed actions'
    semantic tags, plus always-run actions. If the previous tier is already
    TARGETED, escalation may open FULL.
    """
    if not failed_action_names:
        return ()
    if token_budget_remaining < 0:
        raise AssuranceViolation("token_budget_remaining must be >= 0")

    by_name = {a.name: a for a in actions}
    failed = [by_name[n] for n in failed_action_names if n in by_name]
    failed_tags = frozenset().union(*(a.affected_by for a in failed)) if failed else frozenset()

    base_tier = previous.max_initial_tier if current_tier is None else current_tier
    next_tier = VerificationTier(
        min(int(base_tier) + 1, int(VerificationTier.FULL))
    )
    candidates = [
        a for a in actions
        if a not in previous.selected
        and a not in previous.cache_hits
        and a.tier <= next_tier
        and (
            a.always_run
            or not failed_tags
            or bool(a.affected_by & failed_tags)
        )
    ]

    # On escalation, positive-value optional cases are still preferred, but
    # mandatory impacted cases remain mandatory.
    mandatory = [a for a in candidates if a.mandatory_when_impacted or a.always_run]
    mandatory_cost = sum(a.token_cost for a in mandatory)
    if mandatory_cost > token_budget_remaining:
        raise AssuranceViolation("escalated mandatory checks exceed token budget")
    optional = [
        a for a in candidates
        if a not in mandatory and a.net_decision_value > 0
    ]
    chosen = _optimal_optional_subset(optional, token_budget_remaining - mandatory_cost)
    return tuple(mandatory + chosen)


# Backward-compatible thin wrapper for 0.2 callers. The old `cost` field no
# longer exists; callers should migrate to plan_verification().
def select_verification_actions(*args, **kwargs):
    raise AssuranceViolation(
        "0.3 API changed: use plan_verification() with explicit token and decision-utility costs"
    )
