from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction
from hashlib import sha256

from .errors import AlmanalError

@dataclass(frozen=True, slots=True)
class HumanOutcomeCandidate:
    """A human-comparable result. Internal implementation details are intentionally separate."""
    candidate_id: str
    human_readable_output: str
    internal_ref: str
    subjective_profile: tuple[tuple[str, str], ...] = ()
    hard_checks_passed: bool = True

    def __post_init__(self) -> None:
        if not self.candidate_id or not self.human_readable_output or not self.internal_ref:
            raise AlmanalError("preference candidate requires id/output/internal ref")
        if len(dict(self.subjective_profile)) != len(self.subjective_profile):
            raise AlmanalError("duplicate subjective profile dimension")


@dataclass(frozen=True, slots=True)
class PreferenceBundle:
    """Bundled subjective tradeoffs shown as a small set of outcomes, not internals."""
    bundle_id: str
    scope_ref: str
    dimensions: tuple[str, ...]
    candidates: tuple[HumanOutcomeCandidate, ...]
    question: str = "Which result do you prefer overall?"
    blind_labels: bool = True

    def __post_init__(self) -> None:
        if not self.bundle_id or not self.scope_ref or not self.dimensions or not self.question:
            raise AlmanalError("preference bundle requires id/scope/dimensions/question")
        if not 2 <= len(self.candidates) <= 3:
            raise AlmanalError("preference bundle must compress subjective choice to 2-3 outcome candidates")
        ids = [c.candidate_id for c in self.candidates]
        if len(set(ids)) != len(ids):
            raise AlmanalError("preference candidate ids must be unique")
        if any(not c.hard_checks_passed for c in self.candidates):
            raise AlmanalError("objective/hard defects must be repaired before subjective preference elicitation")

    def human_view(self) -> tuple[tuple[str, str], ...]:
        """Return only human-interpretable artifacts; never expose internal implementation refs."""
        labels = tuple(chr(ord("A") + i) for i in range(len(self.candidates)))
        return tuple((label, candidate.human_readable_output) for label, candidate in zip(labels, self.candidates))

    def fingerprint(self) -> str:
        payload = "|".join((
            self.bundle_id, self.scope_ref, *self.dimensions, self.question, str(int(self.blind_labels)),
            *[
                sha256((c.candidate_id + "|" + c.human_readable_output + "|" + c.internal_ref + "|" + repr(c.subjective_profile)).encode("utf-8")).hexdigest()
                for c in self.candidates
            ],
        ))
        return sha256(payload.encode("utf-8")).hexdigest()


class PreferenceQueryDecision(Enum):
    ASK_USER = auto()
    AUTO_SELECT_KNOWN_PREFERENCE = auto()
    DEFER_LOW_IMPACT = auto()


@dataclass(frozen=True, slots=True)
class PreferenceQueryPlan:
    decision: PreferenceQueryDecision
    reason: str


def plan_preference_query(
    *,
    preference_uncertainty: Fraction,
    decision_impact: Fraction,
    known_preference_confidence: Fraction,
    uncertainty_threshold: Fraction = Fraction(1, 4),
    impact_threshold: Fraction = Fraction(1, 4),
    confidence_threshold: Fraction = Fraction(3, 4),
) -> PreferenceQueryPlan:
    for value in (
        preference_uncertainty, decision_impact, known_preference_confidence,
        uncertainty_threshold, impact_threshold, confidence_threshold,
    ):
        if not Fraction(0) <= value <= 1:
            raise AlmanalError("preference query values must lie in [0,1]")
    if known_preference_confidence >= confidence_threshold:
        return PreferenceQueryPlan(
            PreferenceQueryDecision.AUTO_SELECT_KNOWN_PREFERENCE,
            "project-scoped preference evidence is sufficiently stable; avoid unnecessary user interruption",
        )
    if preference_uncertainty >= uncertainty_threshold and decision_impact >= impact_threshold:
        return PreferenceQueryPlan(
            PreferenceQueryDecision.ASK_USER,
            "preference uncertainty can materially change the outcome; ask once using bundled human-readable results",
        )
    return PreferenceQueryPlan(
        PreferenceQueryDecision.DEFER_LOW_IMPACT,
        "subjective difference is too low-impact or too small to justify a high-cost user preference query",
    )


@dataclass(frozen=True, slots=True)
class PreferenceEvidence:
    bundle_fingerprint: str
    selected_candidate_id: str
    scope_ref: str
    rationale: str = ""

    def __post_init__(self) -> None:
        if not self.bundle_fingerprint or not self.selected_candidate_id or not self.scope_ref:
            raise AlmanalError("preference evidence requires bundle/selection/scope")


def bundle_subjective_outcomes(
    *,
    bundle_id: str,
    scope_ref: str,
    dimensions: tuple[str, ...],
    candidates: tuple[HumanOutcomeCandidate, ...],
    question: str = "Which result do you prefer overall?",
    blind_labels: bool = True,
) -> PreferenceBundle:
    """Bundle many subjective decisions into 2-3 coherent, hard-valid outcome profiles."""
    return PreferenceBundle(
        bundle_id=bundle_id,
        scope_ref=scope_ref,
        dimensions=dimensions,
        candidates=candidates,
        question=question,
        blind_labels=blind_labels,
    )
