"""Dependency-directed lazy public facade; full runtime source is not active residency."""
from importlib import import_module

_GROUPS = (
    ('model', 'ObjectId ObjectType TypedObject TaskSemantics EvaluationCriterion EpochSnapshot'),
    ('runtime', 'Runtime RuntimeStatus StopReason TransitionRecord'),
    ('certificate', 'Certificate FormalStatus EmpiricalStatus ProcedureStatus IndependenceStatus SeparationVector TriState'),
    ('authority', 'Permission AuthoritySet'),
    ('provenance', 'SourceRoot'),
    ('evaluator', 'QualityVector WitnessLeaseLedger AnalyticCostVector AnalyticParetoDecision analytic_pareto_prescreen RepresentationCandidate RepresentationRacePolicy RepresentationRacePlan plan_representation_race representation_reserve_reopen_allowed finalization_pass_allowed cheap_falsifier_is_decision_relevant benchmark_is_decision_relevant'),
    ('reference', 'bounded_reference_synthesize'),
    ('orchestrator', 'run_worker_cycle OrchestrationResult ScoredCandidate RunCost CognitiveRouteKind CognitiveRoutePlan plan_cognitive_route'),
    ('worker', 'Worker CandidateDraft ChallengeDraft DeterministicDemoWorker'),
    ('verification', 'VerificationBasis VerificationReceipt VerificationBasisValidator IndependenceAuditValidator VALID_CLAIM_MODES VALID_EVIDENCE_INPUT_CLASSES EpistemicClaimIdentity ClaimRevisionStatus assess_claim_revision admissible_objective_evidence validate_epistemic_claim'),
    ('assurance', 'Materiality VerificationTier VerificationAction ChangeSet ImpactGraph ImpactCoverageReceipt verify_impact_graph VerificationCache AssuranceSelection plan_verification escalate_verification'),
    ('adaptive_verifier', 'VerificationCase ExecutedCheck AdaptiveVerificationResult run_adaptive_verification'),
    ('prompting', 'WorkerRole PromptCapsule PromptPacket build_prompt_packet default_library_capsules utf8_byte_token_upper_bound rough_token_estimate'),
    ('portable', 'ALMANAL_RUNTIME_PROTOCOL Capability Availability Enforcement WitnessBasis BackendProfile BootstrapStatus ValidationGrade CapabilityRecord CapabilityManifest CapabilityWitnessValidator RuntimeOperatorBinding PortableBootstrapResult MINIMUM_PORTABLE_CAPABILITIES OPTIONAL_PORTABLE_CAPABILITIES bootstrap_portable validate_binding_claims compact_runtime_card'),
    ('portable_spec', 'AlmanalSpecInfo PortableSpecInfo extract_manifest lint_almanal_text lint_almanal_file lint_portable_text lint_portable_file'),
    ('economy', 'CognitiveActionPackage gate_cognitive_package CognitiveActionKind EconomyDecision RiskRule ResourceVector UtilityEstimate CognitiveOffer EconomyPolicy EconomyGateResult gate_cognitive_action LifecycleImprovement LifecycleDecision decide_lifecycle_improvement TokenInvestment exact_myopic_voc_from_outcomes MetaTransition MetaAction FiniteMetaProblem MetaSolution solve_finite_horizon_metareasoning CognitiveDecisionRecord EconomyGovernor EconomySettlementStatus CognitiveSettlementRecord FormalResidency FormalObjectProfile FormalismDecision classify_formal_object FormalismFootprint summarize_formalism'),
    ('governed', 'GovernedStatus GovernedExecution execute_governed'),
    ('behavioral_benchmark', 'BehavioralClaimStatus PairedBehaviorObservation PairedMetricEvidence PairedBehaviorSummary BehavioralClaimPolicy exact_two_sided_sign_test_pvalue summarize_paired_behavior gate_behavioral_superiority_claim'),
    ('feedback', 'MetricDirection MetricRole MetricSpec MeasurementPlan PairObservation MetricEvidence MeasurementResult evaluate_measurement DiagnosisKind DirectionDiagnosis diagnose_direction CausalEvidenceKind CausalSupport CausalHypothesis CausalTestSpec CausalWitnessBasis CausalExecutionReceipt CausalReceiptValidator CausalEvidence CausalDiagnosis CausalTargetSelection diagnose_cause select_causal_repair_target CausalConfirmation ReMeasureDecision ReMeasureReport compare_remeasurement FeedbackPhase MeasurementDrivenFeedbackLoop'),
    ('experiment', 'ExperimentCondition ExperimentTier ExperimentDifficulty ExperimentRisk SubjectType SubjectUnderTest ObjectiveDecision ObjectiveAssessment assess_objective_result ChangeImpact ExperimentTask ExperimentConditionSpec ExperimentEnvironment PlainBaselineRecord ExperimentStoppingRule ExperimentCostModel TradeoffEnvelope TradeoffDecision TradeoffAssessment assess_change_tradeoff ExperimentSpec design_localized_experiment governed_design_localized_experiment ExperimentRunOutput ExperimentJudgeOutput ExperimentRunnerBinding ExperimentTrial ExperimentExecutionResult execute_experiment_batch execute_experiment merge_experiment_executions CanarySpilloverAssessment assess_adjacent_canaries ExperimentBatchDecision ExperimentBatchPlan plan_next_experiment_batch settle_experiment_batch_cost evaluate_experiment_pair'),
    ('improvement', 'ObjectiveSource ObjectiveMode ExperimentObjective resolve_experiment_objective ClaimKind EvidenceKind EvidenceRequest EvidenceSelection select_evidence_path CheckpointDecision ImprovementChangeRecord ImprovementBatchPolicy ImprovementCheckpointPlan plan_improvement_checkpoint ProgressGuardDecision ImprovementProgressPolicy ImprovementProgressState ImprovementProgressPlan guard_improvement_progress ObjectiveTermWeight ObjectiveTermDelta EndogenousObjectiveRevaluation describe_endogenous_objective_change'),
    ('design_direction', 'DesignPressure DesignDirection DesignSeverity DesignSignal LegacySourceBasis LegacyPriorCard LegacyPriorValidator LegacySearchValidator LegacyUnavailableValidator DesignDirectionCandidate DesignDirectionPlan select_design_direction DesignBenefitAxis DesignBurdenAxis DesignAlternative DesignTradeStudyPlan DesignAlternativeValidator trade_study_design_alternatives DesignRevisitTrigger DesignDecisionRecord record_design_decision SubsystemAdmissionDecision SubsystemProposal SubsystemAdmissionAssessment assess_subsystem_admission'),
    ('consolidation', 'ConsolidationOperation ConsolidationAuditClass ConsolidationDecision ConsolidationEquivalence StructuralComplexityFootprint StructuralConsolidationCandidate StructuralConsolidationAssessment StructuralConsolidationAuditReport ConsolidationApplyOutcome ConsolidationApplyBinding ConsolidationApplyRecord StructuralConsolidationExecutionReport assess_structural_consolidation audit_structural_consolidation execute_structural_consolidation_audit'),
    ('preference', 'HumanOutcomeCandidate PreferenceBundle PreferenceQueryDecision PreferenceQueryPlan PreferenceEvidence bundle_subjective_outcomes plan_preference_query'),
)
_EXPORT_MODULE = {name: module for module, names in _GROUPS for name in names.split()}
__all__ = 'ObjectId ObjectType TypedObject TaskSemantics EvaluationCriterion EpochSnapshot Runtime RuntimeStatus StopReason TransitionRecord Certificate FormalStatus EmpiricalStatus ProcedureStatus IndependenceStatus SeparationVector TriState Permission AuthoritySet SourceRoot QualityVector bounded_reference_synthesize run_worker_cycle OrchestrationResult CognitiveRouteKind CognitiveRoutePlan plan_cognitive_route Worker CandidateDraft ChallengeDraft DeterministicDemoWorker VerificationBasis VerificationReceipt VerificationBasisValidator IndependenceAuditValidator VALID_CLAIM_MODES VALID_EVIDENCE_INPUT_CLASSES admissible_objective_evidence validate_epistemic_claim'.split()

def __getattr__(name):
    module = _EXPORT_MODULE.get(name)
    if module is None:
        raise AttributeError(name)
    value = getattr(import_module(f".{module}", __name__), name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(globals()) | set(_EXPORT_MODULE))
