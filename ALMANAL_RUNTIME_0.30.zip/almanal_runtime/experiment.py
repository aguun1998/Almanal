from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from fractions import Fraction
from hashlib import sha256

from .economy import (
    ResourceVector, CognitiveOffer, CognitiveActionKind, UtilityEstimate,
    EconomyGovernor, EconomyDecision, CognitiveSettlementRecord,
)
from .errors import AlmanalError
from .feedback import (
    MetricDirection, MetricRole, MetricSpec, MeasurementPlan, MeasurementResult, PairObservation,
    evaluate_measurement, diagnose_direction, DiagnosisKind,
)
from .improvement import (
    ObjectiveSource, ObjectiveMode, ExperimentObjective, resolve_experiment_objective,
)

class ExperimentCondition(Enum):
    PLAIN = auto()
    PARENT = auto()
    CANDIDATE = auto()


class ExperimentTier(Enum):
    STATIC = auto()
    CANARY = auto()
    TARGETED = auto()
    BROADER_DOMAIN = auto()
    FULL = auto()


class ExperimentDifficulty(Enum):
    EASY = auto()
    MEDIUM = auto()
    HARD = auto()


class ExperimentRisk(Enum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()


class SubjectType(Enum):
    PROTOCOL = auto()
    ALGORITHM = auto()
    PROMPT = auto()
    RUNTIME = auto()
    MODEL_CONFIGURATION = auto()
    CREATIVE_PIPELINE = auto()
    OTHER = auto()


@dataclass(frozen=True, slots=True)
class SubjectUnderTest:
    """Generic experiment subject; ALMANAL is only one possible consumer."""
    subject_id: str
    subject_type: SubjectType
    subject_ref: str
    native_goal_ref: str = ""

    def __post_init__(self) -> None:
        if not self.subject_id or not self.subject_ref:
            raise AlmanalError("experiment subject id/ref must be nonempty")

    def fingerprint(self) -> str:
        return sha256("|".join((
            self.subject_id, self.subject_type.name, self.subject_ref, self.native_goal_ref,
        )).encode("utf-8")).hexdigest()




class ObjectiveDecision(Enum):
    KEEP = auto()
    REVERT = auto()
    CONTINUE = auto()
    UNRESOLVED = auto()


@dataclass(frozen=True, slots=True)
class ObjectiveAssessment:
    decision: ObjectiveDecision
    primary_improvements: tuple[str, ...]
    primary_regressions: tuple[str, ...]
    cost_improvements: tuple[str, ...]
    protected_regressions: tuple[str, ...]
    reason: str


def assess_objective_result(
    plan: MeasurementPlan,
    result: MeasurementResult,
    objective: ExperimentObjective,
) -> ObjectiveAssessment:
    """Evaluate directed or general-Pareto improvement without arbitrary scalarization."""
    if result.plan_fingerprint != plan.fingerprint():
        raise AlmanalError("objective assessment changed the frozen measurement plan")
    evidence = result.by_name()
    declared = set(objective.primary_metrics) | set(objective.protected_metrics) | set(objective.cost_metrics) | set(objective.diagnostic_metrics)
    missing = declared - set(evidence)
    if missing:
        raise AlmanalError(f"objective references unknown metrics: {sorted(missing)}")
    protected = tuple(sorted(
        name for name in objective.protected_metrics
        if evidence[name].material_regression
    ))
    if protected:
        return ObjectiveAssessment(ObjectiveDecision.REVERT, (), (), (), protected, "protected/non-compensable objective floor regressed")
    p_improve = tuple(sorted(name for name in objective.primary_metrics if evidence[name].material_improvement))
    p_regress = tuple(sorted(name for name in objective.primary_metrics if evidence[name].material_regression))
    c_improve = tuple(sorted(name for name in objective.cost_metrics if evidence[name].material_improvement))
    if p_regress:
        return ObjectiveAssessment(ObjectiveDecision.REVERT, p_improve, p_regress, c_improve, (), "task-relevant primary metric materially regressed")
    if objective.mode is ObjectiveMode.DIRECTED:
        if p_improve:
            return ObjectiveAssessment(ObjectiveDecision.KEEP, p_improve, (), c_improve, (), "explicit/native/change objective materially improved without protected regression")
        return ObjectiveAssessment(ObjectiveDecision.CONTINUE, (), (), c_improve, (), "primary goal has not materially improved; cost savings alone do not satisfy the directed objective")
    # General improvement: task value must advance, or be materially equivalent while economics improves.
    if p_improve:
        return ObjectiveAssessment(ObjectiveDecision.KEEP, p_improve, (), c_improve, (), "general Pareto frontier advanced on task-relevant value")
    if c_improve:
        return ObjectiveAssessment(ObjectiveDecision.KEEP, (), (), c_improve, (), "task-relevant value remained within material equivalence and secondary economics improved")
    return ObjectiveAssessment(ObjectiveDecision.CONTINUE, (), (), (), (), "no Pareto improvement established")


@dataclass(frozen=True, slots=True)
class ChangeImpact:
    """Frozen causal-impact map used to choose experiment scope."""
    change_id: str
    changed_components: tuple[str, ...]
    affected_paths: tuple[str, ...]
    affected_task_classes: tuple[str, ...]
    affected_metrics: tuple[str, ...]
    adjacent_task_classes: tuple[str, ...] = ()
    touches_hot_core: bool = False
    protected_impact: bool = False

    def __post_init__(self) -> None:
        if not self.change_id or not self.changed_components:
            raise AlmanalError("change impact requires id/components")
        if not self.affected_task_classes or not self.affected_metrics:
            raise AlmanalError("change impact must declare affected tasks/metrics")

    def fingerprint(self) -> str:
        payload = "|".join([
            self.change_id,
            *self.changed_components,
            "PATHS", *self.affected_paths,
            "TASKS", *self.affected_task_classes,
            "ADJACENT", *self.adjacent_task_classes,
            "METRICS", *self.affected_metrics,
            str(int(self.touches_hot_core)), str(int(self.protected_impact)),
        ])
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExperimentTask:
    task_id: str
    task_class: str
    payload: str
    difficulty: ExperimentDifficulty = ExperimentDifficulty.MEDIUM
    risk: ExperimentRisk = ExperimentRisk.MEDIUM
    affected_paths: tuple[str, ...] = ()
    failure_modes: tuple[str, ...] = ()
    metadata: tuple[tuple[str, str], ...] = ()
    version: str = "1"

    def __post_init__(self) -> None:
        if not self.task_id or not self.task_class or not self.version:
            raise AlmanalError("experiment task id/class/version must be nonempty")
        if len(dict(self.metadata)) != len(self.metadata):
            raise AlmanalError("experiment task metadata keys must be unique")

    def fingerprint(self) -> str:
        payload = "|".join([
            self.task_id, self.task_class, self.payload,
            self.difficulty.name, self.risk.name,
            "PATHS", *self.affected_paths,
            "FAILURES", *self.failure_modes,
            "META", *[f"{k}={v}" for k, v in sorted(self.metadata)],
            "VERSION", self.version,
        ])
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExperimentConditionSpec:
    condition: ExperimentCondition
    implementation_ref: str
    runtime_ref: str
    config_ref: str
    feature_flags: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.implementation_ref or not self.runtime_ref or not self.config_ref:
            raise AlmanalError("experiment condition identity must be fully specified")

    def fingerprint(self) -> str:
        payload = "|".join([
            self.condition.name, self.implementation_ref, self.runtime_ref,
            self.config_ref, *sorted(self.feature_flags),
        ])
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExperimentEnvironment:
    """Identity plus hard resource envelope for experiment reuse/planning."""
    base_model_ref: str
    task_distribution_ref: str
    evaluator_ref: str
    resource_envelope_ref: str
    host_ref: str = ""
    resource_budget: ResourceVector | None = None

    def fingerprint(self) -> str:
        budget_key = "NONE" if self.resource_budget is None else ",".join(map(str, self.resource_budget.key()))
        payload = "|".join((
            self.base_model_ref, self.task_distribution_ref,
            self.evaluator_ref, self.resource_envelope_ref, self.host_ref,
            budget_key,
        ))
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class PlainBaselineRecord:
    environment_fingerprint: str
    plain_condition_fingerprint: str
    task_fingerprints: tuple[tuple[str, str], ...]
    evidence_ref: str
    metrics_by_task: tuple[tuple[str, tuple[tuple[str, Fraction], ...]], ...] = ()

    def __post_init__(self) -> None:
        ids = tuple(task_id for task_id, _ in self.task_fingerprints)
        if len(set(ids)) != len(ids):
            raise AlmanalError("plain baseline task fingerprints must be unique")
        if self.metrics_by_task:
            metric_ids = tuple(task_id for task_id, _ in self.metrics_by_task)
            if len(set(metric_ids)) != len(metric_ids):
                raise AlmanalError("duplicate plain baseline metric task")
            if not set(metric_ids) <= set(ids):
                raise AlmanalError("plain baseline metrics reference unknown task")

    @property
    def task_ids(self) -> tuple[str, ...]:
        return tuple(task_id for task_id, _ in self.task_fingerprints)

    def reusable_for(
        self,
        environment: ExperimentEnvironment,
        tasks: tuple[ExperimentTask, ...],
        plain_condition: ExperimentConditionSpec,
        required_metric_names: tuple[str, ...] = (),
    ) -> bool:
        stored = dict(self.task_fingerprints)
        if not (
            bool(self.evidence_ref)
            and self.environment_fingerprint == environment.fingerprint()
            and self.plain_condition_fingerprint == plain_condition.fingerprint()
            and all(stored.get(t.task_id) == t.fingerprint() for t in tasks)
        ):
            return False
        if required_metric_names:
            metric_map = dict(self.metrics_by_task)
            expected = set(required_metric_names)
            for task in tasks:
                if task.task_id not in metric_map or set(dict(metric_map[task.task_id])) != expected:
                    return False
        return True

    def metrics_for(self, task_id: str) -> dict[str, Fraction]:
        mapping = dict(self.metrics_by_task)
        if task_id not in mapping:
            raise AlmanalError("plain baseline metrics unavailable for task")
        return dict(mapping[task_id])


@dataclass(frozen=True, slots=True)
class ExperimentStoppingRule:
    minimum_pairs: int = 10
    maximum_pairs: int = 30
    initial_batch_size: int = 5
    batch_size: int = 5
    full_completion_required: bool = False

    def __post_init__(self) -> None:
        if min(self.minimum_pairs, self.maximum_pairs, self.initial_batch_size, self.batch_size) < 1:
            raise AlmanalError("experiment stopping counts must be positive")
        if self.initial_batch_size > self.maximum_pairs:
            raise AlmanalError("initial batch cannot exceed maximum pairs")

    def fingerprint(self) -> str:
        return sha256("|".join(map(str, (
            self.minimum_pairs, self.maximum_pairs, self.initial_batch_size,
            self.batch_size, int(self.full_completion_required),
        ))).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ExperimentCostModel:
    """Precommitted resource estimator; coordinates remain non-commensurate."""
    design: ResourceVector = ResourceVector()
    precommit: ResourceVector = ResourceVector()
    per_condition_run: ResourceVector = ResourceVector()
    per_task_evaluation: ResourceVector = ResourceVector()
    per_batch_analysis: ResourceVector = ResourceVector()

    def estimate_design(self) -> ResourceVector:
        return self.design.add(self.precommit)

    def estimate_batch(self, *, task_count: int, condition_count: int) -> ResourceVector:
        if task_count < 1 or condition_count < 1:
            raise AlmanalError("batch cost requires positive task/condition count")
        return (
            self.per_condition_run.scale(task_count * condition_count)
            .add(self.per_task_evaluation.scale(task_count))
            .add(self.per_batch_analysis)
        )


@dataclass(frozen=True, slots=True)
class TradeoffEnvelope:
    """Frozen tolerances for compensable losses; protected metrics remain non-tradable."""
    target_metrics: tuple[str, ...]
    compensable_regression_tolerances: tuple[tuple[str, Fraction], ...] = ()
    minimum_net_decision_value: Fraction = Fraction(0)
    require_all_target_improvements: bool = False

    def __post_init__(self) -> None:
        if not self.target_metrics:
            raise AlmanalError("tradeoff envelope requires target metrics")
        tolerances = dict(self.compensable_regression_tolerances)
        if len(tolerances) != len(self.compensable_regression_tolerances):
            raise AlmanalError("duplicate tradeoff tolerance metric")
        if any(v < 0 for v in tolerances.values()):
            raise AlmanalError("tradeoff regression tolerance must be nonnegative")

    def fingerprint(self) -> str:
        return sha256("|".join([
            *self.target_metrics,
            *[f"{k}:{v}" for k, v in sorted(self.compensable_regression_tolerances)],
            str(self.minimum_net_decision_value),
            str(int(self.require_all_target_improvements)),
        ]).encode("utf-8")).hexdigest()


class TradeoffDecision(Enum):
    KEEP = auto()
    REVERT = auto()
    CONTINUE = auto()
    UNRESOLVED = auto()


@dataclass(frozen=True, slots=True)
class TradeoffAssessment:
    decision: TradeoffDecision
    target_improvements: tuple[str, ...]
    protected_regressions: tuple[str, ...]
    excess_spillovers: tuple[str, ...]
    reason: str


def assess_change_tradeoff(
    plan: MeasurementPlan,
    result: MeasurementResult,
    envelope: TradeoffEnvelope,
    *,
    net_decision_value: Fraction | None,
) -> TradeoffAssessment:
    if result.plan_fingerprint != plan.fingerprint():
        raise AlmanalError("tradeoff assessment changed the frozen measurement plan")
    evidence = result.by_name()
    unknown = set(envelope.target_metrics) - set(evidence)
    if unknown:
        raise AlmanalError(f"unknown target metrics: {sorted(unknown)}")
    protected = tuple(e.name for e in result.evidence if e.protected and e.material_regression)
    if protected:
        return TradeoffAssessment(
            TradeoffDecision.REVERT, (), protected, (),
            "protected/non-compensable metric regressed",
        )

    improved = tuple(name for name in envelope.target_metrics if evidence[name].material_improvement)
    target_ok = (
        set(improved) == set(envelope.target_metrics)
        if envelope.require_all_target_improvements
        else bool(improved)
    )
    tolerances = dict(envelope.compensable_regression_tolerances)
    excess: list[str] = []
    for item in result.evidence:
        if item.name in envelope.target_metrics or item.protected:
            continue
        tolerance = tolerances.get(item.name, Fraction(0))
        if item.oriented_mean_delta < -tolerance:
            excess.append(item.name)
    if excess:
        return TradeoffAssessment(
            TradeoffDecision.REVERT, improved, (), tuple(excess),
            "spillover loss exceeded the frozen compensable regression envelope",
        )
    if not target_ok:
        return TradeoffAssessment(
            TradeoffDecision.CONTINUE, improved, (), (),
            "target gain is not yet materially established",
        )
    if net_decision_value is None:
        return TradeoffAssessment(
            TradeoffDecision.UNRESOLVED, improved, (), (),
            "target gain exists but net decision value is not commensurately estimated",
        )
    if net_decision_value <= envelope.minimum_net_decision_value:
        return TradeoffAssessment(
            TradeoffDecision.REVERT, improved, (), (),
            "local gain did not pay for total spillover/lifecycle cost",
        )
    return TradeoffAssessment(
        TradeoffDecision.KEEP, improved, (), (),
        "material target gain pays for spillover within the frozen tradeoff envelope",
    )


def _task_labels(task: ExperimentTask, impact: ChangeImpact) -> frozenset[str]:
    labels = {
        f"class:{task.task_class}",
        f"difficulty:{task.difficulty.name}",
        f"risk:{task.risk.name}",
    }
    for path in task.affected_paths:
        if not impact.affected_paths or path in set(impact.affected_paths):
            labels.add(f"path:{path}")
    for failure in task.failure_modes:
        labels.add(f"failure:{failure}")
    return frozenset(labels)


def _representative_order(
    tasks: tuple[ExperimentTask, ...],
    impact: ChangeImpact,
    seed: int,
) -> tuple[str, ...]:
    """Greedy impact-aware set-cover order; later batches remain frozen pre-outcome."""
    if not tasks:
        return ()
    labels = {t.task_id: _task_labels(t, impact) for t in tasks}
    uncovered = set().union(*(labels.values()))

    def weight(label: str) -> int:
        if label.startswith("path:"):
            return 7
        if label.startswith("failure:"):
            return 6
        if label.startswith("class:"):
            return 5
        if label.startswith("risk:"):
            return 3
        return 2

    def stable_key(task_id: str) -> str:
        return sha256(f"{seed}|{task_id}".encode("utf-8")).hexdigest()

    remaining = {t.task_id: t for t in tasks}
    order: list[str] = []
    while remaining:
        best = max(
            remaining,
            key=lambda tid: (
                sum(weight(label) for label in labels[tid] & uncovered),
                len(labels[tid] & uncovered),
                -len(labels[tid]),
                stable_key(tid),
            ),
        )
        order.append(best)
        uncovered -= set(labels[best])
        del remaining[best]
    return tuple(order)



def _shadow_reserve_task(
    tasks: tuple[ExperimentTask, ...],
    impact: ChangeImpact,
    seed: int,
    representative_first: str = "",
) -> str | None:
    """Frozen label-independent exploration reserve.

    The representative order exploits known metadata. The shadow reserve is chosen
    independently of those labels by a pre-outcome hash, so early stopping cannot
    rely exclusively on the known taxonomy. It is only a hedge, not proof that
    unknown failure modes are covered.
    """
    if not tasks:
        return None
    ids = tuple(t.task_id for t in tasks)
    candidates = tuple(tid for tid in ids if tid != representative_first) if len(ids) > 1 else ids
    return max(
        candidates,
        key=lambda tid: sha256(f"shadow|{seed}|{tid}".encode("utf-8")).hexdigest(),
    )


def _select_adjacent_canaries(
    task_catalog: tuple[ExperimentTask, ...],
    classes: tuple[str, ...],
    seed: int,
) -> tuple[str, ...]:
    selected: list[str] = []
    for task_class in sorted(set(classes)):
        candidates = [t for t in task_catalog if t.task_class == task_class]
        if not candidates:
            continue
        # High-risk edge cases make better spillover canaries; stable hash breaks ties.
        candidates.sort(
            key=lambda t: (
                -t.risk.value,
                -len(t.failure_modes),
                sha256(f"{seed}|canary|{t.task_id}".encode("utf-8")).hexdigest(),
            )
        )
        selected.append(candidates[0].task_id)
    return tuple(selected)


@dataclass(frozen=True, slots=True)
class ExperimentSpec:
    """Frozen localized experiment contract, fixed before outcomes."""
    experiment_id: str
    question: str
    change_fingerprint: str
    environment_fingerprint: str
    resource_budget: ResourceVector | None
    tier: ExperimentTier
    condition_specs: tuple[ExperimentConditionSpec, ...]
    task_fingerprints: tuple[tuple[str, str], ...]
    primary_task_ids: tuple[str, ...]
    adjacent_canary_ids: tuple[str, ...]
    sample_order: tuple[str, ...]
    task_classes: tuple[str, ...]
    adjacent_canary_classes: tuple[tuple[str, str], ...]
    metrics: tuple[MetricSpec, ...]
    subject: SubjectUnderTest
    objective: ExperimentObjective
    tradeoff_envelope: TradeoffEnvelope
    stopping_rule: ExperimentStoppingRule
    alpha: Fraction = Fraction(1, 20)
    blind_evaluator: bool = True
    randomization_seed: int = 0
    plain_baseline_reused: bool = False
    escalation_reason: str = ""

    def __post_init__(self) -> None:
        if not self.experiment_id or not self.question:
            raise AlmanalError("experiment id/question must be nonempty")
        conds = tuple(c.condition for c in self.condition_specs)
        if set(conds) != {ExperimentCondition.PLAIN, ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE}:
            raise AlmanalError("experiment must freeze PLAIN/PARENT/CANDIDATE identities")
        if len(set(conds)) != len(conds):
            raise AlmanalError("duplicate experiment condition")
        task_ids = tuple(task_id for task_id, _ in self.task_fingerprints)
        if not task_ids or len(set(task_ids)) != len(task_ids):
            raise AlmanalError("experiment task fingerprints must be nonempty/unique")
        if not set(self.primary_task_ids) <= set(task_ids):
            raise AlmanalError("primary tasks escaped frozen task pool")
        if not set(self.adjacent_canary_ids) <= set(task_ids):
            raise AlmanalError("canary tasks escaped frozen task pool")
        if set(self.primary_task_ids) & set(self.adjacent_canary_ids):
            raise AlmanalError("primary and adjacent canary tasks must be disjoint")
        if set(self.sample_order) != set(self.primary_task_ids):
            raise AlmanalError("sample order must cover primary task pool exactly")
        canary_class_map = dict(self.adjacent_canary_classes)
        if len(canary_class_map) != len(self.adjacent_canary_classes):
            raise AlmanalError("duplicate adjacent canary class mapping")
        if set(canary_class_map) != set(self.adjacent_canary_ids):
            raise AlmanalError("adjacent canary class mapping must bind every canary exactly")
        metric_names = {m.name for m in self.metrics}
        objective_names = set(self.objective.primary_metrics) | set(self.objective.protected_metrics) | set(self.objective.cost_metrics) | set(self.objective.diagnostic_metrics)
        if not objective_names <= metric_names:
            raise AlmanalError("objective escaped frozen experiment metrics")
        if not set(self.tradeoff_envelope.target_metrics) <= metric_names:
            raise AlmanalError("tradeoff target escaped frozen experiment metrics")
        if not self.task_classes:
            raise AlmanalError("experiment task classes must be nonempty")
        if not Fraction(0) < self.alpha <= 1:
            raise AlmanalError("experiment alpha must be in (0,1]")
        if self.stopping_rule.maximum_pairs > len(self.primary_task_ids):
            raise AlmanalError("maximum pairs cannot exceed frozen primary pool")

    @property
    def conditions(self) -> tuple[ExperimentCondition, ...]:
        if self.plain_baseline_reused:
            return (ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE)
        return (ExperimentCondition.PLAIN, ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE)

    @property
    def task_ids(self) -> tuple[str, ...]:
        return tuple(task_id for task_id, _ in self.task_fingerprints)

    @property
    def initial_task_ids(self) -> tuple[str, ...]:
        n = min(self.stopping_rule.initial_batch_size, self.stopping_rule.maximum_pairs)
        return tuple(self.sample_order[:n]) + self.adjacent_canary_ids

    @property
    def evidence_floor_reachable(self) -> bool:
        return self.stopping_rule.minimum_pairs <= self.stopping_rule.maximum_pairs

    def condition_spec(self, condition: ExperimentCondition) -> ExperimentConditionSpec:
        return next(c for c in self.condition_specs if c.condition is condition)

    def fingerprint(self) -> str:
        payload = "|".join([
            self.experiment_id, self.question, self.change_fingerprint,
            self.environment_fingerprint,
            "RESOURCE_BUDGET", "NONE" if self.resource_budget is None else ",".join(map(str, self.resource_budget.key())),
            self.tier.name,
            "CONDITIONS", *[c.fingerprint() for c in self.condition_specs],
            "TASKS", *[f"{tid}:{fp}" for tid, fp in self.task_fingerprints],
            "PRIMARY", *self.primary_task_ids,
            "CANARY", *self.adjacent_canary_ids,
            "CANARY_CLASSES", *[f"{tid}:{cls}" for tid, cls in self.adjacent_canary_classes],
            "ORDER", *self.sample_order,
            "CLASSES", *self.task_classes,
            "METRICS", *(
                ":".join((
                    m.name, m.direction.name, m.role.name, str(m.material_delta),
                    str(int(m.protected)), m.measurement_boundary, m.start_event,
                    m.end_event, m.aggregation, m.measurement_method,
                    ",".join(m.included_components), ",".join(m.excluded_components),
                ))
                for m in self.metrics
            ),
            "SUBJECT", self.subject.fingerprint(),
            "OBJECTIVE", self.objective.fingerprint(),
            "TRADEOFF", self.tradeoff_envelope.fingerprint(),
            self.stopping_rule.fingerprint(), str(self.alpha), str(int(self.blind_evaluator)),
            str(self.randomization_seed), str(int(self.plain_baseline_reused)),
            self.escalation_reason,
        ])
        return sha256(payload.encode("utf-8")).hexdigest()

    def measurement_plan(
        self,
        reference: ExperimentCondition,
        candidate: ExperimentCondition,
    ) -> MeasurementPlan:
        if reference is candidate:
            raise AlmanalError("experiment comparison requires distinct conditions")
        if candidate not in self.conditions:
            raise AlmanalError("candidate condition unavailable")
        if reference not in self.conditions and not (
            reference is ExperimentCondition.PLAIN and self.plain_baseline_reused
        ):
            raise AlmanalError("reference condition unavailable")
        return MeasurementPlan(
            plan_id=f"{self.experiment_id}:{reference.name}->{candidate.name}",
            task_scope=",".join(self.task_classes),
            metrics=self.metrics,
            minimum_pairs=self.stopping_rule.minimum_pairs,
            alpha=self.alpha,
            require_same_pairs_on_remeasure=True,
        )


def design_localized_experiment(
    *,
    experiment_id: str,
    question: str,
    impact: ChangeImpact,
    task_catalog: tuple[ExperimentTask, ...],
    metrics: tuple[MetricSpec, ...],
    environment: ExperimentEnvironment,
    condition_specs: tuple[ExperimentConditionSpec, ...],
    subject: SubjectUnderTest | None = None,
    objective: ExperimentObjective | None = None,
    plain_baseline: PlainBaselineRecord | None = None,
    refresh_plain_claim: bool = False,
    unexpected_spillover: bool = False,
    spillover_task_classes: tuple[str, ...] = (),
    unresolved_uncertainty: bool = False,
    release_high_risk: bool = False,
    minimum_pairs: int = 10,
    maximum_pairs: int | None = None,
    initial_batch_size: int = 5,
    batch_size: int = 5,
    alpha: Fraction = Fraction(1, 20),
    randomization_seed: int = 0,
    tradeoff_envelope: TradeoffEnvelope | None = None,
) -> ExperimentSpec:
    """Freeze impact-local scope, representative order, identities, and stopping rule.

    Scope != sample: the entire causally eligible pool is frozen, but only a small
    representative initial batch is executed. Additional pairs require the frozen
    batch scheduler/Economy gate.
    """
    affected = tuple(t for t in task_catalog if t.task_class in set(impact.affected_task_classes))
    if not affected:
        raise AlmanalError("no tasks cover the declared affected task classes")

    escalation: list[str] = []
    if impact.touches_hot_core:
        escalation.append("HOT_CORE")
    if impact.protected_impact:
        escalation.append("PROTECTED_IMPACT")
    if unexpected_spillover:
        escalation.append("UNEXPECTED_SPILLOVER")
    if unresolved_uncertainty:
        escalation.append("UNRESOLVED_UNCERTAINTY")
    if release_high_risk:
        escalation.append("RELEASE_HIGH_RISK")

    primary = affected
    tier = ExperimentTier.TARGETED
    if impact.touches_hot_core or unexpected_spillover:
        tier = ExperimentTier.BROADER_DOMAIN
        broadened_classes = set(impact.affected_task_classes) | set(spillover_task_classes)
        primary = tuple(t for t in task_catalog if t.task_class in broadened_classes)
        if not primary:
            raise AlmanalError("broader-domain experiment has no causally linked tasks")

    if (impact.touches_hot_core and impact.protected_impact) or len(escalation) >= 3:
        tier = ExperimentTier.FULL
        primary = task_catalog

    primary_ids = tuple(t.task_id for t in primary)
    if len(set(primary_ids)) != len(primary_ids):
        raise AlmanalError("task catalog ids must be unique")

    adjacent_classes = tuple(
        c for c in impact.adjacent_task_classes
        if c not in {t.task_class for t in primary}
    )
    canary_ids = () if tier is ExperimentTier.FULL else _select_adjacent_canaries(
        task_catalog, adjacent_classes, randomization_seed,
    )
    frozen_ids = set(primary_ids) | set(canary_ids)
    frozen_tasks = tuple(t for t in task_catalog if t.task_id in frozen_ids)

    order = _representative_order(primary, impact, randomization_seed)
    shadow = _shadow_reserve_task(primary, impact, randomization_seed, order[0] if order else "")
    if shadow is not None and len(order) > 1:
        # Reserve one novelty-oriented case inside the first executable batch.
        order = (shadow,) + tuple(tid for tid in order if tid != shadow)
    max_pairs = len(primary) if maximum_pairs is None else min(maximum_pairs, len(primary))
    if max_pairs < 1:
        raise AlmanalError("experiment has no executable primary pairs")
    initial = min(initial_batch_size, max_pairs)
    stopping = ExperimentStoppingRule(
        minimum_pairs=minimum_pairs,
        maximum_pairs=max_pairs,
        initial_batch_size=initial,
        batch_size=min(batch_size, max_pairs),
        full_completion_required=(tier is ExperimentTier.FULL),
    )

    c_map = {c.condition: c for c in condition_specs}
    if set(c_map) != {ExperimentCondition.PLAIN, ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE}:
        raise AlmanalError("condition_specs must freeze exactly PLAIN/PARENT/CANDIDATE")
    plain_condition = c_map[ExperimentCondition.PLAIN]
    baseline_reused = (
        plain_baseline is not None
        and not refresh_plain_claim
        and plain_baseline.reusable_for(
            environment, frozen_tasks, plain_condition, tuple(m.name for m in metrics)
        )
    )
    metric_names = {m.name for m in metrics}
    metric_map = {m.name: m for m in metrics}
    frozen_subject = subject or SubjectUnderTest(
        subject_id="subject-under-test", subject_type=SubjectType.OTHER, subject_ref="caller-supplied-runtime-subject"
    )
    if objective is None:
        protected_names = tuple(m.name for m in metrics if m.protected)
        cost_names = tuple(m.name for m in metrics if m.role is MetricRole.COST and not m.protected)
        affected_value_names = tuple(
            name for name in impact.affected_metrics
            if name in metric_map and metric_map[name].role is not MetricRole.COST and not metric_map[name].protected
        )
        general_values = affected_value_names or tuple(
            m.name for m in metrics if m.role is not MetricRole.COST and not m.protected
        )
        objective = resolve_experiment_objective(
            general_value_metrics=general_values,
            protected_metrics=protected_names,
            cost_metrics=cost_names,
        )
    objective_names = set(objective.primary_metrics) | set(objective.protected_metrics) | set(objective.cost_metrics) | set(objective.diagnostic_metrics)
    if not objective_names <= metric_names:
        raise AlmanalError("objective references metrics outside experiment metric set")
    frozen_tradeoff = tradeoff_envelope or TradeoffEnvelope(objective.primary_metrics)
    canary_class_map = tuple(sorted(
        (tid, next(t.task_class for t in frozen_tasks if t.task_id == tid))
        for tid in canary_ids
    ))

    return ExperimentSpec(
        experiment_id=experiment_id,
        question=question,
        change_fingerprint=impact.fingerprint(),
        environment_fingerprint=environment.fingerprint(),
        resource_budget=environment.resource_budget,
        tier=tier,
        condition_specs=tuple(sorted(condition_specs, key=lambda c: c.condition.value)),
        task_fingerprints=tuple(sorted((t.task_id, t.fingerprint()) for t in frozen_tasks)),
        primary_task_ids=primary_ids,
        adjacent_canary_ids=canary_ids,
        sample_order=order,
        task_classes=tuple(sorted({t.task_class for t in frozen_tasks})),
        adjacent_canary_classes=canary_class_map,
        metrics=metrics,
        subject=frozen_subject,
        objective=objective,
        tradeoff_envelope=frozen_tradeoff,
        stopping_rule=stopping,
        alpha=alpha,
        blind_evaluator=True,
        randomization_seed=randomization_seed,
        plain_baseline_reused=baseline_reused,
        escalation_reason=",".join(escalation),
    )


def governed_design_localized_experiment(
    governor: EconomyGovernor,
    offer: CognitiveOffer,
    *,
    cost_model: ExperimentCostModel,
    **kwargs,
):
    """Economy-wired design entrypoint with frozen estimator consistency.

    Utility/value estimates remain an external epistemic input, but the resource
    vector attached to the offer must equal the precommitted design+precommit cost
    model. This prevents a caller from economically gating one cost and then buying
    a different design procedure.
    """
    if offer.kind is not CognitiveActionKind.DESIGN_EXPERIMENT:
        raise AlmanalError("design offer must use DESIGN_EXPERIMENT kind")
    if offer.resources != cost_model.estimate_design():
        raise AlmanalError("experiment design offer drifted from frozen cost model")
    environment = kwargs.get("environment")
    if environment is not None and environment.resource_budget is not None:
        if governor.initial_budget != environment.resource_budget:
            raise AlmanalError("experiment design governor does not match frozen resource envelope")
    from .governed import execute_governed
    return execute_governed(governor, offer, lambda: design_localized_experiment(**kwargs))


@dataclass(frozen=True, slots=True)
class ExperimentRunOutput:
    content: str
    runtime_metrics: tuple[tuple[str, Fraction], ...] = ()
    resources_used: ResourceVector = ResourceVector()
    resource_witness_ref: str = ""

    def __post_init__(self) -> None:
        if len(dict(self.runtime_metrics)) != len(self.runtime_metrics):
            raise AlmanalError("duplicate runtime metric")


@dataclass(frozen=True, slots=True)
class ExperimentJudgeOutput:
    metrics_by_label: tuple[tuple[str, tuple[tuple[str, Fraction], ...]], ...]
    resources_used: ResourceVector = ResourceVector()
    resource_witness_ref: str = ""

    def metric_map(self) -> dict[str, dict[str, Fraction]]:
        return {label: dict(metrics) for label, metrics in self.metrics_by_label}


@dataclass(frozen=True, slots=True)
class ExperimentRunnerBinding:
    condition_spec_fingerprint: str
    runner: object

    def __post_init__(self) -> None:
        if not self.condition_spec_fingerprint or not callable(self.runner):
            raise AlmanalError("experiment runner binding requires fingerprint/callable")


@dataclass(frozen=True, slots=True)
class ExperimentTrial:
    task_id: str
    task_fingerprint: str
    condition_metrics: tuple[tuple[ExperimentCondition, tuple[tuple[str, Fraction], ...]], ...]
    output_refs: tuple[tuple[ExperimentCondition, str], ...] = ()

    def metric_map(self, condition: ExperimentCondition) -> dict[str, Fraction]:
        mapping = dict(self.condition_metrics)
        if condition not in mapping:
            raise AlmanalError("condition absent from experiment trial")
        return dict(mapping[condition])


@dataclass(frozen=True, slots=True)
class ExperimentExecutionResult:
    spec_fingerprint: str
    trials: tuple[ExperimentTrial, ...]
    execution_witness_ref: str
    batch_index: int = 0
    estimated_resources: ResourceVector = ResourceVector()
    actual_resources: ResourceVector = ResourceVector()
    actual_resource_witness_complete: bool = False

    def __post_init__(self) -> None:
        if not self.execution_witness_ref:
            raise AlmanalError("experiment execution requires a witness reference")
        ids = tuple(t.task_id for t in self.trials)
        if len(set(ids)) != len(ids):
            raise AlmanalError("duplicate experiment trial id")
        if self.batch_index < 0:
            raise AlmanalError("batch index must be nonnegative")

    @property
    def cost_error(self) -> tuple[int, ...] | None:
        if not self.actual_resource_witness_complete:
            return None
        a = self.actual_resources.key()
        e = self.estimated_resources.key()
        return tuple(x - y for x, y in zip(a, e))

    def paired_observations(
        self,
        spec: ExperimentSpec,
        *,
        reference: ExperimentCondition,
        candidate: ExperimentCondition,
        task_ids: tuple[str, ...] | None = None,
    ) -> tuple[PairObservation, ...]:
        if self.spec_fingerprint != spec.fingerprint():
            raise AlmanalError("execution result does not match frozen experiment spec")
        expected = {m.name for m in spec.metrics}
        selected = set(task_ids) if task_ids is not None else {t.task_id for t in self.trials}
        observations = []
        for trial in self.trials:
            if trial.task_id not in selected:
                continue
            ref = trial.metric_map(reference)
            cand = trial.metric_map(candidate)
            if set(ref) != expected or set(cand) != expected:
                raise AlmanalError("trial metrics do not match frozen experiment metrics")
            observations.append(PairObservation(
                pair_id=trial.task_id,
                reference=tuple(sorted(ref.items())),
                candidate=tuple(sorted(cand.items())),
            ))
        if task_ids is not None and {o.pair_id for o in observations} != selected:
            raise AlmanalError("requested paired task subset not fully executed")
        return tuple(observations)


def execute_experiment_batch(
    spec: ExperimentSpec,
    tasks: tuple[ExperimentTask, ...],
    *,
    task_ids: tuple[str, ...],
    runners: dict[ExperimentCondition, ExperimentRunnerBinding],
    blind_evaluator: object,
    execution_witness_ref: str,
    cost_model: ExperimentCostModel = ExperimentCostModel(),
    batch_index: int = 0,
    resource_witness_validator: object | None = None,
) -> ExperimentExecutionResult:
    """Execute only one frozen batch; do not silently run the whole scope."""
    import random

    if not task_ids or not set(task_ids) <= set(spec.task_ids):
        raise AlmanalError("experiment batch escaped frozen task pool")
    task_map = {t.task_id: t for t in tasks}
    frozen_fps = dict(spec.task_fingerprints)
    for task_id in task_ids:
        if task_id not in task_map:
            raise AlmanalError("experiment task payload missing")
        if task_map[task_id].fingerprint() != frozen_fps[task_id]:
            raise AlmanalError("experiment task payload/version drifted after freeze")
    if set(spec.conditions) - set(runners):
        raise AlmanalError("experiment condition runner missing")
    if not callable(blind_evaluator):
        raise AlmanalError("blind evaluator must be callable")
    for condition in spec.conditions:
        expected_fp = spec.condition_spec(condition).fingerprint()
        if runners[condition].condition_spec_fingerprint != expected_fp:
            raise AlmanalError("experiment runner condition identity drifted")

    estimated = cost_model.estimate_batch(task_count=len(task_ids), condition_count=len(spec.conditions))
    actual = ResourceVector()
    actual_complete = resource_witness_validator is not None and callable(resource_witness_validator)
    trials = []
    for task_id in task_ids:
        task = task_map[task_id]
        outputs: dict[ExperimentCondition, ExperimentRunOutput] = {}
        for condition in spec.conditions:
            out = runners[condition].runner(task)
            if not isinstance(out, ExperimentRunOutput):
                raise AlmanalError("experiment runner returned wrong type")
            outputs[condition] = out
            actual = actual.add(out.resources_used)
            if actual_complete:
                try:
                    actual_complete &= bool(out.resource_witness_ref) and bool(resource_witness_validator(out.resource_witness_ref, out.resources_used))
                except Exception:
                    actual_complete = False

        order = list(spec.conditions)
        rng = random.Random(f"{spec.randomization_seed}:{batch_index}:{task_id}")
        rng.shuffle(order)
        labels = tuple(chr(ord('A') + i) for i in range(len(order)))
        label_to_condition = dict(zip(labels, order))
        presented = tuple((label, outputs[cond].content) for label, cond in zip(labels, order))
        judged_raw = blind_evaluator(task, presented)
        if isinstance(judged_raw, ExperimentJudgeOutput):
            judged = judged_raw.metric_map()
            actual = actual.add(judged_raw.resources_used)
            if actual_complete:
                try:
                    actual_complete &= bool(judged_raw.resource_witness_ref) and bool(resource_witness_validator(judged_raw.resource_witness_ref, judged_raw.resources_used))
                except Exception:
                    actual_complete = False
        else:
            judged = {
                label: {k: Fraction(v) for k, v in metrics.items()}
                for label, metrics in judged_raw.items()
            }
            actual_complete = False
        if set(judged) != set(labels):
            raise AlmanalError("blind evaluator label set mismatch")

        condition_metrics = []
        output_refs = []
        expected_metrics = {m.name for m in spec.metrics}
        for label, condition in label_to_condition.items():
            eval_metrics = {k: Fraction(v) for k, v in judged[label].items()}
            runtime_metrics = dict(outputs[condition].runtime_metrics)
            merged = {**eval_metrics, **runtime_metrics}
            if set(merged) != expected_metrics:
                raise AlmanalError("evaluator/runtime metrics do not match frozen metric set")
            condition_metrics.append((condition, tuple(sorted(merged.items()))))
            output_refs.append((condition, sha256(outputs[condition].content.encode('utf-8')).hexdigest()))

        trials.append(ExperimentTrial(
            task_id=task_id,
            task_fingerprint=task.fingerprint(),
            condition_metrics=tuple(condition_metrics),
            output_refs=tuple(output_refs),
        ))

    return ExperimentExecutionResult(
        spec_fingerprint=spec.fingerprint(),
        trials=tuple(trials),
        execution_witness_ref=execution_witness_ref,
        batch_index=batch_index,
        estimated_resources=estimated,
        actual_resources=actual,
        actual_resource_witness_complete=actual_complete,
    )


def execute_experiment(
    spec: ExperimentSpec,
    tasks: tuple[ExperimentTask, ...],
    *,
    runners: dict[ExperimentCondition, ExperimentRunnerBinding],
    blind_evaluator: object,
    execution_witness_ref: str,
    cost_model: ExperimentCostModel = ExperimentCostModel(),
    resource_witness_validator: object | None = None,
) -> ExperimentExecutionResult:
    """Compatibility convenience: execute only the frozen initial representative batch."""
    return execute_experiment_batch(
        spec, tasks, task_ids=spec.initial_task_ids,
        runners=runners, blind_evaluator=blind_evaluator,
        execution_witness_ref=execution_witness_ref,
        cost_model=cost_model, batch_index=0,
        resource_witness_validator=resource_witness_validator,
    )


def merge_experiment_executions(
    spec: ExperimentSpec,
    executions: tuple[ExperimentExecutionResult, ...],
) -> ExperimentExecutionResult:
    if not executions:
        raise AlmanalError("cannot merge zero experiment executions")
    if any(e.spec_fingerprint != spec.fingerprint() for e in executions):
        raise AlmanalError("cannot merge executions from different frozen specs")
    trials = tuple(t for e in executions for t in e.trials)
    ids = tuple(t.task_id for t in trials)
    if len(set(ids)) != len(ids):
        raise AlmanalError("experiment batches overlap")
    estimated = ResourceVector()
    actual = ResourceVector()
    complete = True
    for e in executions:
        estimated = estimated.add(e.estimated_resources)
        actual = actual.add(e.actual_resources)
        complete &= e.actual_resource_witness_complete
    witness = sha256("|".join(e.execution_witness_ref for e in executions).encode("utf-8")).hexdigest()
    return ExperimentExecutionResult(
        spec_fingerprint=spec.fingerprint(), trials=trials,
        execution_witness_ref=witness, batch_index=max(e.batch_index for e in executions),
        estimated_resources=estimated, actual_resources=actual,
        actual_resource_witness_complete=complete,
    )


@dataclass(frozen=True, slots=True)
class CanarySpilloverAssessment:
    escalate: bool
    task_ids: tuple[str, ...]
    task_classes: tuple[str, ...]
    metrics: tuple[str, ...]
    reason: str


def assess_adjacent_canaries(
    spec: ExperimentSpec,
    execution: ExperimentExecutionResult,
) -> CanarySpilloverAssessment:
    """Use frozen adjacent canaries only as escalation sensors.

    A canary does not establish a population-level regression. It can reveal a
    predeclared protected/material or out-of-envelope loss that justifies a new,
    broader frozen experiment before a final KEEP/REVERT decision.
    """
    if execution.spec_fingerprint != spec.fingerprint():
        raise AlmanalError("canary assessment received execution from another spec")
    if not spec.adjacent_canary_ids:
        return CanarySpilloverAssessment(False, (), (), (), "no adjacent canaries frozen")
    trial_map = {t.task_id: t for t in execution.trials}
    class_map = dict(spec.adjacent_canary_classes)
    tolerances = dict(spec.tradeoff_envelope.compensable_regression_tolerances)
    target_set = set(spec.tradeoff_envelope.target_metrics)
    triggered_tasks: set[str] = set()
    triggered_classes: set[str] = set()
    triggered_metrics: set[str] = set()
    for task_id in spec.adjacent_canary_ids:
        trial = trial_map.get(task_id)
        if trial is None:
            continue
        parent = trial.metric_map(ExperimentCondition.PARENT)
        candidate = trial.metric_map(ExperimentCondition.CANDIDATE)
        for metric in spec.metrics:
            if metric.name not in parent or metric.name not in candidate:
                raise AlmanalError("canary metrics do not match frozen experiment metrics")
            oriented_delta = (
                candidate[metric.name] - parent[metric.name]
                if metric.direction is MetricDirection.HIGHER_IS_BETTER
                else parent[metric.name] - candidate[metric.name]
            )
            if metric.protected:
                boundary = metric.material_delta
                trigger = oriented_delta < -boundary if boundary > 0 else oriented_delta < 0
            elif metric.name not in target_set:
                boundary = tolerances.get(metric.name, Fraction(0))
                trigger = oriented_delta < -boundary if boundary > 0 else oriented_delta < 0
            else:
                trigger = False
            if trigger:
                triggered_tasks.add(task_id)
                triggered_classes.add(class_map[task_id])
                triggered_metrics.add(metric.name)
    if triggered_tasks:
        return CanarySpilloverAssessment(
            True, tuple(sorted(triggered_tasks)), tuple(sorted(triggered_classes)),
            tuple(sorted(triggered_metrics)),
            "adjacent canary crossed frozen protected/tradeoff boundary; broaden before final decision",
        )
    return CanarySpilloverAssessment(
        False, (), (), (), "adjacent canaries did not cross frozen escalation boundary"
    )


class ExperimentBatchDecision(Enum):
    EXECUTE = auto()
    ESCALATE_BROADER_DOMAIN = auto()
    STOP_DECISIVE = auto()
    STOP_MAX_PAIRS = auto()
    STOP_NO_REMAINING_TASKS = auto()
    STOP_ECONOMY = auto()
    BLOCKED_BUDGET = auto()


@dataclass(frozen=True, slots=True)
class ExperimentBatchPlan:
    decision: ExperimentBatchDecision
    task_ids: tuple[str, ...]
    estimated_resources: ResourceVector
    reason: str


def plan_next_experiment_batch(
    spec: ExperimentSpec,
    *,
    execution_so_far: ExperimentExecutionResult | None,
    cost_model: ExperimentCostModel,
    governor: EconomyGovernor,
    expected_information_value: UtilityEstimate,
    current_stop_utility: Fraction,
    decision_cost_utility: Fraction = Fraction(0),
) -> ExperimentBatchPlan:
    """Adaptive frozen-order batching with actual Economy Governor admission."""
    # When actual metering is complete, a previously admitted experiment batch must
    # be settled before another batch is purchased. Incomplete metering deliberately
    # retains the conservative estimated reservation and may continue.
    records = governor.records()
    if records:
        last = records[-1]
        if (
            last.kind is CognitiveActionKind.EXPERIMENT_BATCH
            and last.decision in {EconomyDecision.EXECUTE, EconomyDecision.MANDATORY_EXECUTE}
            and execution_so_far is not None
            and execution_so_far.actual_resource_witness_complete
            and not any(s.action_id == last.action_id for s in governor.settlements())
        ):
            raise AlmanalError("witnessed experiment batch must be cost-settled before planning the next batch")
    if spec.resource_budget is not None and governor.initial_budget != spec.resource_budget:
        raise AlmanalError("experiment batch governor does not match frozen resource envelope")
    executed = set()
    if execution_so_far is not None:
        if execution_so_far.spec_fingerprint != spec.fingerprint():
            raise AlmanalError("batch scheduler received execution from another spec")
        executed = {t.task_id for t in execution_so_far.trials}

    primary_done = [tid for tid in spec.sample_order if tid in executed]
    if execution_so_far is not None and spec.adjacent_canary_ids:
        canary = assess_adjacent_canaries(spec, execution_so_far)
        if canary.escalate:
            return ExperimentBatchPlan(
                ExperimentBatchDecision.ESCALATE_BROADER_DOMAIN, (), ResourceVector(),
                canary.reason + f" classes={','.join(canary.task_classes)} metrics={','.join(canary.metrics)}",
            )
    if spec.stopping_rule.full_completion_required:
        if len(primary_done) >= spec.stopping_rule.maximum_pairs:
            return ExperimentBatchPlan(
                ExperimentBatchDecision.STOP_MAX_PAIRS, (), ResourceVector(),
                "mandatory FULL coverage completed",
            )
    elif execution_so_far is not None and len(primary_done) >= spec.stopping_rule.minimum_pairs:
        primary_ids = tuple(primary_done)
        result = evaluate_experiment_pair(
            spec, execution_so_far,
            reference=ExperimentCondition.PARENT,
            candidate=ExperimentCondition.CANDIDATE,
            task_ids=primary_ids,
        )
        objective_assessment = assess_objective_result(
            spec.measurement_plan(ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE),
            result, spec.objective,
        )
        if objective_assessment.decision in {ObjectiveDecision.KEEP, ObjectiveDecision.REVERT}:
            return ExperimentBatchPlan(
                ExperimentBatchDecision.STOP_DECISIVE, (), ResourceVector(),
                f"frozen primary objective reached {objective_assessment.decision.name}: {objective_assessment.reason}",
            )

    remaining_primary = [
        tid for tid in spec.sample_order[:spec.stopping_rule.maximum_pairs]
        if tid not in executed
    ]
    if not remaining_primary and all(cid in executed for cid in spec.adjacent_canary_ids):
        return ExperimentBatchPlan(
            ExperimentBatchDecision.STOP_NO_REMAINING_TASKS, (), ResourceVector(),
            "no frozen tasks remain",
        )

    if not executed:
        batch_ids = spec.initial_task_ids
    else:
        batch_ids = tuple(remaining_primary[:spec.stopping_rule.batch_size])
    if not batch_ids:
        return ExperimentBatchPlan(
            ExperimentBatchDecision.STOP_MAX_PAIRS, (), ResourceVector(),
            "frozen maximum primary pair count reached",
        )

    estimated = cost_model.estimate_batch(task_count=len(batch_ids), condition_count=len(spec.conditions))
    offer = CognitiveOffer(
        action_id=f"{spec.experiment_id}:batch:{len(primary_done)}",
        kind=CognitiveActionKind.EXPERIMENT_BATCH,
        current_stop_utility=current_stop_utility,
        post_action_stop_utility=expected_information_value,
        decision_cost_utility=decision_cost_utility,
        resources=estimated,
        mandatory=spec.stopping_rule.full_completion_required,
        evidence_ref=f"frozen-experiment:{spec.fingerprint()}",
    )
    gate = governor.consider(offer)
    if gate.decision is EconomyDecision.BLOCKED_MANDATORY_BUDGET:
        return ExperimentBatchPlan(
            ExperimentBatchDecision.BLOCKED_BUDGET, (), estimated,
            "mandatory experiment batch exceeds hard resource envelope",
        )
    if gate.decision in {
        EconomyDecision.SKIP_NONPOSITIVE_VOC,
        EconomyDecision.SKIP_INSUFFICIENT_MARGIN,
        EconomyDecision.SKIP_BUDGET,
    }:
        return ExperimentBatchPlan(
            ExperimentBatchDecision.STOP_ECONOMY, (), estimated,
            gate.reason,
        )
    return ExperimentBatchPlan(
        ExperimentBatchDecision.EXECUTE, tuple(batch_ids), estimated,
        "next frozen representative batch admitted by Economy Governor",
    )


def settle_experiment_batch_cost(
    governor: EconomyGovernor,
    batch_plan: ExperimentBatchPlan,
    execution: ExperimentExecutionResult,
):
    """Reconcile reserved batch resources with witnessed actual usage.

    If actual metering is incomplete, keep the conservative estimate reserved and
    return None rather than fabricating a precise cost.
    """
    if batch_plan.decision is not ExperimentBatchDecision.EXECUTE:
        raise AlmanalError("only an executed batch can be settled")
    if execution.estimated_resources != batch_plan.estimated_resources:
        raise AlmanalError("execution cost estimate drifted from admitted batch plan")
    if not execution.actual_resource_witness_complete:
        return None
    return governor.settle_last(execution.actual_resources)


def evaluate_experiment_pair(
    spec: ExperimentSpec,
    execution: ExperimentExecutionResult,
    *,
    reference: ExperimentCondition,
    candidate: ExperimentCondition,
    plain_baseline: PlainBaselineRecord | None = None,
    task_ids: tuple[str, ...] | None = None,
) -> MeasurementResult:
    plan = spec.measurement_plan(reference, candidate)
    selected_ids = task_ids or tuple(t.task_id for t in execution.trials)
    if reference is ExperimentCondition.PLAIN and spec.plain_baseline_reused:
        if plain_baseline is None:
            raise AlmanalError("reused PLAIN comparison requires baseline evidence")
        if plain_baseline.environment_fingerprint != spec.environment_fingerprint:
            raise AlmanalError("plain baseline environment drifted")
        if plain_baseline.plain_condition_fingerprint != spec.condition_spec(ExperimentCondition.PLAIN).fingerprint():
            raise AlmanalError("plain baseline condition identity drifted")
        stored_fp = dict(plain_baseline.task_fingerprints)
        frozen_fp = dict(spec.task_fingerprints)
        expected = {m.name for m in spec.metrics}
        trial_map = {t.task_id: t for t in execution.trials}
        observations = []
        for task_id in selected_ids:
            if stored_fp.get(task_id) != frozen_fp.get(task_id):
                raise AlmanalError("plain baseline task fingerprint drifted")
            if task_id not in trial_map:
                raise AlmanalError("candidate trial missing for reused plain comparison")
            ref = plain_baseline.metrics_for(task_id)
            cand = trial_map[task_id].metric_map(candidate)
            if set(ref) != expected or set(cand) != expected:
                raise AlmanalError("reused plain metrics do not match frozen experiment metrics")
            observations.append(PairObservation(
                pair_id=task_id,
                reference=tuple(sorted(ref.items())),
                candidate=tuple(sorted(cand.items())),
            ))
        return evaluate_measurement(plan, tuple(observations))

    observations = execution.paired_observations(
        spec, reference=reference, candidate=candidate, task_ids=selected_ids,
    )
    return evaluate_measurement(plan, observations)


