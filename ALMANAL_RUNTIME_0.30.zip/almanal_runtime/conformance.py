from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from .errors import ConformanceViolation

class ConformanceProfile(Enum):
    SPEC = auto()
    EXEC = auto()

@dataclass(frozen=True, slots=True)
class OperatorRealization:
    signature: str
    implementation_ref: str | None = None
    termination_contract: str | None = None
    termination_enforced: bool = False
    totalizes_failure: bool = False

    def is_exec_ready(self) -> bool:
        return bool(
            self.implementation_ref
            and self.termination_contract
            and self.termination_enforced
            and self.totalizes_failure
        )

class OperatorRegistry:
    def __init__(self) -> None:
        self.__operators: dict[str, OperatorRealization] = {}

    def register(self, name: str, realization: OperatorRealization) -> None:
        self.__operators[name] = realization

    def get(self, name: str) -> OperatorRealization | None:
        return self.__operators.get(name)

    def verify_profile(
        self, profile: ConformanceProfile, required_operators: frozenset[str]
    ) -> None:
        missing = [name for name in required_operators if name not in self.__operators]
        if missing:
            raise ConformanceViolation(f"missing operators: {sorted(missing)}")
        if profile is ConformanceProfile.EXEC:
            bad = [
                name for name in required_operators
                if not self.__operators[name].is_exec_ready()
            ]
            if bad:
                raise ConformanceViolation(
                    f"operators not EXEC-ready: {sorted(bad)}"
                )
