from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

class ObjectType(Enum):
    CLAIM = auto()
    OBSERVATION = auto()
    REPORT = auto()
    HYPOTHESIS = auto()
    FORMAL_RESULT = auto()
    MODEL = auto()
    SIMULATION = auto()
    PLAN = auto()
    ALGORITHM = auto()
    RECIPE = auto()
    STATE_UPDATE = auto()
    EVALUATION = auto()
    CERTIFICATE = auto()
    CONFLICT = auto()
    MEMORY = auto()
    ALGORITHM_TASK = auto()

@dataclass(frozen=True, slots=True)
class ObjectId:
    value: str
    def __str__(self) -> str:
        return self.value

@dataclass(frozen=True, slots=True)
class TypedObject:
    id: ObjectId
    object_type: ObjectType
    content: str
    scope: str
    semantic_referent: Optional[str] = None
    version: int = 1

    @staticmethod
    def new(id: str, object_type: ObjectType, content: str, scope: str) -> "TypedObject":
        return TypedObject(ObjectId(id), object_type, content, scope)

    def with_referent(self, referent: str) -> "TypedObject":
        return TypedObject(
            self.id, self.object_type, self.content, self.scope,
            referent, self.version
        )

@dataclass(frozen=True, slots=True)
class TaskSemantics:
    task_class: str
    current_state_schema: str
    goal_or_target_delta: str
    preservation_contract: str
    allowed_change_set: str
    realization_space: str
    evidence_or_oracle_contract: str
    perturbation_model: str
    cost_model: str
    scope: str
    version: int = 1

@dataclass(frozen=True, slots=True)
class EvaluationCriterion:
    metrics: tuple[str, ...]
    protected_metric_indexes: tuple[int, ...]
    thresholds: tuple[int, ...] = ()
    tolerances: tuple[int, ...] = ()
    scope: str = ""
    version: int = 1

@dataclass(frozen=True, slots=True)
class EpochSnapshot:
    task_semantics: TaskSemantics
    evaluation_criterion: EvaluationCriterion
    protected_invariants: tuple[str, ...]
    scope: str
    protocol_version: str

    def canonical_encode(self) -> str:
        # repr of frozen dataclasses is deterministic for these primitive fields.
        return (
            f"task={self.task_semantics!r}|eval={self.evaluation_criterion!r}|"
            f"inv={self.protected_invariants!r}|scope={self.scope}|"
            f"protocol={self.protocol_version}"
        )
