# ALMANAL Runtime 0.30 — Witnessed Closure / Validated Lease Guards

**Status:** executable reference runtime for **ALMANAL 14.30 candidate / NOT CANON**.

Inherited floors include witnessed-progress liveness, baseline fallback, practical Pareto axes, benchmark-last, bounded representation race, residual execution compression, and local I/O closure.

## 0.30 delta

- Strong search/finalization transitions fail closed on evidence: Representation Lock is validated before it can dominate alternatives; residual completion is evidence-bound; even an immaterial-resource skip must be witnessed.
- Representation lock requires explicit feasibility and a unique witnessed non-dominated lock survivor; Pareto tradeoffs stay unresolved.
- Optimistic candidate bounds/obligation metadata are beam-ranking hints, not peer-elimination evidence; only a proved external frontier or witnessed lock can reject a surviving representation.
- Finalization validates residual evidence internally instead of trusting a caller completion boolean. Extra finalization, reserve reopen, and post-lock falsifier work consume fresh validated witness identity through a serialized run-scoped ledger; concurrent reuse is rejected. The ledger also owns ordinary-finalization/reopen budgets, so caller counter resets cannot refresh them.
- Representation candidates require mechanism + nonnegative reasoning-work bounds and a nonempty frozen mandatory-obligation set.
- Arithmetic narrowing checks the complete intermediate interval. Benchmark-last prerequisites fail closed when omitted.
- No new conceptual subsystem; hardening stays in the existing evaluator/PLANNING boundary.

Exact wall time remains measurement-scoped; structural-work reductions are not fabricated milliseconds. Independent behavioral superiority remains **NOT_TESTED** without matching external paired evidence.
