import unittest
from dataclasses import replace

from almanal_runtime import Runtime, StopReason, QualityVector
from almanal_runtime.demo import demo_snapshot
from almanal_runtime.model import EvaluationCriterion
from almanal_runtime.orchestrator import run_worker_cycle, CognitiveRoutePlan
from almanal_runtime.worker import CandidateDraft
from almanal_runtime.prompting import default_library_capsules


class OneCandidateWorker:
    def __init__(self, candidate: CandidateDraft):
        self.candidate = candidate

    def generate(self, snapshot):
        return [self.candidate]

    def challenge(self, snapshot, candidates):
        return []

    def repair(self, snapshot, candidate, challenges):
        return candidate


def artifact_snapshot():
    base = demo_snapshot()
    criterion = EvaluationCriterion(
        metrics=("correctness", "artifact_parsimony"),
        protected_metric_indexes=(0,),
        thresholds=(1, 0),
        tolerances=(0, 0),
        scope="artifact-quality-regression",
    )
    return replace(base, evaluation_criterion=criterion, protocol_version="ALMANAL-14.21/PY-RUNTIME-0.21")


class BaselineDominanceClosureTests(unittest.TestCase):
    def test_dominated_enhanced_artifact_falls_back_to_frozen_baseline(self):
        baseline = CandidateDraft("shadow-baseline", "reuse derived intermediate")
        enhanced = CandidateDraft("enhanced", "recompute equivalent expression redundantly")
        rt = Runtime(artifact_snapshot(), 20)
        result = run_worker_cycle(
            rt,
            OneCandidateWorker(enhanced),
            lambda c: QualityVector((1, 9)),
            baseline_quality=QualityVector((1, 10)),
            baseline_candidate=baseline,
            comparison_indexes=(0, 1),
            require_strict_improvement=False,
        )
        self.assertEqual(result.selected, baseline)
        self.assertEqual(result.quality, QualityVector((1, 10)))
        self.assertTrue(result.used_baseline_fallback)
        self.assertEqual(rt.stop_reason, StopReason.NO_CERTIFIED_IMPROVEMENT)
        self.assertEqual(result.admissible, ())

    def test_strictly_better_artifact_displaces_baseline(self):
        baseline = CandidateDraft("shadow-baseline", "baseline")
        enhanced = CandidateDraft("enhanced", "simplified")
        rt = Runtime(artifact_snapshot(), 20)
        result = run_worker_cycle(
            rt,
            OneCandidateWorker(enhanced),
            lambda c: QualityVector((1, 11)),
            baseline_quality=QualityVector((1, 10)),
            baseline_candidate=baseline,
            comparison_indexes=(0, 1),
            require_strict_improvement=True,
        )
        self.assertEqual(result.selected, enhanced)
        self.assertFalse(result.used_baseline_fallback)
        self.assertEqual(rt.stop_reason, StopReason.COMPLETED)

    def test_planning_capsule_compiles_finalization_and_baseline_guard(self):
        planning = next(c for c in default_library_capsules() if c.capsule_id == "PLANNING")
        body = planning.body.lower()
        self.assertIn("shadow baseline", body)
        self.assertIn("output fallback", body)
        self.assertIn("duplicated computation", body)
        self.assertIn("re-verify", body)
        self.assertIn("fall back to baseline", body)

    def test_unverified_enhanced_route_cannot_displace_supplied_baseline(self):
        baseline = CandidateDraft("shadow-baseline", "known floor")
        enhanced = CandidateDraft("enhanced", "unverified elaboration")
        rt = Runtime(artifact_snapshot(), 20)
        result = run_worker_cycle(
            rt,
            OneCandidateWorker(enhanced),
            lambda c: QualityVector((1, 11)),
            baseline_quality=QualityVector((1, 10)),
            baseline_candidate=baseline,
            comparison_indexes=(0, 1),
            route_plan=CognitiveRoutePlan(True, False, False, False),
        )
        self.assertEqual(result.selected, baseline)
        self.assertTrue(result.used_baseline_fallback)
        self.assertEqual(rt.stop_reason, StopReason.NO_CERTIFIED_IMPROVEMENT)


if __name__ == "__main__":
    unittest.main()
