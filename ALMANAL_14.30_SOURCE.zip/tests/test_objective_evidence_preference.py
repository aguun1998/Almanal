import unittest
from fractions import Fraction

from almanal_runtime.errors import AlmanalError
from almanal_runtime.feedback import (
    MetricDirection, MetricRole, MetricSpec, MeasurementPlan, PairObservation,
    evaluate_measurement,
)
from almanal_runtime.improvement import (
    ClaimKind, EvidenceKind, EvidenceRequest, select_evidence_path,
    CheckpointDecision, ImprovementChangeRecord, ImprovementBatchPolicy,
    plan_improvement_checkpoint, ObjectiveSource, ObjectiveMode,
    ProgressGuardDecision, ImprovementProgressPolicy, ImprovementProgressState, guard_improvement_progress,
    resolve_experiment_objective,
)
from almanal_runtime.experiment import (
    SubjectType, SubjectUnderTest,
    ObjectiveDecision, assess_objective_result,
    ExperimentCondition, ExperimentConditionSpec, ExperimentEnvironment,
    ExperimentTask, ChangeImpact, design_localized_experiment,
    ExperimentRunOutput, ExperimentJudgeOutput, ExperimentRunnerBinding,
    execute_experiment, ExperimentCostModel, ExperimentBatchDecision, plan_next_experiment_batch,
)
from almanal_runtime.preference import (
    HumanOutcomeCandidate, PreferenceQueryDecision,
    bundle_subjective_outcomes, plan_preference_query,
)
from almanal_runtime.economy import EconomyGovernor, ResourceVector, UtilityEstimate


class EvidenceSelectorTests(unittest.TestCase):
    def test_deterministic_bug_does_not_buy_experiment(self):
        s = select_evidence_path(EvidenceRequest(ClaimKind.IMPLEMENTATION, deterministic_defect=True))
        self.assertFalse(s.experiment_required)
        self.assertEqual(s.kinds, (EvidenceKind.STATIC_CHECK, EvidenceKind.UNIT_PROPERTY))

    def test_behavioral_claim_requires_experiment(self):
        s = select_evidence_path(EvidenceRequest(ClaimKind.BEHAVIORAL))
        self.assertTrue(s.experiment_required)
        self.assertIn(EvidenceKind.EXPERIMENT, s.kinds)

    def test_direct_metered_cost_does_not_require_experiment(self):
        s = select_evidence_path(EvidenceRequest(ClaimKind.COST, direct_measurement_available=True))
        self.assertFalse(s.experiment_required)
        self.assertEqual(s.kinds, (EvidenceKind.DIRECT_MEASUREMENT,))

    def test_subjective_preference_uses_user_outcome_preference(self):
        s = select_evidence_path(EvidenceRequest(ClaimKind.SUBJECTIVE_PREFERENCE))
        self.assertFalse(s.experiment_required)
        self.assertEqual(s.kinds, (EvidenceKind.USER_PREFERENCE,))


class CheckpointCadenceTests(unittest.TestCase):
    def test_do_not_experiment_every_patch(self):
        changes = tuple(ImprovementChangeRecord(f"c{i}", True) for i in range(3))
        plan = plan_improvement_checkpoint(changes, ImprovementBatchPolicy(checkpoint_after_changes=4))
        self.assertEqual(plan.decision, CheckpointDecision.CONTINUE_LOCAL)

    def test_checkpoint_after_meaningful_batch(self):
        changes = tuple(ImprovementChangeRecord(f"c{i}", True) for i in range(4))
        plan = plan_improvement_checkpoint(changes, ImprovementBatchPolicy(checkpoint_after_changes=4))
        self.assertEqual(plan.decision, CheckpointDecision.CHECKPOINT_EVALUATION)

    def test_high_risk_change_triggers_early_checkpoint(self):
        plan = plan_improvement_checkpoint((ImprovementChangeRecord("risk", True, protected_or_high_risk=True),))
        self.assertEqual(plan.decision, CheckpointDecision.CHECKPOINT_EVALUATION)

    def test_failed_local_verification_blocks_batch_hiding(self):
        plan = plan_improvement_checkpoint((ImprovementChangeRecord("bad", False),))
        self.assertEqual(plan.decision, CheckpointDecision.BLOCK_FAILED_LOCAL_VERIFICATION)


class ImprovementProgressGuardTests(unittest.TestCase):
    def test_no_progress_stops_with_continuation_checkpoint(self):
        plan = guard_improvement_progress(
            ImprovementProgressState("epoch", step_index=5, last_progress_step=2, progress_refs=("test:1",)),
            ImprovementProgressPolicy(max_no_progress_steps=3, max_epoch_steps=12),
        )
        self.assertEqual(plan.decision, ProgressGuardDecision.CHECKPOINT_STOP)
        self.assertTrue(plan.continuation_required)

    def test_real_progress_refreshes_step_lease(self):
        plan = guard_improvement_progress(
            ImprovementProgressState("epoch", step_index=5, last_progress_step=4, progress_refs=("artifact:a", "test:b")),
            ImprovementProgressPolicy(max_no_progress_steps=3, max_epoch_steps=12),
        )
        self.assertEqual(plan.decision, ProgressGuardDecision.CONTINUE)

    def test_epoch_cap_stops_even_with_recent_progress(self):
        plan = guard_improvement_progress(
            ImprovementProgressState("epoch", step_index=12, last_progress_step=11, progress_refs=("decision:x",)),
            ImprovementProgressPolicy(max_no_progress_steps=3, max_epoch_steps=12),
        )
        self.assertEqual(plan.decision, ProgressGuardDecision.CHECKPOINT_STOP)

    def test_invalid_progress_policy_rejected(self):
        with self.assertRaises(AlmanalError):
            ImprovementProgressPolicy(max_no_progress_steps=4, max_epoch_steps=3)


class ObjectiveResolverTests(unittest.TestCase):
    @staticmethod
    def plan():
        return MeasurementPlan(
            "objective", "scope", (
                MetricSpec("quality", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, Fraction(1)),
                MetricSpec("correctness", MetricDirection.HIGHER_IS_BETTER, MetricRole.ERROR, Fraction(1), protected=True),
                MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, Fraction(5)),
            ), minimum_pairs=6, alpha=Fraction(1, 20),
        )

    def test_user_goal_outranks_native_and_change_goal(self):
        o = resolve_experiment_objective(
            user_primary=("quality",), native_primary=("correctness",), change_primary=("tokens",),
            general_value_metrics=("quality",), cost_metrics=("tokens",),
        )
        self.assertEqual(o.source, ObjectiveSource.USER_EXPLICIT)
        self.assertEqual(o.primary_metrics, ("quality",))

    def test_just_improve_is_general_pareto_not_cost_minimization(self):
        o = resolve_experiment_objective(
            general_value_metrics=("quality",), protected_metrics=("correctness",), cost_metrics=("tokens",)
        )
        self.assertEqual(o.mode, ObjectiveMode.GENERAL_PARETO)
        self.assertEqual(o.primary_metrics, ("quality",))
        self.assertEqual(o.cost_metrics, ("tokens",))

    def test_goal_free_cost_only_objective_is_rejected(self):
        with self.assertRaises(AlmanalError):
            resolve_experiment_objective(general_value_metrics=(), cost_metrics=("tokens",))

    def test_general_improvement_allows_cost_tiebreak_when_quality_equivalent(self):
        p = self.plan()
        obs = tuple(PairObservation(
            str(i),
            (("quality", Fraction(10)), ("correctness", Fraction(10)), ("tokens", Fraction(100))),
            (("quality", Fraction(10)), ("correctness", Fraction(10)), ("tokens", Fraction(80))),
        ) for i in range(6))
        result = evaluate_measurement(p, obs)
        objective = resolve_experiment_objective(
            general_value_metrics=("quality",), protected_metrics=("correctness",), cost_metrics=("tokens",)
        )
        assessment = assess_objective_result(p, result, objective)
        self.assertEqual(assessment.decision, ObjectiveDecision.KEEP)
        self.assertEqual(assessment.cost_improvements, ("tokens",))

    def test_directed_quality_goal_is_not_satisfied_by_cost_only_gain(self):
        p = self.plan()
        obs = tuple(PairObservation(
            str(i),
            (("quality", Fraction(10)), ("correctness", Fraction(10)), ("tokens", Fraction(100))),
            (("quality", Fraction(10)), ("correctness", Fraction(10)), ("tokens", Fraction(80))),
        ) for i in range(6))
        result = evaluate_measurement(p, obs)
        objective = resolve_experiment_objective(
            user_primary=("quality",), protected_metrics=("correctness",), cost_metrics=("tokens",)
        )
        assessment = assess_objective_result(p, result, objective)
        self.assertEqual(assessment.decision, ObjectiveDecision.CONTINUE)


class PreferenceBundlingTests(unittest.TestCase):
    def candidates(self):
        return (
            HumanOutcomeCandidate(
                "literal", "He answered in a restrained, literal voice.", "impl:literal",
                (("literalness", "high"), ("intensity", "low")), True,
            ),
            HumanOutcomeCandidate(
                "natural", "He snapped back in a sharper, more natural voice.", "impl:natural",
                (("literalness", "medium"), ("intensity", "high")), True,
            ),
        )

    def test_subjective_choices_are_bundled_as_human_outputs_not_internals(self):
        bundle = bundle_subjective_outcomes(
            bundle_id="translation-tone", scope_ref="novel/chapter", dimensions=("literalness", "intensity"),
            candidates=self.candidates(),
        )
        view = bundle.human_view()
        self.assertEqual([label for label, _ in view], ["A", "B"])
        joined = " ".join(text for _, text in view)
        self.assertNotIn("impl:", joined)
        self.assertIn("restrained", joined)
        self.assertIn("sharper", joined)

    def test_hard_invalid_candidate_cannot_be_delegated_to_user(self):
        bad = HumanOutcomeCandidate("bad", "Pretty but mistranslated.", "impl:bad", (), False)
        with self.assertRaises(AlmanalError):
            bundle_subjective_outcomes(
                bundle_id="bad", scope_ref="novel", dimensions=("tone",),
                candidates=(self.candidates()[0], bad),
            )

    def test_stable_known_preference_avoids_user_interruption(self):
        q = plan_preference_query(
            preference_uncertainty=Fraction(1, 2), decision_impact=Fraction(1, 2),
            known_preference_confidence=Fraction(9, 10),
        )
        self.assertEqual(q.decision, PreferenceQueryDecision.AUTO_SELECT_KNOWN_PREFERENCE)

    def test_decision_relevant_uncertainty_asks_once(self):
        q = plan_preference_query(
            preference_uncertainty=Fraction(3, 4), decision_impact=Fraction(3, 4),
            known_preference_confidence=Fraction(1, 4),
        )
        self.assertEqual(q.decision, PreferenceQueryDecision.ASK_USER)


class ObjectiveAwareSchedulerTests(unittest.TestCase):
    def test_cost_only_gain_does_not_end_quality_directed_experiment(self):
        tasks = tuple(ExperimentTask(f"t{i}", "analysis", f"task {i}") for i in range(4))
        metrics = (
            MetricSpec("quality", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, Fraction(1)),
            MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, Fraction(5)),
        )
        conditions = (
            ExperimentConditionSpec(ExperimentCondition.PLAIN, "base", "none", "plain"),
            ExperimentConditionSpec(ExperimentCondition.PARENT, "parent", "r1", "parent"),
            ExperimentConditionSpec(ExperimentCondition.CANDIDATE, "candidate", "r2", "candidate"),
        )
        env = ExperimentEnvironment("model", "tasks", "judge", "budget", resource_budget=ResourceVector(tokens=10000, steps=1000))
        objective = resolve_experiment_objective(user_primary=("quality",), cost_metrics=("tokens",))
        spec = design_localized_experiment(
            experiment_id="objective-stop", question="quality first",
            impact=ChangeImpact("chg", ("runtime",), ("analysis",), ("analysis",), ("quality", "tokens")),
            task_catalog=tasks, metrics=metrics, environment=env, condition_specs=conditions,
            objective=objective, minimum_pairs=3, maximum_pairs=4, initial_batch_size=3, batch_size=1,
        )
        def runner_for(name, tokens):
            return lambda task: ExperimentRunOutput(f"{name}:{task.task_id}", (("tokens", Fraction(tokens)),))
        bindings = {
            ExperimentCondition.PLAIN: ExperimentRunnerBinding(spec.condition_spec(ExperimentCondition.PLAIN).fingerprint(), runner_for("plain", 120)),
            ExperimentCondition.PARENT: ExperimentRunnerBinding(spec.condition_spec(ExperimentCondition.PARENT).fingerprint(), runner_for("parent", 100)),
            ExperimentCondition.CANDIDATE: ExperimentRunnerBinding(spec.condition_spec(ExperimentCondition.CANDIDATE).fingerprint(), runner_for("candidate", 70)),
        }
        def judge(task, presented):
            return ExperimentJudgeOutput(tuple((label, (("quality", Fraction(10)),)) for label, _ in presented))
        execution = execute_experiment(spec, tasks, runners=bindings, blind_evaluator=judge, execution_witness_ref="pilot")
        governor = EconomyGovernor(budget=env.resource_budget)
        nxt = plan_next_experiment_batch(
            spec, execution_so_far=execution, cost_model=ExperimentCostModel(), governor=governor,
            expected_information_value=UtilityEstimate(Fraction(2), Fraction(3), Fraction(4)),
            current_stop_utility=Fraction(1),
        )
        self.assertEqual(nxt.decision, ExperimentBatchDecision.EXECUTE)
        self.assertEqual(len(nxt.task_ids), 1)


class GenericExperimentSubjectTests(unittest.TestCase):
    def test_experiment_engine_accepts_non_almanal_algorithm_subject(self):
        tasks = tuple(ExperimentTask(f"t{i}", "game", f"state {i}") for i in range(3))
        metrics = (
            MetricSpec("win_rate", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, Fraction(1)),
            MetricSpec("compute", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, Fraction(1)),
        )
        conditions = (
            ExperimentConditionSpec(ExperimentCondition.PLAIN, "baseline", "engine", "plain"),
            ExperimentConditionSpec(ExperimentCondition.PARENT, "algo-v1", "engine", "parent"),
            ExperimentConditionSpec(ExperimentCondition.CANDIDATE, "algo-v2", "engine", "candidate"),
        )
        subject = SubjectUnderTest("mahjong-policy", SubjectType.ALGORITHM, "riichi-algorithm-v2")
        objective = resolve_experiment_objective(native_primary=("win_rate",), cost_metrics=("compute",))
        spec = design_localized_experiment(
            experiment_id="generic", question="did algorithm improve?",
            impact=ChangeImpact("c", ("policy",), ("decision",), ("game",), ("win_rate", "compute")),
            task_catalog=tasks, metrics=metrics,
            environment=ExperimentEnvironment("model", "games", "judge", "budget"),
            condition_specs=conditions, subject=subject, objective=objective,
            minimum_pairs=2, initial_batch_size=1, batch_size=1,
        )
        self.assertEqual(spec.subject.subject_type, SubjectType.ALGORITHM)
        self.assertEqual(spec.objective.primary_metrics, ("win_rate",))
        self.assertNotIn("ALMANAL", spec.subject.subject_ref)


if __name__ == "__main__":
    unittest.main()
