import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]

class Test1426IOClosure(unittest.TestCase):
    def test_compact_io_rule(self):
        s=(ROOT/"spec"/"ALMANAL.md").read_text()
        for x in ["LOCAL I/O BOTTLENECK CLOSURE","CoreCheapCanExposeIO","CustomIO != Default","lightweight buffering"]:
            self.assertIn(x,s)
    def test_active_io_rule(self):
        s=(ROOT/"spec"/"ACTIVE_CORE.md").read_text()
        for x in ["Local I/O bottleneck closure","IOVolumeMaterial -> AuditIO","peak-memory/source"]:
            self.assertIn(x,s)

if __name__=="__main__": unittest.main()
