import unittest

from almanal_runtime.economy import (
    FormalObjectProfile, FormalResidency,
    classify_formal_object, summarize_formalism,
)


class FormalismEconomicsTests(unittest.TestCase):
    def test_runtime_required_is_hot(self):
        d = classify_formal_object(
            FormalObjectProfile(
                "runtime-freeze",
                source_chars=100,
                active_context_chars=80,
                runtime_required=True,
            )
        )
        self.assertEqual(d.residency, FormalResidency.HOT)
        self.assertTrue(d.keep)

    def test_task_conditional_guard_is_warm(self):
        d = classify_formal_object(
            FormalObjectProfile(
                "social-guard",
                source_chars=120,
                active_context_chars=60,
                protected_defect_guard=True,
                task_conditional=True,
            )
        )
        self.assertEqual(d.residency, FormalResidency.WARM)

    def test_proof_only_is_cold_and_costs_no_active_context(self):
        d = classify_formal_object(
            FormalObjectProfile(
                "bellman-proof",
                source_chars=500,
                active_context_chars=0,
                proof_only=True,
            )
        )
        self.assertEqual(d.residency, FormalResidency.COLD)
        self.assertEqual(d.net_active_char_cost, 0)

    def test_unjustified_formalism_defaults_to_delete(self):
        d = classify_formal_object(
            FormalObjectProfile(
                "decorative-theorem",
                source_chars=300,
                active_context_chars=100,
            )
        )
        self.assertEqual(d.residency, FormalResidency.DELETE)
        self.assertFalse(d.keep)

    def test_compression_can_justify_warm_object(self):
        d = classify_formal_object(
            FormalObjectProfile(
                "compact-rule",
                source_chars=100,
                active_context_chars=40,
                compression_chars_saved=80,
            )
        )
        self.assertEqual(d.residency, FormalResidency.WARM)
        self.assertEqual(d.net_active_char_cost, 0)

    def test_footprint_separates_hot_warm_cold_delete(self):
        footprint = summarize_formalism((
            FormalObjectProfile(
                "hot", 100, 80, runtime_required=True
            ),
            FormalObjectProfile(
                "warm", 100, 50, empirical_value_witnessed=True
            ),
            FormalObjectProfile(
                "cold", 300, 0, proof_only=True
            ),
            FormalObjectProfile(
                "delete", 200, 70
            ),
        ))
        self.assertEqual(footprint.hot_chars, 80)
        self.assertEqual(footprint.warm_chars, 50)
        self.assertEqual(footprint.cold_chars, 300)
        self.assertEqual(footprint.deleted_chars, 200)
        self.assertEqual(footprint.active_floor_chars, 80)


if __name__ == "__main__":
    unittest.main()
