import os
import subprocess
import sys
import threading
import unittest
from fractions import Fraction

from almanal_runtime.design_direction import (
    DesignPressure, DesignDirection, DesignSeverity, DesignSignal, LegacySourceBasis, LegacyPriorCard,
    SubsystemProposal, SubsystemAdmissionDecision, assess_subsystem_admission,
    select_design_direction,
)
from almanal_runtime.verification import (
    EpistemicClaimIdentity, ClaimRevisionStatus, assess_claim_revision,
)
from almanal_runtime.feedback import (
    CausalEvidenceKind, CausalEvidence, CausalExecutionReceipt, CausalWitnessBasis,
    CausalHypothesis, CausalTestSpec, CausalSupport, diagnose_cause,
)
from almanal_runtime.economy import (
    CognitiveActionPackage, CognitiveActionKind, CognitiveOffer, EconomyDecision, EconomyGovernor, EconomyPolicy, ResourceVector, UtilityEstimate,
    gate_cognitive_package,
)
from almanal_runtime.model import (
    EpochSnapshot, TaskSemantics, EvaluationCriterion, TypedObject, ObjectId, ObjectType,
)
from almanal_runtime.runtime import Runtime
from almanal_runtime.orchestrator import plan_cognitive_route
from almanal_runtime.provenance import SourceRoot
from almanal_runtime.authority import Permission


class DirectionAndHardeningTests(unittest.TestCase):
    def test_design_direction_uses_legacy_prior_as_advisory(self):
        signal = DesignSignal("s1", DesignPressure.SEMANTIC_WITNESS_GAP, DesignSeverity.CRITICAL, "redteam:causal", True, True)
        prior = LegacyPriorCard(
            "atam", "CMU-SEI-ATAM", frozenset({DesignPressure.SEMANTIC_WITNESS_GAP}),
            ("identify risk/sensitivity/tradeoff points",), source_basis=LegacySourceBasis.RETRIEVED_PRIMARY,
            retrieval_evidence_ref="web:sei-atam",
        )
        plan = select_design_direction((signal,), (prior,), prior_validator=lambda p: p.prior_id == "atam")
        self.assertEqual(plan.selected, DesignDirection.HARDEN_SEMANTIC_WITNESSING)
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ("atam",))

    def test_new_subsystem_requires_separation_and_exit_path(self):
        p = SubsystemProposal("truth-axis", existing_primitive_insufficient=False)
        self.assertEqual(assess_subsystem_admission(p).decision, SubsystemAdmissionDecision.USE_EXISTING_COMPOSITION)
        q = SubsystemProposal(
            "new-manager", unique_persistent_state=True, independent_lifecycle=True,
            existing_primitive_insufficient=True, legacy_search_ref="web:legacy-search",
            expected_lifecycle_value_ref="e:value", exit_or_compile_away_path="SCA after 3 checkpoints",
        )
        self.assertEqual(assess_subsystem_admission(q, legacy_search_validator=lambda ref: ref == "web:legacy-search").decision, SubsystemAdmissionDecision.PROVISIONAL_COMPONENT)


    def test_declared_only_legacy_prior_cannot_steer_direction(self):
        signal = DesignSignal("s2", DesignPressure.STRUCTURAL_COMPLEXITY, DesignSeverity.HIGH, "sca:1")
        prior = LegacyPriorCard(
            "fake", "self-declared", frozenset({DesignPressure.STRUCTURAL_COMPLEXITY}),
            ("just trust me",), source_basis=LegacySourceBasis.DECLARED_ONLY,
        )
        plan = select_design_direction((signal,), (prior,))
        self.assertEqual(plan.selected, DesignDirection.SIMPLIFY)
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ())

    def test_new_subsystem_blocks_when_legacy_search_was_not_attempted(self):
        p = SubsystemProposal(
            "new-organ", unique_persistent_state=True, existing_primitive_insufficient=True,
            expected_lifecycle_value_ref="e:value", exit_or_compile_away_path="SCA checkpoint",
        )
        self.assertEqual(assess_subsystem_admission(p).decision, SubsystemAdmissionDecision.BLOCKED)

    def test_post_outcome_claim_mode_change_is_new_claim(self):
        before = EpistemicClaimIdentity("worst-case complexity is O(n log n)", "all inputs", (), "UNIVERSAL")
        after = EpistemicClaimIdentity("typical complexity is O(n log n)", "typical inputs", (), "STATISTICAL")
        status, _ = assess_claim_revision(before, after, outcome_seen=True)
        self.assertEqual(status, ClaimRevisionStatus.NEW_CLAIM_REQUIRED)

    def test_causal_metadata_without_execution_receipt_is_not_strong(self):
        h = CausalHypothesis("h", "mechanism", "component", ("m",))
        t = CausalTestSpec("t", "h", CausalEvidenceKind.ABLATION, "disable mechanism", (("m", 1),))
        ev = CausalEvidence("e", "h", t.fingerprint(), CausalEvidenceKind.ABLATION, True,
                            (("m", Fraction(1)),), True, "string-only")
        d = diagnose_cause(h, (t,), (ev,), regressed_metrics=("m",))
        self.assertEqual(d.support, CausalSupport.ASSOCIATED_ONLY)

    def test_forged_matching_receipt_without_validator_is_not_strong(self):
        h = CausalHypothesis("h", "mechanism", "component", ("m",))
        t = CausalTestSpec("t", "h", CausalEvidenceKind.ABLATION, "disable mechanism", (("m", 1),))
        receipt = CausalExecutionReceipt("forged", t.fingerprint(), CausalEvidenceKind.ABLATION, "exec", "measure", "env", CausalWitnessBasis.RUNTIME_EXECUTED)
        ev = CausalEvidence("e", "h", t.fingerprint(), CausalEvidenceKind.ABLATION, True,
                            (("m", Fraction(1)),), True, "prov", receipt)
        self.assertEqual(diagnose_cause(h, (t,), (ev,), regressed_metrics=("m",)).support, CausalSupport.ASSOCIATED_ONLY)
        d = diagnose_cause(h, (t,), (ev,), regressed_metrics=("m",), receipt_validator=lambda r: r.receipt_id == "forged")
        self.assertEqual(d.support, CausalSupport.SUPPORTED)

    def test_causal_receipt_validator_exception_does_not_promote_evidence(self):
        h = CausalHypothesis("h", "mechanism", "component", ("m",))
        t = CausalTestSpec("t", "h", CausalEvidenceKind.ABLATION, "disable mechanism", (("m", 1),))
        receipt = CausalExecutionReceipt("r", t.fingerprint(), CausalEvidenceKind.ABLATION, "exec", "measure", "env", CausalWitnessBasis.RUNTIME_EXECUTED)
        ev = CausalEvidence("e", "h", t.fingerprint(), CausalEvidenceKind.ABLATION, True,
                            (("m", Fraction(1)),), True, "prov", receipt)
        def boom(_):
            raise RuntimeError("validator failed")
        self.assertEqual(
            diagnose_cause(h, (t,), (ev,), regressed_metrics=("m",), receipt_validator=boom).support,
            CausalSupport.ASSOCIATED_ONLY,
        )

    def test_mismatched_causal_receipt_is_not_strong(self):
        h = CausalHypothesis("h", "mechanism", "component", ("m",))
        t = CausalTestSpec("t", "h", CausalEvidenceKind.ABLATION, "disable mechanism", (("m", 1),))
        receipt = CausalExecutionReceipt("r", "wrong", CausalEvidenceKind.ABLATION, "exec", "measure", "env", CausalWitnessBasis.RUNTIME_EXECUTED)
        ev = CausalEvidence("e", "h", t.fingerprint(), CausalEvidenceKind.ABLATION, True,
                            (("m", Fraction(1)),), True, "prov", receipt)
        self.assertEqual(diagnose_cause(h, (t,), (ev,), regressed_metrics=("m",)).support, CausalSupport.ASSOCIATED_ONLY)

    def test_multi_step_package_can_pass_when_individual_first_step_would_not(self):
        package = CognitiveActionPackage(
            "deep-chain", ("search", "counterexample", "redesign"), ResourceVector(tokens=300, steps=3),
            UtilityEstimate(Fraction(2), Fraction(4), Fraction(6)), "legacy+trace",
        )
        result = gate_cognitive_package(package, remaining=ResourceVector(tokens=1000, steps=10), policy=EconomyPolicy())
        self.assertEqual(result.decision, EconomyDecision.EXECUTE)



    def test_package_voc_is_wired_into_real_cognitive_route(self):
        gov = EconomyGovernor(budget=ResourceVector(tokens=100, steps=5))
        generate = CognitiveOffer(
            "g", CognitiveActionKind.GENERATE, Fraction(0),
            UtilityEstimate(Fraction(-3), Fraction(-2), Fraction(-1)), Fraction(0),
            ResourceVector(tokens=20, steps=1), evidence_ref="e:g",
        )
        challenge = CognitiveOffer(
            "c", CognitiveActionKind.CHALLENGE, Fraction(0),
            UtilityEstimate(Fraction(-2), Fraction(-1), Fraction(0)), Fraction(0),
            ResourceVector(tokens=20, steps=1), evidence_ref="e:c",
        )
        package = CognitiveActionPackage(
            "deep", ("g", "c"), ResourceVector(tokens=40, steps=2),
            UtilityEstimate(Fraction(1), Fraction(3), Fraction(5)), "e:bundle",
        )
        plan = plan_cognitive_route(gov, (generate, challenge), (package,))
        self.assertTrue(plan.generate)
        self.assertTrue(plan.challenge)
        self.assertEqual(gov.remaining, ResourceVector(tokens=60, steps=3))
        self.assertEqual(gov.records()[0].action_id, "package:deep")

    def test_route_package_cannot_understate_contained_resource_cost(self):
        gov = EconomyGovernor(budget=ResourceVector(tokens=100, steps=5))
        generate = CognitiveOffer(
            "g", CognitiveActionKind.GENERATE, Fraction(0), UtilityEstimate(Fraction(-1), Fraction(-1), Fraction(-1)), Fraction(0),
            ResourceVector(tokens=20, steps=1), evidence_ref="e:g",
        )
        challenge = CognitiveOffer(
            "c", CognitiveActionKind.CHALLENGE, Fraction(0), UtilityEstimate(Fraction(-1), Fraction(-1), Fraction(-1)), Fraction(0),
            ResourceVector(tokens=20, steps=1), evidence_ref="e:c",
        )
        package = CognitiveActionPackage(
            "cheap-lie", ("g", "c"), ResourceVector(tokens=1, steps=1),
            UtilityEstimate(Fraction(1), Fraction(2), Fraction(3)), "e:bundle",
        )
        with self.assertRaises(Exception):
            plan_cognitive_route(gov, (generate, challenge), (package,))

    def test_package_voc_cannot_hide_unrelated_action(self):
        with self.assertRaises(Exception):
            CognitiveActionPackage(
                "bad-chain", ("search", "unrelated", "redesign"), ResourceVector(tokens=30, steps=3),
                UtilityEstimate(Fraction(1), Fraction(2), Fraction(3)), "evidence",
                dependency_edges=(("search", "redesign"),), terminal_action_id="redesign",
            )

    def _runtime(self):
        snap = EpochSnapshot(
            TaskSemantics("OPTIMIZE", "state", "goal", "preserve", "allowed", "space",
                          "oracle", "none", "steps", "scope"),
            EvaluationCriterion(("quality", "neg_cost"), (0, 1), scope="scope"),
            ("freeze", "authority"), "scope", "14.17-test",
        )
        return Runtime(snap, 20)


    def test_partial_shared_commit_exception_rolls_back_all_ledgers(self):
        rt = self._runtime()
        real = rt._Runtime__authority
        class FaultAuthority:
            def contains_object(self, object_id): return real.contains_object(object_id)
            def register_object(self, object_id, authority): raise RuntimeError("injected commit fault")
            def discard_object(self, object_id): return real.discard_object(object_id)
            def authority_of(self, object_id): return real.authority_of(object_id)
            def validate_output(self, operator, inputs, requested): return real.validate_output(operator, inputs, requested)
        rt._Runtime__authority = FaultAuthority()
        oid = ObjectId("faulted")
        with self.assertRaises(RuntimeError):
            rt.ingest_object(
                TypedObject(oid, ObjectType.ALGORITHM, "content", "scope", "ref"),
                frozenset({SourceRoot("root")}), frozenset({Permission.READ}),
            )
        self.assertEqual(rt.objects(), ())
        self.assertFalse(rt._Runtime__provenance.contains(oid))
        self.assertFalse(real.contains_object(oid))

    def test_parallel_ingest_serializes_shared_commit(self):
        rt = self._runtime()
        errors=[]
        def worker(i):
            try:
                rt.ingest_object(
                    TypedObject(ObjectId(f"o{i}"), ObjectType.ALGORITHM, f"c{i}", "scope", "ref"),
                    frozenset({SourceRoot(f"r{i}")}), frozenset({Permission.READ}),
                )
            except Exception as exc:
                errors.append(exc)
        threads=[threading.Thread(target=worker,args=(i,)) for i in range(20)]
        [t.start() for t in threads]; [t.join() for t in threads]
        self.assertFalse(errors)
        self.assertEqual(len(rt.objects()), 20)
        for i in range(20):
            oid=ObjectId(f"o{i}")
            self.assertTrue(rt.provenance_roots(oid))
            self.assertEqual(rt.authority_of(oid), frozenset({Permission.READ}))

    def test_design_direction_is_task_local_lazy_warm(self):
        code = (
            "import sys, almanal_runtime as a; "
            "print(int('almanal_runtime.design_direction' in sys.modules)); "
            "_ = a.select_design_direction; "
            "print(int('almanal_runtime.design_direction' in sys.modules)); "
            "print(int('almanal_runtime.feedback' in sys.modules)); "
            "print(int('almanal_runtime.consolidation' in sys.modules))"
        )
        proc = subprocess.run([sys.executable, "-S", "-c", code], capture_output=True, text=True, check=False, timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout.strip().splitlines(), ["0", "1", "0", "0"])


    def test_shadow_reserve_is_distinct_from_known_label_first_when_possible(self):
        from almanal_runtime.experiment import (
            ChangeImpact, ExperimentDifficulty, ExperimentRisk, ExperimentTask,
            _representative_order, _shadow_reserve_task,
        )
        tasks = (
            ExperimentTask("a", "c", "p-a", ExperimentDifficulty.EASY, ExperimentRisk.LOW, ("x",), ("known-a",)),
            ExperimentTask("b", "c", "p-b", ExperimentDifficulty.MEDIUM, ExperimentRisk.HIGH, ("y",), ("known-b",)),
            ExperimentTask("c", "c", "p-c", ExperimentDifficulty.HARD, ExperimentRisk.MEDIUM, ("z",), ("known-c",)),
        )
        impact = ChangeImpact("chg", ("component",), ("x", "y", "z"), ("c",), ("quality",), ())
        order = _representative_order(tasks, impact, 7)
        shadow = _shadow_reserve_task(tasks, impact, 7, order[0])
        self.assertIsNotNone(shadow)
        self.assertNotEqual(shadow, order[0])

    @unittest.skipIf(os.environ.get("ALMANAL_SELFTEST_CHILD") == "1", "avoid recursive selftest smoke")
    def test_cli_selftest_entrypoint_smoke(self):
        env = dict(os.environ)
        env["ALMANAL_SELFTEST_CHILD"] = "1"
        proc = subprocess.run([sys.executable, "-m", "almanal_runtime", "selftest"], capture_output=True, text=True, check=False, env=env, timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("OK", proc.stderr + proc.stdout)

    def test_cli_public_entrypoint_smoke(self):
        proc = subprocess.run([sys.executable, "-m", "almanal_runtime", "demo"], capture_output=True, text=True, check=False, timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("status=COMPLETE", proc.stdout)


if __name__ == "__main__":
    unittest.main()
