import unittest
from fractions import Fraction

from almanal_runtime.behavioral_benchmark import (
    BehavioralClaimStatus, PairedBehaviorObservation,
    BehavioralClaimPolicy, exact_two_sided_sign_test_pvalue,
    gate_behavioral_superiority_claim,
)


def obs(i, *, q_plain=10, q_a=10, over_plain=1, over_a=0, tok_plain=100, tok_a=80):
    return PairedBehaviorObservation(
        str(i),
        Fraction(q_plain), Fraction(q_a),
        over_plain, over_a, tok_plain, tok_a,
    )


class BehavioralBenchmarkTests(unittest.TestCase):
    def test_no_trials_means_not_tested(self):
        status, summary, _ = gate_behavioral_superiority_claim(())
        self.assertEqual(status, BehavioralClaimStatus.NOT_TESTED)
        self.assertIsNone(summary)

    def test_too_few_pairs_cannot_support_claim(self):
        status, _, _ = gate_behavioral_superiority_claim(
            tuple(obs(i) for i in range(5)),
            policy=BehavioralClaimPolicy(
                minimum_pairs=10,
                require_overclaim_improvement=True,
            ),
        )
        self.assertEqual(status, BehavioralClaimStatus.INSUFFICIENT_EVIDENCE)

    def test_exact_sign_test_all_wins(self):
        # n=6 all wins -> two-sided p = 2/64 = 1/32
        self.assertEqual(
            exact_two_sided_sign_test_pvalue(wins=6, losses=0),
            Fraction(1, 32),
        )

    def test_scoped_overclaim_and_token_claim_can_pass(self):
        trials = tuple(obs(i) for i in range(12))
        status, summary, _ = gate_behavioral_superiority_claim(
            trials,
            policy=BehavioralClaimPolicy(
                minimum_pairs=10,
                alpha=Fraction(1, 20),
                require_quality_nonloss_majority=True,
                require_overclaim_improvement=True,
                require_token_improvement=True,
            ),
        )
        self.assertEqual(status, BehavioralClaimStatus.SUPPORTED_SCOPED)
        self.assertLess(summary.total_almanal_tokens, summary.total_plain_tokens)

    def test_quality_regression_blocks_supported_claim(self):
        trials = tuple(
            obs(i, q_plain=10, q_a=9)
            for i in range(12)
        )
        status, _, _ = gate_behavioral_superiority_claim(
            trials,
            policy=BehavioralClaimPolicy(
                minimum_pairs=10,
                require_overclaim_improvement=True,
                require_token_improvement=True,
            ),
        )
        self.assertEqual(status, BehavioralClaimStatus.NOT_SUPPORTED)


if __name__ == "__main__":
    unittest.main()
