import unittest

from almanal_runtime.prompting import (
    WorkerRole, PromptCapsule, build_prompt_packet, default_library_capsules
)


class PromptMinimalityTests(unittest.TestCase):
    def test_only_relevant_library_capsules_mount(self):
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="Improve a chess-search algorithm.",
            task_tags=frozenset({"algorithm","synthesis"}),
            capsules=default_library_capsules(),
            budget_tokens=4000,
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertIn("PLANNING", ids)
        self.assertNotIn("HUMAN_CULTURE", ids)
        self.assertNotIn("DEFENSE", ids)

    def test_runtime_enforced_rule_omitted_by_default(self):
        packet = build_prompt_packet(
            role=WorkerRole.REPAIR,
            task_text="Repair revision authority handling.",
            task_tags=frozenset({"authority","revision","learning"}),
            capsules=default_library_capsules(),
            budget_tokens=4000,
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertNotIn("RUNTIME_AUTHORITY_ENVELOPE", ids)
        self.assertGreaterEqual(packet.runtime_enforced_omitted, 1)

    def test_prompt_budget_is_hard(self):
        packet = build_prompt_packet(
            role=WorkerRole.CHALLENGE,
            task_text="Attack the algorithm.",
            task_tags=frozenset({
                "algorithm","synthesis","learning","revision","social",
                "security","threat","culture","human","moral"
            }),
            capsules=default_library_capsules(),
            budget_tokens=400,
        )
        self.assertLessEqual(packet.estimated_tokens, 400)
        self.assertGreater(len(packet.omitted_capsules), 0)

    def test_behaviorally_required_machine_rule_can_be_included(self):
        capsule = PromptCapsule(
            "X", frozenset({"x"}), frozenset({WorkerRole.GENERATE}),
            "Do not output forbidden transition X.", "src",
            runtime_enforced=True, behaviorally_required=True, priority=10,
        )
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="Do x task.",
            task_tags=frozenset({"x"}),
            capsules=(capsule,),
            budget_tokens=100,
        )
        self.assertEqual([c.capsule_id for c in packet.mounted_capsules], ["X"])


    def test_dependency_cannot_be_dropped_by_budget(self):
        dep = PromptCapsule(
            "DEP", frozenset({"x"}), frozenset({WorkerRole.GENERATE}),
            "dependency contract " * 8, "dep-src", priority=1,
        )
        root = PromptCapsule(
            "ROOT", frozenset({"x"}), frozenset({WorkerRole.GENERATE}),
            "root contract " * 8, "root-src", priority=100,
            dependencies=frozenset({"DEP"}),
        )
        # Enough for ROOT alone, not ROOT+DEP: valid planner must omit ROOT too.
        counter = lambda text: max(1, (len(text) + 3)//4)
        root_only_budget = counter("task") + counter("ROLE: GENERATE\nTASK:\n") + counter(root.body) + 2
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="task",
            task_tags=frozenset({"x"}),
            capsules=(dep, root),
            budget_tokens=root_only_budget,
            token_counter=counter,
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertFalse("ROOT" in ids and "DEP" not in ids)



    def test_adapter_token_counter_controls_hard_budget(self):
        capsule = PromptCapsule(
            "C", frozenset({"x"}), frozenset({WorkerRole.GENERATE}),
            "abcdefghij", "src", priority=5,
        )
        counter = lambda text: len(text)  # exact fake provider: 1 char = 1 token
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="x",
            task_tags=frozenset({"x"}),
            capsules=(capsule,),
            budget_tokens=100,
            token_counter=counter,
        )
        expected = counter("x") + counter("ROLE: GENERATE\nTASK:\n") + counter(capsule.body)
        self.assertEqual(packet.estimated_tokens, expected)


    def test_learning_capsule_does_not_mount_during_generation_stage(self):
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="Improve a revision algorithm.",
            task_tags=frozenset({"algorithm", "improvement", "revision"}),
            capsules=default_library_capsules(),
            budget_tokens=4000,
            stage_needs=frozenset({"generate"}),
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertIn("PLANNING", ids)
        self.assertNotIn("LEARNING", ids)

    def test_learning_capsule_can_mount_at_repair_stage(self):
        packet = build_prompt_packet(
            role=WorkerRole.REPAIR,
            task_text="Repair a measured revision defect.",
            task_tags=frozenset({"improvement", "revision"}),
            capsules=default_library_capsules(),
            budget_tokens=4000,
            stage_needs=frozenset({"repair"}),
            required_capabilities=frozenset({"learning"}),
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertIn("LEARNING", ids)

    def test_required_capability_can_route_without_keyword_tag(self):
        packet = build_prompt_packet(
            role=WorkerRole.GENERATE,
            task_text="Construct the next steps.",
            task_tags=frozenset({"opaque-task"}),
            capsules=default_library_capsules(),
            budget_tokens=4000,
            stage_needs=frozenset({"generate"}),
            required_capabilities=frozenset({"planning"}),
        )
        ids = {c.capsule_id for c in packet.mounted_capsules}
        self.assertIn("PLANNING", ids)


if __name__ == "__main__":
    unittest.main()
