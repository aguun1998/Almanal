import unittest
from fractions import Fraction

from almanal_runtime.economy import (
    CognitiveActionKind, CognitiveOffer, EconomyDecision, ResourceVector,
    UtilityEstimate, gate_cognitive_action,
)
from almanal_runtime.feedback import (
    MetricDirection, MetricRole, MetricSpec, MeasurementPlan,
)
from almanal_runtime.verification import admissible_objective_evidence, validate_epistemic_claim


class EpistemicInvariantTests(unittest.TestCase):
    def assess(self, mode="OTHER", **kwargs):
        return validate_epistemic_claim(proposition="P", scope="declared-domain", mode=mode, **kwargs)

    def test_known_reality_contradiction_blocks_promotion(self):
        status, allowed, _ = self.assess(known_in_scope_contradiction=True)
        self.assertEqual(status, "FALSE")
        self.assertFalse(allowed)

    def test_universal_counterexample_falsifies(self):
        self.assertEqual(self.assess("UNIVERSAL", valid_counterexample_found=True)[0], "FALSE")

    def test_generic_exception_does_not_auto_falsify(self):
        self.assertEqual(self.assess("GENERIC", valid_counterexample_found=True)[0], "NOT_FALSIFIED")

    def test_no_refutation_is_not_proof(self):
        status, allowed, _ = self.assess()
        self.assertEqual(status, "NOT_FALSIFIED")
        self.assertFalse(allowed)

    def test_verified_proof_can_promote(self):
        status, allowed, _ = self.assess(verified_proof=True)
        self.assertEqual(status, "PROVED")
        self.assertTrue(allowed)

    def test_statistical_exception_does_not_auto_falsify(self):
        self.assertEqual(self.assess("STATISTICAL", valid_counterexample_found=True)[0], "NOT_FALSIFIED")

    def test_subjective_state_is_not_objective_evidence(self):
        self.assertFalse(admissible_objective_evidence("SUBJECTIVE_STATE"))
        self.assertTrue(admissible_objective_evidence("OBJECTIVE_EVIDENCE_CANDIDATE"))


class ResourceSurfaceTests(unittest.TestCase):
    def test_artifact_count_is_independent_of_storage_bytes(self):
        offer = CognitiveOffer(
            action_id="file-explosion", kind=CognitiveActionKind.OTHER,
            current_stop_utility=Fraction(0),
            post_action_stop_utility=UtilityEstimate(Fraction(2), Fraction(2), Fraction(2)),
            decision_cost_utility=Fraction(0),
            resources=ResourceVector(persistent_storage_bytes=1, artifact_count=500_000_000),
            evidence_ref="estimate",
        )
        remaining = ResourceVector(persistent_storage_bytes=10**12, artifact_count=1000)
        self.assertEqual(
            gate_cognitive_action(offer, remaining=remaining).decision,
            EconomyDecision.SKIP_BUDGET,
        )

    def test_native_resource_vector_does_not_fake_time(self):
        r = ResourceVector(tokens=1, context_bytes=2, artifact_count=3)
        self.assertEqual(len(r.key()), 9)
        self.assertFalse(hasattr(r, "wall_ms"))
        self.assertFalse(hasattr(r, "compute_ms"))
        self.assertFalse(hasattr(r, "critical_path_ms"))


class MeasurementIntegrityTests(unittest.TestCase):
    def test_measurement_boundary_changes_plan_fingerprint(self):
        a = MetricSpec(
            "latency", MetricDirection.LOWER_IS_BETTER, MetricRole.COST,
            measurement_boundary="CORE_COMPUTE", start_event="core_start",
            end_event="core_end", measurement_method="EXTERNAL_CLOCK",
        )
        b = MetricSpec(
            "latency", MetricDirection.LOWER_IS_BETTER, MetricRole.COST,
            measurement_boundary="END_TO_END", start_event="request_received",
            end_event="usable_result", measurement_method="EXTERNAL_CLOCK",
        )
        pa = MeasurementPlan("p", "scope", (a,), minimum_pairs=1)
        pb = MeasurementPlan("p", "scope", (b,), minimum_pairs=1)
        self.assertNotEqual(pa.fingerprint(), pb.fingerprint())

    def test_measurement_method_changes_plan_fingerprint(self):
        a = MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, measurement_method="TOKENIZER_A")
        b = MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, measurement_method="TOKENIZER_B")
        self.assertNotEqual(
            MeasurementPlan("p", "scope", (a,), minimum_pairs=1).fingerprint(),
            MeasurementPlan("p", "scope", (b,), minimum_pairs=1).fingerprint(),
        )

    def test_external_time_is_metric_not_native_resource(self):
        latency = MetricSpec(
            "end_to_end_latency_ms", MetricDirection.LOWER_IS_BETTER, MetricRole.COST,
            measurement_boundary="END_TO_END", start_event="request_received",
            end_event="usable_result", measurement_method="EXTERNAL_CLOCK",
        )
        plan = MeasurementPlan("latency", "interactive", (latency,), minimum_pairs=1)
        self.assertTrue(plan.fingerprint())
        self.assertFalse(hasattr(ResourceVector(), "wall_ms"))

    def test_included_excluded_component_overlap_rejected(self):
        with self.assertRaises(Exception):
            MetricSpec(
                "cost", MetricDirection.LOWER_IS_BETTER, MetricRole.COST,
                included_components=("tool",), excluded_components=("tool",),
            )


if __name__ == "__main__":
    unittest.main()
