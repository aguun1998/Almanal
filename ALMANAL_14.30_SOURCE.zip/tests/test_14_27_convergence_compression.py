import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
from almanal_runtime.evaluator import (
    AnalyticCostVector, RepresentationCandidate, RepresentationRacePolicy, WitnessLeaseLedger,
    plan_representation_race, representation_reserve_reopen_allowed, finalization_pass_allowed,
)

class Test1427ConvergenceCompression(unittest.TestCase):
    def test_dominance_and_bounded_beam(self):
        c=(
          RepresentationCandidate("sim",AnalyticCostVector((100,100)),frozenset({"correct"}),9,feasible=True,mechanism_ref="m:sim"),
          RepresentationCandidate("prefix",AnalyticCostVector((60,70)),frozenset({"correct","construct"}),4,feasible=True,mechanism_ref="m:prefix"),
          RepresentationCandidate("period",AnalyticCostVector((20,20)),frozenset({"correct","construct","bound"}),2,True,True,mechanism_ref="m:period"),
        )
        p=plan_representation_race(c,mandatory_obligations=frozenset({"correct","construct","bound"}),lock_validator=lambda c,o:True,policy=RepresentationRacePolicy(active_beam_width=2))
        self.assertIn("period",p.active_ids)
        self.assertEqual(p.locked_id,"period")
        self.assertIn("sim",p.rejected_ids)
        self.assertLessEqual(len(p.active_ids),2)
    def test_reserve_not_parallelized(self):
        c=tuple(RepresentationCandidate(str(i),AnalyticCostVector((10+i,20-i)),frozenset({"a"}),i+1,feasible=True,mechanism_ref=f"m:{i}") for i in range(4))
        p=plan_representation_race(c,mandatory_obligations=frozenset({"a"}),policy=RepresentationRacePolicy(active_beam_width=2))
        self.assertEqual(len(p.active_ids),2)
        self.assertEqual(len(p.reserve_ids),2)
    def test_budget_enforced(self):
        c=tuple(RepresentationCandidate(str(i),AnalyticCostVector((i,)),reasoning_work_upper_bound=1,feasible=True,mechanism_ref=f"m:{i}") for i in range(5))
        with self.assertRaises(Exception): plan_representation_race(c,mandatory_obligations=frozenset({"correct"}))

    def test_reopen_and_finalization_are_enforced(self):
        pol=RepresentationRacePolicy(max_reopen_batches=1,finalization_pass_limit=1)
        self.assertFalse(representation_reserve_reopen_allowed(reopen_batches_used=0,policy=pol))
        self.assertFalse(representation_reserve_reopen_allowed(reopen_batches_used=0,active_failed=True,policy=pol))
        self.assertTrue(representation_reserve_reopen_allowed(reopen_batches_used=0,active_failed=True,trigger_witness_ref="failure:1",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda r:r=="failure:1",policy=pol))
        self.assertFalse(representation_reserve_reopen_allowed(reopen_batches_used=1,active_failed=True,trigger_witness_ref="failure:2",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:True,policy=pol))
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:resources-immaterial",materiality_validator=lambda _:True,policy=pol)
        ledger=WitnessLeaseLedger()
        self.assertTrue(finalization_pass_allowed(passes_used=0,witness_ledger=ledger,**base))
        self.assertFalse(finalization_pass_allowed(passes_used=0,witness_ledger=ledger,**base))
        self.assertFalse(finalization_pass_allowed(passes_used=1,witness_ledger=ledger,**base))
        self.assertTrue(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="defect:1",witness_ledger=ledger,witness_validator=lambda r:r=="defect:1",**base))

    def test_spec_rules(self):
        s=(ROOT/"spec"/"ALMANAL.md").read_text()
        for x in ["REPRESENTATION RACE / BOUNDED SEARCH CLOSURE","max_representation_hypotheses = 4","active_representation_beam    = 2","ordinary_finalization_passes  = 1","Feedback(Feedback)=Allowed"]:
            self.assertIn(x,s)
    def test_planning_capsule_is_compact(self):
        p=(ROOT/"almanal_runtime"/"prompting.py").read_text()
        self.assertIn("representation race",p)
        self.assertIn("Finalize once",p)
        self.assertIn("ALMANAL-14.30-LIB:E",p)

if __name__=="__main__": unittest.main()
