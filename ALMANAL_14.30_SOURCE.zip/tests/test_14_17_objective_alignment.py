import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "spec"

class ObjectiveAlignmentTests(unittest.TestCase):
    def test_official_algorithm_objective_is_present_in_portable_and_core(self):
        portable=(SPEC/"ALMANAL.md").read_text(encoding="utf-8")
        core=(SPEC/"ACTIVE_CORE.md").read_text(encoding="utf-8")
        for text in (portable, core):
            self.assertIn("ProblemOrExistingAlgorithm", text)
            self.assertIn("BetterAlgorithm", text)
            for mode in ("SYNTHESIZE","IMPROVE","REPAIR","OPTIMIZE","CONSOLIDATE"):
                self.assertIn(mode, text)

    def test_current_normative_sca_and_conformance_are_release_aligned(self):
        core=(SPEC/"ACTIVE_CORE.md").read_text(encoding="utf-8")
        self.assertIn("ALMANAL14_22Conformant", core)
        self.assertNotIn("ALMANAL14_14Conformant", core)
        self.assertIn("MOVE_WARM", core)
        self.assertIn("PASSIVE | ACTIVE", core)
        self.assertIn("ALMANAL_14.30_WITNESSED_RESIDUAL_CLOSURE_FRESH_WITNESS_CANDIDATE", core)

    def test_feedback_and_sca_share_pipeline_without_identity_merge(self):
        portable=(SPEC/"ALMANAL.md").read_text(encoding="utf-8")
        core=(SPEC/"ACTIVE_CORE.md").read_text(encoding="utf-8")
        self.assertIn("Feedback != SCA", portable)
        self.assertIn("Feedback != SCA", core)
        self.assertIn("Generic Revision", portable)
        self.assertIn("Generic Revision", core)

if __name__ == "__main__":
    unittest.main()
