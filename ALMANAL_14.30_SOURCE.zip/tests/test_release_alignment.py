import json, unittest
from pathlib import Path

from almanal_runtime.portable import ALMANAL_RUNTIME_PROTOCOL
from almanal_runtime.portable_spec import lint_portable_file

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "spec"


class ReleaseAlignmentTests(unittest.TestCase):
    def test_14_27_artifacts_align(self):
        core = (SPEC / "ACTIVE_CORE.md").read_text(encoding="utf-8")
        lib = (SPEC / "INTERNAL_LIBRARY.md").read_text(encoding="utf-8")
        info = lint_portable_file(SPEC / "ALMANAL.md")
        pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        self.assertIn("알만알 14.30", core)
        self.assertIn("Required Kernel:** 알만알 14.30", lib)
        self.assertEqual(info.version, "14.30")
        self.assertEqual(info.runtime_protocol, ALMANAL_RUNTIME_PROTOCOL)
        self.assertIn('version = "0.30.0"', pyproject)
        self.assertIn("I-OUTPUT-BASELINE-FLOOR", core)
        self.assertIn("14.22 Portable Execution-Shape Resident Rule", lib)
        self.assertIn("# 6.2 BASELINE-DOMINANCE / FINALIZATION CLOSURE", (SPEC / "ALMANAL.md").read_text(encoding="utf-8"))
        self.assertIn("# 6.3 PORTABLE EXECUTION-SHAPE CLOSURE", (SPEC / "ALMANAL.md").read_text(encoding="utf-8"))

    def test_release_evidence_tracks_current_delta(self):
        e=json.loads((ROOT/"RELEASE_EVIDENCE.json").read_text(encoding="utf-8"))
        self.assertEqual(e["version"],"14.30")
        self.assertEqual(e["runtime"],"0.30")
        self.assertEqual(e["parent"],"14.29")
        self.assertIn("witness",e["primary_delta"].lower())

    def test_portable_is_smaller_than_active_source_pair(self):
        core = (SPEC / "ACTIVE_CORE.md").read_text(encoding="utf-8")
        lib = (SPEC / "INTERNAL_LIBRARY.md").read_text(encoding="utf-8")
        portable = (SPEC / "ALMANAL.md").read_text(encoding="utf-8")
        self.assertLess(len(portable), len(core) + len(lib))

    def test_proof_bodies_remain_cold(self):
        core = (SPEC / "ACTIVE_CORE.md").read_text(encoding="utf-8")
        cold = (SPEC / "COLD_APPENDIX.md").read_text(encoding="utf-8")
        self.assertGreaterEqual(core.count("**Proof body:** COLD appendix"), 10)
        self.assertIn("# 14.7 Proof Bodies Externalized from Active Core", cold)


if __name__ == "__main__":
    unittest.main()
