import unittest
from almanal_runtime.evaluator import AnalyticCostVector, cheap_falsifier_is_decision_relevant, WitnessLeaseLedger

class Test1428PreimplementationFalsifier(unittest.TestCase):
    def test_empty_footprint_rejected(self):
        with self.assertRaises(Exception): AnalyticCostVector(())
    def test_cheap_counterexample_search_admitted(self):
        self.assertTrue(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=True, falsifier_work_upper_bound=20,
            next_deep_reasoning_work_upper_bound=100, representation_locked=False))
    def test_expensive_or_nondecisive_test_rejected(self):
        self.assertFalse(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=True, falsifier_work_upper_bound=100,
            next_deep_reasoning_work_upper_bound=20, representation_locked=False))
        self.assertFalse(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=False, falsifier_work_upper_bound=1,
            next_deep_reasoning_work_upper_bound=100, representation_locked=False))
    def test_lock_blocks_falsifier_without_new_witness(self):
        self.assertFalse(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=True, falsifier_work_upper_bound=1,
            next_deep_reasoning_work_upper_bound=100, representation_locked=True))
        self.assertTrue(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=True, falsifier_work_upper_bound=1,
            next_deep_reasoning_work_upper_bound=100, representation_locked=True,
            defect_or_frontier_witness_ref="defect:1",witness_ledger=WitnessLeaseLedger(),
            witness_validator=lambda r:r=="defect:1"))
        used=WitnessLeaseLedger(); used.consume("defect:1",lambda _:True)
        self.assertFalse(cheap_falsifier_is_decision_relevant(
            counterexample_would_reject=True, falsifier_work_upper_bound=1,
            next_deep_reasoning_work_upper_bound=100, representation_locked=True,
            defect_or_frontier_witness_ref="defect:1",witness_ledger=used,
            witness_validator=lambda _:True))
