import unittest

from almanal_runtime.design_direction import (
    DesignAlternative,
    DesignBenefitAxis,
    DesignBurdenAxis,
    DesignDirection,
    DesignPressure,
    DesignSeverity,
    DesignSignal,
    LegacyPriorCard,
    LegacySourceBasis,
    SubsystemAdmissionDecision,
    SubsystemProposal,
    assess_subsystem_admission,
    select_design_direction,
    trade_study_design_alternatives,
)


class AutoDesignHardeningTests(unittest.TestCase):
    def _signal(self):
        return DesignSignal(
            "legacy-witness-gap",
            DesignPressure.SEMANTIC_WITNESS_GAP,
            DesignSeverity.HIGH,
            "audit:dds-prior-self-declaration",
            protected_impact=True,
            observed_defect=True,
        )

    def _prior(self):
        return LegacyPriorCard(
            "atam",
            "CMU-SEI-ATAM",
            frozenset({DesignPressure.SEMANTIC_WITNESS_GAP}),
            ("identify risk, sensitivity, and tradeoff points",),
            source_basis=LegacySourceBasis.RETRIEVED_PRIMARY,
            retrieval_evidence_ref="retrieval:sei-atam",
        )

    def test_retrieval_string_alone_does_not_witness_legacy_prior(self):
        plan = select_design_direction((self._signal(),), (self._prior(),))
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ())

    def test_host_validator_makes_retrieved_prior_decision_usable(self):
        plan = select_design_direction(
            (self._signal(),),
            (self._prior(),),
            prior_validator=lambda p: p.retrieval_evidence_ref == "retrieval:sei-atam",
        )
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ("atam",))

    def test_forged_legacy_prior_validator_failure_is_inert(self):
        plan = select_design_direction(
            (self._signal(),),
            (self._prior(),),
            prior_validator=lambda p: False,
        )
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ())

    def test_subsystem_search_string_alone_does_not_admit_component(self):
        proposal = SubsystemProposal(
            "new-organ",
            unique_persistent_state=True,
            existing_primitive_insufficient=True,
            legacy_search_ref="search:claimed",
            expected_lifecycle_value_ref="e:value",
            exit_or_compile_away_path="SCA after checkpoint",
        )
        self.assertEqual(
            assess_subsystem_admission(proposal).decision,
            SubsystemAdmissionDecision.BLOCKED,
        )
        self.assertEqual(
            assess_subsystem_admission(proposal, legacy_search_validator=lambda ref: True).decision,
            SubsystemAdmissionDecision.PROVISIONAL_COMPONENT,
        )

    def test_unavailability_string_alone_cannot_bypass_legacy_search(self):
        proposal = SubsystemProposal(
            "offline-organ",
            unique_persistent_state=True,
            existing_primitive_insufficient=True,
            legacy_search_unavailable_reason="no web",
            legacy_search_unavailable_evidence_ref="capability:offline",
            expected_lifecycle_value_ref="e:value",
            exit_or_compile_away_path="SCA after checkpoint",
        )
        self.assertEqual(
            assess_subsystem_admission(proposal).decision,
            SubsystemAdmissionDecision.BLOCKED,
        )
        self.assertEqual(
            assess_subsystem_admission(
                proposal, legacy_unavailable_validator=lambda ref: ref == "capability:offline"
            ).decision,
            SubsystemAdmissionDecision.PROVISIONAL_COMPONENT,
        )

    def test_prior_card_never_self_witnesses(self):
        self.assertFalse(self._prior().witnessed_source)

    def test_trade_study_selects_strict_set_pareto_dominator(self):
        plan = select_design_direction((self._signal(),))
        weak = DesignAlternative(
            "weak",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset({DesignBurdenAxis.SOURCE_COMPLEXITY, DesignBurdenAxis.MAINTENANCE_SURFACE}),
            ("design:weak",),
            protected_safe=True,
            reversible=True,
            introduces_new_subsystem=False,
        )
        strong = DesignAlternative(
            "strong",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset({DesignBurdenAxis.SOURCE_COMPLEXITY}),
            ("design:strong",),
            protected_safe=True,
            reversible=True,
            introduces_new_subsystem=False,
        )
        result = trade_study_design_alternatives(plan, (weak, strong), alternative_validator=lambda a: True)
        self.assertFalse(result.unresolved_tradeoff)
        self.assertTrue(result.analysis_witnessed)
        self.assertEqual(result.selected_alternative_id, "strong")

    def test_trade_study_preserves_non_dominated_tradeoff(self):
        plan = select_design_direction((self._signal(),))
        small = DesignAlternative(
            "small-change",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset({DesignBurdenAxis.EVIDENCE_COST}),
            ("design:small",),
        )
        deep = DesignAlternative(
            "deep-change",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE, DesignBenefitAxis.EXECUTION_ASSURANCE}),
            frozenset({DesignBurdenAxis.SOURCE_COMPLEXITY}),
            ("design:deep",),
        )
        result = trade_study_design_alternatives(plan, (small, deep), alternative_validator=lambda a: True)
        self.assertTrue(result.unresolved_tradeoff)
        self.assertTrue(result.analysis_witnessed)
        self.assertEqual({x.alternative_id for x in result.frontier}, {"small-change", "deep-change"})

    def test_protected_direction_filters_unsafe_alternative(self):
        plan = select_design_direction((self._signal(),))
        unsafe = DesignAlternative(
            "unsafe",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset(),
            ("design:unsafe",),
            protected_safe=False,
        )
        result = trade_study_design_alternatives(plan, (unsafe,))
        self.assertTrue(result.unresolved_tradeoff)
        self.assertEqual(result.frontier, ())

    def test_unvalidated_prior_cannot_be_referenced_by_alternative(self):
        plan = select_design_direction((self._signal(),), (self._prior(),))
        alt = DesignAlternative(
            "bad-prior-ref",
            DesignDirection.HARDEN_SEMANTIC_WITNESSING,
            ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset(),
            ("design:x",),
            legacy_prior_ids=("atam",),
        )
        with self.assertRaises(Exception):
            trade_study_design_alternatives(plan, (alt,))

    def test_prior_validator_exception_is_inert(self):
        def boom(_):
            raise RuntimeError("validator unavailable")
        plan = select_design_direction((self._signal(),), (self._prior(),), prior_validator=boom)
        self.assertEqual(plan.frontier[0].legacy_prior_ids, ())

    def test_no_design_signals_stops_without_churn(self):
        plan = select_design_direction(())
        self.assertEqual(plan.selected, DesignDirection.STOP)
        self.assertFalse(plan.unresolved_tradeoff)

    def test_empty_trade_study_does_not_invent_an_option(self):
        plan = select_design_direction((self._signal(),))
        result = trade_study_design_alternatives(plan, ())
        self.assertTrue(result.unresolved_tradeoff)
        self.assertIsNone(result.selected_alternative_id)

    def test_trade_study_rejects_direction_outside_frozen_frontier(self):
        plan = select_design_direction((self._signal(),))
        alt = DesignAlternative(
            "wrong-direction", DesignDirection.SIMPLIFY, ("legacy-witness-gap",),
            frozenset({DesignBenefitAxis.STRUCTURAL_SIMPLICITY}), frozenset(),
            ("design:wrong",),
        )
        with self.assertRaises(Exception):
            trade_study_design_alternatives(plan, (alt,))

    def test_unavailability_validator_failure_blocks_subsystem(self):
        proposal = SubsystemProposal(
            "offline-organ-2", unique_persistent_state=True, existing_primitive_insufficient=True,
            legacy_search_unavailable_reason="network unavailable",
            legacy_search_unavailable_evidence_ref="capability:offline-2",
            expected_lifecycle_value_ref="e:value", exit_or_compile_away_path="SCA later",
        )
        self.assertEqual(
            assess_subsystem_admission(proposal, legacy_unavailable_validator=lambda ref: False).decision,
            SubsystemAdmissionDecision.BLOCKED,
        )


if __name__ == "__main__":
    unittest.main()
