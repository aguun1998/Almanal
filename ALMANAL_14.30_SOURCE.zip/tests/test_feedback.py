import unittest
from fractions import Fraction

from almanal_runtime.economy import (
    CognitiveActionKind, CognitiveOffer, EconomyGovernor,
    ResourceVector, UtilityEstimate,
)
from almanal_runtime.feedback import (
    MetricDirection, MetricRole, MetricSpec, MeasurementPlan,
    PairObservation, DiagnosisKind, ReMeasureDecision,
    MeasurementDrivenFeedbackLoop, evaluate_measurement,
    diagnose_direction, compare_remeasurement,
    CausalEvidenceKind, CausalSupport, CausalHypothesis, CausalTestSpec, CausalEvidence,
    CausalWitnessBasis, CausalExecutionReceipt,
    diagnose_cause, select_causal_repair_target, CausalConfirmation,
)
from almanal_runtime.experiment import (
    ExperimentCondition, ExperimentTier, ExperimentDifficulty, ExperimentRisk,
    ChangeImpact, ExperimentTask, ExperimentConditionSpec,
    ExperimentEnvironment, PlainBaselineRecord, ExperimentSpec,
    ExperimentCostModel, TradeoffEnvelope, TradeoffDecision, assess_change_tradeoff,
    design_localized_experiment, governed_design_localized_experiment,
    ExperimentRunOutput, ExperimentJudgeOutput,
    ExperimentRunnerBinding, execute_experiment_batch, execute_experiment, evaluate_experiment_pair,
    ExperimentBatchDecision, plan_next_experiment_batch, settle_experiment_batch_cost,
)
from almanal_runtime.governed import GovernedStatus, execute_governed


def plan():
    return MeasurementPlan(
        plan_id="p1",
        task_scope="paired synthetic regression",
        metrics=(
            MetricSpec(
                "quality", MetricDirection.HIGHER_IS_BETTER,
                MetricRole.VALUE, material_delta=Fraction(1, 2), protected=True,
            ),
            MetricSpec(
                "overclaim", MetricDirection.LOWER_IS_BETTER,
                MetricRole.CALIBRATION, material_delta=Fraction(0),
            ),
            MetricSpec(
                "tokens", MetricDirection.LOWER_IS_BETTER,
                MetricRole.COST, material_delta=Fraction(10),
            ),
        ),
        minimum_pairs=6,
        alpha=Fraction(1, 20),
    )


def obs(i, *, q_ref=10, q_cand=10, o_ref=2, o_cand=1, t_ref=100, t_cand=130):
    return PairObservation(
        pair_id=str(i),
        reference=(("quality", Fraction(q_ref)), ("overclaim", Fraction(o_ref)), ("tokens", Fraction(t_ref))),
        candidate=(("quality", Fraction(q_cand)), ("overclaim", Fraction(o_cand)), ("tokens", Fraction(t_cand))),
    )


def token_hypothesis():
    return CausalHypothesis(
        "h-eager", "eager measurement module residency increases ordinary token/context cost",
        "measurement-residency", ("tokens",), dependency_depth=1,
    )


def ablation_spec(hid="h-eager"):
    return CausalTestSpec(
        "t-ablate", hid, CausalEvidenceKind.ABLATION,
        "disable the suspected mechanism while holding the paired task fixed",
        (("tokens", 1),), expect_mechanism_observed=True,
    )


def supportive_ablation():
    spec = ablation_spec()
    receipt = CausalExecutionReceipt(
        "r-ablate", spec.fingerprint(), CausalEvidenceKind.ABLATION,
        "runtime-executor", "measurement:p1", "env:frozen", CausalWitnessBasis.RUNTIME_EXECUTED,
    )
    return CausalEvidence(
        "e-ablate", "h-eager", spec.fingerprint(), CausalEvidenceKind.ABLATION, True,
        (("tokens", Fraction(50)),), mechanism_observed=True, provenance_ref="controlled replay",
        execution_receipt=receipt,
    )

def receipt_validator(receipt):
    return receipt.receipt_id in {"r-ablate", "r2"} and receipt.executor_ref == "runtime-executor"


class MeasurementFeedbackTests(unittest.TestCase):
    def test_insufficient_evidence_does_not_generate_direction(self):
        p = plan()
        result = evaluate_measurement(p, tuple(obs(i) for i in range(3)))
        d = diagnose_direction(p, result)
        self.assertEqual(d.kind, DiagnosisKind.INSUFFICIENT_EVIDENCE)

    def test_metric_regression_is_symptom_not_repair_target(self):
        p = plan()
        result = evaluate_measurement(p, tuple(obs(i, q_cand=12, t_cand=140) for i in range(8)))
        d = diagnose_direction(p, result)
        self.assertIn("tokens", d.regressions)
        # A metric name is not a component/mechanism repair target.
        self.assertNotEqual("measurement-residency", "tokens")

    def test_trace_only_cannot_license_causal_repair(self):
        h = token_hypothesis()
        ev = CausalEvidence(
            "trace", h.hypothesis_id, CausalTestSpec(
                "t-trace", h.hypothesis_id, CausalEvidenceKind.EXECUTION_TRACE,
                "inspect execution trace", (("tokens", 1),)
            ).fingerprint(), CausalEvidenceKind.EXECUTION_TRACE, False,
            (("tokens", Fraction(1)),), mechanism_observed=True,
        )
        d = diagnose_cause(h, (CausalTestSpec("t-trace", h.hypothesis_id, CausalEvidenceKind.EXECUTION_TRACE, "inspect execution trace", (("tokens", 1),)),), (ev,), regressed_metrics=("tokens",))
        self.assertEqual(d.support, CausalSupport.ASSOCIATED_ONLY)
        self.assertIsNone(d.repair_component)

    def test_controlled_ablation_can_support_causal_repair(self):
        h = token_hypothesis()
        d = diagnose_cause(h, (ablation_spec(),), (supportive_ablation(),), regressed_metrics=("tokens",), receipt_validator=receipt_validator)
        self.assertEqual(d.support, CausalSupport.SUPPORTED)
        self.assertEqual(d.repair_component, "measurement-residency")

    def test_conflicting_supported_components_are_causal_uncertain(self):
        h1 = token_hypothesis()
        h2 = CausalHypothesis("h2", "another mechanism", "other-component", ("tokens",), 2)
        d1 = diagnose_cause(h1, (ablation_spec(),), (supportive_ablation(),), regressed_metrics=("tokens",), receipt_validator=receipt_validator)
        t2 = CausalTestSpec("t2", "h2", CausalEvidenceKind.INTERVENTION,
                            "change other mechanism", (("tokens", 1),))
        r2 = CausalExecutionReceipt("r2", t2.fingerprint(), CausalEvidenceKind.INTERVENTION,
                                    "runtime-executor", "measurement:p1", "env:frozen", CausalWitnessBasis.RUNTIME_EXECUTED)
        e2 = CausalEvidence("e2", "h2", t2.fingerprint(), CausalEvidenceKind.INTERVENTION, True,
                            (("tokens", Fraction(20)),), mechanism_observed=True, provenance_ref="controlled",
                            execution_receipt=r2)
        d2 = diagnose_cause(h2, (t2,), (e2,), regressed_metrics=("tokens",), receipt_validator=receipt_validator)
        sel = select_causal_repair_target((h1, h2), (d1, d2))
        self.assertTrue(sel.causal_uncertain)
        self.assertIsNone(sel.selected_component)

    def test_outer_loop_requires_causal_diagnosis_before_patch(self):
        p = plan()
        loop = MeasurementDrivenFeedbackLoop(p)
        loop.record_measurement(tuple(obs(i, q_cand=12, t_cand=140) for i in range(8)))
        symptoms = loop.observe_symptoms()
        self.assertIn("tokens", symptoms.regressions)
        with self.assertRaises(Exception):
            loop.mark_targeted_improvement_complete()
        sel = loop.diagnose_causal_target((token_hypothesis(),), (ablation_spec(),), (supportive_ablation(),), receipt_validator=receipt_validator)
        self.assertFalse(sel.causal_uncertain)
        self.assertEqual(loop.repair_component, "measurement-residency")
        loop.mark_targeted_improvement_complete()

    def test_outer_loop_keep_requires_causal_confirmation(self):
        p = plan()
        loop = MeasurementDrivenFeedbackLoop(p)
        loop.record_measurement(tuple(obs(i, q_cand=12, t_cand=140) for i in range(8)))
        loop.observe_symptoms()
        loop.diagnose_causal_target((token_hypothesis(),), (ablation_spec(),), (supportive_ablation(),), receipt_validator=receipt_validator)
        loop.mark_targeted_improvement_complete()
        loop.record_measurement(tuple(obs(i, q_cand=12, t_cand=90) for i in range(8)))
        decision = loop.decide_after_remeasurement((
            CausalConfirmation("h-eager", True, "post-patch trace"),
        ))
        self.assertEqual(decision.decision, ReMeasureDecision.KEEP)

    def test_metric_gain_without_mechanism_confirmation_reverts(self):
        p = plan()
        loop = MeasurementDrivenFeedbackLoop(p)
        loop.record_measurement(tuple(obs(i, q_cand=12, t_cand=140) for i in range(8)))
        loop.observe_symptoms()
        loop.diagnose_causal_target((token_hypothesis(),), (ablation_spec(),), (supportive_ablation(),), receipt_validator=receipt_validator)
        loop.mark_targeted_improvement_complete()
        loop.record_measurement(tuple(obs(i, q_cand=12, t_cand=90) for i in range(8)))
        decision = loop.decide_after_remeasurement((
            CausalConfirmation("h-eager", False, "mechanism unchanged"),
        ))
        self.assertEqual(decision.decision, ReMeasureDecision.REVERT)

    def test_remeasurement_rejects_pair_set_drift(self):
        p = plan()
        before = evaluate_measurement(p, tuple(obs(i, q_cand=12, t_cand=130) for i in range(8)))
        after = evaluate_measurement(p, tuple(obs(i + 100, q_cand=12, t_cand=90) for i in range(8)))
        with self.assertRaises(Exception):
            compare_remeasurement(p, before, after, targeted_metrics=("tokens",))

    def test_measurement_itself_is_economy_gated(self):
        p = plan()
        gov = EconomyGovernor(budget=ResourceVector(tokens=1000, steps=10))
        offer = CognitiveOffer(
            action_id="remeasure", kind=CognitiveActionKind.RE_MEASURE,
            current_stop_utility=Fraction(10),
            post_action_stop_utility=UtilityEstimate(Fraction(10), Fraction(10), Fraction(11)),
            decision_cost_utility=Fraction(1), resources=ResourceVector(tokens=200, steps=1),
            evidence_ref="no-decision-impact-expected",
        )
        calls = []
        result = execute_governed(
            gov, offer,
            lambda: calls.append("measured") or evaluate_measurement(p, tuple(obs(i) for i in range(8))),
        )
        self.assertEqual(result.status, GovernedStatus.SKIPPED)
        self.assertEqual(calls, [])

    def test_causal_evidence_must_match_frozen_test_prediction(self):
        h = token_hypothesis()
        frozen = ablation_spec()
        wrong = CausalEvidence(
            "wrong", h.hypothesis_id, "not-the-frozen-fingerprint",
            CausalEvidenceKind.ABLATION, True, (("tokens", Fraction(50)),),
            mechanism_observed=True, provenance_ref="controlled",
        )
        d = diagnose_cause(h, (frozen,), (wrong,), regressed_metrics=("tokens",))
        self.assertEqual(d.support, CausalSupport.UNTESTED)



class ExperimentDesignTests(unittest.TestCase):
    def setUp(self):
        self.tasks = (
            ExperimentTask(
                "r1", "retrieval", "retrieval task 1",
                ExperimentDifficulty.EASY, ExperimentRisk.LOW,
                affected_paths=("retrieve",), failure_modes=("cache-miss",),
            ),
            ExperimentTask(
                "r2", "retrieval", "retrieval task 2",
                ExperimentDifficulty.MEDIUM, ExperimentRisk.MEDIUM,
                affected_paths=("retrieve",), failure_modes=("stale",),
            ),
            ExperimentTask(
                "r3", "retrieval", "retrieval task 3",
                ExperimentDifficulty.HARD, ExperimentRisk.HIGH,
                affected_paths=("retrieve", "rank"), failure_modes=("ranking",),
            ),
            ExperimentTask(
                "r4", "retrieval", "retrieval task 4",
                ExperimentDifficulty.HARD, ExperimentRisk.MEDIUM,
                affected_paths=("rank",), failure_modes=("ranking",),
            ),
            ExperimentTask("c1", "coding", "coding task 1"),
            ExperimentTask(
                "p1", "planning", "planning task 1",
                risk=ExperimentRisk.HIGH, failure_modes=("long-horizon",),
            ),
            ExperimentTask("p2", "planning", "planning task 2"),
        )
        self.metrics = (
            MetricSpec("quality", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, material_delta=Fraction(1)),
            MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, material_delta=Fraction(5)),
        )
        self.env = ExperimentEnvironment(
            "model-v1", "tasks-v1", "judge-v1", "budget-v1", "host-v1",
            ResourceVector(tokens=100000, tool_calls=1000, money_micros=1000000, steps=10000, context_bytes=1000000),
        )
        self.conditions = (
            ExperimentConditionSpec(ExperimentCondition.PLAIN, "model-v1", "NO_ALMANAL", "plain-config-v1"),
            ExperimentConditionSpec(ExperimentCondition.PARENT, "model-v1", "ALMANAL-14.10", "parent-config-v1"),
            ExperimentConditionSpec(ExperimentCondition.CANDIDATE, "model-v1", "ALMANAL-14.11", "candidate-config-v1"),
        )
        self.impact = ChangeImpact(
            "chg-retrieval", ("retrieval-cache",), ("retrieve", "rank"),
            ("retrieval",), ("quality", "tokens"), adjacent_task_classes=("planning",),
        )

    def _design(self, **kwargs):
        params = dict(
            experiment_id="e", question="did change help?", impact=self.impact,
            task_catalog=self.tasks, metrics=self.metrics, environment=self.env,
            condition_specs=self.conditions, minimum_pairs=3,
            initial_batch_size=2, batch_size=1, randomization_seed=7,
        )
        params.update(kwargs)
        return design_localized_experiment(**params)

    def _bindings(self, spec):
        def runner(prefix, token_value):
            return lambda t: ExperimentRunOutput(
                prefix + ":" + t.task_id,
                (("tokens", Fraction(token_value)),),
                ResourceVector(tokens=token_value, steps=1),
                "runner-meter",
            )
        return {
            ExperimentCondition.PLAIN: ExperimentRunnerBinding(
                spec.condition_spec(ExperimentCondition.PLAIN).fingerprint(), runner("plain", 120)
            ),
            ExperimentCondition.PARENT: ExperimentRunnerBinding(
                spec.condition_spec(ExperimentCondition.PARENT).fingerprint(), runner("parent", 110)
            ),
            ExperimentCondition.CANDIDATE: ExperimentRunnerBinding(
                spec.condition_spec(ExperimentCondition.CANDIDATE).fingerprint(), runner("candidate", 90)
            ),
        }

    @staticmethod
    def _resource_witness(ref, resources):
        return ref in {"runner-meter", "judge-meter"} and resources.steps >= 0

    @staticmethod
    def _judge(task, presented):
        metrics = []
        for label, content in presented:
            quality = Fraction(12 if "candidate:" in content else 10 if "parent:" in content else 8)
            metrics.append((label, (("quality", quality),)))
        return ExperimentJudgeOutput(
            tuple(metrics), ResourceVector(tokens=20, steps=1), "judge-meter"
        )

    def test_scope_and_sample_are_distinct(self):
        spec = self._design()
        self.assertEqual(spec.tier, ExperimentTier.TARGETED)
        self.assertEqual(set(spec.primary_task_ids), {"r1", "r2", "r3", "r4"})
        self.assertEqual(len(spec.sample_order), 4)
        # Initial primary sample is two, plus exactly one adjacent planning canary.
        self.assertEqual(len(set(spec.initial_task_ids) & set(spec.primary_task_ids)), 2)
        self.assertEqual(len(spec.adjacent_canary_ids), 1)
        self.assertIn(spec.adjacent_canary_ids[0], {"p1", "p2"})
        self.assertNotIn("c1", spec.task_ids)

    def test_minimum_pairs_is_not_silently_lowered_to_catalog_size(self):
        small_tasks = self.tasks[:2] + self.tasks[4:]
        spec = design_localized_experiment(
            experiment_id="small", question="small pool", impact=self.impact,
            task_catalog=small_tasks, metrics=self.metrics, environment=self.env,
            condition_specs=self.conditions, minimum_pairs=10,
            initial_batch_size=1, batch_size=1,
        )
        self.assertEqual(spec.stopping_rule.minimum_pairs, 10)
        self.assertFalse(spec.evidence_floor_reachable)

    def test_representative_order_prioritizes_diverse_risk_and_failure_strata(self):
        spec = self._design(initial_batch_size=3)
        first = [next(t for t in self.tasks if t.task_id == tid) for tid in spec.sample_order[:3]]
        self.assertGreaterEqual(len({t.difficulty for t in first}), 2)
        self.assertGreaterEqual(len(set(f for t in first for f in t.failure_modes)), 2)

    def test_plain_baseline_reuse_requires_exact_task_payload_and_condition_identity(self):
        spec0 = self._design()
        plain = spec0.condition_spec(ExperimentCondition.PLAIN)
        frozen_tasks = tuple(t for t in self.tasks if t.task_id in spec0.task_ids)
        baseline = PlainBaselineRecord(
            self.env.fingerprint(), plain.fingerprint(),
            tuple((t.task_id, t.fingerprint()) for t in frozen_tasks),
            "plain-ledger-ref",
            metrics_by_task=tuple(
                (t.task_id, (("quality", Fraction(8)), ("tokens", Fraction(130))))
                for t in frozen_tasks
            ),
        )
        reused = self._design(plain_baseline=baseline)
        self.assertTrue(reused.plain_baseline_reused)
        self.assertEqual(reused.conditions, (ExperimentCondition.PARENT, ExperimentCondition.CANDIDATE))

        changed = tuple(
            ExperimentTask(t.task_id, t.task_class, t.payload + " changed", t.difficulty, t.risk,
                           t.affected_paths, t.failure_modes, t.metadata, t.version)
            if t.task_id == "r1" else t
            for t in self.tasks
        )
        not_reused = design_localized_experiment(
            experiment_id="drift", question="payload drift", impact=self.impact,
            task_catalog=changed, metrics=self.metrics, environment=self.env,
            condition_specs=self.conditions, plain_baseline=baseline,
            minimum_pairs=3, initial_batch_size=2, batch_size=1,
        )
        self.assertFalse(not_reused.plain_baseline_reused)


    def test_plain_baseline_identity_without_metric_payload_is_not_reused(self):
        spec0 = self._design()
        plain = spec0.condition_spec(ExperimentCondition.PLAIN)
        frozen_tasks = tuple(t for t in self.tasks if t.task_id in spec0.task_ids)
        metadata_only = PlainBaselineRecord(
            self.env.fingerprint(), plain.fingerprint(),
            tuple((t.task_id, t.fingerprint()) for t in frozen_tasks),
            "metadata-only",
        )
        spec = self._design(plain_baseline=metadata_only)
        self.assertFalse(spec.plain_baseline_reused)
        self.assertIn(ExperimentCondition.PLAIN, spec.conditions)

    def test_condition_runner_identity_is_enforced(self):
        spec = self._design()
        bindings = self._bindings(spec)
        bindings[ExperimentCondition.PARENT] = ExperimentRunnerBinding(
            "wrong-fingerprint", lambda t: ExperimentRunOutput("parent", (("tokens", Fraction(1)),))
        )
        with self.assertRaises(Exception):
            execute_experiment(
                spec, self.tasks, runners=bindings, blind_evaluator=self._judge,
                execution_witness_ref="run",
            )

    def test_execute_experiment_runs_only_initial_batch_not_whole_scope(self):
        spec = self._design()
        execution = execute_experiment(
            spec, self.tasks, runners=self._bindings(spec), blind_evaluator=self._judge,
            execution_witness_ref="run", resource_witness_validator=self._resource_witness,
        )
        self.assertEqual({t.task_id for t in execution.trials}, set(spec.initial_task_ids))
        self.assertLess(len(execution.trials), len(spec.task_ids))
        self.assertTrue(execution.actual_resource_witness_complete)

    def test_cost_model_is_used_by_batch_scheduler_and_governor(self):
        spec = self._design()
        cost_model = ExperimentCostModel(
            per_condition_run=ResourceVector(tokens=100, steps=1),
            per_task_evaluation=ResourceVector(tokens=20, steps=1),
            per_batch_analysis=ResourceVector(tokens=10, steps=1),
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        batch = plan_next_experiment_batch(
            spec, execution_so_far=None, cost_model=cost_model, governor=governor,
            expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
            current_stop_utility=Fraction(10),
        )
        self.assertEqual(batch.decision, ExperimentBatchDecision.EXECUTE)
        expected = cost_model.estimate_batch(
            task_count=len(spec.initial_task_ids), condition_count=len(spec.conditions)
        )
        self.assertEqual(batch.estimated_resources, expected)
        self.assertLess(governor.remaining.tokens, self.env.resource_budget.tokens)

    def test_nonpositive_next_batch_voc_stops_without_execution(self):
        spec = self._design()
        cost_model = ExperimentCostModel(per_condition_run=ResourceVector(tokens=10, steps=1))
        governor = EconomyGovernor(budget=self.env.resource_budget)
        batch = plan_next_experiment_batch(
            spec, execution_so_far=None, cost_model=cost_model, governor=governor,
            expected_information_value=UtilityEstimate(Fraction(9), Fraction(10), Fraction(10)),
            current_stop_utility=Fraction(10),
        )
        self.assertEqual(batch.decision, ExperimentBatchDecision.STOP_ECONOMY)

    def test_full_tier_is_sequential_but_completion_is_mandatory(self):
        broad = ChangeImpact(
            "hot", ("economy-gate",), ("all-runtime",),
            ("retrieval", "coding", "planning"), ("quality", "tokens"),
            touches_hot_core=True, protected_impact=True,
        )
        spec = design_localized_experiment(
            experiment_id="full", question="hot core", impact=broad,
            task_catalog=self.tasks, metrics=self.metrics, environment=self.env,
            condition_specs=self.conditions, minimum_pairs=3,
            initial_batch_size=2, batch_size=2,
        )
        self.assertEqual(spec.tier, ExperimentTier.FULL)
        self.assertTrue(spec.stopping_rule.full_completion_required)
        self.assertEqual(spec.stopping_rule.maximum_pairs, len(self.tasks))
        self.assertEqual(len(spec.initial_task_ids), 2)


    def test_adjacent_canary_spillover_forces_broader_escalation_before_stop(self):
        envelope = TradeoffEnvelope(("quality",), (("tokens", Fraction(5)),))
        spec = self._design(tradeoff_envelope=envelope)
        bindings = self._bindings(spec)
        candidate_fp = spec.condition_spec(ExperimentCondition.CANDIDATE).fingerprint()
        def candidate_runner(task):
            tok = 140 if task.task_class == "planning" else 90
            return ExperimentRunOutput(
                "candidate:" + task.task_id, (("tokens", Fraction(tok)),),
                ResourceVector(tokens=tok, steps=1), "runner-meter",
            )
        bindings[ExperimentCondition.CANDIDATE] = ExperimentRunnerBinding(candidate_fp, candidate_runner)
        execution = execute_experiment(
            spec, self.tasks, runners=bindings, blind_evaluator=self._judge,
            execution_witness_ref="canary-spill",
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        decision = plan_next_experiment_batch(
            spec, execution_so_far=execution, cost_model=ExperimentCostModel(), governor=governor,
            expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
            current_stop_utility=Fraction(10),
        )
        self.assertEqual(decision.decision, ExperimentBatchDecision.ESCALATE_BROADER_DOMAIN)
        self.assertIn("planning", decision.reason)
        self.assertIn("tokens", decision.reason)

    def test_execution_records_estimated_vs_actual_cost_when_witnessed(self):
        spec = self._design()
        cost_model = ExperimentCostModel(
            per_condition_run=ResourceVector(tokens=100, steps=1),
            per_task_evaluation=ResourceVector(tokens=20, steps=1),
        )
        execution = execute_experiment(
            spec, self.tasks, runners=self._bindings(spec), blind_evaluator=self._judge,
            execution_witness_ref="run", cost_model=cost_model, resource_witness_validator=self._resource_witness,
        )
        self.assertIsNotNone(execution.cost_error)
        self.assertEqual(len(execution.cost_error), 9)

    def test_tradeoff_envelope_allows_small_compensable_cost_loss(self):
        p = MeasurementPlan(
            "trade", "affected", (
                MetricSpec("quality", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, Fraction(1), protected=True),
                MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, Fraction(5), protected=False),
            ), minimum_pairs=6, alpha=Fraction(1, 20),
        )
        observations = tuple(
            PairObservation(
                str(i),
                (("quality", Fraction(10)), ("tokens", Fraction(100))),
                (("quality", Fraction(12)), ("tokens", Fraction(103))),
            ) for i in range(6)
        )
        result = evaluate_measurement(p, observations)
        envelope = TradeoffEnvelope(
            ("quality",), (("tokens", Fraction(5)),), minimum_net_decision_value=Fraction(0)
        )
        assessment = assess_change_tradeoff(p, result, envelope, net_decision_value=Fraction(2))
        self.assertEqual(assessment.decision, TradeoffDecision.KEEP)

    def test_protected_regression_is_never_compensated(self):
        p = MeasurementPlan(
            "protected", "affected", (
                MetricSpec("quality", MetricDirection.HIGHER_IS_BETTER, MetricRole.VALUE, Fraction(1), protected=True),
                MetricSpec("tokens", MetricDirection.LOWER_IS_BETTER, MetricRole.COST, Fraction(1)),
            ), minimum_pairs=6, alpha=Fraction(1, 20),
        )
        observations = tuple(
            PairObservation(
                str(i),
                (("quality", Fraction(10)), ("tokens", Fraction(100))),
                (("quality", Fraction(8)), ("tokens", Fraction(50))),
            ) for i in range(6)
        )
        result = evaluate_measurement(p, observations)
        envelope = TradeoffEnvelope(("tokens",), (("quality", Fraction(100)),))
        assessment = assess_change_tradeoff(p, result, envelope, net_decision_value=Fraction(100))
        self.assertEqual(assessment.decision, TradeoffDecision.REVERT)

    def test_batch_cost_settlement_refunds_conservative_overestimate(self):
        spec = self._design()
        cost_model = ExperimentCostModel(
            per_condition_run=ResourceVector(tokens=150, steps=2),
            per_task_evaluation=ResourceVector(tokens=50, steps=1),
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        batch = plan_next_experiment_batch(
            spec, execution_so_far=None, cost_model=cost_model, governor=governor,
            expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
            current_stop_utility=Fraction(10),
        )
        reserved = governor.remaining.tokens
        execution = execute_experiment_batch(
            spec, self.tasks, task_ids=batch.task_ids, runners=self._bindings(spec),
            blind_evaluator=self._judge, execution_witness_ref="settle",
            cost_model=cost_model, batch_index=0, resource_witness_validator=self._resource_witness,
        )
        settlement = settle_experiment_batch_cost(governor, batch, execution)
        self.assertIsNotNone(settlement)
        self.assertGreater(governor.remaining.tokens, reserved)
        self.assertEqual(governor.remaining.tokens, self.env.resource_budget.tokens - execution.actual_resources.tokens)



    def test_resource_witness_strings_alone_do_not_license_actual_cost_settlement(self):
        spec = self._design()
        cost_model = ExperimentCostModel(
            per_condition_run=ResourceVector(tokens=150, steps=2),
            per_task_evaluation=ResourceVector(tokens=50, steps=1),
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        batch = plan_next_experiment_batch(
            spec, execution_so_far=None, cost_model=cost_model, governor=governor,
            expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
            current_stop_utility=Fraction(10),
        )
        execution = execute_experiment_batch(
            spec, self.tasks, task_ids=batch.task_ids, runners=self._bindings(spec),
            blind_evaluator=self._judge, execution_witness_ref="claimed-meter",
            cost_model=cost_model, batch_index=0,
        )
        self.assertFalse(execution.actual_resource_witness_complete)
        self.assertIsNone(settle_experiment_batch_cost(governor, batch, execution))

    def test_resource_witness_validator_exception_keeps_actual_cost_unwitnessed(self):
        spec = self._design()
        def boom(ref, resources):
            raise RuntimeError("meter validator unavailable")
        execution = execute_experiment(
            spec, self.tasks, runners=self._bindings(spec), blind_evaluator=self._judge,
            execution_witness_ref="run", resource_witness_validator=boom,
        )
        self.assertFalse(execution.actual_resource_witness_complete)
        self.assertIsNone(execution.cost_error)

    def test_design_offer_resources_must_match_frozen_cost_model(self):
        cost_model = ExperimentCostModel(
            design=ResourceVector(tokens=100, steps=1),
            precommit=ResourceVector(tokens=50, steps=1),
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        wrong_offer = CognitiveOffer(
            action_id="design", kind=CognitiveActionKind.DESIGN_EXPERIMENT,
            current_stop_utility=Fraction(0),
            post_action_stop_utility=UtilityEstimate(Fraction(1), Fraction(2), Fraction(3)),
            decision_cost_utility=Fraction(0),
            resources=ResourceVector(tokens=1),
        )
        with self.assertRaises(Exception):
            governed_design_localized_experiment(
                governor, wrong_offer, cost_model=cost_model,
                experiment_id="gated-design", question="design?", impact=self.impact,
                task_catalog=self.tasks, metrics=self.metrics, environment=self.env,
                condition_specs=self.conditions, minimum_pairs=3, initial_batch_size=2, batch_size=1,
            )

    def test_witnessed_batch_must_settle_before_next_batch(self):
        spec = self._design()
        cost_model = ExperimentCostModel(
            per_condition_run=ResourceVector(tokens=150, steps=2),
            per_task_evaluation=ResourceVector(tokens=50, steps=1),
        )
        governor = EconomyGovernor(budget=self.env.resource_budget)
        batch = plan_next_experiment_batch(
            spec, execution_so_far=None, cost_model=cost_model, governor=governor,
            expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
            current_stop_utility=Fraction(10),
        )
        execution = execute_experiment_batch(
            spec, self.tasks, task_ids=batch.task_ids, runners=self._bindings(spec),
            blind_evaluator=self._judge, execution_witness_ref="unsettled",
            cost_model=cost_model, batch_index=0, resource_witness_validator=self._resource_witness,
        )
        self.assertTrue(execution.actual_resource_witness_complete)
        with self.assertRaises(Exception):
            plan_next_experiment_batch(
                spec, execution_so_far=execution, cost_model=cost_model, governor=governor,
                expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
                current_stop_utility=Fraction(10),
            )

    def test_batch_governor_must_match_frozen_resource_envelope(self):
        spec = self._design()
        wrong = EconomyGovernor(budget=ResourceVector(tokens=999, steps=99))
        with self.assertRaises(Exception):
            plan_next_experiment_batch(
                spec, execution_so_far=None, cost_model=ExperimentCostModel(), governor=wrong,
                expected_information_value=UtilityEstimate(Fraction(12), Fraction(13), Fraction(14)),
                current_stop_utility=Fraction(10),
            )

    def test_reused_plain_metrics_compare_only_executed_frozen_tasks(self):
        spec0 = self._design()
        plain = spec0.condition_spec(ExperimentCondition.PLAIN)
        frozen_tasks = tuple(t for t in self.tasks if t.task_id in spec0.task_ids)
        baseline = PlainBaselineRecord(
            self.env.fingerprint(), plain.fingerprint(),
            tuple((t.task_id, t.fingerprint()) for t in frozen_tasks),
            "plain-ledger-ref",
            metrics_by_task=tuple(
                (t.task_id, (("quality", Fraction(8)), ("tokens", Fraction(130))))
                for t in frozen_tasks
            ),
        )
        spec = self._design(plain_baseline=baseline)
        execution = execute_experiment(
            spec, self.tasks, runners=self._bindings(spec), blind_evaluator=self._judge,
            execution_witness_ref="reuse",
        )
        primary_executed = tuple(t.task_id for t in execution.trials if t.task_id in set(spec.primary_task_ids))
        result = evaluate_experiment_pair(
            spec, execution, reference=ExperimentCondition.PLAIN,
            candidate=ExperimentCondition.CANDIDATE, plain_baseline=baseline,
            task_ids=primary_executed,
        )
        self.assertEqual(result.pairs, len(primary_executed))
        self.assertTrue(all(e.oriented_mean_delta > 0 for e in result.evidence))

if __name__ == "__main__":
    unittest.main()
