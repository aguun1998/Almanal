import unittest
from fractions import Fraction

from almanal_runtime.economy import (
    CognitiveActionKind, ResourceVector, UtilityEstimate,
    CognitiveOffer, EconomyGovernor,
)
from almanal_runtime.governed import GovernedStatus, execute_governed


def offer(expected=12, cost=1, *, mandatory=False, tokens=10):
    return CognitiveOffer(
        "x",
        CognitiveActionKind.CHALLENGE,
        Fraction(10),
        UtilityEstimate(Fraction(expected), Fraction(expected), Fraction(expected)),
        Fraction(cost),
        ResourceVector(tokens=tokens, steps=1),
        mandatory=mandatory,
        evidence_ref="test",
    )


class GovernedExecutionTests(unittest.TestCase):
    def test_skipped_cognition_is_not_executed(self):
        calls = []
        gov = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        result = execute_governed(
            gov,
            offer(expected=10, cost=1),
            lambda: calls.append("ran"),
        )
        self.assertEqual(result.status, GovernedStatus.SKIPPED)
        self.assertEqual(calls, [])

    def test_positive_voc_cognition_executes(self):
        calls = []
        gov = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        result = execute_governed(
            gov,
            offer(expected=13, cost=1),
            lambda: calls.append("ran") or 42,
        )
        self.assertEqual(result.status, GovernedStatus.EXECUTED)
        self.assertEqual(result.value, 42)
        self.assertEqual(calls, ["ran"])

    def test_mandatory_unfunded_is_blocked_not_run(self):
        calls = []
        gov = EconomyGovernor(budget=ResourceVector(tokens=5, steps=10))
        result = execute_governed(
            gov,
            offer(expected=13, cost=1, mandatory=True, tokens=10),
            lambda: calls.append("ran"),
        )
        self.assertEqual(result.status, GovernedStatus.BLOCKED)
        self.assertEqual(calls, [])

    def test_operator_failure_is_totalized(self):
        gov = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        result = execute_governed(
            gov,
            offer(expected=13, cost=1),
            lambda: (_ for _ in ()).throw(RuntimeError("boom")),
        )
        self.assertEqual(result.status, GovernedStatus.FAILED)
        self.assertIn("RuntimeError", result.error)


if __name__ == "__main__":
    unittest.main()
