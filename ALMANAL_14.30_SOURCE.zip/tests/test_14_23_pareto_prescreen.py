import unittest
from pathlib import Path

from almanal_runtime.evaluator import (
    AnalyticCostVector, analytic_pareto_prescreen, benchmark_is_decision_relevant,
)
from almanal_runtime.prompting import default_library_capsules

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "spec"

class AnalyticParetoPrescreenTests(unittest.TestCase):
    def test_dominated_optimistic_candidate_is_not_materialized(self):
        front = (AnalyticCostVector((225, 2504, 639)),)
        # Even its optimistic lower bounds are no better than the frontier.
        d = analytic_pareto_prescreen(AnalyticCostVector((230, 2600, 650)), front, feasible=True)
        self.assertFalse(d.materialize)

    def test_possible_front_advance_survives_static_screen(self):
        front = (AnalyticCostVector((225, 2504, 639)),)
        d = analytic_pareto_prescreen(AnalyticCostVector((190, 2504, 639)), front, feasible=True)
        self.assertTrue(d.materialize)

    def test_benchmark_last_requires_unresolved_and_decision_changing(self):
        self.assertFalse(benchmark_is_decision_relevant(unresolved_empirical_axis=False, can_change_selection=True))
        self.assertFalse(benchmark_is_decision_relevant(unresolved_empirical_axis=True, can_change_selection=False))
        self.assertFalse(benchmark_is_decision_relevant(unresolved_empirical_axis=True, can_change_selection=True))
        self.assertTrue(benchmark_is_decision_relevant(unresolved_empirical_axis=True, can_change_selection=True, mechanism_identified=True, static_screen_complete=True))
        self.assertFalse(benchmark_is_decision_relevant(unresolved_empirical_axis=True, can_change_selection=True, mechanism_identified=False))
        self.assertFalse(benchmark_is_decision_relevant(unresolved_empirical_axis=True, can_change_selection=True, static_screen_complete=False))

    def test_goal_conditioning_and_benchmark_last_are_in_planning_capsule(self):
        body = next(c for c in default_library_capsules() if c.capsule_id == "PLANNING").body.lower()
        self.assertIn("backward co-reachability", body)
        self.assertIn("benchmark last", body)
        self.assertIn("optimistic static", body)

    def test_portable_contract_exposes_new_guards(self):
        text=(SPEC/"ALMANAL.md").read_text(encoding="utf-8")
        self.assertIn('"analytic_pareto_prescreen": true', text)
        self.assertIn('"benchmark_last_gate": true', text)
        self.assertIn('"goal_conditioned_state_pruning": true', text)

if __name__ == "__main__":
    unittest.main()
