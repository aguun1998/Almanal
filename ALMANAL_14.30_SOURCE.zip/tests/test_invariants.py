import unittest

from almanal_runtime import *
from almanal_runtime.errors import *
from almanal_runtime.stage import Stage
from almanal_runtime.persistence import RevisionProposal
from almanal_runtime.typesystem import PromotionRegistry
from almanal_runtime.authority import Permission
from almanal_runtime.conformance import ConformanceProfile, OperatorRealization
from almanal_runtime.ontology import ConceptLicense, ConceptCategory
from almanal_runtime.library import LibraryClaim, ClaimStatus, ResidentRecipeContract
from almanal_runtime.verification import VerificationBasis
from almanal_runtime.assurance import (
    VerificationAction, VerificationTier, Materiality, ChangeSet,
    ImpactGraph, VerificationCache, plan_verification, verify_impact_graph
)


def snapshot():
    return EpochSnapshot(
        TaskSemantics(
            "OPTIMIZE","state","goal","preserve","allowed","space",
            "oracle","none","steps","scope"
        ),
        EvaluationCriterion(("q","neg_cost"), (0,1), scope="scope"),
        ("freeze","authority"),
        "scope",
        "14.2/py0.2",
    )


def advance_to_regression(rt):
    for st in (
        Stage.AUTOTUNE, Stage.SCOPE, Stage.MOUNT, Stage.FORMALIZE,
        Stage.GENERATE, Stage.CHALLENGE, Stage.VALIDATE, Stage.REGRESSION
    ):
        rt.transition(st)


def empirical_cert(cid, oid, criterion):
    return Certificate(
        certificate_id=cid,
        subject_ref=oid,
        criterion_snapshot_ref=criterion,
        scope="scope",
        evidence_refs=("eval",),
        empirical_status=EmpiricalStatus.SUPPORTED,
        procedure_status=ProcedureStatus.COMPLETE,
    )


class RuntimeInvariantTests(unittest.TestCase):
    def test_unregistered_promotion_rejected(self):
        r = PromotionRegistry()
        obj = TypedObject.new("x", ObjectType.SIMULATION, "s", "scope")
        with self.assertRaises(TypePromotionNotRegistered):
            r.promote(obj, new_id="y", target_type=ObjectType.OBSERVATION,
                      transformed_content="o")

    def test_registered_promotion_allowed(self):
        r = PromotionRegistry()
        r.register(ObjectType.REPORT, ObjectType.CLAIM)
        obj = TypedObject.new("x", ObjectType.REPORT, "r", "scope")
        out = r.promote(obj, new_id="y", target_type=ObjectType.CLAIM,
                        transformed_content="c")
        self.assertEqual(out.object_type, ObjectType.CLAIM)
        self.assertEqual(out.version, 2)

    def test_illegal_transition_does_not_consume_budget(self):
        rt = Runtime(snapshot(), 3)
        before = rt.remaining_steps
        with self.assertRaises(InvalidTransition):
            rt.transition(Stage.GENERATE)
        self.assertEqual(rt.remaining_steps, before)

    def test_each_normal_transition_consumes_one(self):
        rt = Runtime(snapshot(), 3)
        rt.transition(Stage.AUTOTUNE)
        self.assertEqual(rt.remaining_steps, 2)

    def test_budget_exhaustion_marks_incomplete(self):
        rt = Runtime(snapshot(), 0)
        with self.assertRaises(BudgetExhausted):
            rt.transition(Stage.AUTOTUNE)
        self.assertEqual(rt.status, RuntimeStatus.INCOMPLETE)
        self.assertEqual(rt.stop_reason, StopReason.BUDGET_EXHAUSTED)

    def test_provenance_union_exact(self):
        rt = Runtime(snapshot(), 10)
        aid = rt.ingest_object(
            TypedObject.new("a", ObjectType.OBSERVATION, "a", "scope"),
            frozenset({SourceRoot("s1")}), frozenset()
        )
        bid = rt.ingest_object(
            TypedObject.new("b", ObjectType.REPORT, "b", "scope"),
            frozenset({SourceRoot("s2")}), frozenset()
        )
        cid = rt.derive_object(
            obj=TypedObject.new("c", ObjectType.CLAIM, "c", "scope"),
            input_ids=(aid,bid), new_roots=frozenset({SourceRoot("s3")}),
            operator="derive", requested_authority=frozenset()
        )
        self.assertEqual(
            rt.provenance_roots(cid),
            frozenset({SourceRoot("s1"),SourceRoot("s2"),SourceRoot("s3")})
        )

    def test_authority_outside_envelope_rejected_atomically(self):
        rt = Runtime(snapshot(), 10)
        aid = rt.ingest_object(
            TypedObject.new("a", ObjectType.CLAIM, "a", "scope"),
            frozenset({SourceRoot("s")}), frozenset({Permission.READ})
        )
        before = len(rt.objects())
        with self.assertRaises(AuthorityViolation):
            rt.derive_object(
                obj=TypedObject.new("c", ObjectType.CLAIM, "c", "scope"),
                input_ids=(aid,), new_roots=frozenset(), operator="derive",
                requested_authority=frozenset({Permission.GOVERNANCE})
            )
        self.assertEqual(len(rt.objects()), before)

    def test_operator_grant_extends_envelope(self):
        rt = Runtime(snapshot(), 10)
        rt.set_operator_grant("judge", frozenset({Permission.EVALUATE}))
        aid = rt.ingest_object(
            TypedObject.new("a", ObjectType.CLAIM, "a", "scope"),
            frozenset({SourceRoot("s")}), frozenset({Permission.READ})
        )
        cid = rt.derive_object(
            obj=TypedObject.new("c", ObjectType.EVALUATION, "c", "scope"),
            input_ids=(aid,), new_roots=frozenset(), operator="judge",
            requested_authority=frozenset({Permission.READ, Permission.EVALUATE})
        )
        self.assertIn(Permission.EVALUATE, rt.authority_of(cid))

    def test_proved_requires_proof_ref(self):
        cert = Certificate(
            "c1", ObjectId("x"), snapshot().canonical_encode(), "scope",
            formal_status=FormalStatus.PROVED,
            procedure_status=ProcedureStatus.COMPLETE
        )
        with self.assertRaises(CertificateViolation):
            cert.validate_structure()

    def test_supported_requires_evidence(self):
        cert = Certificate(
            "c1", ObjectId("x"), snapshot().canonical_encode(), "scope",
            empirical_status=EmpiricalStatus.SUPPORTED,
            procedure_status=ProcedureStatus.COMPLETE
        )
        with self.assertRaises(CertificateViolation):
            cert.validate_structure()

    def test_same_model_root_blocks_independence(self):
        cert = Certificate(
            "c1", ObjectId("x"), snapshot().canonical_encode(), "scope",
            evidence_refs=("e",),
            separation=SeparationVector(model_root=TriState.NO),
            independence_status=IndependenceStatus.INDEPENDENCE_SUPPORTED_SCOPED,
            independence_audit_ref="audit:dep",
            empirical_status=EmpiricalStatus.SUPPORTED,
            procedure_status=ProcedureStatus.COMPLETE
        )
        with self.assertRaises(CertificateViolation):
            cert.validate_structure()

    def test_arbitrary_proof_ref_cannot_be_persisted_without_verification(self):
        rt = Runtime(snapshot(), 10)
        rt.seed_persistent("alg", "v1")
        oid = rt.ingest_object(
            TypedObject.new("x", ObjectType.ALGORITHM, "x", "scope"),
            frozenset({SourceRoot("s")}), frozenset()
        )
        cert = Certificate(
            "fake-proof", oid, rt.snapshot.canonical_encode(), "scope",
            proof_ref="trust-me.txt",
            formal_status=FormalStatus.PROVED,
            procedure_status=ProcedureStatus.COMPLETE,
        )
        # Structure is valid, but STRUCTURE_ONLY can never verify PROVED.
        with self.assertRaises(VerificationViolation):
            rt.verify_and_add_certificate(
                cert, verifier_ref="self", basis=VerificationBasis.STRUCTURE_ONLY,
                verifier=lambda _: True,
            )

    def test_verified_empirical_certificate_can_commit_and_rollback(self):
        rt = Runtime(snapshot(), 10)
        rt.seed_persistent("alg", "v1")
        oid = rt.ingest_object(
            TypedObject.new("x", ObjectType.ALGORITHM, "x", "scope"),
            frozenset({SourceRoot("s")}), frozenset()
        )
        cert = empirical_cert("e1", oid, rt.snapshot.canonical_encode())
        rt.verify_and_add_certificate(
            cert, verifier_ref="unit-evaluator",
            basis=VerificationBasis.RUNTIME_EVALUATOR,
            verifier=lambda _: True,
        )
        proposal = RevisionProposal(
            "alg", 1, oid, "v2", rt.snapshot.canonical_encode(),
            "trial", "restore v1", cert
        )
        advance_to_regression(rt)
        rt.commit_revision(proposal)
        self.assertEqual(rt.persistent_value("alg").value, "v2")
        rt.rollback_last()
        self.assertEqual(rt.persistent_value("alg").value, "v1")

    def test_unverified_certificate_cannot_commit(self):
        rt = Runtime(snapshot(), 10)
        rt.seed_persistent("alg", "v1")
        oid = rt.ingest_object(
            TypedObject.new("x", ObjectType.ALGORITHM, "x", "scope"),
            frozenset({SourceRoot("s")}), frozenset()
        )
        cert = empirical_cert("e1", oid, rt.snapshot.canonical_encode())
        proposal = RevisionProposal(
            "alg", 1, oid, "v2", rt.snapshot.canonical_encode(),
            "trial", "rollback", cert
        )
        advance_to_regression(rt)
        with self.assertRaises(PersistenceViolation):
            rt.commit_revision(proposal)

    def test_certificate_must_bind_candidate(self):
        rt = Runtime(snapshot(), 10)
        rt.seed_persistent("alg", "v1")
        a = rt.ingest_object(
            TypedObject.new("a", ObjectType.ALGORITHM, "a", "scope"),
            frozenset({SourceRoot("s1")}), frozenset()
        )
        b = rt.ingest_object(
            TypedObject.new("b", ObjectType.ALGORITHM, "b", "scope"),
            frozenset({SourceRoot("s2")}), frozenset()
        )
        cert = empirical_cert("e1", a, rt.snapshot.canonical_encode())
        rt.verify_and_add_certificate(
            cert, verifier_ref="eval", basis=VerificationBasis.RUNTIME_EVALUATOR,
            verifier=lambda _: True,
        )
        proposal = RevisionProposal(
            "alg", 1, b, "candidate-b", rt.snapshot.canonical_encode(),
            "trial", "rollback", cert
        )
        advance_to_regression(rt)
        with self.assertRaises(PersistenceViolation):
            rt.commit_revision(proposal)

    def test_persistent_commit_rejected_after_runtime_complete(self):
        rt = Runtime(snapshot(), 20)
        rt.seed_persistent("alg", "v1")
        oid = rt.ingest_object(
            TypedObject.new("x", ObjectType.ALGORITHM, "x", "scope"),
            frozenset({SourceRoot("s")}), frozenset()
        )
        cert = empirical_cert("e-after", oid, rt.snapshot.canonical_encode())
        rt.verify_and_add_certificate(
            cert, verifier_ref="eval", basis=VerificationBasis.RUNTIME_EVALUATOR,
            verifier=lambda _: True,
        )
        proposal = RevisionProposal(
            "alg", 1, oid, "v2", rt.snapshot.canonical_encode(),
            "trial", "rollback", cert
        )
        advance_to_regression(rt)
        rt.transition(Stage.OUTPUT)
        rt.finish()
        with self.assertRaises(PersistenceViolation):
            rt.commit_revision(proposal)

    def test_exec_profile_requires_implementation(self):
        rt = Runtime(snapshot(), 10)
        rt.register_operator_realization("K", OperatorRealization("P->C"))
        with self.assertRaises(ConformanceViolation):
            rt.verify_profile(ConformanceProfile.EXEC, frozenset({"K"}))

    def test_exec_profile_passes_ready_operator(self):
        rt = Runtime(snapshot(), 10)
        rt.register_operator_realization(
            "K", OperatorRealization("P->C", "python:worker.generate", "timeout=1", True, True)
        )
        rt.verify_profile(ConformanceProfile.EXEC, frozenset({"K"}))

    def test_exec_profile_rejects_text_only_timeout_contract(self):
        rt = Runtime(snapshot(), 10)
        rt.register_operator_realization(
            "K", OperatorRealization(
                "P->C", "python:worker.generate", "timeout=1", False, True
            )
        )
        with self.assertRaises(ConformanceViolation):
            rt.verify_profile(ConformanceProfile.EXEC, frozenset({"K"}))

    def test_ontology_license_requires_witnesses(self):
        rt = Runtime(snapshot(), 10)
        with self.assertRaises(OntologyViolation):
            rt.register_concept_license(
                "X", ConceptLicense(
                    ConceptCategory.META_ALGORITHM,
                    ("effective","terminating"), ("effective",), True,
                )
            )

    def test_library_theorem_needs_proof(self):
        rt = Runtime(snapshot(), 10)
        with self.assertRaises(LibraryViolation):
            rt.register_library_claim(LibraryClaim("t1", ClaimStatus.THEOREM, "x"))

    def test_library_exec_recipe_requires_realizations(self):
        rt = Runtime(snapshot(), 10)
        rt.register_library_recipe(
            ResidentRecipeContract("SOCIAL", frozenset({"update","compare"}), True)
        )
        rt.realize_library_operator("update", "python:update")
        with self.assertRaises(LibraryViolation):
            rt.check_library_exec_ready("SOCIAL")


class QualityTests(unittest.TestCase):
    def test_non_regression(self):
        self.assertTrue(QualityVector((2,3)).protected_non_regression(QualityVector((1,3)), (0,1)))

    def test_strict_dominance(self):
        self.assertTrue(QualityVector((2,3)).strictly_dominates(QualityVector((1,3)), (0,1)))

    def test_reference_pareto(self):
        result = bounded_reference_synthesize(
            [0,1,2,3], (0,1), lambda x: True, lambda x: QualityVector((x, -x))
        )
        self.assertEqual(result.feasible_count, 4)
        self.assertEqual(len(result.pareto_front), 4)



class AssuranceTests(unittest.TestCase):
    def actions(self):
        return (
            VerificationAction(
                "syntax", token_cost=0, decision_cost_utility=0,
                expected_loss_avoided_utility=1,
                affected_by=frozenset(), tier=VerificationTier.STATIC,
                always_run=True,
            ),
            VerificationAction(
                "assurance-canary", token_cost=200, decision_cost_utility=1,
                expected_loss_avoided_utility=8,
                affected_by=frozenset({"assurance"}),
                tier=VerificationTier.CANARY,
                mandatory_when_impacted=True,
            ),
            VerificationAction(
                "certificate-canary", token_cost=250, decision_cost_utility=1,
                expected_loss_avoided_utility=8,
                affected_by=frozenset({"certificate"}),
                tier=VerificationTier.CANARY,
                mandatory_when_impacted=True,
            ),
            VerificationAction(
                "assurance-redteam", token_cost=1800, decision_cost_utility=4,
                expected_loss_avoided_utility=12,
                affected_by=frozenset({"assurance"}),
                tier=VerificationTier.TARGETED,
            ),
            VerificationAction(
                "full-regression", token_cost=7000, decision_cost_utility=12,
                expected_loss_avoided_utility=15,
                affected_by=frozenset({"kernel","assurance","certificate"}),
                tier=VerificationTier.FULL,
            ),
        )

    def test_impact_locality_avoids_unrelated_checks(self):
        plan = plan_verification(
            self.actions(),
            change=ChangeSet(frozenset({"assurance"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=10000,
        )
        self.assertIn("syntax", plan.selected_names)
        self.assertIn("assurance-canary", plan.selected_names)
        self.assertNotIn("certificate-canary", plan.selected_names)
        self.assertNotIn("assurance-redteam", plan.selected_names)
        self.assertNotIn("full-regression", plan.selected_names)
        self.assertLess(plan.total_token_cost, plan.full_token_cost)

    def test_material_change_opens_targeted_with_verified_impact_coverage(self):
        graph = verify_impact_graph(
            ImpactGraph(version="g1"),
            verifier_ref="unit-test-coverage",
            scope="test",
            verifier=lambda g: True,
        )
        plan = plan_verification(
            self.actions(),
            change=ChangeSet(frozenset({"assurance"}), Materiality.MATERIAL),
            impact_graph=graph,
            token_budget=10000,
        )
        self.assertIn("assurance-redteam", plan.selected_names)
        self.assertNotIn("full-regression", plan.selected_names)
        self.assertEqual(plan.max_initial_tier, VerificationTier.TARGETED)

    def test_protected_change_opens_full(self):
        plan = plan_verification(
            self.actions(),
            change=ChangeSet(frozenset({"kernel"}), Materiality.PROTECTED),
            impact_graph=ImpactGraph({"kernel": {"assurance","certificate"}}),
            token_budget=10000,
        )
        self.assertEqual(plan.max_initial_tier, VerificationTier.FULL)
        self.assertIn("full-regression", plan.selected_names)

    def test_unverified_impact_graph_opens_full_for_material_change(self):
        plan = plan_verification(
            self.actions(),
            change=ChangeSet(
                frozenset({"assurance"}), Materiality.MATERIAL
            ),
            impact_graph=ImpactGraph(version="unverified"),
            token_budget=10000,
        )
        self.assertEqual(plan.max_initial_tier, VerificationTier.FULL)

    def test_failed_impact_coverage_verifier_does_not_enable_narrowing(self):
        graph = verify_impact_graph(
            ImpactGraph(version="g2"),
            verifier_ref="failing-verifier",
            scope="test",
            verifier=lambda g: False,
        )
        plan = plan_verification(
            self.actions(),
            change=ChangeSet(frozenset({"assurance"}), Materiality.MATERIAL),
            impact_graph=graph,
            token_budget=10000,
        )
        self.assertEqual(plan.max_initial_tier, VerificationTier.FULL)

    def test_mandatory_impacted_floor_cannot_be_dropped(self):
        with self.assertRaises(AssuranceViolation):
            plan_verification(
                self.actions(),
                change=ChangeSet(frozenset({"assurance"}), Materiality.ROUTINE),
                impact_graph=ImpactGraph(),
                token_budget=100,
            )

    def test_knapsack_beats_greedy(self):
        actions = (
            VerificationAction(
                "A", 6, 1, 7, frozenset({"x"}), VerificationTier.CANARY
            ), # net 6
            VerificationAction(
                "B", 4, 1, 6, frozenset({"x"}), VerificationTier.CANARY
            ), # net 5
            VerificationAction(
                "C", 4, 1, 6, frozenset({"x"}), VerificationTier.CANARY
            ), # net 5; B+C net 10 > A
        )
        plan = plan_verification(
            actions,
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=8,
        )
        self.assertEqual(set(plan.selected_names), {"B","C"})

    def test_decision_value_and_token_budget_are_separate_units(self):
        action = VerificationAction(
            "expensive-but-valuable",
            token_cost=1000,
            decision_cost_utility=2,
            expected_loss_avoided_utility=10,
            affected_by=frozenset({"x"}),
            tier=VerificationTier.CANARY,
        )
        plan = plan_verification(
            (action,),
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=1000,
        )
        self.assertEqual(plan.selected_names, ("expensive-but-valuable",))

    def test_exact_cache_reuse_skips_cost(self):
        cache = VerificationCache()
        action = VerificationAction(
            "x-canary", 300, 1, 9, frozenset({"x"}),
            VerificationTier.CANARY, mandatory_when_impacted=True,
        )
        fps = {"x": "hash-v1"}
        cache.record(action, fps, passed=True)
        plan = plan_verification(
            (action,),
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=0,
            fingerprints=fps,
            cache=cache,
        )
        self.assertEqual(plan.total_token_cost, 0)
        self.assertEqual(tuple(a.name for a in plan.cache_hits), ("x-canary",))

    def test_cache_invalidates_when_relevant_fingerprint_changes(self):
        cache = VerificationCache()
        action = VerificationAction(
            "x-canary", 300, 1, 9, frozenset({"x"}),
            VerificationTier.CANARY, mandatory_when_impacted=True,
        )
        cache.record(action, {"x": "old"}, passed=True)
        with self.assertRaises(AssuranceViolation):
            plan_verification(
                (action,),
                change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
                impact_graph=ImpactGraph(),
                token_budget=0,
                fingerprints={"x": "new"},
                cache=cache,
            )


    def test_unscoped_verification_requires_explicit_global_mark(self):
        action = VerificationAction(
            "hidden-global", 100, 1, 5, frozenset(), VerificationTier.CANARY
        )
        with self.assertRaises(AssuranceViolation):
            plan_verification(
                (action,),
                change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
                impact_graph=ImpactGraph(),
                token_budget=1000,
            )



    def test_zero_token_positive_value_check_runs_at_zero_budget(self):
        action = VerificationAction(
            "free-static", 0, 0, 5, frozenset(), VerificationTier.STATIC,
            always_run=True,
        )
        plan = plan_verification(
            (action,),
            change=ChangeSet(frozenset({"x"}), Materiality.TRIVIAL),
            impact_graph=ImpactGraph(),
            token_budget=0,
        )
        self.assertEqual(plan.selected_names, ("free-static",))
        self.assertEqual(plan.total_token_cost, 0)



if __name__ == "__main__":
    unittest.main()
