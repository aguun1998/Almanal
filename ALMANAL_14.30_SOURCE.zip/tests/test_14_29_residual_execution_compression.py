import unittest
from pathlib import Path
from almanal_runtime.evaluator import residual_execution_closure_complete, delayed_reduction_safe, finalization_pass_allowed, WitnessLeaseLedger
from almanal_runtime.prompting import default_library_capsules
ROOT=Path(__file__).resolve().parents[1]
AUDITS=("minimal_state","transition_native","class_aggregation","narrow_sparse_storage","arithmetic_bounds","selective_specialization","io_bottleneck")
def refs(): return tuple((k,f"audit:{k}") for k in AUDITS)
def valid(k,r): return r==f"audit:{k}"
class Test1429ResidualCompression(unittest.TestCase):
    def test_material_task_requires_witnessed_complete_audit(self):
        self.assertTrue(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs(),audit_validator=valid))
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs()[:-1],audit_validator=valid))
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs()))
    def test_nonmaterial_task_skips_residual_audit_only_with_witness(self):
        self.assertFalse(residual_execution_closure_complete(resource_material=False))
        self.assertTrue(residual_execution_closure_complete(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True))
    def test_arithmetic_narrowing_requires_bound(self):
        self.assertTrue(delayed_reduction_safe(min_intermediate=0,max_intermediate=100,type_min=0,type_max=255))
        self.assertFalse(delayed_reduction_safe(min_intermediate=0,max_intermediate=256,type_min=0,type_max=255))
    def test_finalization_blocked_until_residual_closure(self):
        self.assertFalse(finalization_pass_allowed(passes_used=0))
        self.assertFalse(finalization_pass_allowed(passes_used=0,resource_material=False))
        self.assertTrue(finalization_pass_allowed(passes_used=0,resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True,witness_ledger=WitnessLeaseLedger()))
    def test_planning_contains_new_closure(self):
        p=next(x for x in default_library_capsules() if x.capsule_id=="PLANNING").body.lower()
        for q in ("minimal sufficient state","transition-native","transition-class aggregation","delayed reduction","structurally material hot classes"):
            self.assertIn(q,p)
    def test_compact_contract_exposes_closure(self):
        s=(ROOT/"spec/ALMANAL.md").read_text()
        self.assertIn("# 6.32 RESIDUAL EXECUTION-COMPRESSION CLOSURE",s)
        self.assertIn('"transition_class_aggregation": true',s)
if __name__=="__main__": unittest.main()
