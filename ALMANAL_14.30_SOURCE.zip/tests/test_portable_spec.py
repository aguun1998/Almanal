import unittest
from pathlib import Path

from almanal_runtime.errors import AlmanalError
from almanal_runtime.portable import ALMANAL_RUNTIME_PROTOCOL
from almanal_runtime.portable_spec import lint_almanal_file, lint_almanal_text


ALMANAL = Path(__file__).resolve().parents[1] / "spec" / "ALMANAL.md"


class PortableSpecTests(unittest.TestCase):
    def test_real_almanal_artifact_lints(self):
        info = lint_almanal_file(ALMANAL)
        self.assertEqual(info.artifact, "ALMANAL")
        self.assertEqual(info.version, "14.30")
        self.assertIn("EXPERIMENT_DESIGN_EXECUTION", info.conditional_operators)
        self.assertIn("OBJECTIVE_RESOLUTION", info.conditional_operators)
        self.assertIn("EVIDENCE_SELECTION", info.conditional_operators)
        self.assertIn("OUTCOME_PREFERENCE_ELICITATION", info.conditional_operators)
        self.assertIn("OBJECTIVE_SELF_REVALUATION", info.conditional_operators)
        self.assertIn("VALIDATE_EPISTEMIC_CLAIM", info.required_operators)
        self.assertEqual(info.runtime_protocol, ALMANAL_RUNTIME_PROTOCOL)
        self.assertTrue(info.runtime_mandatory)

    def test_runtime_cannot_be_marked_optional(self):
        text = ALMANAL.read_text(encoding="utf-8").replace(
            '"runtime_mandatory": true', '"runtime_mandatory": false'
        )
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)

    def test_protocol_mismatch_rejected(self):
        text = ALMANAL.read_text(encoding="utf-8").replace(
            "ALMANAL-RUNTIME-CONTRACT/1", "OTHER-RUNTIME/1"
        )
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)

    def test_brand_specific_dependency_rejected(self):
        text = ALMANAL.read_text(encoding="utf-8") + "\nUse ChatGPT specifically.\n"
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)


    def test_missing_operational_section_rejected(self):
        text = ALMANAL.read_text(encoding="utf-8").replace(
            "# 7. LOCALIZED EXPERIMENT + CAUSAL FEEDBACK",
            "# 7. Removed Measurement Feedback",
            1,
        )
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)



    def test_external_file_dependency_rejected(self):
        text = ALMANAL.read_text(encoding="utf-8").replace(
            '"external_files_required": false',
            '"external_files_required": true',
        )
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)

    def test_unproved_full_equivalence_claim_rejected(self):
        text = ALMANAL.read_text(encoding="utf-8").replace(
            '"formal_source_equivalence_claimed": false',
            '"formal_source_equivalence_claimed": true',
        )
        with self.assertRaises(AlmanalError):
            lint_almanal_text(text)



if __name__ == "__main__":
    unittest.main()
