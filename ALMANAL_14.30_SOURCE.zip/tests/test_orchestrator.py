import unittest
from fractions import Fraction

from almanal_runtime.demo import demo_snapshot
from almanal_runtime import Runtime, RuntimeStatus, StopReason, QualityVector
from almanal_runtime.worker import DeterministicDemoWorker, CandidateDraft
from almanal_runtime.orchestrator import (
    run_worker_cycle, CognitiveRoutePlan, CognitiveRouteKind, plan_cognitive_route,
)
from almanal_runtime.economy import (
    CognitiveActionKind, CognitiveOffer, EconomyGovernor,
    ResourceVector, UtilityEstimate,
)


class EmptyWorker:
    def generate(self, snapshot): return []
    def challenge(self, snapshot, candidates): return []
    def repair(self, snapshot, candidate, challenges): return candidate


class TradeoffWorker:
    def generate(self, snapshot):
        return [CandidateDraft("A", "A"), CandidateDraft("B", "B")]
    def challenge(self, snapshot, candidates): return []
    def repair(self, snapshot, candidate, challenges): return candidate


class FailingWorker:
    def generate(self, snapshot): raise RuntimeError("boom")
    def challenge(self, snapshot, candidates): return []
    def repair(self, snapshot, candidate, challenges): return candidate


class RepairFailWorker:
    def generate(self, snapshot): return [CandidateDraft("A", "A")]
    def challenge(self, snapshot, candidates): return []
    def repair(self, snapshot, candidate, challenges): raise RuntimeError("repair boom")


class CountingWorker:
    def __init__(self):
        self.generate_calls = 0
        self.challenge_calls = 0
        self.repair_calls = 0
    def generate(self, snapshot):
        self.generate_calls += 1
        return [CandidateDraft("A", "A")]
    def challenge(self, snapshot, candidates):
        self.challenge_calls += 1
        return []
    def repair(self, snapshot, candidate, challenges):
        self.repair_calls += 1
        return candidate


def offer(kind, expected, *, mandatory=False, tokens=10):
    return CognitiveOffer(
        action_id=kind.name,
        kind=kind,
        current_stop_utility=Fraction(10),
        post_action_stop_utility=UtilityEstimate(
            Fraction(expected), Fraction(expected), Fraction(expected)
        ),
        decision_cost_utility=Fraction(0),
        resources=ResourceVector(tokens=tokens, steps=1),
        mandatory=mandatory,
        evidence_ref="route-test",
    )


class OrchestratorTests(unittest.TestCase):
    def test_default_cycle_is_minimum_generate_verify_not_full_ritual(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, DeterministicDemoWorker(),
            lambda c: QualityVector((len(c.body), -len(c.id))),
            baseline_quality=QualityVector((0, -100)),
        )
        self.assertEqual(rt.status, RuntimeStatus.COMPLETE)
        self.assertEqual(rt.stop_reason, StopReason.COMPLETED)
        self.assertIsNotNone(result.selected)
        self.assertEqual(result.route, CognitiveRouteKind.GENERATE_VERIFY)
        self.assertEqual(result.cost.worker_generate_calls, 1)
        self.assertEqual(result.cost.worker_challenge_calls, 0)
        self.assertEqual(result.cost.worker_repair_calls, 0)
        self.assertEqual(result.cost.evaluator_calls, 1)
        self.assertGreater(result.cost.elapsed_ns, 0)
        rt.check_trace_invariants()

    def test_full_loop_runs_only_when_explicitly_selected(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, DeterministicDemoWorker(),
            lambda c: QualityVector((len(c.body), -len(c.id))),
            baseline_quality=QualityVector((0, -100)),
            route_plan=CognitiveRoutePlan(True, True, True, True),
        )
        self.assertEqual(result.route, CognitiveRouteKind.FULL_REPAIR_LOOP)
        self.assertEqual(result.cost.worker_challenge_calls, 1)
        self.assertEqual(result.cost.worker_repair_calls, 1)

    def test_economy_route_skips_nonpositive_challenge_and_dependent_repair(self):
        governor = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        plan = plan_cognitive_route(governor, (
            offer(CognitiveActionKind.GENERATE, 12),
            offer(CognitiveActionKind.CHALLENGE, 10),  # VOC = 0 -> skip
            offer(CognitiveActionKind.REPAIR, 13),     # prereq skipped -> never executed
            offer(CognitiveActionKind.VERIFY, 12),
        ))
        self.assertTrue(plan.generate)
        self.assertFalse(plan.challenge)
        self.assertFalse(plan.repair)
        self.assertTrue(plan.verify)
        worker = CountingWorker()
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, worker, lambda c: QualityVector((1, 1)),
            baseline_quality=QualityVector((0, 0)), route_plan=plan,
        )
        self.assertEqual(worker.challenge_calls, 0)
        self.assertEqual(worker.repair_calls, 0)
        self.assertEqual(result.route, CognitiveRouteKind.GENERATE_VERIFY)

    def test_direct_route_executes_no_worker_brains(self):
        governor = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        plan = plan_cognitive_route(governor, (
            offer(CognitiveActionKind.GENERATE, 9),
            offer(CognitiveActionKind.VERIFY, 9),
        ))
        self.assertEqual(plan.kind, CognitiveRouteKind.DIRECT)
        worker = CountingWorker()
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, worker, lambda c: QualityVector((1, 1)),
            baseline_quality=QualityVector((0, 0)), route_plan=plan,
            direct_answer=lambda snap: CandidateDraft("direct", "direct answer"),
        )
        self.assertEqual(worker.generate_calls, 0)
        self.assertEqual(worker.challenge_calls, 0)
        self.assertEqual(result.selected.id, "direct")
        self.assertEqual(result.cost.worker_direct_calls, 1)

    def test_mandatory_downstream_without_prerequisite_blocks_route(self):
        governor = EconomyGovernor(budget=ResourceVector(tokens=100, steps=10))
        plan = plan_cognitive_route(governor, (
            offer(CognitiveActionKind.GENERATE, 9),
            offer(CognitiveActionKind.CHALLENGE, 12, mandatory=True),
        ))
        self.assertTrue(plan.blocked)

    def test_empty_worker_stops_explicitly(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, EmptyWorker(), lambda c: QualityVector((0, 0)),
            baseline_quality=QualityVector((0, 0)),
        )
        self.assertIsNone(result.selected)
        self.assertEqual(rt.stop_reason, StopReason.NO_NEW_CANDIDATE)

    def test_baseline_non_regression_blocks_lexicographic_failure(self):
        rt = Runtime(demo_snapshot(), 20)
        scores = {"A": QualityVector((11, 0)), "B": QualityVector((10, 11))}
        result = run_worker_cycle(
            rt, TradeoffWorker(), lambda c: scores[c.id],
            baseline_quality=QualityVector((10, 10)),
        )
        self.assertEqual([x.candidate.id for x in result.admissible], ["B"])
        self.assertEqual(result.selected.id, "B")
        self.assertEqual(result.quality.values, (10, 11))

    def test_unresolved_pareto_tradeoff_not_silently_scalarized(self):
        rt = Runtime(demo_snapshot(), 20)
        scores = {"A": QualityVector((11, 10)), "B": QualityVector((10, 11))}
        result = run_worker_cycle(
            rt, TradeoffWorker(), lambda c: scores[c.id],
            baseline_quality=QualityVector((10, 10)),
        )
        self.assertIsNone(result.selected)
        self.assertEqual(rt.stop_reason, StopReason.UNRESOLVED_TRADEOFF)
        self.assertEqual({x.candidate.id for x in result.pareto_front}, {"A", "B"})

    def test_quality_dimension_failure_totalized(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, TradeoffWorker(), lambda c: QualityVector((1,)),
            baseline_quality=QualityVector((0, 0)),
        )
        self.assertEqual(rt.stop_reason, StopReason.EVALUATOR_FAILURE)
        self.assertEqual(result.failure, "evaluation/selection failed")

    def test_selection_policy_failure_totalized(self):
        rt = Runtime(demo_snapshot(), 20)
        scores = {"A": QualityVector((11, 10)), "B": QualityVector((10, 11))}
        result = run_worker_cycle(
            rt, TradeoffWorker(), lambda c: scores[c.id],
            baseline_quality=QualityVector((10, 10)),
            selection_policy=lambda front: (_ for _ in ()).throw(RuntimeError("bad policy")),
        )
        self.assertEqual(rt.stop_reason, StopReason.EVALUATOR_FAILURE)
        self.assertEqual(result.failure, "evaluation/selection failed")

    def test_worker_exception_totalized_as_explicit_result(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, FailingWorker(), lambda c: QualityVector((0, 0)),
            baseline_quality=QualityVector((0, 0)),
        )
        self.assertEqual(rt.status, RuntimeStatus.INVALIDATED)
        self.assertEqual(rt.stop_reason, StopReason.WORKER_FAILURE)
        self.assertEqual(result.failure, "worker.generate failed")

    def test_repair_failure_totalized(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, RepairFailWorker(), lambda c: QualityVector((1, 1)),
            baseline_quality=QualityVector((0, 0)), repair=True,
        )
        self.assertEqual(rt.status, RuntimeStatus.INVALIDATED)
        self.assertEqual(rt.stop_reason, StopReason.WORKER_FAILURE)
        self.assertEqual(result.failure, "worker.repair failed")

    def test_evaluator_failure_labeled_correctly(self):
        rt = Runtime(demo_snapshot(), 20)
        result = run_worker_cycle(
            rt, TradeoffWorker(),
            lambda c: (_ for _ in ()).throw(RuntimeError("eval boom")),
            baseline_quality=QualityVector((0, 0)),
        )
        self.assertEqual(rt.status, RuntimeStatus.INVALIDATED)
        self.assertEqual(rt.stop_reason, StopReason.EVALUATOR_FAILURE)
        self.assertEqual(result.failure, "evaluator failed")


if __name__ == "__main__":
    unittest.main()
