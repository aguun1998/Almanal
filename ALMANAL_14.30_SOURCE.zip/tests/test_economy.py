import unittest
from fractions import Fraction

from almanal_runtime.errors import AlmanalError
from almanal_runtime.economy import (
    CognitiveActionKind, EconomyDecision, RiskRule,
    ResourceVector, UtilityEstimate, CognitiveOffer, EconomyPolicy,
    gate_cognitive_action, LifecycleImprovement,
    decide_lifecycle_improvement, TokenInvestment,
    exact_myopic_voc_from_outcomes,
    MetaTransition, MetaAction, FiniteMetaProblem,
    solve_finite_horizon_metareasoning, EconomyGovernor,
)


class CognitiveEconomyTests(unittest.TestCase):
    def offer(
        self,
        *,
        current=10,
        lower=10,
        expected=12,
        upper=14,
        cost=1,
        resources=ResourceVector(tokens=10, steps=1),
        mandatory=False,
        evidence="estimate",
    ):
        return CognitiveOffer(
            action_id="a",
            kind=CognitiveActionKind.CHALLENGE,
            current_stop_utility=Fraction(current),
            post_action_stop_utility=UtilityEstimate(
                Fraction(lower), Fraction(expected), Fraction(upper)
            ),
            decision_cost_utility=Fraction(cost),
            resources=resources,
            mandatory=mandatory,
            evidence_ref=evidence,
        )

    def test_positive_expected_voc_executes(self):
        result = gate_cognitive_action(
            self.offer(),
            remaining=ResourceVector(tokens=100, steps=10),
        )
        self.assertEqual(result.decision, EconomyDecision.EXECUTE)
        self.assertEqual(result.score, Fraction(1))

    def test_stop_wins_zero_or_negative_voc(self):
        result = gate_cognitive_action(
            self.offer(expected=11, cost=1),
            remaining=ResourceVector(tokens=100, steps=10),
        )
        self.assertEqual(
            result.decision, EconomyDecision.SKIP_NONPOSITIVE_VOC
        )

    def test_lower_bound_policy_can_reject_positive_expected_value(self):
        offer = self.offer(lower=9, expected=13, upper=18, cost=1)
        result = gate_cognitive_action(
            offer,
            remaining=ResourceVector(tokens=100, steps=10),
            policy=EconomyPolicy(risk_rule=RiskRule.LOWER_BOUND),
        )
        self.assertEqual(
            result.decision, EconomyDecision.SKIP_NONPOSITIVE_VOC
        )

    def test_mandatory_floor_executes_even_with_negative_voc(self):
        result = gate_cognitive_action(
            self.offer(lower=4, expected=5, upper=6, cost=10, mandatory=True),
            remaining=ResourceVector(tokens=100, steps=10),
        )
        self.assertEqual(result.decision, EconomyDecision.MANDATORY_EXECUTE)

    def test_mandatory_floor_blocks_if_hard_budget_insufficient(self):
        result = gate_cognitive_action(
            self.offer(mandatory=True),
            remaining=ResourceVector(tokens=9, steps=10),
        )
        self.assertEqual(
            result.decision, EconomyDecision.BLOCKED_MANDATORY_BUDGET
        )

    def test_resource_dimensions_are_not_scalarized(self):
        offer = self.offer(
            resources=ResourceVector(tokens=1, tool_calls=1, steps=1),
        )
        result = gate_cognitive_action(
            offer,
            remaining=ResourceVector(tokens=10_000, tool_calls=0, steps=10),
        )
        self.assertEqual(result.decision, EconomyDecision.SKIP_BUDGET)

    def test_optional_evidence_requirement(self):
        result = gate_cognitive_action(
            self.offer(evidence=""),
            remaining=ResourceVector(tokens=100, steps=10),
            policy=EconomyPolicy(require_evidence_for_optional=True),
        )
        self.assertEqual(
            result.decision, EconomyDecision.SKIP_INSUFFICIENT_MARGIN
        )

    def test_exact_myopic_voc(self):
        voc = exact_myopic_voc_from_outcomes(
            current_stop_utility=Fraction(10),
            outcome_probabilities_and_stop_utilities=(
                (Fraction(1, 2), Fraction(15)),
                (Fraction(1, 2), Fraction(9)),
            ),
            decision_cost_utility=Fraction(1),
        )
        self.assertEqual(voc, Fraction(1))

    def test_exact_voc_rejects_bad_probability_mass(self):
        with self.assertRaises(AlmanalError):
            exact_myopic_voc_from_outcomes(
                current_stop_utility=Fraction(0),
                outcome_probabilities_and_stop_utilities=(
                    (Fraction(1, 3), Fraction(1)),
                ),
                decision_cost_utility=Fraction(0),
            )

    def test_lifecycle_improvement_can_be_possible_but_not_worth_doing(self):
        proposal = LifecycleImprovement(
            improvement_id="cosmetic-formalism",
            one_time_decision_cost_utility=Fraction(100),
            per_use_utility_gain=UtilityEstimate(
                Fraction(0), Fraction(1), Fraction(2)
            ),
            per_use_decision_cost_utility=Fraction(0),
            discounted_expected_uses=Fraction(20),
        )
        decision = decide_lifecycle_improvement(proposal)
        self.assertFalse(decision.execute)
        self.assertEqual(decision.npv, Fraction(-80))

    def test_lifecycle_improvement_becomes_worthwhile_with_exposure(self):
        proposal = LifecycleImprovement(
            improvement_id="portable-compression",
            one_time_decision_cost_utility=Fraction(100),
            per_use_utility_gain=UtilityEstimate(
                Fraction(2), Fraction(3), Fraction(4)
            ),
            per_use_decision_cost_utility=Fraction(1),
            discounted_expected_uses=Fraction(100),
        )
        decision = decide_lifecycle_improvement(proposal)
        self.assertTrue(decision.execute)
        self.assertEqual(decision.npv, Fraction(100))

    def test_token_break_even_is_separate_exact_accounting(self):
        investment = TokenInvestment(
            one_time_tokens=10_000,
            per_use_tokens_saved=200,
        )
        self.assertEqual(investment.break_even_uses(), 50)

    def test_zero_savings_never_break_even_if_investment_positive(self):
        self.assertIsNone(TokenInvestment(1, 0).break_even_uses())

    def test_bellman_solver_prefers_stop_when_computation_not_worth_it(self):
        problem = FiniteMetaProblem(
            stop_utilities=(("s", Fraction(10)),),
            actions=(
                MetaAction(
                    "think",
                    "s",
                    Fraction(2),
                    (MetaTransition(Fraction(1), "s"),),
                ),
            ),
        )
        sol = solve_finite_horizon_metareasoning(problem, horizon=3)
        self.assertEqual(dict(sol.policy)["s"], "STOP")
        self.assertEqual(dict(sol.values)["s"], Fraction(10))

    def test_bellman_solver_uses_information_when_worth_it(self):
        problem = FiniteMetaProblem(
            stop_utilities=(
                ("uncertain", Fraction(5)),
                ("resolved", Fraction(10)),
            ),
            actions=(
                MetaAction(
                    "inspect",
                    "uncertain",
                    Fraction(1),
                    (MetaTransition(Fraction(1), "resolved"),),
                ),
            ),
        )
        sol = solve_finite_horizon_metareasoning(problem, horizon=1)
        self.assertEqual(dict(sol.policy)["uncertain"], "inspect")
        self.assertEqual(dict(sol.values)["uncertain"], Fraction(9))

    def test_exact_tie_prefers_stop(self):
        problem = FiniteMetaProblem(
            stop_utilities=(
                ("a", Fraction(5)),
                ("b", Fraction(6)),
            ),
            actions=(
                MetaAction(
                    "compute",
                    "a",
                    Fraction(1),
                    (MetaTransition(Fraction(1), "b"),),
                ),
            ),
        )
        sol = solve_finite_horizon_metareasoning(problem, horizon=1)
        self.assertEqual(dict(sol.values)["a"], Fraction(5))
        self.assertEqual(dict(sol.policy)["a"], "STOP")

    def test_governor_records_cost_decisions_without_recursive_deliberation(self):
        gov = EconomyGovernor(
            budget=ResourceVector(tokens=100, steps=10)
        )
        first = gov.consider(self.offer())
        second = gov.consider(
            self.offer(expected=10, cost=1)
        )
        self.assertEqual(first.decision, EconomyDecision.EXECUTE)
        self.assertEqual(second.decision, EconomyDecision.SKIP_NONPOSITIVE_VOC)
        self.assertEqual(len(gov.records()), 2)
        self.assertEqual(gov.remaining.tokens, 90)


    def test_bellman_respects_componentwise_resource_budget(self):
        problem = FiniteMetaProblem(
            stop_utilities=(
                ("a", Fraction(5)),
                ("b", Fraction(10)),
            ),
            actions=(
                MetaAction(
                    "tool-inspect",
                    "a",
                    Fraction(1),
                    (MetaTransition(Fraction(1), "b"),),
                    resources=ResourceVector(tool_calls=1),
                ),
            ),
        )
        no_tool = solve_finite_horizon_metareasoning(
            problem,
            horizon=1,
            budget=ResourceVector(tool_calls=0),
        )
        one_tool = solve_finite_horizon_metareasoning(
            problem,
            horizon=1,
            budget=ResourceVector(tool_calls=1),
        )
        self.assertEqual(dict(no_tool.policy)["a"], "STOP")
        self.assertEqual(dict(one_tool.policy)["a"], "tool-inspect")

    def test_negative_execution_margin_rejected(self):
        with self.assertRaises(AlmanalError):
            EconomyPolicy(minimum_voc_margin=Fraction(-1))



if __name__ == "__main__":
    unittest.main()
