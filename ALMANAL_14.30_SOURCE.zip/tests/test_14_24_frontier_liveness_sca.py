import subprocess, sys, unittest
from pathlib import Path

from almanal_runtime.improvement import (
    ImprovementProgressPolicy, ImprovementProgressState,
    ProgressGuardDecision, guard_improvement_progress,
)

ROOT=Path(__file__).resolve().parents[1]
SPEC=ROOT/'spec'

class FrontierLivenessSCATests(unittest.TestCase):
    def test_frontier_stall_stops_even_when_activity_continues(self):
        state=ImprovementProgressState('e', step_index=7, last_progress_step=7,
                                      last_frontier_progress_step=4,
                                      progress_refs=('tool:latest',))
        plan=guard_improvement_progress(state, ImprovementProgressPolicy(
            max_no_progress_steps=3, max_no_frontier_progress_steps=3, max_epoch_steps=12))
        self.assertIs(plan.decision, ProgressGuardDecision.CHECKPOINT_STOP)
        self.assertIn('frontier', plan.reason)

    def test_legacy_state_defaults_frontier_to_activity(self):
        state=ImprovementProgressState('e',2,2,('decision:x',))
        self.assertIs(guard_improvement_progress(state).decision, ProgressGuardDecision.CONTINUE)

    def test_cold_economy_helpers_are_lazy_on_worker_path(self):
        code=("import sys,almanal_runtime; _=almanal_runtime.run_worker_cycle; "
              "print(int('almanal_runtime.economy' in sys.modules),"
              "int('almanal_runtime.economy_cold' in sys.modules))")
        out=subprocess.check_output([sys.executable,'-S','-c',code],cwd=ROOT,
                                    env={'PYTHONPATH':str(ROOT)},text=True,timeout=30).strip()
        self.assertEqual(out,'1 0')

    def test_cold_public_surface_still_loads(self):
        code=("import sys; from almanal_runtime.economy import MetaAction,FormalObjectProfile; "
              "print(MetaAction.__name__,FormalObjectProfile.__name__,"
              "int('almanal_runtime.economy_cold' in sys.modules))")
        out=subprocess.check_output([sys.executable,'-S','-c',code],cwd=ROOT,
                                    env={'PYTHONPATH':str(ROOT)},text=True,timeout=30).strip()
        self.assertEqual(out,'MetaAction FormalObjectProfile 1')

    def test_contract_exposes_frontier_and_mechanism_guards(self):
        text=(SPEC/'ALMANAL.md').read_text()
        self.assertIn('"decision_frontier_progress_lease": true',text)
        self.assertIn('"mechanism_before_benchmark": true',text)
        self.assertIn('"hot_residency_sca": true',text)

if __name__=='__main__': unittest.main()
