import unittest
from pathlib import Path

from almanal_runtime.consolidation import StructuralComplexityFootprint
from almanal_runtime.evaluator import AnalyticCostVector
from almanal_runtime.prompting import default_library_capsules

ROOT=Path(__file__).resolve().parents[1]
SPEC=ROOT/'spec'

class PracticalPareto1425Tests(unittest.TestCase):
    def test_structural_work_is_real_cost_not_fake_time(self):
        base=AnalyticCostVector((100,4096,700))
        cand=AnalyticCostVector((80,4096,700))
        self.assertTrue(cand.strictly_dominates(base))
        self.assertFalse(base.strictly_dominates(cand))

    def test_sca_footprint_has_practical_execution_axes(self):
        f=StructuralComplexityFootprint(execution_work_units=9,peak_live_memory_bytes=10,artifact_bytes=11)
        self.assertEqual(f.key()[-3:],(9,10,11))
        self.assertIn(('artifact_bytes',-1),StructuralComplexityFootprint(artifact_bytes=10).changed_coordinates_from(f))

    def test_compact_contract_separates_time_and_work(self):
        t=(SPEC/'ALMANAL.md').read_text()
        for s in ('ExactWallTime != StructuralWork','StructuralWorkDown != ExactMillisecondsDown',
                  'PARETO CORE: runtime-work + peak-live-memory + source/code-bytes + produced-artifact-bytes',
                  'Deterministic/analytic feedback runs **before** empirical feedback'):
            self.assertIn(s,t)
        self.assertIn('"practical_code_pareto_default": true',t)
        self.assertIn('"structural_runtime_evidence": true',t)
        self.assertIn('"sca_runtime_memory_artifact_axes": true',t)

    def test_planning_capsule_carries_practical_default(self):
        p=next(x for x in default_library_capsules() if x.capsule_id=='PLANNING')
        self.assertIn('runtime/structural work',p.body)
        self.assertIn('Exact/proved work counts',p.body)
        self.assertIn('Benchmark only residual',p.body)

if __name__=='__main__': unittest.main()
