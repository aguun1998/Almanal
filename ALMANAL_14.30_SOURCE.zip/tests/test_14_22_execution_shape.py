import unittest
from pathlib import Path

from almanal_runtime.prompting import default_library_capsules

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "spec"


class PortableExecutionShapeClosureTests(unittest.TestCase):
    def test_planning_capsule_checks_portable_execution_shape(self):
        planning = next(c for c in default_library_capsules() if c.capsule_id == "PLANNING")
        body = planning.body.lower()
        for phrase in ("single-pass/streaming", "in-place", "buffer lifetimes", "locality/batchability", "structure before microarchitecture"):
            self.assertIn(phrase, body)

    def test_specialization_is_gated_not_resident_default(self):
        planning = next(c for c in default_library_capsules() if c.capsule_id == "PLANNING")
        body = " ".join(planning.body.lower().split())
        self.assertIn("not resident defaults", body)
        self.assertIn("explicit high-performance admission", body)
        self.assertIn("portability/complexity rent", body)

    def test_active_core_contains_specialization_rent_invariant(self):
        core = (SPEC / "ACTIVE_CORE.md").read_text(encoding="utf-8")
        self.assertIn("I-SPECIALIZATION-RENT", core)
        self.assertIn("Vectorizable != MustVectorize", core)
        self.assertIn("PotentiallyFaster != MeasuredFaster", core)

    def test_portable_contract_exposes_execution_shape_closure(self):
        portable = (SPEC / "ALMANAL.md").read_text(encoding="utf-8")
        self.assertIn('"portable_execution_shape_closure": true', portable)
        self.assertIn("# 6.3 PORTABLE EXECUTION-SHAPE CLOSURE", portable)


if __name__ == "__main__":
    unittest.main()
