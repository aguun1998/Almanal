import unittest

from almanal_runtime.consolidation import (
    ConsolidationOperation, ConsolidationDecision, ConsolidationEquivalence, ConsolidationAuditClass,
    StructuralComplexityFootprint, StructuralConsolidationCandidate,
    ConsolidationApplyBinding, ConsolidationApplyOutcome,
    assess_structural_consolidation, audit_structural_consolidation, execute_structural_consolidation_audit,
)


class StructuralConsolidationAuditTests(unittest.TestCase):
    def fp(self, **kw):
        base = dict(
            active_context_chars=1000, source_chars=2000, module_count=2,
            type_count=5, decision_branch_count=8, dependency_edge_count=7,
            persistent_artifact_count=2, maintenance_surface_count=10,
        )
        base.update(kw)
        return StructuralComplexityFootprint(**base)

    def test_delete_obsolete_leaf_is_safe_pareto_reduction(self):
        c = StructuralConsolidationCandidate(
            target_ref="obsolete-adapter", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e:scoped",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                                            type_count=0, decision_branch_count=0, dependency_edge_count=0,
                                            persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.decision, ConsolidationDecision.AUTO_APPLY)
        self.assertEqual(a.audit_class, ConsolidationAuditClass.PASSIVE)
        self.assertTrue(a.auto_apply_eligible)

    def test_unique_capability_blocks_delete(self):
        c = StructuralConsolidationCandidate(
            target_ref="unique", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e:scoped",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0),
            unique_capabilities=frozenset({"CAP"}),
            obsolete_or_unreachable=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.decision, ConsolidationDecision.BLOCKED)
        self.assertIn("unique capabilities", a.reason)

    def test_protected_role_must_survive_replacement(self):
        c = StructuralConsolidationCandidate(
            target_ref="guard", operation=ConsolidationOperation.GENERALIZE_REPLACE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=700, source_chars=1700),
            unique_capabilities=frozenset({"VERIFY"}),
            protected_roles=frozenset({"NO_PROMOTION"}), replacement_ref="generic-verify",
            replacement_capabilities=frozenset({"VERIFY"}),
            equivalence=ConsolidationEquivalence.DERIVABLE,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)

    def test_merge_requires_semantic_and_authority_compatibility(self):
        c = StructuralConsolidationCandidate(
            target_ref="moral-policy", operation=ConsolidationOperation.MERGE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=800, source_chars=1800),
            replacement_ref="generic-policy", equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
            semantic_boundary_compatible=False,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)

    def test_compile_away_rejects_real_runtime_state(self):
        c = StructuralConsolidationCandidate(
            target_ref="stateful-organ", operation=ConsolidationOperation.COMPILE_AWAY,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=500, source_chars=1500),
            replacement_ref="static-guard", equivalence=ConsolidationEquivalence.FORMALLY_PROVED,
            runtime_state_required=True, static_invariant_equivalent=True,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)

    def test_compile_away_static_guard_is_admissible(self):
        c = StructuralConsolidationCandidate(
            target_ref="repeated-meta-check", operation=ConsolidationOperation.COMPILE_AWAY,
            evidence_refs=("e:scoped",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=400, source_chars=1600,
                                            decision_branch_count=4, dependency_edge_count=4),
            replacement_ref="type-invariant", equivalence=ConsolidationEquivalence.FORMALLY_PROVED,
            static_invariant_equivalent=True, private_or_leaf=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.decision, ConsolidationDecision.AUTO_APPLY)
        self.assertIn("STATIC_INVARIANT_EQUIVALENCE_CHECK", a.required_verification)

    def test_move_cold_only_for_audit_or_proof_material(self):
        bad = StructuralConsolidationCandidate(
            target_ref="live-runtime", operation=ConsolidationOperation.MOVE_COLD,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0),
            runtime_state_required=False, proof_or_audit_only=False,
        )
        self.assertEqual(assess_structural_consolidation(bad).decision, ConsolidationDecision.BLOCKED)
        good = StructuralConsolidationCandidate(
            target_ref="historical-proof", operation=ConsolidationOperation.MOVE_COLD,
            evidence_refs=("e:scoped",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0),
            proof_or_audit_only=True,
        )
        self.assertEqual(assess_structural_consolidation(good).decision, ConsolidationDecision.AUTO_APPLY)

    def test_mixed_complexity_delta_is_unresolved_not_scalarized(self):
        c = StructuralConsolidationCandidate(
            target_ref="mixed", operation=ConsolidationOperation.MERGE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=700, source_chars=2400),
            replacement_ref="merged", equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.decision, ConsolidationDecision.UNRESOLVED_TRADEOFF)
        self.assertFalse(a.trial_eligible)

    def test_high_impact_candidate_requires_targeted_ablation(self):
        c = StructuralConsolidationCandidate(
            target_ref="shared-generic", operation=ConsolidationOperation.GENERALIZE_REPLACE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=700, source_chars=1700),
            replacement_ref="generic", equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
            high_impact_or_shared=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.decision, ConsolidationDecision.PROPOSE_TRIAL)
        self.assertIn("TARGETED_ABLATION_OR_INTERVENTION", a.required_verification)

    def test_destructive_change_without_evidence_provenance_is_blocked(self):
        c = StructuralConsolidationCandidate(
            target_ref="no-evidence", operation=ConsolidationOperation.DELETE,
            before=self.fp(), after=self.fp(active_context_chars=0),
            rollback_ref="rb", audit_history_ref="audit", obsolete_or_unreachable=True,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)

    def test_reverse_dependency_scope_cannot_be_omitted(self):
        c = StructuralConsolidationCandidate(
            target_ref="shared", operation=ConsolidationOperation.GENERALIZE_REPLACE,
            evidence_refs=("e",), rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=500, source_chars=1500),
            replacement_ref="generic", equivalence=ConsolidationEquivalence.DERIVABLE,
            reverse_dependency_refs=("dep-a",), footprint_includes_reverse_dependency_closure=False,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)

    def test_batch_audit_separates_apply_tradeoff_and_blocked(self):
        apply = StructuralConsolidationCandidate(
            target_ref="a", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e:scoped",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                                            type_count=0, decision_branch_count=0, dependency_edge_count=0,
                                            persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        trade = StructuralConsolidationCandidate(
            target_ref="b", operation=ConsolidationOperation.MERGE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=500, source_chars=2500),
            replacement_ref="x", equivalence=ConsolidationEquivalence.DERIVABLE,
        )
        blocked = StructuralConsolidationCandidate(
            target_ref="c", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e:scoped",), rollback_ref="rb:1", audit_history_ref="audit:1",
            before=self.fp(), after=self.fp(active_context_chars=0),
        )
        r = audit_structural_consolidation((apply, trade, blocked))
        self.assertEqual(len(r.passive_auto_apply), 1)
        self.assertEqual(len(r.trial_candidates), 0)
        self.assertEqual(len(r.unresolved), 1)
        self.assertEqual(len(r.blocked), 1)

    def test_move_warm_can_be_passive_even_for_shared_facade_when_residency_only(self):
        c = StructuralConsolidationCandidate(
            target_ref="package-facade", operation=ConsolidationOperation.MOVE_WARM,
            evidence_refs=("e:api-parity", "e:regression"), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(active_context_chars=1000, dependency_edge_count=20),
            after=self.fp(active_context_chars=100, dependency_edge_count=5),
            unique_capabilities=frozenset({"PUBLIC_API"}),
            equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
            load_on_demand_supported=True, residency_semantics_preserved=True,
            interface_compatibility_verified=True, residency_only_change=True,
            high_impact_or_shared=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.audit_class, ConsolidationAuditClass.PASSIVE)
        self.assertEqual(a.decision, ConsolidationDecision.AUTO_APPLY)

    def test_generalize_replace_remains_active_even_when_pareto(self):
        c = StructuralConsolidationCandidate(
            target_ref="specialized-policy", operation=ConsolidationOperation.GENERALIZE_REPLACE,
            evidence_refs=("e",), rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=700, source_chars=1600),
            replacement_ref="generic-policy", equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.audit_class, ConsolidationAuditClass.ACTIVE)
        self.assertEqual(a.decision, ConsolidationDecision.PROPOSE_TRIAL)

    def test_passive_execution_auto_applies_and_active_never_does(self):
        state = {"passive": False, "active": False}
        passive = StructuralConsolidationCandidate(
            target_ref="leaf", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                type_count=0, decision_branch_count=0, dependency_edge_count=0, persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        active = StructuralConsolidationCandidate(
            target_ref="general", operation=ConsolidationOperation.GENERALIZE_REPLACE,
            evidence_refs=("e2",), rollback_ref="rb2", audit_history_ref="audit2",
            before=self.fp(), after=self.fp(active_context_chars=800, source_chars=1800),
            replacement_ref="g", equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
        )
        bindings = (
            ConsolidationApplyBinding("leaf", ConsolidationOperation.DELETE,
                lambda: state.__setitem__("passive", True), lambda: state["passive"], lambda: state.__setitem__("passive", False),
                measurement_contract_ref="m:struct", measure_after=lambda: passive.after),
            ConsolidationApplyBinding("general", ConsolidationOperation.GENERALIZE_REPLACE,
                lambda: state.__setitem__("active", True), lambda: True, lambda: state.__setitem__("active", False),
                measurement_contract_ref="m:struct", measure_after=lambda: active.after),
        )
        r = execute_structural_consolidation_audit((passive, active), bindings)
        self.assertTrue(state["passive"])
        self.assertFalse(state["active"])
        by_target = {x.target_ref: x for x in r.applications}
        self.assertEqual(by_target["leaf"].outcome, ConsolidationApplyOutcome.AUTO_APPLIED)
        self.assertEqual(by_target["general"].outcome, ConsolidationApplyOutcome.REVIEW_REQUIRED)

    def test_failed_passive_verification_rolls_back(self):
        state = {"x": False}
        c = StructuralConsolidationCandidate(
            target_ref="leaf2", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e",), measurement_contract_ref="m:struct", before_measurement_ref="m:before", rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                type_count=0, decision_branch_count=0, dependency_edge_count=0, persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        b = ConsolidationApplyBinding("leaf2", ConsolidationOperation.DELETE,
            lambda: state.__setitem__("x", True), lambda: False, lambda: state.__setitem__("x", False),
            measurement_contract_ref="m:struct", measure_after=lambda: c.after)
        r = execute_structural_consolidation_audit((c,), (b,))
        self.assertFalse(state["x"])
        self.assertEqual(r.applications[0].outcome, ConsolidationApplyOutcome.ROLLED_BACK)

    def test_passive_lane_requires_measurement_provenance(self):
        c = StructuralConsolidationCandidate(
            target_ref="unmeasured-leaf", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e",), rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                type_count=0, decision_branch_count=0, dependency_edge_count=0, persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        a = assess_structural_consolidation(c)
        self.assertEqual(a.audit_class, ConsolidationAuditClass.ACTIVE)
        self.assertEqual(a.decision, ConsolidationDecision.PROPOSE_TRIAL)

    def test_passive_measurement_mismatch_rolls_back(self):
        state = {"x": False}
        c = StructuralConsolidationCandidate(
            target_ref="leaf3", operation=ConsolidationOperation.DELETE,
            evidence_refs=("e",), measurement_contract_ref="m:struct", before_measurement_ref="m:before",
            rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=0, source_chars=0, module_count=0,
                type_count=0, decision_branch_count=0, dependency_edge_count=0, persistent_artifact_count=1, maintenance_surface_count=2),
            obsolete_or_unreachable=True, private_or_leaf=True,
        )
        wrong_after = self.fp(active_context_chars=1, source_chars=0, module_count=0,
            type_count=0, decision_branch_count=0, dependency_edge_count=0, persistent_artifact_count=1, maintenance_surface_count=2)
        b = ConsolidationApplyBinding(
            "leaf3", ConsolidationOperation.DELETE,
            lambda: state.__setitem__("x", True), lambda: True, lambda: state.__setitem__("x", False),
            measurement_contract_ref="m:struct", measure_after=lambda: wrong_after,
        )
        r = execute_structural_consolidation_audit((c,), (b,))
        self.assertFalse(state["x"])
        self.assertEqual(r.applications[0].outcome, ConsolidationApplyOutcome.ROLLED_BACK)

    def test_move_warm_without_interface_parity_is_blocked(self):
        c = StructuralConsolidationCandidate(
            target_ref="facade-risk", operation=ConsolidationOperation.MOVE_WARM,
            evidence_refs=("e",), measurement_contract_ref="m", before_measurement_ref="b",
            rollback_ref="rb", audit_history_ref="audit",
            before=self.fp(), after=self.fp(active_context_chars=100),
            equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
            load_on_demand_supported=True, residency_semantics_preserved=True,
            interface_compatibility_verified=False, residency_only_change=True,
        )
        self.assertEqual(assess_structural_consolidation(c).decision, ConsolidationDecision.BLOCKED)


if __name__ == "__main__":
    unittest.main()
