import unittest

from almanal_runtime.errors import AlmanalError
from almanal_runtime.portable import (
    ALMANAL_RUNTIME_PROTOCOL,
    Capability, Availability, Enforcement, WitnessBasis, BackendProfile,
    BootstrapStatus, ValidationGrade, CapabilityRecord, CapabilityManifest,
    bootstrap_portable, validate_binding_claims, compact_runtime_card,
)


def rec(cap, *, available=True, enforcement=Enforcement.INTERNAL,
        basis=WitnessBasis.SELF_DECLARED, ref="host", protocols=()):
    return CapabilityRecord(
        capability=cap,
        availability=Availability.AVAILABLE if available else Availability.UNAVAILABLE,
        enforcement=enforcement,
        witness_basis=basis,
        witness_ref=ref,
        protocols=tuple(protocols),
    )


def host_witness(record):
    return record.witness_ref == "host" and record.claims_strong_witness


def minimum_manifest(extra=()):
    return CapabilityManifest(
        "generic-host",
        (
            rec(Capability.REASON),
            rec(Capability.CONTEXT_STATE),
            rec(Capability.STRUCTURED_OUTPUT),
            *extra,
        ),
    )


class PortableBootstrapTests(unittest.TestCase):
    def test_minimum_generic_host_boots_native(self):
        result = bootstrap_portable(minimum_manifest())
        self.assertEqual(result.profile, BackendProfile.NATIVE)
        self.assertEqual(result.status, BootstrapStatus.DEGRADED)
        self.assertFalse(result.can_claim_external_enforcement)
        self.assertIn("VALIDATE_EPISTEMIC_CLAIM", {b.operator for b in result.bindings})

    def test_unknown_minimum_capability_blocks(self):
        manifest = CapabilityManifest(
            "host",
            (
                rec(Capability.REASON),
                CapabilityRecord(
                    Capability.CONTEXT_STATE,
                    Availability.UNKNOWN,
                    Enforcement.INTERNAL,
                    WitnessBasis.SELF_DECLARED,
                    "unknown",
                ),
                rec(Capability.STRUCTURED_OUTPUT),
            ),
        )
        result = bootstrap_portable(manifest)
        self.assertEqual(result.status, BootstrapStatus.BLOCKED)
        self.assertIn(Capability.CONTEXT_STATE, result.missing_required_capabilities)

    def test_tools_upgrade_to_tool_augmented(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.RETRIEVAL,
                    enforcement=Enforcement.TOOL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                ),
                rec(
                    Capability.CODE_EXECUTION,
                    enforcement=Enforcement.TOOL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                ),
            )), capability_witness_validator=host_witness
        )
        self.assertEqual(result.profile, BackendProfile.TOOL_AUGMENTED)
        ops = {b.operator for b in result.bindings}
        self.assertIn("RETRIEVE_EVIDENCE", ops)
        self.assertIn("EXECUTE_COMPUTATION", ops)

    def test_external_runtime_upgrades_reference_exec(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_RUNTIME,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                    protocols=(ALMANAL_RUNTIME_PROTOCOL,),
                ),
            )), capability_witness_validator=host_witness
        )
        self.assertEqual(result.profile, BackendProfile.REFERENCE_EXEC)
        self.assertTrue(result.can_claim_external_enforcement)

    def test_process_isolation_upgrades_hardened(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_RUNTIME,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                    protocols=(ALMANAL_RUNTIME_PROTOCOL,),
                ),
                rec(Capability.PROCESS_ISOLATION, enforcement=Enforcement.HARDENED,
                    basis=WitnessBasis.OBSERVED_INTERFACE),
            )), capability_witness_validator=host_witness
        )
        self.assertEqual(result.profile, BackendProfile.HARDENED)

    def test_same_host_challenge_is_not_independent(self):
        result = bootstrap_portable(minimum_manifest())
        challenge = next(b for b in result.bindings if b.operator == "CHALLENGE_CANDIDATE")
        self.assertFalse(challenge.external_independence)
        with self.assertRaises(AlmanalError):
            validate_binding_claims(
                result,
                claims_external_enforcement=False,
                claims_independent_verification=True,
            )

    def test_external_verifier_allows_independent_claim(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(Capability.EXTERNAL_VERIFICATION,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.EXTERNAL_ATTESTATION),
            )), capability_witness_validator=host_witness
        )
        self.assertTrue(result.can_claim_independent_verification)
        validate_binding_claims(
            result,
            claims_external_enforcement=False,
            claims_independent_verification=True,
        )

    def test_runtime_card_is_small_and_cot_free(self):
        card = compact_runtime_card(
            epoch_id="epoch-1",
            profile=BackendProfile.NATIVE,
            validation_grade=ValidationGrade.SELF_CHECKED,
            task_ref="task-hash",
            baseline_ref="baseline-hash",
            criterion_ref="criterion-hash",
            stage="CHALLENGE",
            steps_remaining=5,
            verification_status="CANARY_PENDING",
            status="RUNNING",
            mounted_capsules=("PLANNING",),
            residuals=("same-host challenge",),
        )
        self.assertEqual(card["stage"], "CHALLENGE")
        self.assertEqual(card["baseline_ref"], "baseline-hash")
        self.assertNotIn("reasoning", card)
        self.assertNotIn("chain_of_thought", card)


    def test_claimed_external_attestation_without_host_validator_cannot_upgrade(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(Capability.EXTERNAL_VERIFICATION, enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.EXTERNAL_ATTESTATION),
                rec(Capability.MACHINE_PROOF, enforcement=Enforcement.TOOL,
                    basis=WitnessBasis.EXECUTED),
            ))
        )
        self.assertFalse(result.can_claim_independent_verification)
        self.assertEqual(result.validation_ceiling, ValidationGrade.SELF_CHECKED)

    def test_self_declared_external_runtime_cannot_upgrade_profile(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_RUNTIME,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.SELF_DECLARED,
                    protocols=(ALMANAL_RUNTIME_PROTOCOL,),
                ),
            ))
        )
        self.assertNotEqual(result.profile, BackendProfile.REFERENCE_EXEC)
        self.assertFalse(result.can_claim_external_enforcement)

    def test_external_runtime_without_almanal_protocol_cannot_upgrade(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_RUNTIME,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                    protocols=("OTHER-RUNTIME/1",),
                ),
            )), capability_witness_validator=host_witness
        )
        self.assertNotEqual(result.profile, BackendProfile.REFERENCE_EXEC)
        self.assertFalse(result.can_claim_external_enforcement)

    def test_self_declared_external_verifier_cannot_claim_independence(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_VERIFICATION,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.SELF_DECLARED,
                ),
            ))
        )
        self.assertFalse(result.can_claim_independent_verification)

    def test_validation_grade_cannot_exceed_ceiling(self):
        result = bootstrap_portable(minimum_manifest())
        self.assertEqual(result.validation_ceiling, ValidationGrade.SELF_CHECKED)
        with self.assertRaises(AlmanalError):
            validate_binding_claims(
                result,
                claims_external_enforcement=False,
                claims_independent_verification=False,
                claimed_validation_grade=ValidationGrade.EXTERNAL_VERIFIED,
            )



    def test_self_declared_tool_does_not_upgrade_or_ground(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.CODE_EXECUTION,
                    enforcement=Enforcement.TOOL,
                    basis=WitnessBasis.SELF_DECLARED,
                ),
            ))
        )
        self.assertEqual(result.profile, BackendProfile.NATIVE)
        self.assertEqual(result.validation_ceiling, ValidationGrade.SELF_CHECKED)
        self.assertNotIn(
            "EXECUTE_COMPUTATION",
            {b.operator for b in result.bindings},
        )

    def test_internal_process_isolation_does_not_make_hardened(self):
        result = bootstrap_portable(
            minimum_manifest((
                rec(
                    Capability.EXTERNAL_RUNTIME,
                    enforcement=Enforcement.EXTERNAL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                    protocols=(ALMANAL_RUNTIME_PROTOCOL,),
                ),
                rec(
                    Capability.PROCESS_ISOLATION,
                    enforcement=Enforcement.INTERNAL,
                    basis=WitnessBasis.OBSERVED_INTERFACE,
                ),
            )), capability_witness_validator=host_witness
        )
        self.assertEqual(result.profile, BackendProfile.REFERENCE_EXEC)



    def test_native_profile_is_not_falsey(self):
        self.assertTrue(bool(BackendProfile.NATIVE))
        result = bootstrap_portable(minimum_manifest())
        self.assertIsNotNone(result.profile)
        self.assertEqual(result.profile.name, "NATIVE")



    def test_capability_equivalent_hosts_bind_identically(self):
        records = minimum_manifest((
            rec(
                Capability.RETRIEVAL,
                enforcement=Enforcement.TOOL,
                basis=WitnessBasis.OBSERVED_INTERFACE,
            ),
        )).records
        a = bootstrap_portable(CapabilityManifest("host-name-A", records), capability_witness_validator=host_witness)
        b = bootstrap_portable(CapabilityManifest("host-name-B", records), capability_witness_validator=host_witness)
        self.assertEqual(a.profile, b.profile)
        self.assertEqual(a.validation_ceiling, b.validation_ceiling)
        self.assertEqual(a.bindings, b.bindings)
        self.assertEqual(
            a.can_claim_external_enforcement,
            b.can_claim_external_enforcement,
        )



    def test_every_boot_binds_economy_gate(self):
        result = bootstrap_portable(minimum_manifest())
        self.assertIn("ECONOMY_GATE", {b.operator for b in result.bindings})



    def test_measurement_feedback_is_not_universal_boot_binding(self):
        result = bootstrap_portable(minimum_manifest())
        self.assertNotIn("MEASUREMENT_FEEDBACK", {b.operator for b in result.bindings})



if __name__ == "__main__":
    unittest.main()
