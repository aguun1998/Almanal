import ast
import importlib
import sys
import subprocess
import unittest
from pathlib import Path


class ResidencyTests(unittest.TestCase):
    def test_top_level_has_no_eager_measurement_imports_or_duplicate_modules(self):
        init_path = Path(__file__).resolve().parents[1] / "almanal_runtime" / "__init__.py"
        tree = ast.parse(init_path.read_text(encoding="utf-8"))
        modules = [
            n.module for n in tree.body
            if isinstance(n, ast.ImportFrom) and n.level == 1 and n.module
        ]
        self.assertNotIn("feedback", modules)
        self.assertNotIn("behavioral_benchmark", modules)
        self.assertNotIn("experiment", modules)
        self.assertNotIn("improvement", modules)
        self.assertNotIn("preference", modules)
        self.assertNotIn("truth", modules)
        self.assertEqual(len(modules), len(set(modules)))

    def test_lazy_top_level_measurement_api_still_works(self):
        import almanal_runtime
        cls = getattr(almanal_runtime, "MeasurementPlan")
        self.assertEqual(cls.__name__, "MeasurementPlan")
        self.assertIn("almanal_runtime.feedback", sys.modules)


    def test_measurement_lazy_load_does_not_mount_experiment(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.MeasurementPlan; "
            "print(int('almanal_runtime.feedback' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "1 0")

    def test_experiment_lazy_load_is_separate_warm_path(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.ExperimentSpec; "
            "print(int('almanal_runtime.feedback' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "1 1")


    def test_improvement_selector_is_separate_warm_path(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.select_evidence_path; "
            "print(int('almanal_runtime.improvement' in sys.modules), "
            "int('almanal_runtime.feedback' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "1 0 0")

    def test_structural_consolidation_audit_reuses_improvement_warm_path(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.audit_structural_consolidation; "
            "print(int('almanal_runtime.consolidation' in sys.modules), "
            "int('almanal_runtime.improvement' in sys.modules), "
            "int('almanal_runtime.feedback' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "1 0 0 0")
        self.assertIn("audit_structural_consolidation", dir(importlib.import_module("almanal_runtime")))

    def test_preference_query_does_not_mount_experiment(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.PreferenceBundle; "
            "print(int('almanal_runtime.preference' in sys.modules), "
            "int('almanal_runtime.feedback' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "1 0 0")


    def test_epistemic_validation_is_compiled_into_verification_not_truth_module(self):
        root = Path(__file__).resolve().parents[1]
        code = (
            "import sys, almanal_runtime; "
            "_ = almanal_runtime.validate_epistemic_claim; "
            "print(int('almanal_runtime.truth' in sys.modules), "
            "int('almanal_runtime.verification' in sys.modules), "
            "int('almanal_runtime.experiment' in sys.modules))"
        )
        out = subprocess.check_output([sys.executable, "-c", code], cwd=root, text=True, timeout=30).strip()
        self.assertEqual(out, "0 1 0")

    def test_portable_declares_measurement_feedback_conditional(self):
        from almanal_runtime.portable_spec import lint_portable_file
        info = lint_portable_file(Path(__file__).resolve().parents[1] / "spec" / "ALMANAL.md")
        self.assertIn("CAUSAL_MEASUREMENT_FEEDBACK", info.conditional_operators)
        self.assertNotIn("CAUSAL_MEASUREMENT_FEEDBACK", info.required_operators)


if __name__ == "__main__":
    unittest.main()
