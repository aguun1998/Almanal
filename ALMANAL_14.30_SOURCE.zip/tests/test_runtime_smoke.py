import unittest
from almanal_runtime.demo import run_demo
from almanal_runtime.consolidation import StructuralComplexityFootprint
from almanal_runtime.evaluator import AnalyticCostVector

class RuntimeSmokeTests(unittest.TestCase):
    def test_demo_completes(self):
        self.assertIn('status=COMPLETE', run_demo())

    def test_practical_cost_axes_execute(self):
        self.assertTrue(AnalyticCostVector((8,10,10)).strictly_dominates(AnalyticCostVector((9,10,10))))
        self.assertEqual(StructuralComplexityFootprint(execution_work_units=1,peak_live_memory_bytes=2,artifact_bytes=3).key()[-3:],(1,2,3))

if __name__=='__main__': unittest.main()
