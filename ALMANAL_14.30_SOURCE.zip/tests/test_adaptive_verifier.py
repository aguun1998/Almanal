
import unittest

from almanal_runtime.assurance import (
    VerificationAction, VerificationTier, Materiality, ChangeSet,
    ImpactGraph, VerificationCache
)
from almanal_runtime.adaptive_verifier import (
    VerificationCase, run_adaptive_verification
)


class AdaptiveVerifierTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.actions = (
            VerificationAction(
                "static", 0, 0, 1, frozenset(), VerificationTier.STATIC,
                always_run=True,
            ),
            VerificationAction(
                "local", 200, 1, 10, frozenset({"x"}), VerificationTier.CANARY,
                mandatory_when_impacted=True,
            ),
            VerificationAction(
                "targeted", 2000, 5, 15, frozenset({"x"}), VerificationTier.TARGETED,
                mandatory_when_impacted=True,
            ),
            VerificationAction(
                "full", 8000, 15, 20, frozenset({"x"}), VerificationTier.FULL,
                mandatory_when_impacted=True,
            ),
        )

    def case(self, action, passed=True):
        return VerificationCase(
            action,
            lambda a=action, p=passed: (self.calls.append(a.name) or p)
        )

    def test_pass_stops_before_targeted_and_full(self):
        cases = tuple(self.case(a, True) for a in self.actions)
        result = run_adaptive_verification(
            cases,
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=20000,
        )
        self.assertTrue(result.passed)
        self.assertEqual(self.calls, ["static", "local"])
        self.assertEqual(result.escalations, 0)
        self.assertEqual(result.planned_tokens_spent, 200)
        self.assertGreater(result.planned_tokens_avoided, 0)

    def test_failure_escalates_one_tier(self):
        cases = (
            self.case(self.actions[0], True),
            self.case(self.actions[1], False),
            self.case(self.actions[2], True),
            self.case(self.actions[3], True),
        )
        result = run_adaptive_verification(
            cases,
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=20000,
        )
        self.assertFalse(result.passed)
        self.assertEqual(self.calls, ["static", "local", "targeted"])
        self.assertEqual(result.escalations, 1)
        self.assertNotIn("full", self.calls)

    def test_second_failure_can_open_full(self):
        cases = (
            self.case(self.actions[0], True),
            self.case(self.actions[1], False),
            self.case(self.actions[2], False),
            self.case(self.actions[3], True),
        )
        result = run_adaptive_verification(
            cases,
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=20000,
        )
        self.assertFalse(result.passed)
        self.assertEqual(self.calls, ["static", "local", "targeted", "full"])
        self.assertEqual(result.escalations, 2)

    def test_cache_can_reduce_execution_to_zero_for_local_check(self):
        cache = VerificationCache()
        local = self.actions[1]
        cache.record(local, {"x":"v1"}, passed=True)
        cases = tuple(self.case(a, True) for a in self.actions)
        result = run_adaptive_verification(
            cases,
            change=ChangeSet(frozenset({"x"}), Materiality.ROUTINE),
            impact_graph=ImpactGraph(),
            token_budget=100,
            fingerprints={"x":"v1"},
            cache=cache,
        )
        self.assertTrue(result.passed)
        self.assertEqual(self.calls, ["static"])
        self.assertIn("local", result.cache_hits)


if __name__ == "__main__":
    unittest.main()
