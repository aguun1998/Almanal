import unittest, threading
from almanal_runtime.evaluator import residual_execution_closure_complete, finalization_pass_allowed, delayed_reduction_safe, AnalyticCostVector, RepresentationCandidate, plan_representation_race, representation_reserve_reopen_allowed, cheap_falsifier_is_decision_relevant, WitnessLeaseLedger

AUDITS=("minimal_state","transition_native","class_aggregation","narrow_sparse_storage","arithmetic_bounds","selective_specialization","io_bottleneck")
def refs(): return tuple((k,f"e:{k}") for k in AUDITS)

class Test1430WitnessedResidualClosure(unittest.TestCase):
    def test_witness_ledger_is_available_from_lazy_public_facade(self):
        import almanal_runtime
        self.assertIs(almanal_runtime.WitnessLeaseLedger,WitnessLeaseLedger)

    def test_self_declared_names_cannot_close_gate(self):
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs()))
    def test_validator_exception_fails_closed(self):
        def boom(*_): raise RuntimeError("down")
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs(),audit_validator=boom))
    def test_duplicate_or_missing_audit_fails_closed(self):
        dup=refs()[:-1]+(refs()[0],)
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=dup,audit_validator=lambda *_:True))
        self.assertFalse(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs()[:-1],audit_validator=lambda *_:True))
    def test_complete_witnessed_audit_closes_gate(self):
        self.assertTrue(residual_execution_closure_complete(resource_material=True,audit_evidence_refs=refs(),audit_validator=lambda k,r:r==f"e:{k}"))
    def test_nonmaterial_skip_is_also_witnessed(self):
        self.assertFalse(residual_execution_closure_complete(resource_material=False))
        self.assertTrue(residual_execution_closure_complete(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True))
    def test_representation_lock_requires_validator(self):
        c=RepresentationCandidate("lock",AnalyticCostVector((1,)),frozenset({"proof"}),1,True,True,mechanism_ref="m:lock")
        p=plan_representation_race((c,),mandatory_obligations=frozenset({"proof"}))
        self.assertIsNone(p.locked_id)
        p=plan_representation_race((c,),mandatory_obligations=frozenset({"proof"}),lock_validator=lambda c,o:True)
        self.assertEqual(p.locked_id,"lock")
        def boom(*_): raise RuntimeError("validator down")
        p=plan_representation_race((c,),mandatory_obligations=frozenset({"proof"}),lock_validator=boom)
        self.assertIsNone(p.locked_id)
    def test_representation_race_requires_frozen_mandatory_obligations(self):
        c=RepresentationCandidate("x",AnalyticCostVector((1,)),frozenset(),1,False,True,mechanism_ref="m:x")
        with self.assertRaises(Exception):
            plan_representation_race((c,))
    def test_candidate_requires_mechanism_and_reasoning_bound(self):
        with self.assertRaises(Exception):
            RepresentationCandidate("unknown",AnalyticCostVector((10,)),frozenset({"proof"}),None,False,True,mechanism_ref="m:unknown")
        with self.assertRaises(Exception):
            RepresentationCandidate("no-mechanism",AnalyticCostVector((10,)),frozenset({"proof"}),1,feasible=True)
    def test_unvalidated_cheaper_lock_claim_cannot_prune_validated_lock(self):
        a=RepresentationCandidate("cheap-false",AnalyticCostVector((10,)),frozenset({"proof"}),1,True,True,mechanism_ref="m:false")
        b=RepresentationCandidate("witnessed",AnalyticCostVector((10,)),frozenset({"proof"}),2,True,True,mechanism_ref="m:true")
        p=plan_representation_race((a,b),mandatory_obligations=frozenset({"proof"}),lock_validator=lambda c,o:c.candidate_id=="witnessed")
        self.assertEqual(p.locked_id,"witnessed")
        self.assertIn("witnessed",p.active_ids)
        self.assertNotIn("witnessed",p.rejected_ids)

    def test_optimistic_candidate_bound_cannot_eliminate_unwitnessed_peer(self):
        # A lower optimistic bound is not an achieved cost; it may rank the beam but cannot reject B.
        a=RepresentationCandidate("optimistic",AnalyticCostVector((1,)),frozenset({"proof"}),1,False,True,mechanism_ref="m:a")
        b=RepresentationCandidate("conservative",AnalyticCostVector((10,)),frozenset({"proof"}),2,False,True,mechanism_ref="m:b")
        p=plan_representation_race((a,b),mandatory_obligations=frozenset({"proof"}))
        self.assertNotIn("conservative",p.rejected_ids)
        self.assertEqual(set(p.active_ids),{"optimistic","conservative"})

    def test_irrelevant_self_declared_obligations_are_priority_not_elimination(self):
        a=RepresentationCandidate("extra",AnalyticCostVector((10,)),frozenset({"proof","irrelevant"}),1,False,True,mechanism_ref="m:a")
        b=RepresentationCandidate("plain",AnalyticCostVector((10,)),frozenset({"proof"}),1,False,True,mechanism_ref="m:b")
        p=plan_representation_race((a,b),mandatory_obligations=frozenset({"proof"}))
        self.assertNotIn("plain",p.rejected_ids)

    def test_multiple_witnessed_pareto_lock_candidates_do_not_scalarize(self):
        a=RepresentationCandidate("time",AnalyticCostVector((1,100)),frozenset({"proof"}),2,True,True,mechanism_ref="m:time")
        b=RepresentationCandidate("memory",AnalyticCostVector((100,1)),frozenset({"proof"}),2,True,True,mechanism_ref="m:memory")
        p=plan_representation_race((a,b),mandatory_obligations=frozenset({"proof"}),lock_validator=lambda *_:True)
        self.assertIsNone(p.locked_id)
        self.assertEqual(set(p.active_ids),{"time","memory"})
        self.assertIn("preserve Pareto frontier",p.reason)

    def test_lower_bound_match_survives_scheduler_dominance(self):
        a=RepresentationCandidate("cheap-unlocked",AnalyticCostVector((10,)),frozenset({"proof"}),1,False,True,mechanism_ref="m:cheap")
        b=RepresentationCandidate("lockable",AnalyticCostVector((10,)),frozenset({"proof"}),2,True,True,mechanism_ref="m:lock")
        p=plan_representation_race((a,b),mandatory_obligations=frozenset({"proof"}),lock_validator=lambda c,o:True)
        self.assertIn("lockable",p.active_ids)
        self.assertEqual(p.locked_id,"lockable")
        self.assertNotIn("lockable",p.rejected_ids)
    def test_arithmetic_narrowing_checks_both_bounds(self):
        self.assertTrue(delayed_reduction_safe(min_intermediate=-100,max_intermediate=100,type_min=-128,type_max=127))
        self.assertFalse(delayed_reduction_safe(min_intermediate=-1000,max_intermediate=100,type_min=-128,type_max=127))
        with self.assertRaises(Exception):
            delayed_reduction_safe(min_intermediate=5,max_intermediate=4,type_min=0,type_max=255)
        with self.assertRaises(TypeError):
            delayed_reduction_safe(max_intermediate=100,type_max=255)
    def test_extra_finalization_requires_fresh_witness(self):
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True)
        self.assertFalse(finalization_pass_allowed(passes_used=1))
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:1"))
        self.assertTrue(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:1",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda r:r=="w:1",**base))
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:1",witness_ledger=(lambda L:(L.consume("w:1",lambda _:True),L)[1])(WitnessLeaseLedger()),witness_validator=lambda _:True,**base))
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:2",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:False,**base))

    def test_immutable_consumed_ledger_fails_closed(self):
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True)
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:old",witness_ledger=frozenset(),witness_validator=lambda _:True,**base))

    def test_successful_witness_use_consumes_identity(self):
        ledger=WitnessLeaseLedger()
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True)
        self.assertTrue(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:once",witness_ledger=ledger,witness_validator=lambda _:True,**base))
        self.assertTrue(ledger.consumed("w:once"))
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:once",witness_ledger=ledger,witness_validator=lambda _:True,**base))

    def test_witness_consumption_is_atomic_across_threads(self):
        ledger=WitnessLeaseLedger(); barrier=threading.Barrier(2); results=[]
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True)
        def validate(_): barrier.wait(); return True
        def run():
            results.append(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:race",witness_ledger=ledger,witness_validator=validate,**base))
        threads=[threading.Thread(target=run) for _ in range(2)]
        for t in threads:t.start()
        for t in threads:t.join(2)
        self.assertEqual(results.count(True),1)
        self.assertEqual(results.count(False),1)

    def test_reopen_requires_fresh_validated_witness(self):
        kw=dict(reopen_batches_used=0,active_failed=True)
        self.assertFalse(representation_reserve_reopen_allowed(**kw))
        self.assertFalse(representation_reserve_reopen_allowed(**kw,trigger_witness_ref="failure:1",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:False))
        self.assertTrue(representation_reserve_reopen_allowed(**kw,trigger_witness_ref="failure:1",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:True))
        self.assertFalse(representation_reserve_reopen_allowed(**kw,trigger_witness_ref="failure:1",witness_ledger=(lambda L:(L.consume("failure:1",lambda _:True),L)[1])(WitnessLeaseLedger()),witness_validator=lambda _:True))


    def test_ordinary_finalization_budget_is_ledger_owned(self):
        ledger=WitnessLeaseLedger()
        base=dict(resource_material=False,nonmaterial_evidence_ref="objective:no-resource-axis",materiality_validator=lambda _:True,witness_ledger=ledger)
        self.assertTrue(finalization_pass_allowed(passes_used=0,**base))
        self.assertFalse(finalization_pass_allowed(passes_used=0,**base))
        self.assertEqual(ledger.count("ordinary_finalization"),1)

    def test_reopen_budget_is_ledger_owned_even_if_caller_repeats_zero(self):
        ledger=WitnessLeaseLedger(); pol=__import__('almanal_runtime.evaluator',fromlist=['RepresentationRacePolicy']).RepresentationRacePolicy(max_reopen_batches=1)
        base=dict(reopen_batches_used=0,active_failed=True,witness_ledger=ledger,witness_validator=lambda _:True,policy=pol)
        self.assertTrue(representation_reserve_reopen_allowed(trigger_witness_ref="failure:a",**base))
        self.assertFalse(representation_reserve_reopen_allowed(trigger_witness_ref="failure:b",**base))
        self.assertEqual(ledger.count("reserve_reopen"),1)

    def test_falsifier_requires_explicit_lock_state(self):
        with self.assertRaises(TypeError):
            cheap_falsifier_is_decision_relevant(counterexample_would_reject=True,falsifier_work_upper_bound=1,next_deep_reasoning_work_upper_bound=2)

    def test_post_lock_falsifier_requires_fresh_validated_witness(self):
        kw=dict(counterexample_would_reject=True,falsifier_work_upper_bound=1,next_deep_reasoning_work_upper_bound=2,representation_locked=True)
        self.assertFalse(cheap_falsifier_is_decision_relevant(**kw))
        self.assertTrue(cheap_falsifier_is_decision_relevant(**kw,defect_or_frontier_witness_ref="frontier:1",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:True))
        self.assertFalse(cheap_falsifier_is_decision_relevant(**kw,defect_or_frontier_witness_ref="frontier:1",witness_ledger=(lambda L:(L.consume("frontier:1",lambda _:True),L)[1])(WitnessLeaseLedger()),witness_validator=lambda _:True))

    def test_fresh_witness_does_not_bypass_residual_gate(self):
        self.assertFalse(finalization_pass_allowed(passes_used=1,defect_or_frontier_witness_ref="w:2",witness_ledger=WitnessLeaseLedger(),witness_validator=lambda _:True))
    def test_caller_boolean_cannot_bypass_residual_validation(self):
        with self.assertRaises(TypeError):
            finalization_pass_allowed(passes_used=0,residual_execution_closure_complete=True)

if __name__=="__main__": unittest.main()
