import unittest

from almanal_runtime.certificate import Certificate, FormalStatus, ProcedureStatus, IndependenceStatus, SeparationVector, TriState
from almanal_runtime.model import ObjectId
from almanal_runtime.verification import VerificationBasis, verify_certificate
from fractions import Fraction
from almanal_runtime.economy import ResourceVector
from almanal_runtime.experiment import ExperimentRunOutput, ExperimentJudgeOutput

from almanal_runtime.consolidation import (
    ConsolidationApplyBinding, ConsolidationApplyOutcome, ConsolidationEquivalence,
    ConsolidationOperation, StructuralComplexityFootprint, StructuralConsolidationCandidate,
    execute_structural_consolidation_audit,
)
from almanal_runtime.design_direction import (
    DesignAlternative, DesignBenefitAxis, DesignBurdenAxis, DesignDirection,
    DesignPressure, DesignSeverity, DesignSignal, select_design_direction,
    trade_study_design_alternatives, DesignRevisitTrigger, record_design_decision,
)


class AutonomousConvergenceTests(unittest.TestCase):
    def _plan(self):
        signal = DesignSignal(
            "self-declared-alt", DesignPressure.SEMANTIC_WITNESS_GAP,
            DesignSeverity.HIGH, "audit:dds-alt-self-declaration",
            protected_impact=True, observed_defect=True,
        )
        return select_design_direction((signal,))

    def _alts(self):
        weak = DesignAlternative(
            "weak", DesignDirection.HARDEN_SEMANTIC_WITNESSING, ("self-declared-alt",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset({DesignBurdenAxis.SOURCE_COMPLEXITY, DesignBurdenAxis.MAINTENANCE_SURFACE}),
            ("analysis:weak",),
        )
        strong = DesignAlternative(
            "strong", DesignDirection.HARDEN_SEMANTIC_WITNESSING, ("self-declared-alt",),
            frozenset({DesignBenefitAxis.SEMANTIC_ASSURANCE}),
            frozenset({DesignBurdenAxis.SOURCE_COMPLEXITY}),
            ("analysis:strong",),
        )
        return weak, strong

    def test_self_declared_alternative_analysis_cannot_auto_select_winner(self):
        result = trade_study_design_alternatives(self._plan(), self._alts())
        self.assertTrue(result.unresolved_tradeoff)
        self.assertIsNone(result.selected_alternative_id)
        self.assertFalse(result.analysis_witnessed)
        self.assertEqual([a.alternative_id for a in result.frontier], ["strong"])

    def test_host_witnessed_alternative_analysis_can_select_strict_dominator(self):
        result = trade_study_design_alternatives(
            self._plan(), self._alts(), alternative_validator=lambda alt: alt.evidence_refs[0].startswith("analysis:")
        )
        self.assertFalse(result.unresolved_tradeoff)
        self.assertEqual(result.selected_alternative_id, "strong")
        self.assertTrue(result.analysis_witnessed)

    def test_alternative_validator_exception_cannot_promote_winner(self):
        def boom(_):
            raise RuntimeError("validator unavailable")
        result = trade_study_design_alternatives(self._plan(), self._alts(), alternative_validator=boom)
        self.assertTrue(result.unresolved_tradeoff)
        self.assertIsNone(result.selected_alternative_id)
        self.assertFalse(result.analysis_witnessed)

    def test_design_decision_record_requires_witnessed_resolved_trade_study(self):
        alts = self._alts()
        unwitnessed = trade_study_design_alternatives(self._plan(), alts)
        with self.assertRaises(Exception):
            record_design_decision(
                self._plan(), unwitnessed, decision_id="d1", protected_constraints_ref="protected:v1",
                evidence_plan_refs=("verify:unit",),
                revisit_triggers=frozenset({DesignRevisitTrigger.NEW_COUNTEREVIDENCE}),
                exit_or_reversal_path="revert patch", rationale="harden witness semantics",
            )

    def test_design_decision_record_binds_frozen_trace_and_is_deterministic(self):
        plan = self._plan()
        trade = trade_study_design_alternatives(plan, self._alts(), alternative_validator=lambda alt: True)
        kwargs = dict(
            decision_id="dds-14.19-1", protected_constraints_ref="protected:v1",
            evidence_plan_refs=("verify:unit", "verify:static"),
            revisit_triggers=frozenset({DesignRevisitTrigger.NEW_COUNTEREVIDENCE, DesignRevisitTrigger.LIFECYCLE_RENT_GROWTH}),
            exit_or_reversal_path="revert or re-open DDS", rationale="close self-declared design-analysis gap",
        )
        a = record_design_decision(plan, trade, **kwargs)
        b = record_design_decision(plan, trade, **kwargs)
        self.assertEqual(a.fingerprint, b.fingerprint)
        self.assertEqual(a.supporting_signal_ids, ("self-declared-alt",))
        self.assertEqual(a.selected_alternative_id, "strong")
        self.assertTrue(a.fingerprint)

    def _passive_move_candidate(self, target="warm-leaf"):
        before = StructuralComplexityFootprint(active_context_chars=10, source_chars=10, module_count=1)
        after = StructuralComplexityFootprint(active_context_chars=5, source_chars=10, module_count=1)
        return StructuralConsolidationCandidate(
            target_ref=target, operation=ConsolidationOperation.MOVE_WARM, before=before, after=after,
            unique_capabilities=frozenset({"cap"}), replacement_capabilities=frozenset({"cap"}),
            evidence_refs=("e:static",), rollback_ref="rollback:1", audit_history_ref="audit:1",
            local_verification_passed=True, measurement_contract_ref="m:1", before_measurement_ref="bm:1",
            load_on_demand_supported=True, residency_semantics_preserved=True, interface_compatibility_verified=True,
            residency_only_change=True, equivalence=ConsolidationEquivalence.REGRESSION_EQUIVALENT_SCOPED,
        )

    def test_sca_rollback_failure_is_explicit_and_stops_further_auto_apply(self):
        first = self._passive_move_candidate("first")
        second = self._passive_move_candidate("second")
        touched = []
        def bad_rollback():
            raise RuntimeError("rollback failed")
        b1 = ConsolidationApplyBinding(
            "first", ConsolidationOperation.MOVE_WARM,
            apply=lambda: touched.append("first"), verify=lambda: False, rollback=bad_rollback,
            measurement_contract_ref="m:1", measure_after=lambda: first.after,
        )
        b2 = ConsolidationApplyBinding(
            "second", ConsolidationOperation.MOVE_WARM,
            apply=lambda: touched.append("second"), verify=lambda: True, rollback=lambda: None,
            measurement_contract_ref="m:1", measure_after=lambda: second.after,
        )
        report = execute_structural_consolidation_audit((first, second), (b1, b2))
        self.assertTrue(report.integrity_compromised)
        self.assertEqual(report.applications[-1].outcome, ConsolidationApplyOutcome.ROLLBACK_FAILED)
        self.assertEqual(touched, ["first"])

    def test_sca_apply_exception_with_successful_rollback_is_reported_not_raised(self):
        c = self._passive_move_candidate("apply-fail")
        rolled = []
        def boom():
            raise RuntimeError("apply failed")
        b = ConsolidationApplyBinding(
            "apply-fail", ConsolidationOperation.MOVE_WARM, apply=boom, verify=lambda: True,
            rollback=lambda: rolled.append(True), measurement_contract_ref="m:1", measure_after=lambda: c.after,
        )
        report = execute_structural_consolidation_audit((c,), (b,))
        self.assertFalse(report.integrity_compromised)
        self.assertEqual(report.applications[0].outcome, ConsolidationApplyOutcome.APPLY_FAILED)
        self.assertEqual(rolled, [True])

    def _proved_cert(self):
        return Certificate(
            "proof-cert", ObjectId("subject"), "criterion", "scope", proof_ref="proof:1",
            formal_status=FormalStatus.PROVED, procedure_status=ProcedureStatus.COMPLETE,
        )

    def test_machine_proof_basis_label_cannot_self_attest(self):
        with self.assertRaises(Exception):
            verify_certificate(
                self._proved_cert(), verifier_ref="local-bool", basis=VerificationBasis.MACHINE_PROOF,
                verifier=lambda _: True,
            )

    def test_machine_proof_basis_requires_host_validated_attestation(self):
        receipt = verify_certificate(
            self._proved_cert(), verifier_ref="proof-checker", basis=VerificationBasis.MACHINE_PROOF,
            verifier=lambda _: True, basis_attestation_ref="host:proof-checker:1",
            basis_validator=lambda verifier_ref, basis, ref: (verifier_ref, basis, ref) == (
                "proof-checker", VerificationBasis.MACHINE_PROOF, "host:proof-checker:1"
            ),
        )
        self.assertTrue(receipt.passed)
        self.assertEqual(receipt.basis_attestation_ref, "host:proof-checker:1")

    def test_external_review_validator_exception_cannot_promote_basis(self):
        cert = Certificate(
            "review-cert", ObjectId("subject"), "criterion", "scope", proof_ref="proof:2",
            formal_status=FormalStatus.PROVED, procedure_status=ProcedureStatus.COMPLETE,
        )
        def boom(*_):
            raise RuntimeError("attestor unavailable")
        with self.assertRaises(Exception):
            verify_certificate(
                cert, verifier_ref="reviewer", basis=VerificationBasis.EXTERNAL_REVIEW, verifier=lambda _: True,
                basis_attestation_ref="external:review:1", basis_validator=boom,
            )

    def test_scoped_independence_cannot_be_declared_with_unknown_roots(self):
        cert = Certificate(
            "ind-unknown", ObjectId("subject"), "criterion", "scope",
            separation=SeparationVector(), independence_status=IndependenceStatus.INDEPENDENCE_SUPPORTED_SCOPED,
            independence_audit_ref="audit:claimed", procedure_status=ProcedureStatus.COMPLETE,
        )
        with self.assertRaises(Exception):
            cert.validate_structure()

    def test_scoped_independence_requires_host_validated_overlap_audit(self):
        cert = Certificate(
            "ind-good", ObjectId("subject"), "criterion", "scope", evidence_refs=("e:1",),
            separation=SeparationVector(model_root=TriState.YES, evidence_root=TriState.YES),
            independence_status=IndependenceStatus.INDEPENDENCE_SUPPORTED_SCOPED,
            independence_audit_ref="audit:dep-1", procedure_status=ProcedureStatus.COMPLETE,
        )
        with self.assertRaises(Exception):
            verify_certificate(cert, verifier_ref="structure", basis=VerificationBasis.STRUCTURE_ONLY, verifier=lambda _: True)
        receipt = verify_certificate(
            cert, verifier_ref="structure", basis=VerificationBasis.STRUCTURE_ONLY, verifier=lambda _: True,
            independence_validator=lambda c: c.independence_audit_ref == "audit:dep-1",
        )
        self.assertTrue(receipt.passed)

    def test_sca_apply_exception_and_rollback_exception_marks_integrity_compromised(self):
        first = self._passive_move_candidate("double-fail")
        second = self._passive_move_candidate("must-not-run")
        touched = []
        def apply_boom():
            touched.append("double-fail")
            raise RuntimeError("apply failed")
        def rollback_boom():
            raise RuntimeError("rollback failed")
        b1 = ConsolidationApplyBinding(
            "double-fail", ConsolidationOperation.MOVE_WARM, apply=apply_boom, verify=lambda: True,
            rollback=rollback_boom, measurement_contract_ref="m:1", measure_after=lambda: first.after,
        )
        b2 = ConsolidationApplyBinding(
            "must-not-run", ConsolidationOperation.MOVE_WARM, apply=lambda: touched.append("must-not-run"),
            verify=lambda: True, rollback=lambda: None, measurement_contract_ref="m:1", measure_after=lambda: second.after,
        )
        report = execute_structural_consolidation_audit((first, second), (b1, b2))
        self.assertTrue(report.integrity_compromised)
        self.assertEqual(report.applications[-1].outcome, ConsolidationApplyOutcome.ROLLBACK_FAILED)
        self.assertEqual(touched, ["double-fail"])


if __name__ == "__main__":
    unittest.main()
