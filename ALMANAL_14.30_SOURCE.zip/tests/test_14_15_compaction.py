import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ReleaseCompactionTests(unittest.TestCase):
    def test_package_facade_is_dependency_lazy(self):
        code = (
            "import json,sys,almanal_runtime as a; "
            "mods=[x for x in sys.modules if x=='almanal_runtime' or x.startswith('almanal_runtime.')]; "
            "print(json.dumps(mods))"
        )
        out = subprocess.check_output(
            [sys.executable, "-S", "-c", code],
            cwd=ROOT,
            env={**os.environ, "PYTHONPATH": str(ROOT)},
            text=True,
            timeout=30,
        )
        mods = json.loads(out)
        self.assertEqual(mods, ["almanal_runtime"])

    def test_private_budget_module_was_merged(self):
        self.assertFalse((ROOT / "almanal_runtime" / "budget.py").exists())
        runtime = (ROOT / "almanal_runtime" / "runtime.py").read_text(encoding="utf-8")
        self.assertIn("class StepBudget:", runtime)

    def test_sca_is_declared_conditional_not_universal(self):
        from almanal_runtime.portable_spec import extract_manifest
        manifest = extract_manifest((ROOT / "spec" / "ALMANAL.md").read_text(encoding="utf-8"))
        self.assertIn("STRUCTURAL_CONSOLIDATION_AUDIT", manifest["conditional_operators"])
        self.assertNotIn("STRUCTURAL_CONSOLIDATION_AUDIT", manifest["required_operators"])


if __name__ == "__main__":
    unittest.main()
