from fractions import Fraction
import random

from almanal_runtime.economy import (
    ResourceVector, MetaTransition, MetaAction,
    FiniteMetaProblem, solve_finite_horizon_metareasoning,
)

random.seed(14505)

cases = 0

# Resource monotonicity: larger componentwise budget cannot lower optimal value.
for i in range(1000):
    stop_a = Fraction(random.randint(0, 20))
    stop_b = Fraction(random.randint(0, 20))
    cost = Fraction(random.randint(0, 5))
    token_cost = random.randint(0, 5)

    problem = FiniteMetaProblem(
        stop_utilities=(("a", stop_a), ("b", stop_b)),
        actions=(
            MetaAction(
                "inspect",
                "a",
                cost,
                (MetaTransition(Fraction(1), "b"),),
                resources=ResourceVector(tokens=token_cost),
            ),
        ),
    )
    small = solve_finite_horizon_metareasoning(
        problem,
        horizon=2,
        budget=ResourceVector(tokens=0),
    )
    large = solve_finite_horizon_metareasoning(
        problem,
        horizon=2,
        budget=ResourceVector(tokens=5),
    )
    assert dict(large.values)["a"] >= dict(small.values)["a"]
    cases += 1

# Horizon monotonicity: with STOP always available, more optional lookahead cannot lower value.
for i in range(1000):
    stop_a = Fraction(random.randint(0, 20))
    stop_b = Fraction(random.randint(0, 20))
    cost = Fraction(random.randint(0, 5))
    problem = FiniteMetaProblem(
        stop_utilities=(("a", stop_a), ("b", stop_b)),
        actions=(
            MetaAction(
                "think",
                "a",
                cost,
                (MetaTransition(Fraction(1), "b"),),
            ),
        ),
    )
    h1 = solve_finite_horizon_metareasoning(
        problem, horizon=1, budget=ResourceVector()
    )
    h3 = solve_finite_horizon_metareasoning(
        problem, horizon=3, budget=ResourceVector()
    )
    assert dict(h3.values)["a"] >= dict(h1.values)["a"]
    cases += 1

print(f"cognitive_economy_properties={cases} PASS")
