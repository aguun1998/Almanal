from fractions import Fraction
import json

from almanal_runtime.economy import (
    CognitiveActionKind, ResourceVector, UtilityEstimate,
    CognitiveOffer, EconomyGovernor, LifecycleImprovement,
    decide_lifecycle_improvement, TokenInvestment,
)
from almanal_runtime.governed import execute_governed


def offer(action_id, kind, current, post, cost, tokens, *, mandatory=False):
    return CognitiveOffer(
        action_id=action_id,
        kind=kind,
        current_stop_utility=Fraction(current),
        post_action_stop_utility=UtilityEstimate(
            Fraction(post), Fraction(post), Fraction(post)
        ),
        decision_cost_utility=Fraction(cost),
        resources=ResourceVector(tokens=tokens, steps=1),
        mandatory=mandatory,
        evidence_ref="demo-estimate",
    )


def main():
    out = {}

    # Simple task: another adversarial pass is not worth its cost.
    simple = EconomyGovernor(
        budget=ResourceVector(tokens=500, steps=5)
    )
    simple_result = execute_governed(
        simple,
        offer(
            "extra-challenge",
            CognitiveActionKind.CHALLENGE,
            current=10,
            post=10,
            cost=1,
            tokens=120,
        ),
        lambda: "should-not-run",
    )
    out["simple_task"] = {
        "decision": simple_result.gate.decision.name,
        "executed": simple_result.status.name,
        "tokens_remaining": simple.remaining.tokens,
    }

    # High-risk floor: verification runs despite negative optional economics.
    high_risk = EconomyGovernor(
        budget=ResourceVector(tokens=500, steps=5)
    )
    high_result = execute_governed(
        high_risk,
        offer(
            "protected-verify",
            CognitiveActionKind.VERIFY,
            current=10,
            post=9,
            cost=2,
            tokens=200,
            mandatory=True,
        ),
        lambda: "verified",
    )
    out["high_risk"] = {
        "decision": high_result.gate.decision.name,
        "executed": high_result.status.name,
        "tokens_remaining": high_risk.remaining.tokens,
    }

    # Creative divergence: early challenge skipped; late audit may be useful.
    creative = EconomyGovernor(
        budget=ResourceVector(tokens=600, steps=5)
    )
    early = execute_governed(
        creative,
        offer(
            "early-critique",
            CognitiveActionKind.CHALLENGE,
            current=10,
            post=9,
            cost=1,
            tokens=120,
        ),
        lambda: "premature-critique",
    )
    late = execute_governed(
        creative,
        offer(
            "late-canon-audit",
            CognitiveActionKind.VERIFY,
            current=10,
            post=14,
            cost=1,
            tokens=150,
        ),
        lambda: "late-audit",
    )
    out["creative_task"] = {
        "early": early.gate.decision.name,
        "late": late.gate.decision.name,
        "tokens_remaining": creative.remaining.tokens,
    }

    # Persistent formal addition: possible but lifecycle-negative.
    cosmetic = LifecycleImprovement(
        improvement_id="extra-formal-layer",
        one_time_decision_cost_utility=Fraction(100),
        per_use_utility_gain=UtilityEstimate(
            Fraction(0), Fraction(1), Fraction(2)
        ),
        per_use_decision_cost_utility=Fraction(1),
        discounted_expected_uses=Fraction(30),
    )
    life = decide_lifecycle_improvement(cosmetic)
    out["self_improvement"] = {
        "execute": life.execute,
        "npv": str(life.npv),
        "reason": life.reason,
    }

    investment = TokenInvestment(
        one_time_tokens=10_000,
        per_use_tokens_saved=250,
    )
    out["token_break_even"] = {
        "uses": investment.break_even_uses(),
    }

    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
