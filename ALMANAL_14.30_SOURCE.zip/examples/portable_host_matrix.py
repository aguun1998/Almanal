import json

from almanal_runtime.portable import (
    ALMANAL_RUNTIME_PROTOCOL,
    Capability, Availability, Enforcement, WitnessBasis,
    CapabilityRecord, CapabilityManifest, bootstrap_portable,
)


def r(cap, enforcement=Enforcement.INTERNAL,
      witness=WitnessBasis.SELF_DECLARED, protocols=()):
    return CapabilityRecord(
        cap, Availability.AVAILABLE, enforcement, witness,
        f"demo:{cap.name}", tuple(protocols)
    )


minimum = (
    r(Capability.REASON),
    r(Capability.CONTEXT_STATE),
    r(Capability.STRUCTURED_OUTPUT),
)

manifests = {
    "native": CapabilityManifest("host-A", minimum),
    "tool_augmented": CapabilityManifest(
        "host-B",
        minimum + (
            r(Capability.RETRIEVAL, Enforcement.TOOL, WitnessBasis.OBSERVED_INTERFACE),
            r(Capability.CODE_EXECUTION, Enforcement.TOOL, WitnessBasis.EXECUTED),
        ),
    ),
    "reference_exec": CapabilityManifest(
        "host-C",
        minimum + (
            r(
                Capability.EXTERNAL_RUNTIME,
                Enforcement.EXTERNAL,
                WitnessBasis.OBSERVED_INTERFACE,
                (ALMANAL_RUNTIME_PROTOCOL,),
            ),
        ),
    ),
    "hardened": CapabilityManifest(
        "host-D",
        minimum + (
            r(
                Capability.EXTERNAL_RUNTIME,
                Enforcement.EXTERNAL,
                WitnessBasis.OBSERVED_INTERFACE,
                (ALMANAL_RUNTIME_PROTOCOL,),
            ),
            r(
                Capability.PROCESS_ISOLATION,
                Enforcement.HARDENED,
                WitnessBasis.EXECUTED,
            ),
        ),
    ),
}

def demo_witness(record):
    return record.witness_ref == f"demo:{record.capability.name}" and record.claims_strong_witness

out = {}
for name, manifest in manifests.items():
    result = bootstrap_portable(manifest, capability_witness_validator=demo_witness)
    out[name] = {
        "status": result.status.name,
        "profile": result.profile.name if result.profile is not None else None,
        "validation_ceiling": result.validation_ceiling.name,
        "external_enforcement": result.can_claim_external_enforcement,
        "independent_verification": result.can_claim_independent_verification,
        "operators": [b.operator for b in result.bindings],
        "residuals": list(result.residuals),
    }

print(json.dumps(out, ensure_ascii=False, indent=2))
