# ALMANAL 14.30 Source / Audit Bundle

Full specifications, regression tests, release evidence, and audit/canary examples.
Extract this and ALMANAL_RUNTIME_0.30.zip into the same directory for the full suite:
`PYTHONPATH=. python -m unittest discover -s tests -q`

The operational Runtime ZIP carries runtime code. Audit assets stay in this source bundle to keep deployment payload separate from audit evidence.
