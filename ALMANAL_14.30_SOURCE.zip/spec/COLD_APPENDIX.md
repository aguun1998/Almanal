# ALMANAL 14.30 COLD Formal Appendix

> **Residency:** COLD — source/proof/audit only; do not mount for ordinary execution.  
> **Parent Active Core:** ALMANAL 14.30 Witnessed Residual Closure / Fresh-Witness Kernel Candidate.
> **Purpose:** preserve nontrivial proof bodies, impossibility reductions, legacy compatibility mappings, and the substantive result ledger without charging ordinary active-context cost.

The content below is intentionally excluded from HOT/WARM execution context.

---

# Part XI. Impossibility Boundaries

## 18. Arbitrary Program Equivalence Is Undecidable

### IMPOSSIBILITY I1

일반적인 Turing-complete program \(A,B\)에 대해 모든 경우에

\[
\llbracket A\rrbracket=\llbracket B\rrbracket
\]

인지 판정하는 total algorithm은 존재하지 않는다.

**Proof sketch by reduction from halting.**  
임의 program \(R\)과 input \(x\)가 주어졌다고 하자. 항상 0을 반환하는 program \(P\)를 만든다. \(Q\)는 \(R(x)\)를 실행하고, 그것이 종료하면 0을 반환한다. termination-sensitive semantics에서 \(P\equiv Q\) iff \(R(x)\)가 종료한다. program equivalence decider가 존재하면 halting problem을 결정할 수 있으므로 모순. \(\square\)

### CONSEQUENCE

13.5의 compression 조건에서 사용된

\[
RequiredBehavior(A')\simeq RequiredBehavior(A)
\]

는 일반적으로 자동 판정 가능한 kernel primitive가 될 수 없다.

다음 세 class로 분리한다.

1. `FORMALLY_PROVED_EQUIVALENCE`: 제한된 formal model/DSL에서 proof 제공.
2. `REGRESSION_EQUIVALENT_SCOPED`: 명시된 test/perturbation scope에서만 경험적으로 동등.
3. `UNPROVED_EQUIVALENCE`: 주장 금지.

---

## 19. Resource-Bounded Universal Optimality Is Impossible for Unrestricted Black-Box Objectives

### IMPOSSIBILITY I2 — Unqueried-point indistinguishability

유한 candidate space \(\mathcal A\)의 크기가 \(N\)이고, synthesizer/optimizer \(M\)가 objective oracle을 최대 \(B<N\)개 candidate에서만 query할 수 있다고 하자. objective class가 임의 함수

\[
q:\mathcal A\to\{0,1\}
\]

를 포함하면 \(M\)은 모든 \(q\)에 대해 global optimum을 보장할 수 없다.

**Proof.** deterministic \(M\)가 query한 candidate 집합을 \(Q_M\)라 하자. \(|Q_M|\le B<N\)이므로 \(x^\star\in\mathcal A\setminus Q_M\)가 존재한다. \(M\)가 관측한 모든 query 값이 0이었다고 하자. 다음 두 objective를 구성한다.

\[
q_0(x)=0\quad\forall x
\]

\[
q_1(x)=
\begin{cases}
1,&x=x^\star\\
0,&otherwise
\end{cases}
\]

\(M\)가 실제로 query한 모든 지점에서 \(q_0,q_1\)은 동일하므로 \(M\)의 transcript와 output은 동일하다. 그러나 \(q_1\)에서는 \(x^\star\)가 유일한 global optimum이며 \(M\)은 \(x^\star\)를 query하지 않았다. 따라서 모든 unrestricted black-box objective에 대한 global-optimum guarantee는 불가능하다. randomized \(M\)도 worst-case guarantee에는 동일한 adversarial argument가 적용된다. \(\square\)

### CONSEQUENCE

ALMANAL이 증명할 수 있는 강한 optimality는 task structure가 추가될 때뿐이다. 예:

- finite exhaustive search,
- admissible heuristic bound,
- convexity/submodularity 등 구조 가정,
- verified domain oracle,
- 제한된 formal DSL.

따라서 올바른 목표는:

\[
\boxed{
\text{명시된 task class + evaluator assumptions + resource bound 아래의 scoped guarantee}
}
\]

이다.

Behavioral superiority over baseline은 별도 empirical benchmark 대상이다.

---

## 20. Formal Proof Is Model-Relative

### THEOREM T14 — Soundness transfer requires sound premises/model

어떤 formal calculus에서:

\[
\Gamma\vdash\phi
\]

이고 calculus가 semantics \(\models\)에 대해 sound하면:

\[
\Gamma\models\phi
\]

이다.

**Proof.** soundness의 정의가 바로 \(\Gamma\vdash\phi\Rightarrow\Gamma\models\phi\)이다. 따라서 derivability에서 semantic entailment가 따라온다. 단, 이 semantics가 empirical world를 올바르게 모델링한다는 명제는 soundness 정의에 포함되지 않는다. \(\square\)

그러나 \(\Gamma\)가 현실을 잘못 모델링하면 이것만으로 empirical truth가 되지 않는다.

따라서:

\[
FormalProof\neq EmpiricalWorldTruth
\]

은 type distinction으로 유지한다.

---



# Part XIII. Reclassification of ALMANAL 13.5 A1–A16

| 13.5 항목 | 14.0 분류 | 처리 |
|---|---|---|
| A1 Typed Separation | `DEF/RULE` | 기존 \(Type(x)\neq Type(y)\Rightarrow x\not\equiv y\) 폐기. tagged type + no implicit coercion으로 대체 |
| A2 No Implicit Promotion | `RULE/INVARIANT` | `T-PROMOTE`, `I-TYPE-1`로 정식화 |
| A3 Preserve Provenance | `INVARIANT/THEOREM` | exact preservation 대신 provenance-root monotonicity + provenance monotonicity |
| A4 No Self-Certification | `POLICY + certificate axis` | self-validation 금지가 아니라 independence class 과장 금지 |
| A5 No Authority Amplification | `INVARIANT/THEOREM` | permission-set envelope + authority envelope |
| A6 No Independence Laundering | `DEF/THEOREM` | multi-axis independence + separation/dependency rules |
| A7 Persistent State ≠ Process | `TYPE/STATE MODEL` | persistent artifact와 ephemeral runtime을 다른 state class로 분리 |
| A8 Reuse Before Creation | `POLICY` | cost-sensitive search policy로 강등 |
| A9 Bound Recursion/Resources | `INVARIANT/THEOREM` | finite budget 문구 대신 decreasing ranking function + T8 |
| A10 Validate Before Persist | `GOVERNANCE INVARIANT` | persistence gate로 유지 |
| A11 Complexity Has Cost | `OBJECTIVE MODEL/POLICY` | 무차원 합산 금지. quality vector의 별도 metric으로 처리 |
| A12 Delete/Merge/Generalize Before Add | `POLICY` | compression/search order 정책 |
| A13 Stop Is Not Perfection | `THEOREM/COROLLARY` | stop taxonomy + exhaustive-search conditions으로 정확화 |
| A14 Understanding Is Not Endorsement | `TYPE SEPARATION` | descriptive/predictive/normative judgement bridge 분리 |
| A15 Missing Support... | `INFERENCE RULE/THEOREM` | positive cert premises + certificate premise rules |
| A16 Semantic Identity Frozen | `INVARIANT/THEOREM` | snapshot/SID + frozen epoch semantics |

---




# Part XVII. Formalization Consequences for Existing 13.5 Components

## 27. `T_\infty`

“불변의 진리를 찾아가라”는 논리적 공리가 아니라 **governance goal schema**다.

\[
T_\infty: \text{truth-directed epistemic objective}
\]

사실명제 \(\phi\)의 external truth semantics가 \(Truth_W(\phi)\)로 정의될 수 있을 때 belief/evaluation은 그 truth에 대한 error를 줄이는 방향을 목표로 한다.

그러나 실제 \(W\)가 직접 알려져 있지 않으므로:

\[
TruthGoal\neq TruthOracle
\]

Popularity, convenience, utility가 truth criterion을 묵시적으로 대체하지 못하게 하는 anti-drift role만 kernel invariant로 유지한다.

---

## 28. K / X / S / Csem / M / Phi / H / B / W

이들은 “뇌”라는 ontology가 아니라 **operator interface families**로 해석한다.

각 primitive family \(F\)는:

\[
F=(Signature,Pre,Post,Effects,Cost,Failure)
\]

를 가져야 한다.

- \(K\): candidate transformation operator family.
- \(X\): challenge generator family. material identity/proof/improvement claim에는 \(X^{ont}\) meta-ontology lane을 포함한다.
- \(S\): external-source ingestion family.
- \(C^{sem}\): relation-map constructor.
- \(M\): persistent-state operator family.
- \(\Phi\): hypothesis/counterfactual generator.
- \(H\): resource/homeostasis scheduler.
- \(B\): formalization/deduction family.
- \(W\): world-model update/query family.

primitive 명칭 자체는 존재론적 독립성이나 epistemic independence를 의미하지 않는다.

---

## 29. Dynamic Composite

composite를 labelled graph로 정의한다.

\[
C=(V,E,\tau,\sigma,\alpha)
\]

- \(V\): operator instances.
- \(E\): typed data/control edges.
- \(\tau\): type labeling.
- \(\sigma\): state-view mapping.
- \(\alpha\): authority requirements.

admission은 최소:

\[
WellTyped(C)
\land AuthorityCompatible(C)
\land DependencyClosed(C)
\land BudgetFeasible(C)
\]

를 요구한다.

`Reuse before create`, `smallest compatible route`는 POLICY다.

---

## 30. Generic Revision

persistent revision proposal:

\[
r=
(Target,BaseVersion,Candidate,
FrozenCriterion,TrialScope,
Rollback,DependencyReach)
\]

### INVARIANT I-REVISION

material revision은:

\[
PrecommitCriterion
\land ProvisionalTrial
\land Regression
\land RollbackAvailable
\]

를 만족하거나 `INCOMPLETE/BLOCKED`로 종료한다.

## 30.1 Persistence Commit Window

### INVARIANT I-PERSIST-WINDOW

persistent material commit은 runtime이 `RUNNING`이고 frozen regression stage 안에 있을 때만 허용한다.

\[
CommitPersistent(r)
\Rightarrow
RuntimeStatus=RUNNING
\land Stage=REGRESSION
\]

terminal `COMPLETE/INVALIDATED/BLOCKED` 이후에는 같은 epoch의 persistent state를 뒤늦게 수정하지 않는다.



# Part XVIII. Substantive Result Ledger

This ledger intentionally excludes theorem-shaped restatements of definitions/invariants.
Only results that add nontrivial information, a constructive witness, a quantitative bound,
a counterexample, or an impossibility boundary are retained.

| ID | Result | Status / scope |
|---|---|---|
| T0 | effective finite runtime composition yields an effective meta-algorithm | CONDITIONAL PROVED |
| P-NATIVE-BOOT | a sufficient cooperative host can construct the NATIVE runtime from the portable contract | CONDITIONAL CONSTRUCTION |
| T-REF-TERM | bounded reference synthesis terminates | PROVED under A-REF |
| T-REF-OPT | exhaustive bounded synthesis returns Pareto-maximal artifacts in its declared space | PROVED under A-REF |
| T-REF-META | bounded reference synthesizer is a concrete meta-algorithm witness | COROLLARY |
| T3 | provenance roots are preserved through admitted finite transforms | PROVED |
| T5 | agreement alone cannot manufacture separation/independence | PROVED under declared dependency rules |
| T8 | strictly decreasing natural-number step rank implies finite execution | PROVED |
| T-BASELINE | candidate-only ranking cannot guarantee baseline non-regression | PROVED by counterexample |
| T10 / T10.1 | simultaneous-confidence acceptance yields bounded per-step / cumulative non-regression | CONDITIONAL PROVED |
| T-COG-BELLMAN | finite-horizon cognitive-economy Bellman recurrence is optimal for the declared finite model | PROVED |
| T-IMPACT-LOCAL-SOUNDNESS | impact-local verification is sound under verified dependency coverage | CONDITIONAL PROVED |
| T-KNAPSACK-NONGREEDY | greedy optional-verification selection is not generally optimal | PROVED by counterexample |
| T13 | finite exhaustive exact evaluation yields global Pareto maximality in the declared space | PROVED |
| T14 | formal proof transfers only relative to sound premises/model | CONDITIONAL THEOREM |
| T-LIB-1 | exported theorem scope cannot exceed dependency-validity scope | CONDITIONAL PROVED |
| T15 | well-founded finite structural flattening terminates | PROVED under A-FLAT |
| I1 | unrestricted program semantic equivalence is undecidable | PROVED SKETCH |
| I2 | bounded black-box queries cannot guarantee unrestricted global optimum | PROVED |

### Proof-hygiene rule

A proposition is **not** promoted to `THEOREM` merely because it can be restated as:
`definition/invariant has conjunct X; X is false; therefore the defined predicate is false`.
Such immediate consequences remain ordinary guards, invariants, or explanatory notes unless
they carry independent operational or mathematical information.

---



# 14.7 Proof Bodies Externalized from Active Core

> These proof bodies remain part of the formal source but are COLD. Ordinary boot/runtime context needs the theorem statements and conditions, not the derivations.

## THEOREM P-NATIVE-BOOT — Conditional

**Proof sketch.** `D`의 bootstrap/runtime operators가 finite instruction sequence이며 HostSufficient가 각 required primitive를 realization할 수 있다는 가정 아래 순차 composition으로 runtime state를 구성한다. \(\square\)

---

## THEOREM T0 — ALMANAL is an effective meta-algorithm under A-EFFECTIVE

**Proof.** admitted state마다 stage wrapper가 next/terminal status를 유한 계산으로 반환하고 각 내부 transition이 computable하며 execution 길이가 finite이므로, 전체 execution은 finite composition of computable mappings이다. `Out`도 computable하므로 전체 synthesis mapping은 total computable하다. randomized stage가 있으면 random bits를 추가 input으로 보는 표준 표현으로 randomized algorithm이 된다. external oracle call이 있으면 같은 논증이 oracle-relative computability를 준다. \(\square\)

이 정리는 “좋은 알고리즘을 반드시 만든다”를 증명하지 않는다. 다만 ALMANAL이 조건을 만족할 때 **문제를 입력받아 algorithm artifact를 출력하는 실제 meta-algorithm**이라는 존재론적 지위를 명확히 한다.



## 4.6 Bounded Reference Synthesizer — Constructive Existence

ALMANAL의 “algorithm-generating algorithm” 지위를 단순 명칭이 아니라 **구성적 witness**로 고정하기 위한 참조 알고리즘이다.

---

## THEOREM T-REF-TERM — Reference synthesis terminates

**Proof.** \(|\Sigma^{\le L}|=\sum_{i=0}^{L}|\Sigma|^i<\infty\). 각 parse/feasibility/evaluation/comparison이 assumption에 의해 finite computable이므로 finite loop가 종료한다. \(\square\)

---

## THEOREM T-REF-OPT — Bounded global Pareto maximality

**Proof.** finite candidate language의 모든 feasible candidate를 exact evaluation하고 maximal set을 정의 그대로 반환했으므로 strict dominator가 남아 있을 수 없다. \(\square\)

---

## THEOREM T3 — Provenance non-laundering / non-fabrication

**Proof.** derivation depth에 대한 귀납. depth 0은 자명. \(y=f(x_1,\ldots,x_n)\)에서 귀납가정에 의해 각 \(x_i\)는 모든 조상 root를 포함한다. `PROV-TRANSFORM`은 그 union을 정확히 포함하고 추가분을 explicit \(NewRoots(f)\)로 제한한다. 따라서 ancestral root는 보존되고, transform이 새 source-ingestion record 없이 source root를 발명할 수도 없다. \(\square\)

**주의:** transform의 metadata 전체가 동일하게 남는다는 뜻이 아니다. scope narrowing, derived node, aggregation metadata는 바뀔 수 있다. 불변인 것은 **source ancestry의 손실·위조 금지**다.

---

## 8. Authority as Permission Sets

---

## THEOREM T5 — Agreement cannot manufacture separation

**Proof.** separation axis는 output agreement가 아니라 dependency/root relation으로 정의된다. SameModelRoot이면 정의상 \(S_{modelroot}=0\). positive independence certificate의 premise가 충족되지 않는다. \(\square\)

---

## THEOREM T8 — Finite execution termination

**Proof.** 자연수에는 무한 strictly descending chain이 존재하지 않는다. 따라서 \(b_{step}\)가 매 전이 감소하는 무한 trace는 불가능하다. \(\square\)

# Part VIII. Evaluation and Improvement

## 13. Frozen Evaluator

---

## THEOREM T-BASELINE — Candidate-only ranking is insufficient for non-regression

**Proof by counterexample.** baseline quality를 \((10,10)\), 후보를 \(A=(11,0), B=(10,11)\)라 하자. 첫 metric 우선 lexicographic rule은 \(A\)를 고르지만 두 번째 protected metric에서 \(0<10\)이므로 baseline non-regression을 위반한다. \(\square\)

---

## THEOREM T10 — High-confidence bounded non-regression

**Proof.**

\[
q_j(a')\ge L_j(a')
\ge U_j(a)-\delta_j
\ge q_j(a)-\delta_j
\]

strict metric도 동일하게:

\[
q_k(a')\ge L_k(a')>U_k(a)+\eta_k\ge q_k(a)+\eta_k.
\]

\(\square\)

---

## THEOREM T-COG-BELLMAN — Finite-horizon optimality

**Proof.** \(h=0\)은 stop뿐이므로 정의상 최적. \(h>0\)에서 첫 선택은 STOP 또는 feasible action 하나다. action 후 남은 문제는 horizon \(h-1\), successor state, residual budget의 동일 문제이므로 induction hypothesis에 의해 \(V_{h-1}\)가 최적 continuation이다. 첫 action 전체에 max를 취하면 최적. \(\square\)

## 15.3 Value of Computation

action \(a\)의 horizon-\(h\) exact VOC:

\[
VOC_h(a|x,b)
=
-k(a)+
E[V_{h-1}(X',b-r(a))]
-
U_{stop}(x)
\]

optional action은 exact model에서:

\[
VOC_h(a|x,b)>\mu
\]

일 때만 실행 후보가 된다. \(\mu\ge0\)는 candidate outcome을 보기 전에 freeze된 execution margin이다.

---

## THEOREM T-IMPACT-LOCAL-SOUNDNESS — Conditional

**Proof sketch.** dependency completeness 가정 아래 변경 영향은 \(Affected(\Delta)\) 밖으로 전파되지 않는다. \(v\)의 모든 invalidating dependency가 closure 밖이면 해당 변경은 \(v\)의 premise/fingerprint를 바꾸지 않는다. \(\square\)

**중요:** 이는 graph completeness에 조건부다. completeness 자체를 theorem 없이 자기선언하지 않는다.

---

## 15.13 Sequential Verification Tiers

---

## THEOREM T13 — Global optimality under finite exhaustive search

**Proof.** 모든 feasible candidate가 평가집합에 포함되어 있고 maximal element를 선택했으므로 더 우월한 미평가 candidate가 존재할 수 없다. \(\square\)

# Part XI. Operational Impossibility Boundaries — COLD proof bodies externalized

Active consequences only:

1. unrestricted semantic equivalence for arbitrary Turing-complete programs is not a total decidable kernel primitive;
2. bounded queries over unrestricted black-box objectives cannot guarantee universal global optimality;
3. equivalence/superiority claims therefore remain model/scope/evidence-qualified.

Full reductions/proofs `I1/I2` are in the COLD formal appendix and are not required in ordinary active context.

---
# Part XII. Library and Composite Formal Binding

## 21. Standard Library Contract

Internal Standard Library의 모든 reusable object는 다음 contract를 가져야 한다.

---

## THEOREM T-LIB-1 — Library theorem status is dependency-closed

**Proof.** proof soundness는 모든 premise가 유효한 interpretation에 대해서만 transfer된다. premise 하나의 validity domain 밖에서는 entailment premise가 확보되지 않는다. \(\square\)


## 22. Mount Selection Is an Optimization Problem

---

## THEOREM T15 — Well-founded structural flattening terminates

**Proof.** well-founded relation에는 ordinal/natural ranking에 대응하는 감소 measure를 둘 수 있다. finite graph 안의 maximal-rank macro를 치환할 때 global multiset rank가 well-founded multiset order에서 감소한다. 무한 descending chain이 없으므로 flatten은 종료한다. finite DAG recipe system은 이 조건의 특수경우다. \(\square\)

---

