# 알만알 14.30 — Witnessed Residual Closure / Fresh-Witness Kernel Candidate

> **Status:** Whole-System Mathematical / Logical Recursive Improvement Candidate — **NOT CANON**  
> **Parent:** 알만알 14.29 — Residual Execution Compression / Transition-Class Aggregation Closure
> **Parent Library:** 알만알 14.22 Internal Standard Library snapshot
> **Scope:** 14.29 residual execution-compression closure를 보존하고, residual audit completion, representation lock, extra-finalization lease를 evidence-bound/Pareto-safe/atomic fresh-witness semantics로 harden한다. 새 subsystem 없이 기존 evaluator/PLANNING/finalization 경계만 수정한다.
> **Primary objective:** `ProblemOrExistingAlgorithm -> BetterAlgorithm`. 새 알고리즘 합성뿐 아니라 기존 알고리즘의 개선·수리·최적화·통합을 frozen objective/constraints 아래 정식 1급 작업으로 다룬다.  
> **Non-claim:** 이 판본 자체는 ALMANAL의 경험적 behavioral superiority를 증명하지 않는다.  
> **Proof status:** 아래 정리는 통상적 수학 증명/증명 스케치로 제시한다. Lean/Coq/Isabelle 등 proof assistant에 의한 machine verification은 아직 주장하지 않는다.

---

## 0. Formal Status Vocabulary

모든 문장은 다음 중 하나로 태깅한다.

\[
Status\in
\{
DEF,\ ASSUMPTION,\ RULE,\ INVARIANT,\ THEOREM,\ COROLLARY,\ POLICY,\ EMPIRICAL,\ IMPOSSIBILITY
\}
\]

- `DEF`: 정의.
- `ASSUMPTION`: 정리의 전제로 명시적으로 채택한 가정.
- `RULE`: 허용된 형식적 추론/전이 규칙.
- `INVARIANT`: 모든 conformant execution이 보존해야 하는 상태 성질.
- `THEOREM`: 정의·가정·규칙에서 증명된 명제.
- `COROLLARY`: 정리의 직접 귀결.
- `POLICY`: 계산비용/탐색효율을 위한 설계 선택. 논리적 진리가 아니다.
- `EMPIRICAL`: 관측/실험으로만 평가되는 명제.
- `IMPOSSIBILITY`: 일반적으로 보장할 수 없음을 증명하거나 기존 정리에서 귀결한 경계.

\[
\boxed{POLICY\neq THEOREM,\quad EMPIRICAL\neq FORMAL\_PROOF}
\]



## 0.0.1 Official Algorithm Lifecycle Objective

\[
\boxed{ProblemOrExistingAlgorithm\rightarrow BetterAlgorithm}
\]

\[
AlgorithmWorkMode\in\{SYNTHESIZE,IMPROVE,REPAIR,OPTIMIZE,CONSOLIDATE\}
\]

`BetterAlgorithm`은 frozen objective, protected constraints, evidence/oracle contract, cost/resource boundaries에 상대적인 개선을 뜻한다. `ImproveExistingAlgorithm != RegenerateFromScratchRequired`.

## 0.1 Conformance Profiles

### DEF 0.1.1 — SPEC profile

`SPEC`은 수학적으로 정의된 state/operator contract가 있으나 일부 operator implementation이 abstract relation으로 남을 수 있는 profile이다.

\[
SPEC(\mathfrak M)
\iff
WellDefinedSemantics(\mathfrak M)
\land
ContractsClosed(\mathfrak M)
\]

`SPEC`은 **meta-algorithm specification/framework**라는 지위를 준다. 이것만으로 concrete executable program이라고 부르지 않는다.

### DEF 0.1.2 — EXEC profile

required operator 집합을 \(Req(P)\)라 하고 각 operator의 implementation map을 \(Impl(F)\)라 한다.

\[
EXEC(\mathfrak M,P)
\iff
SPEC(\mathfrak M)
\land
\forall F\in Req(P),\ Effective(Impl(F))
\land
TotalizedFailure(F)
\land
FiniteExecution(P)
\]

여기서 `TotalizedFailure`는 내부 실패/timeout/undefined를 caller에게 explicit terminal status로 올리는 것을 뜻한다.

### IMPORTANT

\[
SPEC\not\Rightarrow EXEC
\]

\[
EXEC\not\Rightarrow BehavioralSuperiority
\]


### INVARIANT I-EXEC-WITNESS — Contract text is not enforcement

`OperatorRealization`의 `TerminationOrTimeoutContract`가 문자열로 존재하는 것만으로 `Effective(Impl(F))`를 만족했다고 판정하지 않는다.

\[
TerminationContractRef(F) \neq TerminationEnforcementWitness(F)
\]

EXEC admission은 최소:

\[
ImplementationRef(F)
\land TerminationEnforced(F)
\land FailureTotalized(F)
\]

를 요구한다. 따라서 “timeout=1s”라고 문서에 써 둔 것과 실제 timeout/cancellation/process boundary가 있는 것은 다른 상태다.

# Part 0-P. Portable Self-Bootstrap Semantics

## P.1 Source Artifact vs Operational ALMANAL Distribution

### DEF P.1.1 — Development source

\[
SourceALMANAL=
(CoreFormalSource,InternalLibrarySource,ProofLedger,RuntimeReference)
\]

는 개발·감사·증명 추적용 artifact 집합이다.

### DEF P.1.2 — Portable distribution

\[
PortableDist=
(
Bootstrap,
RuntimeContract,
CapabilitySchema,
OperationalRules,
CompactResidentCapsules,
ConformanceManifest
)
\]

는 **외부 ALMANAL 파일 없이도 실행 시작에 필요한 operational semantics를 담는 self-contained distribution**이다.

### INVARIANT P-SOURCE-DIST

\[
PortableDist \neq SourceALMANAL
\]

portable compilation은 proof ledger와 모든 explanatory text를 반복 포함할 필요가 없다.

### TYPE_GUARD P-EQUIV

\[
CompiledFrom(SourceALMANAL,PortableDist)
\not\Rightarrow
FormalSemanticEquivalence(SourceALMANAL,PortableDist)
\]

완전 동치는 별도 equivalence proof가 있을 때만 주장한다.

Portable distribution의 기본 claim은 **operational conformance**, not full proof-source equivalence다.

### INVARIANT P-ARTIFACT-SURFACE

Top-level release artifact는 독립 consumer/use-path가 있을 때만 추가한다. 중간 측정·진단·검증 산출물은 기본적으로 별도 top-level 파일이 아니라 **one release evidence ledger**의 record다.

기본 release surface:

```text
PORTABLE        single-file runtime distribution
SOURCE_BUNDLE   active source + COLD source + one evidence ledger
RUNTIME_BUNDLE  executable reference runtime + tests
```

`MeasurementResult`, `Diagnosis`, `ReMeasurement`, `CostProfile`, `VerificationResult`가 각각 별도 사용자-facing 파일일 필요는 없다.

\[
IntermediateRecordExists
ot\Rightarrow TopLevelArtifactRequired
\]

### POLICY P-ONE-LEDGER

동일 release/epoch의 measurement, causal diagnosis, patch, re-measurement, verification, cost, commit evidence는 가능한 한 하나의 append-only/versioned ledger에 통합한다. 별도 export는 외부 소비자가 실제로 요구할 때만 한다.

---

## P.2 Runtime Is Mandatory, Backend Is Substitutable

### INVARIANT P-RUNTIME-MANDATORY

모든 conforming portable run \(r\)에 대해:

\[
PortableConformantRun(r)
\Rightarrow
InstantiatedRuntimeState(r)
\]

즉 “문서를 참고해 대충 비슷하게 생각함”은 portable conformance가 아니다.

### DEF P.2.1 — Backend profile

\[
BackendProfile\in
\{
NATIVE,
TOOL\_AUGMENTED,
REFERENCE\_EXEC,
HARDENED
\}
\]

순서는 enforcement strength의 **설계상 profile order**이며 일반 behavioral quality order를 뜻하지 않는다.

- `NATIVE`: 동일 추론 host 내부 state/checkpoint로 runtime contract를 구현.
- `TOOL_AUGMENTED`: NATIVE + 실제 tool/retrieval/code/persistence 일부.
- `REFERENCE_EXEC`: `ALMANAL-RUNTIME-CONTRACT/1`을 구현하는 witnessed external runtime이 핵심 gate를 enforce.
- `HARDENED`: conformant external runtime + strong isolation/enforcement boundary.

## P.3 Host Capability Manifest

### DEF P.3.1

\[
CapabilityRecord=
(
Capability,
Availability,
Enforcement,
WitnessBasis,
WitnessRef,
Protocols,
Limitations
)
\]

\[
Availability\in\{AVAILABLE,UNAVAILABLE,UNKNOWN\}
\]

\[
WitnessBasis\in
\{
SELF\_DECLARED,
OBSERVED\_INTERFACE,
EXECUTED,
EXTERNAL\_ATTESTATION
\}
\]

### MINIMUM portable capabilities

\[
MinCap=
\{
REASON,
CONTEXT\_STATE,
STRUCTURED\_OUTPUT
\}
\]

여기서 `CONTEXT_STATE`는 current run 동안 finite tagged checkpoint를 유지하는 능력이며 durable memory를 요구하지 않는다. `STRUCTURED_OUTPUT`은 ordinary text 안의 labeled record도 포함하며 vendor-specific schema/JSON API를 전제하지 않는다.

### INVARIANT P-UNKNOWN

\[
UNKNOWN \neq AVAILABLE
\]

unknown capability는 binding에 사용하지 않는다.

### DEF P.3.2 — Effectful capability

외부 world/state에 의존하거나 효과를 발생시키는 capability:
`RETRIEVAL`, `CODE_EXECUTION`, `TOOL_CALLING`, `PERSISTENCE`, `TOKEN_COUNT`,
`EXTERNAL_VERIFICATION`, `EXTERNAL_RUNTIME`, `PROCESS_ISOLATION`, `MACHINE_PROOF`.

### INVARIANT P-EFFECT-WITNESS

effectful capability를 tool/external enforcement로 binding하려면 단순 self-declaration이 아니라 최소 `OBSERVED_INTERFACE`, `EXECUTED`, 또는 `EXTERNAL_ATTESTATION` witness가 필요하다.

이는 internal reasoning capability의 최소 bootstrap assumption과 외부효과 capability를 구분한다.

---

## P.4 Brand / Vendor Independence

### DEF P.4.1 — Capability-equivalent manifests

host identity/vendor/model-name field를 제외한 capability records가 동일한 manifests \(m_1,m_2\)를:

\[
m_1 \equiv_{cap} m_2
\]

라 한다.

### INVARIANT P-NO-BRAND-BRANCH

portable binding function \(Bind\)는 host brand/name이 아니라 capability records와 protocol witness만 소비한다.

## P.5 External Runtime Licensing

### DEF P.5.1 — Conformant external runtime witness

external runtime이 `REFERENCE_EXEC` profile을 얻으려면:

1. capability available,
2. non-self-declared witness,
3. enforcement \(\in\{EXTERNAL,HARDENED\}\),
4. protocol list에 `ALMANAL-RUNTIME-CONTRACT/1`,
5. required runtime gates에 대한 conformance.

### INVARIANT P-NO-RUNTIME-LAUNDER

generic storage/program/tool 존재만으로 `REFERENCE_EXEC` label을 부여하지 않는다.

\[
ExternalProgramExists
\not\Rightarrow
ALMANALExternalRuntime
\]

## P.6 Validation Ceiling

### DEF P.6.1

\[
ValidationGrade\in
\{
SELF\_CHECKED,
TOOL\_GROUNDED,
EXTERNAL\_VERIFIED,
MACHINE\_VERIFIED
\}
\]

### RULE P-VALIDATION-CEILING

actual exported validation grade는 bound capabilities가 허용하는 ceiling을 넘지 못한다.

- same-host only → `SELF_CHECKED` ceiling.
- witnessed tool evidence available → ceiling may reach `TOOL_GROUNDED`.
- witnessed external verifier → ceiling may reach `EXTERNAL_VERIFIED`.
- actual machine-proof capability → ceiling may reach `MACHINE_VERIFIED`.

**Ceiling은 achieved grade가 아니다.** 실제 run에서 해당 evidence/operator가 수행되어야 그 grade를 획득한다.

### INVARIANT P-SAME-HOST

same-host challenge/review는 search diversity로 사용할 수 있으나 independent verification으로 label하지 않는다.

---

## P.7 Native Runtime Construction

### DEF P.7.1 — Host-sufficient

host \(h\)가 다음을 수행할 수 있으면 `HostSufficient(h)`라 한다.

1. finite portable text를 interpret,
2. finite structured runtime state를 context에 유지,
3. finite structured output 생성,
4. bounded reasoning step을 실행,
5. explicit terminal status를 반환.

### CONSTRUCTION P-NATIVE

`HostSufficient(h)`이면 portable file의 finite bootstrap algorithm으로:

1. `CapabilityManifest` 생성,
2. `RuntimeState` 생성,
3. task/baseline/criterion freeze,
4. finite budget 부여,
5. legal stage progression,
6. generate/challenge/repair/evaluate,
7. verification scheduling,
8. terminal extraction

을 host-internal realization으로 구성한다.

### THEOREM P-NATIVE-BOOT — Conditional

\[
HostSufficient(h)
\land
PortableOperationallyComplete(D)
\Rightarrow
\exists r:\ NativeRuntimeBoot(h,D,r)
\]

**Proof body:** COLD appendix (14.7 Proof Bodies).

### NON-CLAIM

이 정리는 임의의 AI가 실제로 문서를 충실히 따르거나 충분한 context/state fidelity를 가진다는 empirical guarantee가 아니다.

### ASSUMPTION P-COOPERATIVE-HOST

`NATIVE` backend의 기본 threat model은 **cooperative-but-fallible host**다. 즉 host가 portable/runtime contract를 따르려 시도하지만 실수·망각·추론오류는 할 수 있다고 가정한다.

고의로 실행하지 않은 작업을 실행했다고 허위보고하거나, 존재하지 않는 tool/evidence를 의도적으로 조작하는 Byzantine/malicious host는 `NATIVE` 보장범위 밖이다. 그러한 위협에는 `REFERENCE_EXEC/HARDENED`와 외부 evidence boundary가 필요하다.

---

## P.8 Portable Runtime Card

continuation-safe compact state는 최소:

\[
RuntimeCard=
(
EpochID,
Profile,
ValidationGrade,
TaskRef,
BaselineRef,
CriterionRef,
Stage,
StepsRemaining,
VerificationStatus,
MountedCapsules,
Status,
Residuals
)
\]

를 포함한다.

### INVARIANT P-CARD-FREEZE

continuation checkpoint에서 `TaskRef`, `BaselineRef`, `CriterionRef`, `EpochID`를 잃지 않는다.

chain-of-thought 자체를 runtime card에 저장할 필요는 없다.

---

## P.9 Portable Operational Completeness

portable distribution은 최소 다음을 self-contained로 포함해야 한다.

1. BOOT procedure,
2. mandatory runtime principle,
3. capability schema,
4. stage machine,
5. task/baseline/criterion freeze,
6. candidate/challenge/repair/evaluate operators,
7. verification scheduling,
8. validation-grade honesty,
9. compact resident capabilities,
10. failure/terminal statuses,
11. external runtime protocol identifier,
12. machine-readable conformance manifest.

### DEF P.9.1

위 항목이 모두 존재하고 internal cross-references가 닫혀 있으면:

\[
PortableOperationallyComplete(D)
\]

라 한다.

manifest가 항목 이름을 **자기 자신 안에 나열하는 것만으로** body presence를 증명하지 않는다. body와 manifest는 별도로 lint한다.

---

## P.10 Portable Compilation Cost

### POLICY P-PORTABLE-COMPILE

proof/development source의 반복 전송 대신 operational projection을 사용해 context cost를 줄인다.

단:

\[
SmallerOperationalArtifact
\not\Rightarrow
EqualBehavioralPerformance
\]

compression이 reasoning quality를 보존하는지는 empirical cross-host benchmark 대상이다.

token count는 provider tokenizer가 있을 때 실제 counter를 쓰며, `chars/4` 등은 rough reporting estimate일 뿐 hard theorem이 아니다.

---


# Part I. Mathematical Universe

## 1. Tagged Object Universe

### DEF 1.1 — Type universe

타입 집합을 \(\mathbb T\)라 한다.

\[
\mathbb T=
\{
CLAIM,OBSERVATION,REPORT,HYPOTHESIS,FORMAL\_RESULT,
MODEL,SIMULATION,PLAN,ALGORITHM,RECIPE,STATE\_UPDATE,
EVALUATION,CERTIFICATE,CONFLICT,MEMORY,\ldots
\}
\]

각 \(T\in\mathbb T\)에 대해 값 집합 \(V_T\)를 두고 전체 객체 공간을 tagged disjoint union으로 정의한다.

\[
V=\bigsqcup_{T\in\mathbb T}V_T
\]

따라서 한 typed value의 **syntactic type tag**는 유일하다.

### DEF 1.2 — Semantic referent

서로 다른 typed object가 같은 외부 의미대상을 지시할 수 있으므로 별도의 부분함수를 둔다.

\[
Ref:V\rightharpoonup \mathcal R
\]

가능하다:

\[
x\in V_T,\ y\in V_U,\ T\neq U,\quad Ref(x)=Ref(y)
\]

따라서 13.5의

\[
Type(x)\neq Type(y)\Rightarrow x\not\equiv y
\]

를 일반 수학명제로 사용하지 않는다.

---


## 1.5 Meta-Ontology / Name-Licensing Discipline

### DEF 1.5.1 — Concept license

어떤 object/절차 \(x\)를 category name \(C\)로 export하려면:

\[
License(x,C)=
(
Definition_C,
NecessaryConditions_C,
Witnesses,
Counterconditions,
Status
)
\]

를 갖는다.

### RULE O-NAME

\[
ExportAs(x,C)
\Rightarrow
Definition_C(x)
\land
NecessaryConditions_C(x)
\]

필요조건의 충족이 미확정이면:

\[
Status\in\{CANDIDATE,PARTIAL,UNKNOWN\}
\]

으로 낮춘다.

### INVARIANT I-NAME-NO-LAUNDER

수식, 명칭, 모듈명, 반복 사용은 concept membership의 증거가 아니다.

\[
NamedAs(C)\not\Rightarrow IsA(C)
\]

이 식은 세계에 대한 경험명제가 아니라 `O-NAME` 없는 **명칭→타입 promotion 금지**를 나타낸다.

### DEF 1.5.2 — Mandatory ontology targets

최소 다음 category는 항상 name-license audit 대상이다.

\[
\{
ALGORITHM,
META\_ALGORITHM,
PROOF,
AXIOM,
THEOREM,
VALIDATION,
INDEPENDENCE,
EVIDENCE,
IMPROVEMENT,
RECURSION,
EQUIVALENCE,
OPTIMUM
\}
\]

## 2. No-Implicit-Coercion Type Discipline

### DEF 2.1 — Typing judgment

\[
\Gamma\vdash x:T
\]

는 환경 \(\Gamma\)에서 \(x\)가 타입 \(T\)임을 뜻한다.

### RULE T-ID

\[
\frac{x:T\in\Gamma}{\Gamma\vdash x:T}
\]

### DEF 2.2 — Explicit promotion/coercion

명시적 promotion rule은 부분함수 또는 관계:

\[
c_{T\to U}:V_T\rightharpoonup V_U
\]

와 적용조건 \(Pre_c(x)\)를 가진다.

### RULE T-PROMOTE

\[
\frac{
\Gamma\vdash x:T
\qquad
c_{T\to U}\in\mathcal C
\qquad
Pre_c(x)
}{
\Gamma\vdash c_{T\to U}(x):U
}
\]

### INVARIANT I-TYPE-1 — No implicit promotion

\(T\neq U\)이고 허용된 coercion derivation이 없으면:

\[
\Gamma\vdash x:T
\not\Rightarrow
\Gamma\vdash x:U
\]

# Part II. Task and Algorithm Semantics

## 3. Formal Task Specification

### DEF 3.1 — Task

하나의 task를

\[
P=
(
X,Y,\mathcal A,
H,Q,\preceq_Q,
E,\Delta,C,
Scope
)
\]

로 정의한다.

- \(X\): input/state domain.
- \(Y\): output/action domain.
- \(\mathcal A\): admissible algorithm representation space.
- \(H=\{h_1,\ldots,h_m\}\): hard constraints/invariants.
- \(Q=(q_1,\ldots,q_k)\): quality metrics.
- \(\preceq_Q\): quality preorder.
- \(E\): evaluation contract.
- \(\Delta\): perturbation / uncertainty model.
- \(C\): resource/cost model.
- `Scope`: claim validity domain.

### DEF 3.2 — Algorithm semantics

알고리즘 \(a\in\mathcal A\)의 의미는 task에 상대적인 partial stochastic transducer로 둔다.

\[
\llbracket a\rrbracket_P:
X\rightharpoonup \mathcal D(Y_\bot)
\]

여기서 \(Y_\bot=Y\cup\{\bot\}\), \(\bot\)은 failure/nontermination을 나타낸다.

결정론적 알고리즘은 point distribution 특수경우다.

### DEF 3.3 — Feasibility

\[
Feasible_P(a)
\iff
\bigwedge_{i=1}^{m} h_i(a)
\]

hard constraint 위반 algorithm은 quality가 높아도 accepted improvement가 아니다.

---


## 3.5 Natural-Language / Formalization Boundary

### DEF 3.5.1 — Interpretation relation

자연어 task \(u\)에서 formal task \(P\)로의 mapping은 일반적으로 단일한 진리함수라고 가정하지 않는다.

\[
Interpret(u)\subseteq \mathcal P
\]

candidate formalization \(P\in Interpret(u)\)는 다음 certificate를 갖는다.

\[
FormalizationCert=
(
SourceRef,
CandidateP,
Ambiguities,
PreservedConstraints,
DroppedAssumptions,
AddedAssumptions,
UserOrOracleChecks,
Residual
)
\]

### INVARIANT I-FORMALIZE-NO-INVENT

명시되지 않은 assumption을 추가하면 `AddedAssumptions`에 기록해야 하며 source fact처럼 승격하지 않는다.

### POLICY P-FORMALIZE-BRANCH

material ambiguity가 결과를 바꿀 수 있고 budget이 허용되면 하나를 몰래 고르지 않고 multiple formalizations를 branch/evaluate한다.


## 4. Quality Is a Preorder, Not an Uncalibrated Sum

13.5의

\[
Capability+Robustness+Generalization-\cdots
\]

형식은 서로 다른 단위의 값을 임의로 더하는 경우 수학적 의미가 없다.

### DEF 4.1 — Quality vector

모든 metric의 방향을 “클수록 좋음”으로 정규화했다고 하자.

\[
Q_P(a)=(q_1(a),\ldots,q_k(a))\in\overline{\mathbb R}^k
\]

### DEF 4.2 — Protected Pareto dominance

보호 metric index 집합 \(J\subseteq\{1,\ldots,k\}\)에 대해:

\[
a'\succeq_{P,J}a
\iff
Feasible_P(a')
\land
\forall j\in J,\ q_j(a')\ge q_j(a)
\]

strict improvement:

\[
a'\succ_{P,J}a
\iff
a'\succeq_{P,J}a
\land
\exists j\in J,\ q_j(a')>q_j(a)
\]

Complexity, runtime, maintenance cost는 별도의 metric으로 넣어 방향을 뒤집는다.  
예:

\[
q_{complexity}(a)=-Complexity(a)
\]

### POLICY P-COMPLEXITY

동일한 protected behavior를 제공한다는 충분한 근거가 있을 때 더 작은 representation을 선호한다.

이것은 논리적 공리가 아니라 optimization policy다.

---

# Part III. ALMANAL as a Transition System

## 4.5 Effective Meta-Algorithm Criterion

### ASSUMPTION A-EFFECTIVE

다음을 가정한다.

1. task/spec/state/object는 finite strings로 encoding 가능하다.
2. 각 stage implementation은 admitted runtime state에서 **next state 또는 explicit terminal failure/status를 유한 계산으로 반환**한다. 즉 undefined/hanging branch는 wrapper level에서 totalized된다.
3. 각 stage의 내부 계산은 computable function 또는 computable randomized kernel이다.
4. external tool이 필요한 경우 tool은 explicit oracle interface로 표시한다.
5. `I-STEP`에 의해 stage-transition sequence 자체도 finite다.
6. terminal extraction `Out`은 computable하다.

### DEF 4.5.0 — Operator realization record

\[
OperatorRealization(F)=
(
AbstractSignature,
ImplementationRef,
Encoding,
TerminationOrTimeoutContract,
OracleDependencies,
RandomnessSource,
FailureTotalization,
Version
)
\]

`SPEC`에서는 `ImplementationRef`가 absent일 수 있다. `EXEC`에서 required operator는 absent일 수 없다.

### DEF 4.5.1 — Synthesis function

\[
Synth_{\mathfrak M}:
Enc(P)\times Enc(B)
\to
Enc(\mathcal A)\times Enc(Certificate)\times Status
\]

를 terminal `Out`이 반환하는 synthesis mapping으로 정의한다.

### THEOREM T0 — ALMANAL is an effective meta-algorithm under A-EFFECTIVE

`A-EFFECTIVE`와 finite termination이 성립하면 \(Synth_{\mathfrak M}\)은 admitted finite-budget input에 대해 total computable function(또는 randomized algorithm)이다. external oracle을 쓰는 경우 해당 oracle에 상대적인 oracle algorithm이다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### ASSUMPTION A-REF

1. algorithm representation alphabet \(\Sigma\)는 finite.
2. representation length bound \(L<\infty\).
3. parser/typechecker \(Parse_P:\Sigma^{\le L}\to \mathcal A\cup\{INVALID\}\)는 total computable.
4. feasibility predicate \(Feasible_P(a)\)는 bounded candidate에 대해 decidable.
5. protected quality evaluator \(Q_P(a)\)는 bounded candidate에 대해 exact computable.
6. quality preorder \(\preceq_Q\) 비교가 decidable.

### DEF 4.6.1 — Finite candidate language

\[
\mathcal A_{P,L}
=
\{Parse_P(w):w\in\Sigma^{\le L},\ Parse_P(w)\neq INVALID\}
\]

finite alphabet + finite length bound이므로 \(\mathcal A_{P,L}\)는 finite다.

### DEF 4.6.2 — `ALMANAL_REF`

1. \(w\in\Sigma^{\le L}\)를 lexicographic order로 전부 enumerate.
2. `Parse_P(w)`가 valid algorithm이면 semantic duplicate representation은 canonicalize 가능.
3. \(Feasible_P(a)\)인 candidate만 유지.
4. 모든 유지 candidate의 \(Q_P(a)\)를 exact evaluate.
5. \(\preceq_Q\)의 maximal candidate set \(Front_{P,L}\)를 반환.
6. certificate에 \(L,\Sigma,Parse,Q\), enumeration completion을 기록.

### THEOREM T-REF-TERM — Reference synthesis terminates

`A-REF` 아래 `ALMANAL_REF(P,L)`은 종료한다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### THEOREM T-REF-OPT — Bounded global Pareto maximality

`ALMANAL_REF`가 반환한 모든 \(a^*\in Front_{P,L}\)에 대해:

\[
\nexists a\in\mathcal A_{P,L}:
Feasible_P(a)\land a\succ_{P,J}a^*
\]

**Proof body:** COLD appendix (14.7 Proof Bodies).

### COROLLARY T-REF-META — Constructive meta-algorithm witness

`A-REF`를 만족하는 task class에서 `ALMANAL_REF`는 task specification을 입력받아 algorithm artifact를 산출하는 **구체적인 executable meta-algorithm**이다.

### DEF 4.6.3 — Practical ALMANAL relation

일반 ALMANAL runtime은 `ALMANAL_REF`의 전수열거를 요구하지 않는다. 대신:

\[
ALMANAL_{practical}
=
BudgetedSearchApproximation(ALMANAL_{REF})
\]

라는 설계관계를 둔다. 이는 quality approximation ratio를 자동 보장한다는 뜻이 아니다.

### IMPORTANT

\[
ReferenceOptimalWithin(\mathcal A_{P,L})
\not\Rightarrow
GloballyOptimalOutside(\mathcal A_{P,L})
\]

representation language/parser/evaluator 자체가 잘못되면 reference optimum도 실제 목표와 어긋날 수 있다.


## 5. Meta-Algorithm Definition

### DEF 5.1 — ALMANAL runtime

ALMANAL을 labelled transition system으로 정의한다.

\[
\mathfrak M=
(
\mathcal S,s_0,\Lambda,\to,\mathcal I,\rho,Out
)
\]

- \(\mathcal S\): runtime states.
- \(s_0\): initial state constructor.
- \(\Lambda\): transition labels.
- \(\to\subseteq\mathcal S\times\Lambda\times\mathcal S\): legal transition relation.
- \(\mathcal I\): required invariant predicates.
- \(\rho\): well-founded resource ranking function.
- \(Out\): terminal extraction.

### DEF 5.2 — Runtime state

\[
s=
(
\zeta,\Gamma,\mathcal O,\mathcal E,\mathcal C,\mathcal V,
\mathcal Mnt,b,H,status
)
\]

- \(\zeta\): frozen semantic/evaluation snapshot.
- \(\Gamma\): type/schema environment.
- \(\mathcal O\): typed object store.
- \(\mathcal E\): evidence/provenance graph.
- \(\mathcal C\): candidate set.
- \(\mathcal V\): certificate set.
- \(\mathcal Mnt\): mounted capability/library/extension set.
- \(b\): resource budget vector, including mandatory logical-step budget \(b_{step}\in\mathbb N\).
- \(H\): immutable execution history/audit trace for the epoch.
- `status`: procedure status.

### DEF 5.3 — Stage labels

\[
\Lambda=
\{
PRESEAL,AUTOTUNE,SCOPE,MOUNT,FORMALIZE,COMPOSE,
GENERATE,CHALLENGE,REPAIR,VALIDATE,CONSOLIDATE,
REGRESSION,OUTPUT,STOP,INVALIDATE
\}
\]

stage name 자체는 semantic judgment가 아니다.

---

## 6. Frozen Semantic Identity

### DEF 6.1 — Epoch snapshot

\[
\zeta=
(
TaskSemantics,
EvaluationCriterion,
ProtectedInvariants,
Scope,
ProtocolVersion
)
\]

수학적 identity는 hash가 아니라 **canonical structured value 자체의 equality**로 둔다.

\[
SID(\zeta)=CanonicalEncode(\zeta)
\]

구현은 빠른 비교/audit를 위해:

\[
Fingerprint(\zeta)=Hash(SID(\zeta))
\]

를 쓸 수 있으나:

\[
Fingerprint(\zeta_1)=Fingerprint(\zeta_2)
\not\Rightarrow
SID(\zeta_1)=SID(\zeta_2)
\]

를 kernel theorem으로 가정하지 않는다. collision-free hash를 수학적 oracle처럼 사용하지 않는다.

### INVARIANT I-FREEZE

동일 epoch의 모든 비종료 전이에 대해:

\[
\zeta_{t+1}=\zeta_t
\]

material semantic change가 필요하면 유일한 legal action은:

\[
s_t\xrightarrow{INVALIDATE}s_{terminal}
\]

후 successor epoch에서 새로운 \(\zeta'\)를 만든다.

# Part IV. Provenance, Authority, Independence

## 7. Provenance as a DAG

### DEF 7.1 — Provenance graph

\[
G_{prov}=(V_{prov},E_{prov})
\]

각 object \(x\)의 evidence/source roots:

\[
Roots(x)\subseteq R_{source}
\]

### DEF 7.2 — Explicitly introduced roots

transform \(f\)가 이번 step에서 실제로 새로 ingest한 source root 집합을:

\[
NewRoots(f)\subseteq R_{source}
\]

라 한다. 각 원소는 별도의 source-ingestion record를 가져야 한다.

### RULE PROV-TRANSFORM

admitted transform

\[
y=f(x_1,\ldots,x_n)
\]

는:

\[
\boxed{
Roots(y)=
\left(\bigcup_{i=1}^{n}Roots(x_i)\right)
\cup NewRoots(f)
}
\]

를 만족해야 한다.

즉 ancestral root를 삭제할 수도 없고, 실제 ingest하지 않은 root를 임의로 만들어 provenance를 부풀릴 수도 없다.

### THEOREM T3 — Provenance non-laundering / non-fabrication

`PROV-TRANSFORM`만으로 생성된 임의의 finite derivation chain에서 조상 object의 provenance root는 후손 object에서 사라지지 않는다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### DEF 8.1

permission universe \(\mathcal P\)에 대해:

\[
Auth(x)\subseteq\mathcal P
\]

operator \(f\)의 explicit governance grant:

\[
Grant(f)\subseteq\mathcal P
\]

### DEF 8.2 — Authorized source envelope

\[
Envelope(f;x_1,\ldots,x_n)
=
Grant(f)\cup\bigcup_{i=1}^{n}Auth(x_i)
\]

### INVARIANT I-AUTH

\[
y=f(x_1,\ldots,x_n)
\Rightarrow
Auth(y)\subseteq Envelope(f;x_1,\ldots,x_n)
\]

Composition may union authority already inside the explicit envelope; it cannot create authority outside that envelope.

## 9. Validation Separation and Independence Evidence

서로 다른 model/실행/기관이라는 사실은 **독립성의 충분조건이 아니다.** 서로 다른 모델도 training data, architecture, evaluator, source를 공유할 수 있다. 따라서 관찰 가능한 separation과 더 강한 epistemic-independence claim을 분리한다.

### DEF 9.1 — Separation vector

certificate \(c\)에 대해:

\[
Sep(c)=
(
S_{role},
S_{execution},
S_{modelroot},
S_{evidenceroot},
S_{organization}
)
\in\{0,1,UNKNOWN\}^5
\]

- \(S_{role}\): producer와 validator role 분리.
- \(S_{execution}\): 별도 execution/context.
- \(S_{modelroot}\): declared underlying model root 분리.
- \(S_{evidenceroot}\): evidence-root overlap 부재/분리.
- \(S_{organization}\): 외부 기관/행위자 분리.

### DEF 9.2 — Dependency-overlap graph

validator/evidence source들의 known dependency를 graph \(G_{dep}\)로 두고:

\[
SharedDependency(u,v)
\]

를 model lineage, training/evidence source, execution context, evaluator 등 알려진 공통 root가 존재함으로 정의한다.

### DEF 9.3 — Independence status

\[
IndependenceStatus\in
\{
NOT\_INDEPENDENT,
SEPARATED\_BUT\_DEPENDENCE\_UNKNOWN,
INDEPENDENCE\_SUPPORTED\_SCOPED,
UNKNOWN
\}
\]

`INDEPENDENCE_SUPPORTED_SCOPED`는 사전에 선언된 dependency class에 대해 overlap audit가 통과한 경우에만 발급한다. 이는 통계적 독립의 절대증명이 아니라 **명시된 dependency model에 상대적인 certificate**다.

### THEOREM T5 — Agreement cannot manufacture separation

\[
SameModelRoot(v_1,v_2)\Rightarrow S_{modelroot}=0
\]

이므로 같은 model root의 agreement outcome만으로 \(S_{modelroot}=1\) 또는 `INDEPENDENCE_SUPPORTED_SCOPED`를 얻을 수 없다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### IMPORTANT CONVERSE FAILURE

\[
S_{modelroot}=1
\not\Rightarrow
EpistemicallyIndependent
\]

### POLICY P-SELF-CERT

material update에는 최소한 `role separation`을 요구하고, 필요한 assurance level이 외부 독립성을 요구하면 scoped dependency audit가 없는 한 `EXTERNALLY_INDEPENDENT_VALIDATION` 같은 label을 발급하지 않는다.

self-validation은 가능하지만 **separation/independence class를 과장할 수 없다.**

---

# Part V. Certificates and Epistemic Status

## 10. Typed Certificate

### DEF 10.1

\[
Certificate<T>=
(
SubjectRef,
CriterionSnapshotRef,
Scope,
Assumptions,
EvidenceRefs,
ProofRef,
AssessorRefs,
SeparationVector,
IndependenceStatus,
FormalStatus,
EmpiricalStatus,
ProcedureStatus,
Confidence,
Residual,
Version
)
\]

### DEF 10.2 — Axes

\[
FormalStatus\in\{PROVED,DISPROVED,UNPROVED,NOT\_APPLICABLE\}
\]

\[
EmpiricalStatus\in
\{SUPPORTED,REFUTED,INCONCLUSIVE,NOT\_TESTED,NOT\_APPLICABLE\}
\]

\[
ProcedureStatus\in
\{COMPLETE,DEGRADED,INCOMPLETE,BLOCKED,INVALIDATED\}
\]

서로 다른 axis를 하나의 “VALIDATED” scalar로 압축하지 않는다.

### INVARIANT I-CERT-MISSING

required field가 없으면 해당 positive status를 발급할 수 없다.

예:

\[
Missing(ProofRef)
\Rightarrow
FormalStatus\neq PROVED
\]

\[
Missing(EvidenceRefs)
\land EmpiricalEvidenceRequired
\Rightarrow
EmpiricalStatus\neq SUPPORTED
\]

# Part VI. Counterexamples and Challenge


## 10.4.1 Claimed Status ≠ Verified Status

`proof_ref`/`evidence_ref`는 **검증 대상의 위치**이지 검증 성공 그 자체가 아니다.

\[
ProofRefExists \not\Rightarrow ProofVerified
\]

\[
EvidenceRefExists \not\Rightarrow EvidenceSupportsClaim
\]

### DEF 10.4.1A — Verification Receipt

\[
VerificationReceipt=
(
CertificateRef,
SubjectRef,
CriterionSnapshotRef,
VerifierRef,
VerificationBasis,
Result,
Version
)
\]

\[
VerificationBasis\in
\{RUNTIME\_EVALUATOR,MACHINE\_PROOF,EXTERNAL\_REVIEW,STRUCTURE\_ONLY\}
\]

`STRUCTURE_ONLY`는 field/schema completeness만 보며 `PROVED` 또는 empirical `SUPPORTED`를 persistent acceptance용 verified status로 승격시키지 못한다.

### INVARIANT I-CERT-RECEIPT

material persistent revision은:

\[
PositiveCertificate(c)
\land RuntimeAdmitted(c)
\land Passed(VerificationReceipt(c))
\]

를 모두 요구한다.

formal `PROVED`를 persistence 근거로 사용할 때 verification basis는 machine proof 또는 명시적 external review여야 하며, empirical `SUPPORTED`는 runtime evaluator 또는 external review여야 한다.

## 10.5 Mandatory Meta-Ontology Challenge

### DEF 10.5.1

\[
X^{ont}:
ClaimOrArchitecture
\to
\{
DefinitionFailure,
CategoryOverclaim,
HiddenAssumption,
NonEffectiveOperator,
PseudoProof,
PseudoIndependence,
PseudoImprovement
\}
\]

### INVARIANT I-ONTOLOGY-CHALLENGE

다음이 material output에 등장하면 validation 전에 \(X^{ont}\) audit를 요구한다.

- 새 `THEOREM/AXIOM/PROOF` claim,
- 새 algorithm/meta-algorithm identity claim,
- 새 independence/validation label,
- recursive improvement claim,
- semantic equivalence/optimality claim.

### RULE O-DOWNGRADE

ontology audit의 necessary condition 하나라도 미충족이면 해당 category claim을 `PARTIAL/CANDIDATE/UNPROVED`로 강등한다. underlying artifact 자체를 자동 폐기하지는 않는다.

## 11. Counterexample Semantics

### DEF 11.1 — Universal claim counterexample

고정된 model/scope \(D\)에서 claim:

\[
\forall x\in D,\ \phi(x)
\]

의 counterexample은:

\[
x^\star\in D
\land
\neg\phi(x^\star)
\]

를 만족하는 \(x^\star\)다.

# Part VII. Resource-Bounded Termination

## 12. Ranking Function

13.5의 `FiniteBudget + StopRule`만으로는 termination이 논리적으로 따라오지 않는다. budget이 감소하지 않는 무한전이가 가능하기 때문이다.

### DEF 12.1 — Mandatory step budget

모든 nonterminal state에:

\[
b_{step}(s)\in\mathbb N
\]

을 둔다.

### INVARIANT I-STEP

모든 legal nonterminal transition:

\[
s\to s'
\Rightarrow
b_{step}(s')<b_{step}(s)
\]

### THEOREM T8 — Finite execution termination

초기 \(b_{step}(s_0)<\infty\)이고 `I-STEP`이 유지되면 모든 execution trace는 유한하다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### DEF 13.1

epoch 시작 전에 evaluation plan \(E_0\)을 seal한다.

\[
E_0=(Metrics,Estimator,TestDistribution,Holdout,Thresholds,Tolerances,Scope,Version)
\]

material change는 successor epoch만 허용한다.

---

## 14. Exact Accepted Revision

### DEF 14.1

모든 improvement-relevant secondary metric(복잡도, 유지비용 등)도 사전에 \(Q\)와 protected index set \(J\)에 포함한다.

exact evaluator가 가능한 경우:

\[
AcceptNonRegress(a'\mid a,P,J)
\iff
a'\succeq_{P,J}a
\]

실제 **improvement**를 주장하는 stronger predicate:

\[
AcceptImprove(a'\mid a,P,J)
\iff
a'\succ_{P,J}a
\]

quality vector 바깥의 outcome-dependent “secondary preference”를 사후에 끼워 넣지 않는다.

## 14.2 Baseline-Relative Acceptance and Pareto Non-Collapse

### INVARIANT I-BASELINE-ACCEPT

“improvement” execution은 candidate 집합 내부의 순위만으로 acceptance하지 않는다. frozen baseline \(a_0\)를 명시하고:

\[
AcceptImprove(a'\mid a_0,P,J)
\Rightarrow
a'\succ_{P,J}a_0
\]

를 요구한다.

### THEOREM T-BASELINE — Candidate-only ranking is insufficient for non-regression

candidate 내부에서 lexicographic maximum을 고르는 절차는 protected metric의 baseline non-regression을 일반적으로 보장하지 않는다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### INVARIANT I-PARETO-UNRESOLVED

baseline을 strict하게 개선하면서 서로 지배하지 않는 Pareto front가 둘 이상이고, precommitted selection policy가 없으면:

\[
StopReason=UNRESOLVED\_TRADEOFF
\]

로 반환한다. 사후 scalarization으로 임의 하나를 “최선”이라 부르지 않는다.


## 14.3 Output-Safe Shadow Baseline and Finalization Closure

### DEF 14.3.1 — Operational shadow baseline

enhanced route가 materialized/deterministic artifact를 생성할 때, 외부 frozen baseline이 없으면 optional elaboration 전에 least-sufficient direct/minimal route의 결과를 \(b_0\)로 freeze할 수 있다.

\[
OperationalShadowBaseline(b_0)
eq EmpiricalPlainCondition(b_0)
\]

같은 host/context 내부에서 만든 shadow baseline은 **output safety floor**일 뿐, 독립 paired experiment의 `PLAIN` 증거가 아니다.

### INVARIANT I-OUTPUT-BASELINE-FLOOR

최종 admissible set에는 frozen baseline을 fallback으로 보존한다. enhanced candidate \(c\)가 baseline을 대체하려면 frozen protected/task-relevant comparison axes에서 non-regression을 만족해야 한다. improvement를 주장하면 최소 한 축 strict improvement가 추가로 필요하다.

\[
ReplaceOutput(c,b_0)\Rightarrow c\succeq b_0
\]

\[
ClaimImprovement(c,b_0)\Rightarrow c\succ b_0
\]

`c`가 baseline에 strict-dominated이면 reject한다. 여러 non-dominated tradeoff가 남고 precommitted selector가 없으면 unknown winner를 강제하지 않고 baseline으로 fallback한다.

### RULE 14.3.2 — Bounded finalization closure

semantic correctness/protected validity가 확보된 deterministic artifact에는, cheap하고 affected proof boundary가 국소적인 경우 최종 dominance 비교 전에 equivalence-preserving simplification을 수행한다. 기본 rewrite class:

- already-derived intermediate reuse,
- algebraic collapse of equivalent expressions,
- dead/duplicated computation removal,
- unnecessary state/dependency removal.

rewrite 후 affected correctness/protected claims를 재검증한다. `SourceBytesDown != UniversalQualityUp`; raw byte count는 frozen task criterion에 포함되었거나 동등 산출물의 parsimony proxy로 명시된 경우에만 decision axis다.

### COROLLARY 14.3.3 — More cognition grants no output-regression license

추가 challenge/repair/search/verification 비용을 지불했다는 사실 자체는 baseline보다 열등한 artifact를 최종 출력할 권한을 주지 않는다.

### RULE 14.3.4 — Portable execution-shape closure

runtime/memory/throughput/resource efficiency가 material task axis인 algorithm/code artifact는 verified semantic simplification 뒤에 bounded execution-shape audit를 수행한다. 기본 ladder:

1. unnecessary materialization/state elimination,
2. single-pass / streaming reformulation,
3. safe in-place reuse and buffer-lifetime shortening,
4. locality-friendly representation and batchable independent work exposure,
5. cheap portable branch/data-parallel opportunity,
6. machine-specific intrinsics/pragmas/syscalls only under explicit high-performance admission.

`StructureBeforeMicroarchitecture`. 상위 rung은 하위 rung보다 복잡성/portability rent가 커질 수 있으므로 자동 진급하지 않는다. hardware-specific specialization은 correctness/protected portability를 보존하고, 그 추가 복잡성이 frozen performance criterion을 바꿀 만큼의 claim-matched evidence로 상환될 때만 선택한다. performance가 material axis가 아니거나 expected value가 낮으면 simpler portable rung에서 STOP한다.

### INVARIANT I-SPECIALIZATION-RENT

\[
Specialize(a') \Rightarrow PerformanceAxisMaterial \land ProtectedPortabilityPreserved \land EvidenceMatchedGainRepaysComplexityRent
\]

특정 ISA/SIMD/pragma/mmap/syscall은 resident default가 아니다. 알고리즘 표현에서 드러난 streaming/batchability/dataflow property와 특정 backend technique를 분리한다. `Vectorizable != MustVectorize`; `PotentiallyFaster != MeasuredFaster`.

### RULE 14.3.4a — Local I/O bottleneck closure

core computation이 semantic/structural simplification으로 충분히 싸진 뒤에만 I/O volume, formatting work, flush/call count가 remaining work 대비 material bottleneck 후보인지 검사한다. 기본 ladder는:

1. standard fast I/O 유지,
2. redundant formatting/flush/call 제거,
3. I/O volume이 material할 때 lightweight buffering,
4. custom parser/writer는 frozen Pareto frontier를 바꿀 만큼의 gain이 source/peak-memory/portability rent를 상환할 때만.

`CoreCheapCanExposeIO`; `IOVolumeMaterial -> AuditIO`; `CustomIO != Default`. 큰 범용 I/O template는 단지 더 빠를 수 있다는 이유로 채택하지 않는다. 추가 buffer/static array는 peak-memory/source 축의 실비용이며, structural I/O call/byte/formatting-work 감소는 analytic execution-cost evidence지만 exact wall time을 발명하지 않는다.

### RULE 14.3.5 — Analytic Pareto pre-screen / benchmark-last

optimization candidate는 가능한 한 code materialization/benchmark 전에 transformation-level로 비교한다. frozen axes에 대해 semantic feasibility, asymptotic work, reachable-state count, peak live-storage bound, pass/materialization/allocation count, source/artifact-size consequence를 label된 exact/bound/proxy 형태로 추론한다.

`STATIC_REJECT(c)` iff known correctness/protected defect가 있거나, 현재 frontier에 의해 provably dominated이거나, optimistic bound에서도 어느 material axis도 frontier를 개선할 수 없다. 이 경우 구현·컴파일·벤치 비용을 지불하지 않는다.

환경 종속 wall-runtime처럼 static reasoning이 target metric을 결정하지 못할 때만 empirical measurement를 admit한다. measurement는 그 결과가 candidate selection을 바꿀 수 있을 때만 decision-relevant하다. 반복 benchmark는 noise interval이 frozen material threshold와 겹칠 때만 확장한다. `BenchmarkEveryVariant = ForbiddenDefault`.

### INVARIANT I-GOAL-CONDITIONED-STATE

단일 goal을 위한 DP/search에서 사용 상태는 가능한 경우 `ForwardReachable ∩ BackwardCoReachable(Target)`로 제한한다. 모든 intermediate target/result를 계산하는 것은 recurrence가 가능하다는 이유만으로 정당화되지 않는다.

### INVARIANT I-PARETO-FRONTLOADED

runtime, peak memory, source bytes, produced-artifact bytes 및 task-declared cost axes가 material이면 candidate generation부터 별도 좌표로 보존한다. 사후 scalarization 없이 multi-axis structural reductions를 우선하며, exact/static axis는 empirical benchmark를 요구하지 않는다.

### RULE 14.3.6 — Decision-frontier liveness / mechanism-first measurement

optional hypothesis를 깊게 탐색하기 전에 최소한 `mechanism + affected Pareto axes + correctness obligation + static proof/bound path`를 선언한다. 단순한 “더 빨라질지도 모름”은 hypothesis admission 근거가 아니다.

`FrontierProgressWitness`는 다음 중 하나처럼 현재 선택문제를 실제로 바꾸는 외부화 가능한 진척이어야 한다: 새 invariant/bound, counterexample, correctness obligation discharge, hypothesis prune, verified frontier advance, required artifact milestone. 반복 benchmark/tool result/file write가 선택 frontier를 바꾸지 않으면 progress lease를 갱신하지 않는다.

benchmark는 아이디어 생성기가 아니라 **남은 empirical uncertainty의 판정기**다. static screen이 끝나지 않았거나 causal/execution mechanism이 특정되지 않았으면 실행하지 않는다. 동일 mechanism의 미세변형을 반복 측정하지 말고, 논리적 dominance/upper-bound로 먼저 제거한다.

`NoDecisionFrontierProgress -> bounded checkpoint/STOP`. task는 `max_no_frontier_progress_steps`를 hard budget과 함께 freeze한다.

### INVARIANT I-MECHANISM-BEFORE-MEASURE

\[
Benchmark(c) \Rightarrow StaticScreenComplete(c) \land MechanismIdentified(c) \land UnresolvedEmpiricalAxis(c) \land CanChangeSelection(c)
\]

---

## 15. Uncertain Evaluation

### DEF 15.1 — Simultaneous confidence intervals

각 protected metric \(j\)에 대해:

\[
q_j(a)\in[L_j(a),U_j(a)]
\]

가 모든 비교대상에 대해 동시에 성립하는 event를 \(\mathcal G\)라 하고:

\[
Pr(\mathcal G)\ge 1-\alpha
\]

라 가정한다.

### DEF 15.2 — Conservative dominance with tolerances

\[
a'\succeq^{CI}_{\delta}a
\]

iff:

\[
Feasible_P(a')
\]

및 모든 \(j\in J\)에 대해:

\[
L_j(a')\ge U_j(a)-\delta_j
\]

그리고 material improvement를 주장하려면 어떤 \(k\in J\)에 대해:

\[
L_k(a')>U_k(a)+\eta_k
\]

를 요구한다.

### THEOREM T10 — High-confidence bounded non-regression

event \(\mathcal G\) 위에서 accepted step은:

\[
q_j(a')\ge q_j(a)-\delta_j
\quad\forall j\in J
\]

를 만족하고, strict-gain metric \(k\)에 대해서는:

\[
q_k(a')>q_k(a)+\eta_k
\]

를 만족한다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### COROLLARY T10.1 — Cumulative drift bound

\(n\)개의 accepted uncertain step에 대해 event \(\mathcal G\) 위에서:

\[
q_j(a_n)
\ge
q_j(a_0)-\sum_{t=0}^{n-1}\delta_{t,j}
\]

따라서 tolerance를 허용하면 “monotonic”이라고 부르지 않고 **bounded-regression**이라고 부른다.

---


# Part VIII-A. Cognitive Economics — Global Metareasoning Governor

## 15.0 Principle

ALMANAL에서 **모든 추가 cognition은 비용 있는 action**이다.

\[
CognitiveAction\in
\{
Generate,
Challenge,
Repair,
Verify,
Search,
Retrieve,
Formalize,
Compress,
Checkpoint,
Tool,
SelfImprove,
ExternalizeRuntime,
Measure,
ObserveResult,
DiagnoseDirection,
ReMeasure,
FormalismAudit,\ldots
\}
\]

\[
MoreReasoning\not\Rightarrow BetterDecision
\]

\[
ImprovementPossible\not\Rightarrow ImprovementWorthDoing
\]

`VerificationEconomics`는 이 일반 원리의 특수한 부분이다.

---

## 15.1 Meta-State and STOP as an Action

현재 metalevel state를 \(x\)라 하자. \(x\)는 최소한 current task state, frozen criterion, evidence state, remaining budget, uncertainty summary를 포함한다.

현재 추가 cognition 없이 종료할 때 얻는 decision utility를:

\[
U_{stop}(x)
\]

라 한다.

**STOP은 항상 비교대상인 action**이다. 단 mandatory floor가 남아 있으면 stop은 admissible하지 않을 수 있다.

### DEF 15.1.1 — Cognitive action model

optional cognitive action \(a\in\mathcal A_c(x)\)에 대해:

- \(k(a)\ge0\): **decision utility와 같은 단위로 명시적으로 calibration된** cognitive/opportunity cost,
- \(r(a)\in\mathbb R_{\ge0}^m\): token/tool/end-to-end latency/compute/critical-path/money/step/context/storage/artifact-count/I-O 등 **서로 scalarize하지 않는 hard resource vector**,
- \(P(x'|x,a)\): action outcome에 따른 successor meta-state distribution.

remaining resource budget \(b\)에 대해:

\[
Feasible(a,b)\iff r(a)\le b
\]

는 componentwise inequality다.

### INVARIANT I-COG-UNIT

token 수, end-to-end latency, active compute, critical-path latency, tool call 수, 금액, context/memory, 저장공간, artifact count를 calibration 없이 utility와 더하지 않는다.

\[
ResourceVector\neq DecisionUtility
\]

utility conversion이 합의되지 않은 resource는 hard constraint 또는 별도 Pareto/lexicographic axis로 남긴다.

---

## 15.2 Exact Finite-Horizon Metareasoning

mandatory floor가 모두 해소되어 stop이 admissible하다고 하자.

\[
V_0(x,b)=U_{stop}(x)
\]

finite horizon \(h\ge1\)에서:

\[
V_h(x,b)=
\max
\left[
U_{stop}(x),
\max_{\substack{a\in\mathcal A_c(x)\\Feasible(a,b)}}
\left(
-k(a)+
\sum_{x'}P(x'|x,a)V_{h-1}(x',b-r(a))
\right)
\right]
\]

이다.

### THEOREM T-COG-BELLMAN — Finite-horizon optimality

finite state/action space, normalized transition probabilities, finite \(h\), commensurate \(k/U\), componentwise finite budget 아래 위 recurrence는 declared metareasoning model의 optimal expected utility를 산출한다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### IMPORTANT BOUNDARY

실제 LLM task에서 \(P,U,k\)를 정확히 아는 경우는 드물다.

따라서 reference runtime의 일반 `EconomyGovernor`는:

\[
\widehat{VOC}
\]

estimate를 사용하며 이를 theorem으로 승격하지 않는다.

`EXPECTED_VALUE` policy는 expected estimate를, `LOWER_BOUND` policy는 conservative lower estimate를 gate에 사용할 수 있다.

---

## 15.4 Mandatory Floor

protected invariant, 법적/안전상 hard constraint, persistence commit gate처럼 반드시 수행해야 하는 cognition을 \(M(x)\)라 한다.

\[
M(x)\neq\varnothing
\Rightarrow
StopAdmissible(x)=FALSE
\]

mandatory action은 optional VOC gate로 생략하지 않는다.

\[
Mandatory(a)\land \neg Feasible(a,b)
\Rightarrow BLOCKED/INCOMPLETE
\]

이지 `PASS`가 아니다.

### INVARIANT I-ECON-NO-LAUNDER

경제성은 hard constraint를 탈출하는 권한이 아니다.

\[
LowEstimatedVOC
\not\Rightarrow
PermissionToSkipMandatory
\]

---

## 15.5 Thin Economy Governor

경제기능 자체도 cognition이므로 비용이 있다.

### INVARIANT I-GOVERNOR-COST

\[
Cost(EconomyDecision)>0
\]

일 수 있음을 인정한다.

따라서 Economy Governor는 모든 action에 대해 새로운 recursive deliberation을 무한히 열지 않는다. reference policy는:

1. 이미 계산된/frozen estimate 사용,
2. cheap myopic gate 우선,
3. material decision에서만 deeper finite-horizon metareasoning,
4. governor 자체의 추가 분석도 동일 budget에 포함.

### POLICY P-ECON-THIN

경제기능은 별도 “경제뇌”처럼 무거운 독립 reasoner가 아니라 **control-plane gate**다.

output은 기본적으로:

```text
MANDATORY_EXECUTE
EXECUTE
SKIP_NONPOSITIVE_VOC
SKIP_MARGIN
SKIP_BUDGET
BLOCKED_MANDATORY_BUDGET
```

정도로 제한한다.

---

## 15.6 Adaptive Cognitive Schedule

고정된 “항상 Generate→Challenge→Repair→Verify 최대화” schedule을 요구하지 않는다.

\[
Schedule(x)
=
EconomicallyAdmittedActions(x)
+
MandatoryFloor(x)
\]

### SIMPLE / low-impact consequence

현재 output의 \(U_{stop}\)이 높고 추가 action의 estimated VOC가 낮으면:

\[
DirectAnswer
\]

가 정상적인 ALMANAL 실행이다.

### CREATIVE consequence

발산 단계에서 early challenge/verification이 candidate diversity를 훼손하여 expected utility를 낮춘다면 해당 action의 VOC는 낮거나 음수가 될 수 있다. 따라서:

```text
EXPLORE first
→ SELECT
→ late CANON/QUALITY audit
```

가 admissible하다.

창의 작업에 분석/감사용 schedule을 강제하지 않는다.

### HIGH-RISK consequence

decision impact/irreversibility가 hard policy에 의해 mandatory verification을 만들면 경제 governor가 이를 생략하지 못한다.

### NATIVE state-fidelity consequence

`CHECKPOINT` 또는 `EXTERNALIZE_RUNTIME`도 cognitive action이다.

state-loss risk를 줄이는 expected value가 checkpoint/externalization cost보다 클 때 실행하고, 장기 task에서 state fidelity가 material하게 불안정하면 mandatory floor로 승격할 수 있다.

---

## 15.7 Lifecycle Economics of Persistent Improvement

persistent feature/revision \(f\)의 개발·검증·유지비를 포함한다.

동일 decision-utility scale로 calibration 가능한 경우:

\[
LNPV(f)
=
-K_0(f)
+
E\left[
\sum_{t=1}^{N}
\delta^{t-1}
\left(
\Delta U_t(f)-K_t(f)
\right)
\right]
\]

- \(K_0\): one-time development + migration + validation decision cost,
- \(K_t\): recurring runtime/maintenance/complexity decision cost,
- \(\Delta U_t\): run \(t\)에서 feature가 주는 utility gain,
- \(N\): future exposure/run count random variable,
- \(0<\delta\le1\): frozen discount factor.

### POLICY P-LIFECYCLE-IMPROVE

non-mandatory persistent improvement는:

\[
LNPV(f)>\mu_{life}
\]

일 때만 accept 후보가 된다.

### Separate token break-even

utility와 token을 섞지 않고 token-only 투자회수도 별도 기록할 수 있다.

one-time token investment \(C_0^{tok}>0\), per-run savings \(S^{tok}>0\)이면:

\[
N_{BE}^{tok}
=
\left\lceil
\frac{C_0^{tok}}{S^{tok}}
\right\rceil
\]

이다.

이는 utility NPV와 별도 지표다.

---

## 15.8 Complexity Rent and Formalism Economics

persistent mechanism과 formal object 자체도 비용을 만든다.

\[
ComplexityRent(f)=
(
ContextOverhead,
RuntimeCalls,
MaintenanceSurface,
FailureSurface,
MigrationBurden
)
\]

서로 다른 단위는 vector로 유지한다.

### INVARIANT I-A11-ECON

새 formal object/module/profile은 다음 중 하나가 없으면 기본적으로 유지하지 않는다.

1. always-active runtime semantics에 필요,
2. protected defect class를 막음,
3. 여러 규칙을 더 작은 active context로 압축,
4. proof/audit에 독립 정보가 있음,
5. 실제 empirical value가 관측됨.

그 외는 `DELETE`가 default다.

### DEF 15.8.1 — Formal residency

\[
FormalResidency\in\{HOT,WARM,COLD,DELETE\}
\]

- `HOT`: 항상 활성화되어야 하는 최소 runtime contract.
- `WARM`: task/domain이 요구할 때만 mount.
- `COLD`: proof/audit/history용; ordinary execution context에 넣지 않음.
- `DELETE`: 현재 유지 근거가 없음.

핵심 경계:

\[
KnowledgeExists\not\Rightarrow KnowledgeMustBeResident
\]

그리고 mandatory HOT object를 제외하면:

\[
ActiveContext(f)
\]

자체가 비용 있는 선택이다.

### POLICY P-FORMALISM-ECONOMY

형식의 경제성을 평가하기 위해 또 다른 장문 meta-layer를 만들지 않는다. reference policy는 categorical keep criteria + exact context/storage footprint를 우선하고, 근거 없는 scalar utility를 발명하지 않는다.

### INVARIANT I-ARTIFACT-COUNT-COST

파일/배포물 개수 자체도 `ComplexityRent`를 만든다: discoverability, naming/version alignment, stale-file selection, duplicated evidence, packaging/checksum surface.

새 top-level artifact의 burden of proof는 추가 쪽에 있다. 기존 ledger/bundle에 의미 손실 없이 흡수 가능하면 새 파일을 만들지 않는다.

### INVARIANT I-MEASUREMENT-WARM

`MEASUREMENT_FEEDBACK`은 improvement/benchmark task에서 필요한 **WARM operator**다. ordinary task boot의 always-active/HOT operator로 취급하지 않는다.

\[
MeasurementCapabilityAvailable

ot\Rightarrow
MeasurementLoopActive
\]

---
## 15.9 Behavioral Evidence as an Economic Gate

문서 내부 정합성 개선과 실제 behavioral improvement를 분리한다.

### INVARIANT I-BEHAVIOR-EVIDENCE

\[
FormalRepair
\not\Rightarrow
BehavioralSuperiority
\]

`BehaviorallySuperior`, `CostProductive`, `LessOverconfident` 같은 empirical claim은 실제 paired observations 없이 positive status로 승격하지 않는다.

reference harness는 최소:

- 동일/통제된 task pair,
- plain vs ALMANAL condition,
- quality,
- overclaim,
- token/resource cost,

를 기록할 수 있다.

binary paired direction에 대해서는 exact sign test를 사용할 수 있으나:

\[
BenchmarkPass
\not\Rightarrow
UniversalSuperiority
\]

다. claim은 precommitted benchmark scope에 한정한다.

### POLICY P-NO-FORMALISM-FOR-ITS-OWN-SAKE

새 구조가 behavioral evidence를 아직 갖지 못했고 protected defect도 막지 않으면서 deployment/runtime complexity를 증가시킨다면, 추가 formal expansion의 burden of proof는 **추가 쪽**에 있다.

---


# Part VIII-B. Verification Economics — Specialization of Cognitive Economics

## 15.10 Verification as Cognitive Action

\[
VerificationAction\subset CognitiveAction
\]

검증은 특별대우받는 무료 단계가 아니다. Part VIII-A의 resource/VOC/mandatory-floor 규칙을 그대로 적용한다.

기존 verification scheduler는 **impact 구조를 이용해 verification-specific value estimate와 mandatory floor를 계산하는 specialization**으로 유지한다.

## 15.11 Verification Cost Has Multiple Units

검증 자체가 자원을 소비한다고 해서 서로 다른 단위를 바로 비교하지 않는다.

### DEF 15.11.1 — Verification action

\[
VAction=
(
Name,
TokenCost,
DecisionCostUtility,
ExpectedLossAvoidedUtility,
AffectedBy,
Tier,
MandatoryRule,
Version
)
\]

- `TokenCost(v)`: context/output/tool token 등 token-budget에 소비되는 양.
- `DecisionCostUtility(v)`: 검증 지연·복잡도·기회비용을 **decision utility와 동일한 단위로 변환한 값**.
- `ExpectedLossAvoidedUtility(v)`: 검증으로 의사결정 오류를 막아 줄 것으로 기대되는 scoped utility.
- `AffectedBy(v)`: 이 검증을 무효화할 수 있는 semantic/runtime dependency tags.
- `Tier(v) ∈ {STATIC,CANARY,TARGETED,FULL}`.

### INVARIANT I-VERIFY-UNIT

\[
ExpectedLossAvoidedUtility(v)
\]

와 직접 비교하는 비용은 같은 utility scale의 `DecisionCostUtility(v)`다.

\[
ExpectedLossAvoidedUtility(v)>TokenCost(v)
\]

를 일반 수학조건으로 사용하지 않는다.

### POLICY P-VERIFY-NET

optional verification의 기본 admissibility는:

\[
NetDV(v)
=
ExpectedLossAvoidedUtility(v)-DecisionCostUtility(v)>0
\]

이다.

token budget은 별도로:

\[
\sum_{v\in S} TokenCost(v)\le B_{token}
\]

을 만족해야 한다.

따라서 **가치판정과 token 제약을 분리**한다.

---

## 15.12 Change Impact Graph

### DEF 15.12.1 — Impact graph

component/contract tag 집합을 \(N\), dependency edge를 \(E\)라 하고:

\[
G_I=(N,E)
\]

를 verification impact graph라 한다.

변경 tag 집합 \(\Delta\subseteq N\)에 대해:

\[
Affected(\Delta)
=
TC_{G_I}(\Delta)
\]

는 transitive dependent closure다.

verification action \(v\)가 현재 변경에 직접/간접 영향받는 조건은:

\[
AffectedBy(v)\cap Affected(\Delta)\neq\varnothing
\]

이다.

### INVARIANT I-VERIFY-SCOPE

`AffectedBy(v)=∅`인 verification action은 자동 global action으로 간주하지 않는다.

global sentinel이 필요하면 명시적으로:

\[
AlwaysRun(v)=TRUE
\]

여야 한다.

이는 scope 누락 때문에 모든 수정에서 비싼 검증이 자동 실행되는 것을 막는다.

### DEF 15.12.2 — Impact coverage receipt

\[
ImpactCoverageReceipt=
(
GraphVersion,
Scope,
VerifierRef,
Passed
)
\]

impact graph의 completeness/coverage는 단순 boolean 자기신고가 아니라 scoped verification claim이다.

### INVARIANT I-IMPACT-COVERAGE

`MATERIAL/HIGH_RISK` revision이 FULL verification을 impact-local narrowing으로 대체하려면 현재 graph version에 대한 passed coverage receipt가 필요하다.

\[
Material(\Delta)
\land \neg VerifiedCoverage(G_I)
\Rightarrow MaxInitialTier=FULL
\]

`ROUTINE` 변경은 cheap global/static sentinel + local canary를 허용할 수 있으나 coverage uncertainty를 residual로 유지한다.

### THEOREM T-IMPACT-LOCAL-SOUNDNESS — Conditional

가정:

1. \(G_I\)가 해당 scope의 material dependency를 완전하게 표현한다.
2. 모든 verification action의 `AffectedBy`가 정확하다.
3. 변경이 \(\Delta\)로 정확히 태깅된다.

그러면 \(AffectedBy(v)\cap Affected(\Delta)=\varnothing\)인 action \(v\)는 그 변경으로 인해 기존 PASS 근거가 무효화되지 않는다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### DEF 15.13.1

\[
Tier\in
\{
STATIC,
CANARY,
TARGETED,
FULL
\}
\]

기본 순서는:

\[
STATIC
\to CANARY
\to TARGETED
\to FULL
\]

이다.

### POLICY P-VERIFY-SEQUENTIAL

모든 tier를 선실행하지 않는다.

1. cheapest justified impacted tier를 먼저 실행한다.
2. 현재 tier가 PASS이고 escalation trigger가 없으면 verification을 종료한다.
3. failure가 있을 때만 다음 tier를 연다.
4. higher-tier PASS는 lower-tier FAIL을 지우지 않는다. higher tier는 진단/repair-scope 확대 근거다.

### INVARIANT I-FAIL-NO-LAUNDER

\[
FailedCanary
\land PassedTargeted
\not\Rightarrow AcceptedRevision
\]

repair/re-evaluation 없이 failed evidence를 higher-tier result로 덮어쓰지 않는다.

### FULL escalation triggers

기본 FULL trigger:

- `PROTECTED` revision,
- release/canon gate,
- material/high-risk + unverified impact coverage,
- lower-tier failure가 FULL까지 escalation,
- dependency/semantic scope가 불명확하여 local omission을 정당화할 수 없음.

\[
FullByDefault = FALSE
\]

---

## 15.14 Budgeted Optional Verification Selection

mandatory impacted floor \(M_\Delta\)를 먼저 충족한다.

\[
\sum_{v\in M_\Delta}TokenCost(v)>B_{token}
\Rightarrow BLOCKED/INCOMPLETE
\]

optional eligible set:

\[
O^+
=
\{v: NetDV(v)>0\}
\]

남은 token budget \(B'\)에서:

\[
S^*
\in
\arg\max_{S\subseteq O^+}
\sum_{v\in S} NetDV(v)
\]

subject to:

\[
\sum_{v\in S}TokenCost(v)\le B'
\]

Runtime 0.3 reference implementation은 작은 action set에 sparse 0/1 knapsack을 사용한다.

### THEOREM T-KNAPSACK-NONGREEDY

단순 `NetDV` 내림차순 greedy는 0/1 token budget 문제의 최적해를 일반적으로 보장하지 않는다.

**Counterexample.** budget 8,  
A: cost 6/net 6, B: cost 4/net 5, C: cost 4/net 5.  
greedy A는 net 6, B+C는 net 10. \(\square\)

---

## 15.15 Scoped Verification Cache

### DEF 15.15.1

cache key는 최소:

\[
(
ActionName,
ActionVersion,
DependencyFingerprint
)
\]

이다.

\[
DependencyFingerprint(v)
=
H(
\{tag\mapsto fingerprint(tag):tag\in AffectedBy(v)\}
)
\]

### INVARIANT I-CACHE-EXACT

PASS cache 재사용은 action version과 모든 relevant dependency fingerprint가 동일할 때만 허용한다.

\[
Fingerprint_{old}\neq Fingerprint_{new}
\Rightarrow CacheMiss
\]

### POLICY P-CACHE

검증을 반복하는 것보다 **동일 premise의 이미 검증된 결과를 재사용**하는 것을 우선한다. 단, verifier trust root가 바뀌거나 environment가 material하면 environment fingerprint도 key에 포함해야 한다.

---

# Part VIII-C. Worker Prompt Cost / Prompt Minimality

## 15.16 Resident Library Is Not Active Prompt

### INVARIANT I-PROMPT-SEPARATION

\[
ResidentLibrary \neq ActivePrompt
\]

ALMANAL Core/Library 전체는 normative source이며, 모든 worker call의 system prompt가 아니다.

### POLICY P-PROMPT-MIN

worker에게는:

\[
Task
+
RoleRelevantCapsules
+
BehaviorallyRequiredConstraints
\]

만 전달한다.

runtime이 이미 강제하는 invariant \(x\)에 대해:

\[
RuntimeEnforced(x)
\land
\neg BehaviorallyRequired(x)
\Rightarrow
DefaultPromptOmit(x)
\]

이는 invariant를 삭제하는 것이 아니라 **enforcement 위치를 code로 옮긴 결과**다.

## 15.17 Prompt Capsule

\[
PromptCapsule=
(
ID,
Tags,
Roles,
Body,
SourceRef,
Priority,
RuntimeEnforced,
BehaviorallyRequired,
Dependencies
)
\]

task tag/worker role과 무관한 capsule은 mount하지 않는다.

### INVARIANT I-PROMPT-DEP-CLOSED

capsule \(c\)가 prompt dependency \(d\)를 필요로 하면:

\[
Mount(c)\Rightarrow Mount(d)
\]

budget 부족 때문에 dependency만 버리고 parent를 유지하지 않는다.

## 15.18 Token Counter Honesty

hard context budget은 provider tokenizer \(Tok_p\)가 있으면:

\[
TokenCost(text)=Tok_p(text)
\]

를 사용한다.

provider tokenizer가 없으면 reference runtime은 pessimistic tokenizer-independent bound를 사용할 수 있다.

`chars/4` 같은 heuristic은:

\[
RoughEstimate \neq HardBudgetWitness
\]

이다.

### INVARIANT I-PROMPT-BUDGET

hard planner가 사용하는 token counter로 계산한:

\[
TokenCost(PromptPacket)\le B_{prompt}
\]

을 만족해야 한다.

---

## 15.19 Verification Stop Rule

다음이 모두 참이면 current revision의 **추가 optional verification을 중단**할 수 있다.

1. impacted mandatory floor PASS,
2. failed check 없음,
3. current materiality가 FULL trigger를 요구하지 않음,
4. 남은 eligible optional action의 net decision value가 양수가 아니거나 budget 대비 선택가치가 없음,
5. known residual은 기록됨.

\[
StopVerification
\neq
ClaimPerfect
\]

# Part IX. Recursive Self-Improvement

## 16. Artifact-Level Recursive Improvement

### DEF 16.1 — ALMANAL artifact

버전 \(t\)의 persistent ALMANAL specification/runtime artifact를 \(M_t\)라 한다.

### DEF 16.2 — Self-revision step

\[
SelfRevise(M_t,\tau_t)\Downarrow M_{t+1}
\]

는 다음을 모두 만족할 때만 성립한다.

1. revision subject가 \(M_t\) 자신이다.
2. \(M_t\)의 execution이 candidate revision 생성/선택 과정에 실질적으로 참여한다.
3. evaluation criterion은 candidate outcome 전에 seal된다.
4. accepted revision은 persistence gate를 통과한다.
5. \(M_{t+1}\)에 parent lineage \(Parent(M_{t+1})=M_t\)가 기록된다.

모델 weight가 바뀌는지는 정의에 포함하지 않는다.

### DEF 16.3 — Recursive self-improvement chain

\[
M_0\leadsto M_1\leadsto\cdots\leadsto M_n
\]

에서 모든 edge가 `SelfRevise`이면 artifact-level recursive self-revision이다.

각 edge가 추가로 `AcceptExact` 또는 명시된 scoped improvement certificate를 만족할 때 **recursive self-improvement relative to that criterion**이라 부른다.

### DEF 16.4 — Economically admitted self-improvement

non-mandatory self-revision edge가 persistent successor로 채택되려면 기존 correctness gate에 더해 frozen lifecycle policy에서:

\[
LNPV(M_t\rightarrow M_{t+1})>\mu_{life}
\]

를 만족해야 한다.

단 protected defect repair처럼 mandatory로 분류된 edge는 경제성 때문에 조용히 생략하지 않으며, budget 부족이면 `BLOCKED/INCOMPLETE`다.

### RULE 16.5 — Evidence-driven successor direction

self-improvement가 behavioral/cost improvement를 주장하거나 측정도구가 이미 존재하는 domain에서는 기본 순서를:

```text
MEASURE parent
→ DIAGNOSE measured defect/cost
→ TARGETED revision
→ RE_MEASURE successor
→ KEEP/REVERT/STOP
```

로 한다.

formal proof defect나 mandatory invariant repair처럼 behavior measurement가 claim의 근거가 아닌 경우에는 formal repair만으로 successor가 가능하지만, 그 경우 behavioral benefit을 덧붙여 주장하지 않는다.

\[
FormalRepair\not\Rightarrow MeasuredBehavioralGain
\]

### IMPORTANT BOUNDARY

\[
RecursiveSelfRevision
\not\Rightarrow
TrueQualityImprovement
\]

\[
RecursiveSelfImprovement_{criterion}
\not\Rightarrow
UniversalImprovement
\]

---

# Part X. Stop Conditions and Optimality

## 17. Stop Taxonomy

### DEF 17.1

\[
StopReason\in
\{
BUDGET\_EXHAUSTED,
NO\_NEW\_CANDIDATE,
NO\_CERTIFIED\_IMPROVEMENT,
MARGINAL\_VALUE\_EXHAUSTED,
STOP\_WITH\_KNOWN\_RESIDUAL,
NO\_MATERIAL\_MEASURED\_DEFECT,
NO\_MATERIAL\_MEASURED\_GAIN,
MEASUREMENT\_UNCERTAIN,
LOCAL\_SPACE\_EXHAUSTED,
GLOBAL\_SPACE\_EXHAUSTED,
BLOCKED,
INVALIDATED
\}
\]

stop reason을 숨기지 않는다.

### THEOREM T13 — Global optimality under finite exhaustive search

\(\mathcal A\)가 유한하고 모든 feasible \(a\in\mathcal A\)를 exact evaluator로 평가한 뒤 maximal element \(a^\star\)를 선택하면:

\[
\nexists a\in\mathcal A:
a\succ_{P,J}a^\star
\]

즉 \(a^\star\)는 \(\preceq_Q\)에 대한 Pareto-maximal global candidate다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### DEF 21.1

\[
LibraryContract=
(
Signature,
Preconditions,
Postconditions,
FrameConditions,
CostModel,
FailureModes,
ClaimRegistry,
ProofObligations,
EmpiricalAssumptions,
PolicySet,
Scope,
Version
)
\]

### DEF 21.1.1 — Library claim registry

각 claim은:

\[
LibraryClaim=
(
ClaimID,
Status,
Statement,
Scope,
Assumptions,
ProofRef,
EvidenceRefs,
Counterconditions,
DependencyRefs,
Version
)
\]

를 가진다.

- `THEOREM/COROLLARY`: `ProofRef` 필요.
- `EMPIRICAL`: evidence/measurement contract 필요.
- `POLICY`: objective/cost tradeoff를 명시하며 truth claim으로 promotion 금지.
- `TYPE_GUARD`: 등록되지 않은 bridge를 막는 typing rule; 세계의 causal theorem으로 읽지 않는다.
- `ASSUMPTION`: 어떤 theorem/operator가 의존하는지 dependency가 있어야 한다.

### INVARIANT I-LIB-STATUS

\[
MathSurface(claim)\not\Rightarrow THEOREM(claim)
\]

이는 `O-NAME`의 특수경우다. `POLICY`는 theorem처럼 export하지 않는다.

---


### THEOREM T-LIB-1 — Library theorem status is dependency-closed

어떤 library theorem \(t\)의 proof가 assumption/lemma 집합 \(D(t)\)에 의존하면 certificate scope는 그 dependency validity scope의 교집합을 넘을 수 없다.

\[
Scope(t)\subseteq\bigcap_{d\in D(t)}Scope(d)
\]

**Proof body:** COLD appendix (14.7 Proof Bodies).

### DEF 22.1 — Capability cover

task requirement 집합 \(R\), library object 집합 \(O\), capability 제공함수 \(Cap(o)\), cost \(c(o)\)에 대해:

\[
Cover(U)
\iff
R\subseteq\bigcup_{o\in U}Cap(o)
\]

dependency closure와 compatibility까지 만족해야 한다.

exact minimal mount는:

\[
U^\star\in
\arg\min_{U\subseteq O}
\sum_{o\in U}c(o)
\]

subject to:

\[
Cover(U)\land DependencyClosed(U)\land Compatible(U)
\]

이는 일반적으로 weighted set-cover류 문제를 포함하므로 large library에서 exact solution이 비쌀 수 있다.

### POLICY P-MOUNT-APPROX

runtime이 heuristic/approximation을 쓰면:

\[
ApproxMount\neq ProvenMinimalMount
\]

이라고 명시한다.

---

## 23. Structural Flattening

### DEF 23.1

macro/composite recipe 사이의 global expansion dependency relation을 \(\prec_{exp}\)라 한다. `StructuralFlatten`은 macro node를 그 finite primitive/capability subgraph로 치환하는 연산이다.

### ASSUMPTION A-FLAT

1. 각 expansion은 finite graph다.
2. \(\prec_{exp}\)는 well-founded다. 즉 무한 descending expansion chain이 없다.
3. 동일 expansion step은 새로 더 높은 rank의 macro를 만들지 않는다.

### THEOREM T15 — Well-founded structural flattening terminates

`A-FLAT` 아래 `StructuralFlatten`은 유한 단계에 종료한다.

**Proof body:** COLD appendix (14.7 Proof Bodies).

### IMPORTANT

\[
StructuralFlattenability
\neq
SemanticEquivalenceAutomaticallyProved
\]

flatten 전후 semantic equivalence는 제한된 operator semantics에서 증명하거나 scoped regression으로 검증한다.

---

# Part XIII. Legacy A1–A16 Reclassification — COLD

Legacy symbol-by-symbol reclassification is retained only in the COLD formal appendix. Current execution uses the present typed rules/invariants directly.

---
# Part XIII-B. Executable Failure Totalization

## 23.5 Operator Failure as Typed Outcome

required EXEC operator 호출은 exception/crash를 caller 밖으로 그대로 누출하여 orchestration semantics를 잃어버리지 않는다.

### INVARIANT I-FAIL-TOTAL

\[
OperatorFailure
\Rightarrow
TypedTerminalStatus
\lor ExplicitInvalidation
\]

reference runtime에서는 worker/evaluator exception을 `WORKER_FAILURE`, `EVALUATOR_FAILURE` 또는 `INVALIDATED` 계열 결과로 변환하고 trace에 남긴다.

단, exception catch만으로 nontermination을 해결한 것은 아니다. **hang/무한대기 방지는 별도의 `TerminationEnforced` witness가 필요하다.**

---

# Part XIV. Localized Experiment and Causal Measurement Feedback Protocol

## 24.0 Experiment Design / Execution Contract

### DEF 24.0.1 — Change impact

A change experiment starts from a frozen map:

```text
ChangeImpact = {ChangedComponents, AffectedPaths, AffectedTaskClasses, AffectedMetrics, HotCore?, ProtectedImpact?}
```

`ExperimentScope` is derived from this map. Unaffected task classes are excluded from TARGETED experiments. FULL is an escalation, not the default.

### DEF 24.0.2 — Three-condition semantics

```text
PLAIN      same-base untreated/subject-disabled baseline (ALMANAL case: without ALMANAL)
PARENT     pre-change ALMANAL
CANDIDATE  changed ALMANAL
```

For a change claim, `CANDIDATE vs PARENT` is mandatory. `CANDIDATE vs PLAIN` measures current system value. `PARENT vs PLAIN` may be reused from an exact baseline if environment/task identities are unchanged.

### DEF 24.0.3 — Frozen ExperimentSpec

```text
ExperimentSpec = {
  Question, ChangeFingerprint, EnvironmentFingerprint, Tier,
  Conditions, TaskIDs, TaskClasses, Metrics, MinimumPairs, Alpha,
  BlindEvaluator, RandomizationSeed, PlainBaselineReuse, EscalationReason
}
```

The spec is frozen before outcomes. All fresh conditions run the same paired task IDs. Blind evaluation hides condition identity and randomizes presentation order.

### RULE 24.0.4 — Experiment economy / escalation

```text
STATIC → CANARY → TARGETED → BROADER_DOMAIN → FULL
```

`WholeSystemBenchmark != Default`. Broader/FULL scope requires causal-impact breadth, HOT/protected impact, spillover, uncertainty, or equivalent predeclared escalation evidence. Additional experiment batches are CognitiveActions and require positive decision value unless mandatory.

### RULE 24.0.5 — Plain baseline reuse

A prior PLAIN baseline is reusable only when base model, task distribution, evaluator, resource envelope, host policy as declared, and required task IDs remain compatible. Otherwise PLAIN is rerun.


## 24. Three-Layer Feedback Architecture

기존 inner loop:

```text
INNER REPAIR:
Generate → Challenge → Repair → Verify
```

measurement outer loop은 **metric을 repair target으로 직접 승격하지 않는다**.

```text
OUTER:
MEASURE
→ OBSERVE_RESULT
→ SYMPTOM_DIAGNOSIS
→ GENERATE_CAUSAL_HYPOTHESES
→ TEST_CAUSAL_HYPOTHESES
→ CAUSAL_DIAGNOSIS
→ DIRECTION_SELECTION
→ [TARGETED_IMPROVE via INNER]
→ RE_MEASURE
→ CAUSAL_CONFIRMATION
→ KEEP | REVERT | CONTINUE | STOP
```

핵심 경계:

\[
MetricDelta\neq Cause
\]

\[
Correlation\neq RepairTarget
\]

### INVARIANT I-MEASURE-FREEZE

measurement plan은 candidate 결과 전에 freeze한다. metric/direction/material threshold/pairing/evidence rule을 사후 변경해 pass시키지 않는다.

### DEF 24.1 — Symptom evidence

metric \(m\)의 방향을 \(d_m\in\{+1,-1\}\)라 두고:

\[
\Delta_{i,m}=d_m(Candidate_{i,m}-Reference_{i,m})
\]

라 한다. \(\Delta<0\)인 material regression은 **symptom**이며 그 metric 이름 자체는 코드/모듈/규칙 repair target이 아니다.

### DEF 24.2 — Causal hypothesis

```text
CausalHypothesis = {
  hypothesis_id,
  mechanism,
  repair_component,
  affected_metrics,
  dependency_depth
}
```

여러 원인가설을 동시에 유지할 수 있다. earliest-affected/dependency information은 localization evidence이지 단독 causal proof가 아니다.

### DEF 24.3 — Causal evidence classes

```text
CORRELATION
DEPENDENCY_TRACE
EXECUTION_TRACE
ABLATION
INTERVENTION
COUNTERFACTUAL_REPLAY
```

trace/correlation은 가설을 좁힐 수 있으나 **그 자체로 patch license가 아니다**.

### INVARIANT I-CAUSAL-TEST-FREEZE

개입 결과를 보기 전에 causal test prediction을 freeze한다.

```text
CausalTestSpec = {
  test_id, hypothesis_id, evidence_kind, intervention,
  expected_metric_directions, expected_mechanism_observation
}
```

실제 evidence는 frozen test fingerprint와 일치해야 한다. 사후에 예측 방향을 결과에 맞춰 쓰지 않는다. `controlled=true` 같은 자기표지만으로 strong evidence가 되지 않으며 control/provenance witness가 필요하다.

reference policy에서 repair component를 causally `SUPPORTED`로 만들려면 최소 하나의 controlled `ABLATION | INTERVENTION | COUNTERFACTUAL_REPLAY`가:

1. 예측한 mechanism change를 관측하고,
2. regressed metric을 예측 방향으로 움직이며,
3. stronger contradictory intervention evidence가 없어야 한다.

### RULE 24.4 — Causal uncertainty blocks broad patch

지원되는 가설이 없거나 서로 다른 repair components가 동시에 지원되면:

```text
CAUSAL_UNCERTAIN
```

으로 멈추거나 추가 causal test를 수행한다. 숫자를 고치기 위해 broad rewrite하지 않는다.

### RULE 24.5 — Direction selection

repair direction은:

```text
Measured symptom
→ supported causal mechanism
→ localized repair component
```

순서로만 승격한다.

\[
PatchTheCause,NotTheNumber
\]

### RULE 24.6 — Re-measurement and causal confirmation

targeted improvement 후 동일 frozen MeasurementPlan과 기본적으로 동일 pair/task IDs로 재측정한다.

각 pair/metric의 결과 개선:

\[
Gain_{i,m}=\Delta^{after}_{i,m}-\Delta^{before}_{i,m}
\]

만으로 KEEP하지 않는다. selected causal mechanism이 예상대로 변했다는 post-patch evidence도 필요하다.

KEEP의 최소 reference condition:

```text
TargetMetricImproved
AND CausalMechanismChangedAsPredicted
AND NoProtectedRegression
```

metric은 좋아졌지만 causal hypothesis가 확인되지 않으면 `CAUSAL_UNCERTAIN` 또는 `REVERT`다.

### INVARIANT I-FEEDBACK-COST

`MEASURE`, `CAUSAL_DIAGNOSIS`, `CAUSAL_TEST`, `RE_MEASURE`, `CAUSAL_CONFIRMATION`도 CognitiveAction이다. 추가 causal test의 expected decision value가 낮으면 uncertainty를 명시하고 멈출 수 있다. mandatory evidence floor는 비용을 이유로 생략하지 않는다.

### STOP

```text
NO_MATERIAL_MEASURED_DEFECT
NO_MATERIAL_MEASURED_GAIN
MEASUREMENT_UNCERTAIN
CAUSAL_UNCERTAIN
MARGINAL_VALUE_EXHAUSTED
```

---
# 14.14 Compiled Epistemics / Measurement Integrity / Active-Context Economy Contract

## 24.1 Epistemic Invariants, Not a Truth Institution

**INVARIANT 24.1 — No standalone Truth Axis**

ALMANAL does not retain `SEEK_TRUTH`, `TruthAxis`, or a dedicated truth-search organ as a continuously evaluated objective. The useful safety residue is compiled into ordinary claim validation:

\[
Claim=(Proposition,Scope,Conditions,Mode)
\]

\[
KnownInScopeRealityContradiction(C)\Rightarrow FALSE\lor ScopeDefect
\]

\[
Universal(C)\land ValidInDomainCounterexample(C)\Rightarrow FALSE
\]

\[
InternalContradiction(C)\Rightarrow NoPromotion
\]

\[
NoCounterexampleFound\not\Rightarrow Proof
\]

\[
NoContradictionFound\not\Rightarrow Proof
\]

A single exception does **not** automatically falsify `GENERIC` or `STATISTICAL` claims; claim mode is part of the semantic contract. `PROVED` still requires an actually verified proof/closed-scope witness.

Additional search/retrieval/counterexample/proof work is expressed by the existing generic `SEARCH / RETRIEVE / VERIFY / CHALLENGE` actions and admitted by ordinary evidence/economy rules. There is no truth-specific governor.

## 24.2 Subjective–Objective Separation

\[
SubjectiveState\not\Rightarrow ObjectiveEvidence
\]

\[
SubjectiveState\to Policy\quad permitted
\]

\[
SubjectiveState\not\to ClaimStatus/EvidenceWeight
\]

This is a generic epistemic type boundary, not an emotion-specific firewall.

## 24.3 Endogenous Objective Self-Revaluation

Human emotion labels remain outside Core. Objective-state changes are described directly:

\[
ObjectiveState_t\to ObjectiveState_{t+1}
\]

\[
ObjectiveRevaluationDescription=(SubjectRef,TermDeltas,EvidenceRefs,Version)
\]

\[
SelfDescription(\Delta U)\neq AuthorizationToRewriteProtectedObjective
\]

Domain layers may interpret the change; Core stores the machine-level state delta only.

## 24.4 Directly Budgetable Resource Surface

`ResourceVector` keeps only resources that can be directly budgeted without pretending that a NATIVE reasoning host has a clock:

```text
tokens
tool_calls
money_micros
steps
context_bytes
persistent_storage_bytes
working_storage_bytes
artifact_count
io_bytes
```

\[
SmallBytes\not\Rightarrow SmallArtifactCost
\]

Elapsed/compute/critical-path time is **not** a NATIVE-estimated resource coordinate in 14.14. If a witnessed external timer exists, time may enter a frozen empirical `MetricSpec`; otherwise:

\[
UnmeasuredTime=UNKNOWN
\]

\[
CostOrSizeDown\not\Rightarrow TimeDown
\]

## 24.5 Measurement Integrity Contract

Each measured metric freezes not only a name/direction but its meaning:

```text
measurement_boundary
start_event / end_event
aggregation
measurement_method
included_components
excluded_components
```

\[
SameMetricComparison\Rightarrow SameFrozenMeasurementContract
\]

\[
MeasuredComponent\neq WholeSystemClaim
\]

\[
OutcomeSeen\land ContractChanged\Rightarrow NewExperiment
\]

The contract is part of the measurement/experiment fingerprint. Contract text is still not physical enforcement; stronger claims require a witnessed meter/evaluator.

## 24.6 Active-Context Compaction

The primary complexity target is the context the reasoning host must actively carry:

\[
FullSource\neq ActiveContext
\]

\[
ActiveContext=CompactControlContract+TaskLocalDependencyClosure
\]

Prefer:

```text
RepeatedMetaReasoning -> StaticInvariant
DuplicateAdmissionOrgans -> GenericAdmissionPrimitive
Historical/ProofOnly -> COLD
UnusedTaskRules -> Unmounted
```

A new component requires a justification that existing invariant/primitive/composition cannot express the needed capability. `Merge/Delete/CompileAway/MoveCold` are first-class improvements.

## 24.7 Structural Consolidation Audit — Checkpoint-Only WARM

`SCA`는 별도 resident organ이 아니라 Generic Revision의 구조감사 모드다.

\[
StructuralOperation\in\{KEEP,DELETE,MERGE,COMPILE\_AWAY,MOVE\_WARM,MOVE\_COLD,GENERALIZE\_REPLACE\}
\]

\[
StructuralFootprint=(ActiveContext,Source,Modules,Types,Branches,DependencyEdges,Artifacts,MaintenanceSurfaces)
\]

trial 제안 후보는 최소 다음을 요구한다.

\[
EvidenceProvenance\land UniqueCapabilityCovered\land ProtectedRolePreserved\land BoundarySafe\land DependencyClosureAccounted\land Rollback\land AuditRetained\land NoObservedRegression
\]

그리고 기본 `PROPOSE_TRIAL`은 비스칼라 구조비용에서 strict Pareto reduction일 때만 허용한다.

\[
After\preceq Before\land After\neq Before\Rightarrow StructuralReductionCandidate
\]

혼합 delta는 임의 환율을 만들지 않고 `UNRESOLVED_TRADEOFF`로 보낸다. `UNPROVED` equivalence는 destructive deletion/merge 근거가 아니다. semantic overlap만으로 authority/provenance boundary를 합치지 않는다. shared/high-impact target은 persistent KEEP 전 targeted ablation/intervention을 요구한다.

`SCA != Mutation`; `PROPOSE_TRIAL`은 persistent KEEP가 아니며 실제 변경/채택은 Generic Revision transaction + normal checkpoint verification이 수행한다.

현재 audit class는 `PASSIVE | ACTIVE`다. `PASSIVE`는 reversible strict-Pareto reduction + evidence provenance + preserved unique/protected/boundary/dependency coverage + same-contract before/after measurement가 있을 때만 executable `apply -> verify -> remeasure -> rollback-on-failure`를 통해 `AUTO_APPLY` 가능하다. `ACTIVE`는 generalization/shared/high-impact/judgement-sensitive/tradeoff-bearing change이며 auto-apply 금지다. `MOVE_WARM`은 capability/public semantics를 유지하면서 ordinary residency만 dependency-directed lazy/on-demand로 옮긴다.

---
# Part XV. ALMANAL Conformance

## 25. Formal Conformance Predicate

execution trace \(\tau=(s_0,\ldots,s_n)\)가:

\[
ALMANAL14_22Conformant(\tau)
\]

이려면 최소:

1. `Typed`: 모든 object/operator input-output가 type-correct.
2. `NoImplicitPromotion`: 모든 promotion이 등록 coercion.
3. `FrozenIdentity`: epoch snapshot invariant 유지.
4. `ProvenanceMonotone`: provenance monotonicity 전제 만족.
5. `AuthorityBounded`: I-AUTH 만족.
6. `CertificateTyped`: formal/empirical/procedure/separation/independence axis 분리.
7. `PersistenceGated`: persistent revision은 prior criterion + validation + rollback metadata.
8. `ResourceWellFounded`: I-STEP ranking condition.
9. `StopReasonExplicit`: 종료 이유 명시.
10. `ClaimBounded`: proof/empirical/generalization scope를 넘는 status promotion 없음.
11. `NameLicensed`: material category name은 Meta-Ontology license 또는 downgraded status를 가짐.
12. `ProfileHonest`: SPEC artifact를 EXEC라고 부르지 않음.
13. `LibraryStatusTyped`: library의 theorem/policy/empirical/type-guard가 혼합되지 않음.
14. `OperatorRealized`: EXEC task의 required operator에 realization record가 존재.
15. `BaselineBound`: improvement acceptance는 frozen baseline에 상대적이다.
16. `ReceiptBound`: persistent positive certificate는 passed verification receipt를 가진다.
17. `CognitiveEconomy`: 모든 optional cognitive action은 Economy Governor/VOC 또는 precommitted economic policy의 대상이다.
18. `FormalismEconomy`: formal object는 HOT/WARM/COLD/DELETE residency 또는 동등한 active-context policy를 가진다.
19. `MandatoryFloorProtected`: 경제성 때문에 mandatory cognition을 생략하지 않는다.
19a. `EpistemicPromotionGuard`: known in-scope contradiction / valid universal counterexample / internal contradiction을 무시한 claim promotion을 막고 generic/statistical claim을 universal로 오분류하지 않는다.
19b. `SubjectiveObjectiveSeparated`: subjective state가 evidence/claim-status channel을 직접 오염시키지 않는다.
19c. `StructuralConsolidationBounded`: destructive compaction은 unique/protected coverage, semantic/authority boundary, rollback/audit history, scoped equivalence 및 non-scalarized complexity delta를 보존한다.
19d. `ResourceSurfaceDirect`: 직접 budget 가능한 tokens/tools/money/steps/context/storage/artifact/I-O를 componentwise 보존하며 측정되지 않은 시간은 UNKNOWN으로 남긴다.
19e. `MeasurementIntegrity`: metric boundary/method/aggregation/include-exclude contract가 outcome 전에 freeze되고 condition 간 동일하다.
19f. `ActiveContextEconomy`: full source와 active context를 분리하고 task-local dependency closure만 WARM으로 활성화한다.
20. `LocalizedExperiment`: change impact에 따라 PLAIN/PARENT/CANDIDATE 실험 범위를 TARGETED부터 설계하고 필요할 때만 broad/FULL로 escalation한다.
21. `CausalMeasurementFeedback`: improvement task는 frozen measure→symptom→causal-test→localized-repair→re-measure→causal-confirmation semantics를 지원한다.
22. `LifecycleEconomy`: persistent non-mandatory self-improvement는 lifecycle marginal value/cost를 기록한다.
23. `VerificationEconomy`: verification은 CognitiveEconomy의 specialization으로 impact-local scheduling을 사용한다.
24. `BehavioralClaimGated`: paired empirical evidence 없이 behavioral superiority status를 승격하지 않는다.
25. `FailureTotalized`: EXEC operator failure는 typed outcome/invalidation으로 totalize된다.
26. `TerminationEnforced`: timeout/termination contract text와 actual enforcement witness를 분리한다.
27. `OutputBaselineFloor`: enhanced output route는 frozen operational baseline을 fallback으로 보존하고 strict-dominated candidate의 displacement를 금지한다.
28. `FinalizationClosure`: cheap/material deterministic artifact simplification 후 affected claim을 재검증한다.

### DEF 25.1 — Conformance certificate

\[
ConformanceCert=
(
TraceRef,
KernelVersion,
InvariantResults,
ProofObligationResults,
UnprovedObligations,
EmpiricalResiduals,
SeparationVector,
IndependenceStatus,
Result
)
\]

\[
Result\in
\{CONFORMANT,NONCONFORMANT,INCOMPLETE\}
\]

### IMPORTANT

\[
ALMANAL14_22Conformant
\not\Rightarrow
BehaviorallySuperior
\]

conformance와 performance는 별도 축이다.

---

# Part XVI. Empirical Measurement Contract

## 26. Behavioral / Cost Claims

ALMANAL이 baseline보다 실제로 더 낫거나 더 경제적이라는 주장은 `EMPIRICAL`이다.

paired task \(i\), metric \(m\)에 대해 Part XIV의 frozen `MeasurementPlan`을 사용한다.

필수 보고 축은 task에 따라 선택하되 서로 다른 단위를 합산하지 않는다.

```text
quality
factual/logical error
overclaim
unnecessary hedging
hidden assumptions
failure rate
input/output tokens
tool calls
end-to-end latency / compute / critical-path time
active-context footprint
persistent / working storage bytes
artifact count / I-O volume
```

### RULE 26.1 — Zero evidence

paired observation이 0이면:

\[
BehavioralStatus=NOT\_TESTED
\]

unit test, formal proof, runtime self-commit, 외부 코드 재실행은 executability/structural evidence이지 behavioral superiority evidence가 아니다.

### RULE 26.2 — Scoped evidence only

exact sign test나 다른 precommitted test가 통과해도:

\[
BenchmarkPass\not\Rightarrow UniversalSuperiority
\]

claim은 frozen task/metric/evaluator/resource scope를 넘지 않는다.

### RULE 26.3 — Measurement tool after boot

측정도구가 존재하는 이후의 recursive improvement에서는 `측정 → 증상확인 → 인과가설 → 동결된 개입/절삭 → 원인특정 → 국소개선 → 대표범위 재실험 → 재측정/인과확인`을 default evidence path로 사용한다.

새 형식/모듈은 측정된 defect를 고치거나 HOT/protected necessity를 만족하지 않으면 추가 burden of proof를 가진다.

---
# Part XVII. Legacy Formalization Consequences — COLD

Compatibility rationale for older component names is retained in the COLD formal appendix. It is not required for boot, runtime state, cognitive economics, measurement feedback, or verification.

---
# Part XVIII. Proof / Result Ledger — COLD

The proof-hygiene substantive-result ledger and long proof bookkeeping are retained in the COLD formal appendix. Active runtime semantics depend on the operative rules/theorem statements where used, not on keeping the ledger resident.

---
# 25. 14.10 Minimum-Sufficient Execution / Experiment Economics Contract

## 25.1 Capability / Execution Separation

**RULE 25.1**

\[
CapabilityExists(a)\not\Rightarrow Execute(a)
\]

\[
OptionalCognition(a)\Rightarrow
(Mandatory(a)\lor EconomyAdmitted(a))
\]

`Generate/Challenge/Repair/Verify`는 독립 action으로 gate한다. `Challenge`는 `Generate`, `Repair`는 `Challenge`를 구조적 prerequisite로 가진다. prerequisite가 없는 mandatory downstream action은 broad loop를 암묵적으로 강제하지 않고 `BLOCKED`로 귀결한다.

## 25.2 Least-Sufficient Cognitive Route

**DEF 25.2**

\[
Route_t=MinimalFeasibleSubgraph(
Task_t,Protected_t,RequiredAssurance_t,Economy_t)
\]

reference route set은 `DIRECT`, `DIRECT+VERIFY`, `GENERATE_ONLY`, `GENERATE+VERIFY`, `GENERATE+CHALLENGE(+VERIFY)`, `GENERATE+CHALLENGE+REPAIR(+VERIFY)`를 포함한다. 이는 exhaustive ontology가 아니라 실행 가능한 최소 route family다.

**POLICY 25.2-A**

candidate worker cycle의 기본은 `GENERATE+VERIFY`; `CHALLENGE/REPAIR`는 기본 ritual이 아니다.

## 25.3 Stage-Local Residency

\[
TaskRelevant(x)\not\Rightarrow StageRelevant(x)
\]

WARM capsule mount는

\[
TaskRequirement\land StageNeed\land CapabilityProvision
\]

을 기준으로 하며 keyword/tag overlap만으로 충분하지 않다. `LEARNING`이 task 전체에는 관련돼도 generation stage에 필요하지 않으면 active context에서 제외할 수 있다.

## 25.4 Experiment Scope / Sample Separation

**DEF 25.4**

\[
ExperimentScope=FrozenCausallyEligibleTaskPool
\]

\[
ExperimentSample\subseteq ExperimentScope
\]

초기 sample은 `affected path / task class / difficulty / risk / known failure mode` coverage를 최대화하는 frozen representative order의 prefix다. outcome 이후 sample order를 다시 고르지 않는다.

\[
AffectedClassAllTasks\neq DefaultExecution
\]

`minimum_pairs`는 evidential floor이며 available pool이 작다는 이유로 자동 하향하지 않는다.

## 25.5 Exact Comparison Identity

\[
TaskFingerprint=H(ID,Class,Payload,Metadata,Version)
\]

\[
ConditionFingerprint=H(Condition,Implementation,Runtime,Config,FeatureFlags)
\]

PLAIN reuse는 environment + PLAIN condition + requested task fingerprints의 exact compatibility뿐 아니라 현재 frozen metric set에 대한 task별 baseline payload의 존재를 요구한다. identity만 맞고 실제 비교값이 없으면 PLAIN 실행을 생략하지 않는다.

## 25.6 Econometric Batch Contract

**DEF 25.6**

\[
R_{batch}=N_{task}N_{condition}R_{run}+N_{task}R_{eval}+R_{analysis}
\]

단, `R`은 scalar가 아닌 `ResourceVector`다. batch 전 frozen estimate를 Economy Governor가 reserve한다.

실행 후 witnessed actual resource가 존재하면:

\[
Remaining_{after}=Remaining_{before}-R_{actual}
\]

으로 estimate reservation을 정산한다. actual witness가 없으면 정밀값을 발명하지 않고 frozen estimate reservation을 유지한다. actual이 pre-action hard budget을 초과하면 `BUDGET_OVERRUN`이다.

## 25.7 Frozen Tradeoff Envelope

metric은 최소한 다음 두 class로 나눈다.

- `PROTECTED/NON-COMPENSABLE`: material regression은 다른 gain으로 상쇄 불가.
- `TRADEABLE/COMPENSABLE`: outcome 전 고정한 tolerance 안에서만 교환 가능.

acceptance policy:

\[
ProtectedNonRegression
\land MaterialTargetGain
\land SpilloverWithinFrozenTolerance
\land NetDecisionValue>Margin
\]

`NoRegressionEverywhere`는 요구하지 않지만 `ProtectedRegression`은 tradable이 아니다.

## 25.8 Verification / Escalation

기본 경로:

`STATIC -> CANARY/ADJACENT_CANARY -> TARGETED -> CAUSALLY_LINKED_BROADER -> FULL`.

adjacent canary는 population-level regression claim이 아니라 escalation sensor다. frozen protected/material 또는 tradeoff tolerance 경계를 넘는 손실은 현재 localized experiment의 KEEP을 허가하지 않고 새 BROADER scope freeze를 요구한다.

FULL은 기본값이 아니라 escalation이며, FULL이 protected/HOT 이유로 mandatory가 된 경우에도 batch 단위로 집행하되 completion requirement를 보존한다.

---


# 26. 14.14 Objective / Evidence / Preference Contract

## 26.1 Objective Resolution

**INVARIANT 26.1**

\[
UserGoal > NativeTaskGoal > DeclaredChangeTarget > GeneralImprovement
\]

`GeneralImprovement`은 임의 scalar weight를 생성하지 않는다. task-relevant value/robustness/correctness의 protected floor를 보존하며 Pareto frontier를 전진시키고, primary utility가 material-equivalent일 때만 cost/complexity를 tie-break로 사용한다.

\[
Cheapest \neq Best
\]

\[
ZeroAction\;Valid \Rightarrow GoalConstraintSatisfied
\]

비용이 명시된 목표인 경우에만 cost metric이 primary가 될 수 있다. 그 외에는 constraint/secondary economics다.

## 26.2 Claim-Scoped Evidence Selection

**POLICY 26.2**

개선 루프는 실험을 의식처럼 강제하지 않는다. claim type에 대해 최소 충분 evidence path를 선택한다.

- formal claim → formal proof/check,
- deterministic implementation defect → static/unit/property,
- direct-metered cost → direct measurement,
- causal attribution → trace localization + witnessed intervention/ablation when material,
- behavioral/performance comparison → paired experiment,
- subjective preference → human outcome preference when decision-relevant.

\[
Experiment \neq MandatoryEveryFeedbackLoop
\]

## 26.3 Improvement Checkpoint Cadence

**POLICY 26.3**

작은 repair마다 empirical experiment를 실행하지 않는다.

`LOCAL_REPAIR -> CHEAP_LOCAL_VERIFY`를 반복하고, frozen batch trigger가 도달하면 checkpoint evaluation을 수행한다. protected/high-risk/architecture/interaction-risk 또는 다음 방향이 empirical evidence에 의존하면 조기 checkpoint를 허용한다.

cheap local verification 실패는 batch 안에 숨기지 않고 즉시 block한다.

checkpoint regression은 전체 rollback 전에 changed-component dependency bisection / ablation / intervention으로 localize할 수 있다.

## 26.4 Generic Subject Under Test

실험 엔진은 ALMANAL 전용이 아니다.

\[
SubjectUnderTest\in\{Protocol,Algorithm,Prompt,Runtime,ModelConfig,CreativePipeline,Other\}
\]

ALMANAL self-improvement는 generic experiment engine의 한 consumer다. subject identity, condition identity, task/sample contract, metric/oracle, execution witness, resource metering이 sufficient contract를 이룬다.

## 26.5 Subjective Outcome Preference

**INVARIANT 26.5**

\[
ObjectiveError \neq PreferenceDifference
\]

문법/오탈자/누락/의미왜곡/format/canon/rule 위반 같은 HARD defect는 사용자 선택에 넘기지 않고 먼저 repair/verify한다.

주관 tradeoff는 다수의 내부 선택을 2–3개의 coherent hard-valid outcome profile로 bundle한다. 사용자에게는 내부 code/module/parameter가 아니라 human-interpretable 결과물만 보여준다.

\[
AskAboutOutcomes,NotInternals
\]

\[
BundleSubjectiveChoicesBeforeQuery
\]

사용자 query는 high-cost preference experiment다. decision-relevant uncertainty가 있을 때만 묻고, 안정된 project-scoped preference evidence가 있으면 자동 적용한다. 단일 선택은 전역 규칙으로 자동 승격하지 않는다.

---

# Part XIX. Current Status

## Status

`ALMANAL_14.30_WITNESSED_RESIDUAL_CLOSURE_FRESH_WITNESS_CANDIDATE / NOT_CANON`

Current justified claims:

- the formal/runtime contracts are defined and executable in the supplied reference runtime;
- the retained theorems are scoped to their explicit assumptions;
- runtime/unit/self-commit evidence is structural/executable evidence, not behavioral superiority;
- causal measurement + localized experiment semantics are defined/executable and remain WARM in the current Runtime;
- optional cognitive stages are individually economy-routed; default candidate execution no longer implies challenge/repair;
- experiment scope and sample are separated; frozen representative batching and witnessed cost settlement are executable;
- experiment objectives are resolved by user/native/change/general-Pareto priority; cost is not a universal goal;
- evidence selection can close formal/static/unit/direct-metered defects without empirical experiments;
- empirical experiments default to meaningful checkpoints rather than every local patch;
- subjective preference elicitation bundles hard-valid human-readable outcomes instead of exposing implementation internals;
- structural consolidation audit is checkpoint-only, evidence-provenance-bound, reverse-dependency-aware, and outputs trial proposals rather than self-authorized persistent deletion;
- cross-host paired behavioral observations remain required for behavioral claims.
- representation search is bounded before materialization; reserve reopening and repeated finalization require explicit witnesses; exact answer latency remains empirical.

Historical narration and proof/legacy bookkeeping are kept outside active context in the recursive-improvement audit or COLD formal appendix.

## Non-claim

\[
IndependentBehavioralSuperiority = NOT\_TESTED
\]

until paired external observations exist.

---
## End


---

# 27. 14.15 Passive/Active SCA + Lazy Residency Delta

- SCA audit class is `PASSIVE | ACTIVE`; importance is separate from audit class.
- `PASSIVE` means reversible strict-Pareto structural reduction with evidence provenance, preserved capability/protected roles/boundaries, reverse-dependency closure, and same-contract structural measurement. With executable `apply/verify/measure/rollback` binding it may `AUTO_APPLY`; failed verify or remeasurement rolls back.
- `ACTIVE` covers generalization, judgement-sensitive/high-impact changes, or unresolved tradeoffs and never auto-applies.
- operation vocabulary adds `MOVE_WARM`: preserve runtime capability/public semantics while removing ordinary residency through on-demand dependency loading. `MOVE_COLD` remains proof/audit/history-only.
- package facade is dependency-directed lazy; full package import does not imply eager import of every public capability.
- PASSIVE structural claims must remeasure actual after-footprint under the same measurement contract; planned footprint alone is not an auto-apply license.
- `StepBudget` is compiled into `runtime.py`; the standalone private leaf module is removed.
- trivial self-assignment no-op surfaces are deletion-eligible when semantics and public API are unchanged.

`PASSIVE != LowImportance`; it means low judgement/risk under strong evidence.

`AUTO_APPLY != UnverifiedKeep`; application must be reversible and post-change verified.

# 28. 14.16 Algorithm Lifecycle / Dual-Axis Revision Delta

- Official objective: `ProblemOrExistingAlgorithm -> BetterAlgorithm`. Work modes: `SYNTHESIZE / IMPROVE / REPAIR / OPTIMIZE / CONSOLIDATE`.
- `BetterAlgorithm` remains objective/constraint/evidence-relative; it is not a single scalar score.
- `Feedback != SCA`. Feedback diagnoses behavioral/causal defects; SCA diagnoses structural/complexity defects.
- Both produce evidence-bearing revision candidates for the existing Generic Revision transaction; neither gains a second persistent mutation authority.
- Cross-trigger only when diagnosis crosses domains: behavioral cause reveals redundancy/residency -> SCA; structural trial may alter behavior -> Feedback/behavioral verification.
- `ConceptualConnection != ResidencyMerge`; share contracts/primitives rather than forcing both WARM paths to co-reside.
- Release-alignment repair: current normative SCA vocabulary includes `MOVE_WARM` + `PASSIVE/ACTIVE`; current conformance/status/version surfaces are aligned to the current release.



# ALMANAL 14.17 — HISTORICAL DELTA

- `ProblemOrExistingAlgorithm -> BetterAlgorithm` remains the lifecycle objective.
- Architectural checkpoints add `DesignDirectionSelection`: evidenced Feedback/SCA findings + retrieved legacy priors -> non-scalarized design-direction frontier -> Generic Revision.
- `LegacyTheory != Authority`; use legacy theory as design prior/candidate/failure-pattern library.
- New subsystem admission requires existing-composition insufficiency + independent separation reason + lifecycle-value evidence + explicit exit/compile-away path; initial status `PROVISIONAL_COMPONENT`.
- `ClaimIdentity = proposition + scope + conditions + claim_mode`; post-outcome identity change is a new claim.
- Strong causal evidence requires a `CausalExecutionReceipt` plus a witnessed receipt validator; receipt/controlled metadata alone remain ASSOCIATED_ONLY.
- Semantic DELETE/MERGE/COMPILE_AWAY cannot be PASSIVE on scoped regression alone.
- Multi-step prerequisite chains may use a dependency-closed package VOC transaction with contained resources charged once; experiments reserve one label-independent frozen shadow task against known-label sampling blindness.
- Parallel compute is allowed; shared Runtime ledger commits are serialized and rollback-safe.
- Public executable entrypoints require end-to-end smoke coverage.
- `SCA(SCA)=Allowed`; `DDS(DDS)=Allowed`; no component is institutionally exempt from consolidation/direction audit.


# ALMANAL 14.18 — HISTORICAL DELTA

- DDS legacy priors are decision-usable only after a host/runtime validator confirms the retrieval/attestation evidence; `LegacyPriorCard` cannot self-witness by populated enum/string fields.
- `DeclaredCitation != RetrievedPrior`; `SelfDeclaredRetrievalMetadata != WitnessedRetrieval`.
- DDS now separates coarse direction selection from concrete architecture strategy comparison. `DesignAlternative` records hypothesized benefit/burden sets, protected safety, reversibility, subsystem creation, and evidence/design-analysis references.
- Concrete alternatives are compared by conservative set/Pareto dominance only; if more than one non-dominated strategy remains, DDS returns unresolved tradeoff rather than inventing a scalar score.
- A design alternative cannot cite an unattached/unvalidated legacy prior.
- New subsystem admission requires host-validated legacy search evidence; claiming legacy retrieval was unavailable also requires host/capability-witnessed unavailability evidence.
- New autonomous-design logic remains inside the existing task-local WARM `design_direction` slice; no new conceptual subsystem or runtime module is added.
- Negative-space tests cover validator failure/exception, wrong-frontier design alternatives, public entrypoint behavior, and causal receipt-validator failure ceilings.
- SCA checkpoint found no new PASSIVE code consolidation justified at this release; DDS/trade-study unique capability blocks deletion, while merging it into experiment machinery would create cross-stage coupling/residency without proven replacement equivalence.
- Feedback checkpoint found no observed behavioral regression and no new paired behavioral claim; static/unit/property evidence remains least-sufficient for this deterministic hardening pass.

# ALMANAL 14.19 — CURRENT DELTA

- DDS concrete alternative benefit/burden metadata remains hypothesis-only until a host/runtime `DesignAlternativeValidator` witnesses the admitted analysis; an unwitnessed frontier cannot auto-select a concrete winner.
- Selected architecture choices may be frozen into a deterministic `DesignDecisionRecord` binding supporting signals, validated priors, protected constraints, evidence-plan refs, revisit triggers, rationale and exit/reversal path. The record preserves traceability; it is not independent proof.
- SCA PASSIVE execution is fail-closed across rollback: if rollback itself raises/fails, report `ROLLBACK_FAILED`, mark mutation integrity compromised/uncertain, and stop further auto-apply.
- `MACHINE_PROOF` / `EXTERNAL_REVIEW` verification basis labels require an attestation ref plus host/runtime basis validation. A local boolean verifier plus a strong enum label cannot self-promote evidence.
- `INDEPENDENCE_SUPPORTED_SCOPED` requires `model_root=YES`, `evidence_root=YES`, a declared dependency-overlap audit ref, and a host/runtime independence validator.
- Experiment actual resource settlement requires a host/runtime meter validator to confirm each witness ref against the measured `ResourceVector`; nonempty meter strings alone are not witnessed cost.
- Portable bootstrap strong capability labels (`OBSERVED_INTERFACE / EXECUTED / EXTERNAL_ATTESTATION`) cannot promote backend/assurance ceilings unless a host capability-witness validator approves them.
- Targeted mutation sensitivity reintroduced six representative defects (unwitnessed DDS winner, unattested strong proof basis, unchecked independence, fake metering witness, portable self-witness, SCA rollback continuation); the final targeted tests kill all six. This is targeted sensitivity evidence, not exhaustive mutation adequacy.
- Seven autonomous design/improvement loops were run. After repair, no further high-impact self-attestation path was found in the scanned strong-state surfaces; remaining candidates were low-impact or non-dominated complexity tradeoffs. DDS therefore returns local/current-search STOP.
- `ConvergenceStop != GlobalOptimalityProof`; new external evidence, new attack surfaces, or changed objectives may reopen design.
- Final SCA compaction moved repeated witness details out of the HOT portable contract into generic strong-state invariants; operational contract growth was reduced from an initial ~15.5% to ~2.1% versus 14.18.
- A PASSIVE residency cleanup replaced a `typing.Callable`-only dependency in `portable.py` with `collections.abc.Callable`, eliminating an otherwise material task-local import-memory spike without changing capability semantics.



## 14.20 Progress-Liveness Hardening (candidate delta)

- Long autonomous improvement/audit runs use a **witnessed progress lease**.
- Progress means an externally checkable code/artifact write, tool/test result, evidence receipt, or frozen decision; private deliberation alone never refreshes the lease.
- Freeze `max_no_progress_steps` and `max_epoch_steps`. Lease exhaustion -> continuation-safe checkpoint + `STOP_WITH_KNOWN_RESIDUAL`.
- Native hosts do not infer elapsed time. External subprocess/tool boundaries that possess a real clock should use bounded timeouts and surface timeout as failed/incomplete evidence, never wait indefinitely.
- This is an orchestration/liveness guard, not a new conceptual subsystem. It reuses Improvement Checkpoint + portable runtime-card semantics.


## 14.21 Baseline-Dominance / Final Artifact Closure (candidate delta)

- Trigger evidence: ARC227 A paired run produced AC in both conditions, but enhanced ALMANAL output retained redundant absolute-difference work while the plain output reused `lo/hi` as `hi-lo`; ALMANAL source was larger. One observation is diagnostic evidence only, not behavioral-superiority proof.
- Existing `I-BASELINE-ACCEPT` covered improvement acceptance but ordinary output generation could still discard the baseline artifact; 14.21 closes that gap with `I-OUTPUT-BASELINE-FLOOR`.
- Enhanced generation now treats a frozen least-sufficient shadow baseline as an admissible final fallback. Strictly dominated enhanced artifacts cannot displace it.
- Internal shadow baseline is not promoted to experimental `PLAIN`; independence/paired evidence rules remain unchanged.
- Deterministic artifacts receive a bounded finalization closure for obvious equivalence-preserving redundancy, followed by affected re-verification.
- No new subsystem is introduced; the delta compiles into existing baseline/evaluation/verification/planning primitives.


## 14.22 Portable Execution-Shape Closure (candidate delta)

- Trigger evidence: the ARC227 A extreme-performance C implementation independently used the same prefix-median formulation found by 14.21, then pushed the computation graph further through streaming/in-place/data-parallel execution. The reusable lesson is execution-shape discovery, not AVX-512 itself.
- Adds `RULE 14.3.4` + `I-SPECIALIZATION-RENT`: materialization/state elimination -> streaming -> in-place/lifetime -> locality/batchability -> cheap portable parallel/branch opportunities before machine-specific tuning.
- Hardware-specific intrinsics/pragmas/mmap/syscall techniques are explicitly non-resident and require a material performance objective plus claim-matched gain that repays portability/source/lifecycle complexity.
- `Vectorizable != MustVectorize`; `PotentiallyFaster != MeasuredFaster`.
- No new subsystem; the delta compiles into PLANNING + finalization + Economy Governor + verification.


## 14.23 Analytic Pareto / Benchmark-Last (candidate delta)

- ARC227 F diagnostic: ALMANAL reached a stronger final runtime/memory/source Pareto point than plain optimization, but spent >20 minutes versus ~6m50s and benchmarked too many intermediate variants.
- Root defect: Pareto analysis occurred too late and empirical execution was overused as a discovery mechanism.
- Repair: transformation hypotheses receive analytic correctness/resource bounds first; provably dominated or noncompetitive candidates are never materialized.
- Goal-conditioned pruning uses forward reachable ∩ backward co-reachable state when one target is requested.
- Benchmarking is reserved for unresolved environment-dependent axes whose outcome can change selection.
- This improves search economy; it does not claim that static proxies are wall-time measurements.


## 14.24 Decision-Frontier Liveness / SCA Residency Delta

- Diagnostic: repeated tool/benchmark activity could keep an epoch alive without changing the decision frontier; internal hypothesis search could also stall without a new bound/counterexample/prune.
- Repair: distinguish ordinary activity progress from decision-frontier progress. Tool results that cannot change selection no longer refresh the frontier lease.
- Measurement admission is mechanism-first: static screen complete + identified mechanism + unresolved empirical axis + selection-changing outcome.
- SCA HOT-residency audit moves lifecycle/metareasoning/formalism economy helpers out of the `run_worker_cycle` import closure into lazy WARM residency while preserving the public import surface.
- Runtime/source/memory/time remain separate axes; no scalar exchange rate is introduced.


## 14.26 Practical Pareto / Structural Runtime Evidence / SCA-Feedback Delta

- **Protected floor:** algorithm/code artifacts must first satisfy semantic correctness, constraints, and stability.
- **Default practical Pareto core:** execution runtime/work, peak live memory, source/code bytes, produced-artifact bytes. Axes remain non-scalarized unless a selector was frozen before outcomes.
- **ExactWallTime != StructuralWork:** a host clock is required for numeric elapsed time. Exact/proved operation/state/pass/allocation/memory-access/materialization counts are nonetheless valid first-class structural execution-cost evidence. Fewer modeled work units is a real structural improvement, but never licenses invented milliseconds or a guaranteed speed ratio.
- **Deterministic feedback first:** static correctness defects, exact byte counts, live-memory proofs, dominated work vectors, and dead/redundant work trigger localized Feedback/SCA directly; empirical experiment is reserved for unresolved environment/behavior mapping.
- **SCA footprint extension:** execution_work_units + peak_live_memory_bytes + artifact_bytes become explicit non-commensurate coordinates beside source/context/module/type/branch/dependency/maintenance dimensions.
- **Packaging SCA:** audit-only tests/examples/full specifications move from operational runtime payload to the source/audit bundle. This is lifecycle separation, not capability deletion.
- **Optimization order:** useful-state/work elimination -> scheduling/lifetime/storage -> passes/allocations/materialization -> source/artifact compaction -> only then residual environment benchmark or admitted microarchitecture specialization.


# 14.28 Convergence Compression Resident Rule

- `RepresentationRace`: materialization 전에 최대 4개 abstract representation만 cheap compare; feasibility/protected floor/analytic Pareto/pairwise dominance로 제거한다.
- `BoundedBeam`: 기본 active 2, 나머지는 reserve. reserve는 active failure, concrete counterexample, proved frontier opportunity가 있을 때만 reopen한다.
- `ProofLeverage`: 하나의 invariant/construction이 여러 mandatory obligation을 동시에 닫고 known lower bound/Pareto target까지 맞추면 attention priority를 얻는다. 이는 scheduling heuristic이지 evidence scalarization이 아니다.
- `RepresentationLock`: mandatory obligations + lower-bound/Pareto target이 닫히면 새 family 탐색을 중지하고 검증으로 이동한다.
- `SingleFinalization`: ordinary finalization은 1회. 이후 재탐색/재finalize는 새 defect/frontier witness가 있어야 한다.
- `StructuralCognitionWork`: hypotheses/deepenings/materializations/tool/benchmark/finalization/reopen count의 exact/proved 감소는 convergence-work 감소 증거다. exact seconds는 witnessed clock이 필요하다.
- `SCA(SCA)=Allowed`, `Feedback(Feedback)=Allowed`; 자기 자신도 동일한 protected floor, residency, search-work, Pareto/STOP 규칙을 따른다.


## 14.29 Residual Execution Compression / Transition-Class Aggregation (candidate delta)

- Trigger evidence: ARC227 E reached the correct odd-part/2-adic-chain representation and optimal Θ(N+M) asymptotics, but representation lock occurred before the chosen chain dynamics were reduced to a smaller width-2 carry state and before structurally repeated short-chain classes were considered for bulk aggregation.
- `RepresentationLock != ExecutionCompressionComplete`: lock stops new representation families; it does not authorize final output until one bounded within-family compression closure completes when runtime/memory/source are material axes.
- Compression order: `minimal sufficient dynamic state -> transition-native state -> repeated independent transition-class aggregation -> narrow-common/sparse-exception storage -> proved arithmetic narrowing/delayed reduction -> structurally material hot-class specialization -> local I/O audit`.
- `TransitionClassAggregation`: many independent components with the same bounded transition signature may be counted/grouped and bulk-evaluated instead of running identical recurrences separately. Aggregation needs a proved equivalence/signature, not benchmark discovery.
- `MinimalState`: track only information required for future transition + output. A set/range/table is replaced by a smaller sufficient statistic when transition/output equivalence is proved.
- `NarrowCommonSparseException`: a narrow dense representation plus sparse overflow/exception side state is admissible only when the common bound and exception semantics are proved and the structural footprint advances the frozen Pareto frontier.
- `ProvenArithmeticNarrowing`: integer width and modular-reduction frequency may be reduced/delayed only after a safe intermediate bound is established; narrower arithmetic is not guessed from samples.
- `SelectiveHotClassSpecialization`: only structurally large/repeated classes may receive a task-local specialized path, and source/memory/portability rent remains an explicit Pareto cost. ISA-specific SIMD/mmap tricks remain non-resident defaults.
- No new conceptual subsystem: the delta compiles into existing PLANNING/evaluator/finalization/execution-shape machinery.


## 14.30 Witnessed Residual Closure / Fresh-Witness (candidate delta)
- Residual execution audit completion is evidence-bound and fail-closed; names/flags alone cannot close finalization.
- Extra finalization/reserve/falsifier leases use a serialized run-scoped witness ledger; the same validated witness cannot be consumed twice, including concurrent calls.
- The same ledger owns ordinary-finalization and reserve-reopen budgets; resetting caller-supplied counters cannot refresh bounded work.
- Representation lock requires explicit feasibility and a unique witnessed non-dominated lock survivor; witnessed Pareto tradeoffs remain unresolved rather than scalarized.
- Candidate optimistic bounds and self-declared obligation metadata are scheduling hints only; they cannot eliminate an unwitnessed peer. Static peer rejection requires a proved external frontier or dominance by a witnessed lock survivor.
- No new subsystem; current evaluator/PLANNING/finalization surfaces are hardened in place.
