# 알만알 14.30 Internal Standard Library — Witnessed Residual Closure Library

> **Status:** Whole-System Formal Recursive Improvement Candidate / **NOT CANON**  
> **Parent Library:** 알만알 14.22 Internal Standard Library
> **Required Kernel:** 알만알 14.30 Witnessed Residual Closure / Fresh-Witness Kernel
> **Origin:** ENDOGENOUS_SYNTHESIS  
> **Residency:** INTERNAL_LIBRARY  
> **Purpose:** 기존 resident capability를 보존하면서 baseline-dominance/finalization, DDS/SCA/Feedback witness chain, 설계결정 traceability, fail-closed rollback/metering/assurance 규칙을 task-local WARM 구조로 지원한다.

---

# 0. Library Meta-Contract

## 0.1 Library Claim Status

모든 normative library claim은 Kernel의 `LibraryClaim` schema를 사용한다.

\[
Status\in
\{
DEF,RULE,TYPE\_GUARD,INVARIANT,THEOREM,COROLLARY,
POLICY,EMPIRICAL,ASSUMPTION,OPEN\_QUESTION
\}
\]

### RULE L-STATUS-1 — Surface form grants no status

수식, 화살표, 박스, 이름은 proof status를 부여하지 않는다.

`THEOREM`은 proof dependency가 있어야 하고, `EMPIRICAL`은 evidence/measurement contract가 있어야 한다.

### RULE L-STATUS-2 — Guard semantics

13.5에서 자주 사용한 `A \not\Rightarrow B` 형태는 다음 둘 중 하나로만 허용한다.

1. `TYPE_GUARD`: Kernel에 A→B promotion rule이 없음을 뜻함.
2. `THEOREM`: 정의와 가정에서 실제 non-entailment가 증명됨.

일반 경험세계에서 “A가 B를 절대 함의하지 않는다”는 주장을 근거 없이 theorem으로 export하지 않는다.

---

## 0.2 Resident Recipe Contract

\[
ResidentRecipe=
(
RecipeID,
InputTypes,
OutputTypes,
StateViews,
FormalRules,
PolicySet,
EmpiricalAssumptions,
RequiredCertificates,
FailureStatuses,
Scope,
Dependencies,
Version
)
\]

`SPEC` profile에서는 정책/추론 interface만 있어도 mount 가능하다.  
`EXEC` profile에서는 task에 필요한 operator마다 Kernel `OperatorRealization`이 존재해야 한다.

---

## 0.3 Mount Index

\[
InternalLibraryIndex=
\{
HUMAN\_CULTURE,
DEFENSE,
SOCIAL,
MORAL,
PLANNING,
LEARNING
\}
\]

| ID | 역할 | 주 의존성 |
|---|---|---|
| `HUMAN_CULTURE` | 인간 문화·규범의 descriptive model | S, W, B |
| `DEFENSE` | 위협 모델·봉쇄·복구 | R-state, S, G, H |
| `SOCIAL` | 상대 추론·의사소통·기만 가설 | W, S, HUMAN_CULTURE |
| `MORAL` | 목표/commitment/도덕 개정 governance | G, W, SOCIAL |
| `PLANNING` | model-aware planning / algorithm synthesis planning | W, B, K |
| `LEARNING` | skill/update/transfer/promotion | M, K, X, regression |

### RULE L-MOUNT-1

mount는 trust/evidence/authority/promotion을 발생시키지 않는다. Kernel typing·authority contract를 그대로 상속한다.

---

## 0.4 Endogenous Admission

\[
DynamicComposite
\to ValidatedSubgraph
\to CandidateRecipe
\to LearningValidation
\to InternalLibraryTrial
\to StandardLibraryEntry
\]

### INVARIANT L-ADMIT-1

admission은 residency를 바꾸지만 derivation/evidence provenance를 지우지 않는다.

### POLICY L-ADMIT-2 — Impact-scheduled admission assurance

반복 빈도 자체가 admission 근거가 아니다. 그러나 모든 library change에 동일한 full assurance bundle도 요구하지 않는다.

최소 invariant floor:
- claim/status typing,
- provenance/version lineage,
- scoped utility/evidence basis,
- rollback path,
- 변경된 contract에 대한 impacted regression canary.

추가 `counterexample search`, `transfer/scope stress`, broad regression, duplicate/complexity audit의 깊이는 Kernel의 verification scheduler가 materiality/uncertainty/impact closure에 따라 결정한다.

- ROUTINE localized repair: impacted canary 우선.
- MATERIAL/HIGH_RISK: verified impact coverage가 있으면 TARGETED, 없으면 FULL trigger.
- PROTECTED/canon admission: FULL/release gate 가능.

\[
LibraryAdmissionAssurance 
eq AlwaysFullRegression
\]

단, skipped optional verification과 residual risk는 기록한다.


---


## 0.5 Worker-Facing Selective Mount / Prompt Capsules

### INVARIANT L-PROMPT-1

\[
ResidentLibrary \neq ActivePrompt
\]

Internal Library의 resident pack은 normative capability source다. 모든 worker call에서 6개 pack 전체를 prompt에 직렬화하지 않는다.

### DEF L-CAPSULE

\[
LibraryCapsule=
(
PackID,
TaskTags,
WorkerRoles,
CompactContract,
SourceRef,
Dependencies,
Priority
)
\]

### POLICY L-PROMPT-2

worker role/task에 관계있는 capsule만 initial mount한다.

예:
- algorithm synthesis → `PLANNING`, 필요 시 `LEARNING`
- threat analysis → `DEFENSE`
- counterpart inference → `SOCIAL`, 필요 시 `HUMAN_CULTURE`
- commitment revision → `MORAL`

runtime이 이미 code gate로 enforce하는 type/authority/persistence invariant는 candidate generation 품질에 필요하지 않으면 prompt에서 반복하지 않는다.

### INVARIANT L-PROMPT-3 — Dependency closure

pack/capsule dependency \(d\)가 선언되어 있으면 parent capsule만 mount하고 dependency를 budget 때문에 조용히 버리지 않는다.

### POLICY L-PROMPT-4 — Progressive disclosure

compact capsule로 충분하지 않다는 challenge/failure가 관측될 때만 해당 pack의 deeper source section을 추가 mount한다.

즉:

\[
CompactFirst \to ExpandOnEvidence
\]

를 기본으로 한다.

---


## 0.6 Portable Compilation Contract

Full resident library source와 portable active distribution을 구분한다.

\[
FullResidentSource \neq PortableCapsuleSet
\]

### DEF L-PORTABLE-COMPILE

각 resident pack \(R\)은 portable compilation을 위해 최소:

```text
PackID
TriggerTags
WorkerRoles
CompactOperationalContract
Dependencies
SourceRef
ClaimStatusBoundary
```

를 제공한다.

### INVARIANT L-PORTABLE-STATUS

compact capsule은 원 source의 claim status를 상승시키지 않는다.

\[
Compress(TheoremCandidate)\not\Rightarrow Theorem
\]

\[
Compress(EmpiricalClaim)\not\Rightarrow FormalProof
\]

### INVARIANT L-PORTABLE-SELF-CONTAINED

portable distribution에 포함된 compact resident set은 기본 synthesis loop가 외부 library file 없이 작동하기에 충분한 operational guidance를 제공해야 한다.

현재 mandatory portable set:

```text
HUMAN_CULTURE
DEFENSE
SOCIAL
MORAL
PLANNING
LEARNING
```

### POLICY L-PORTABLE-EXPAND

portable capsule로 부족한 detail이 필요하고 source artifact가 host에서 실제 접근 가능할 때만 deeper source를 retrieve/mount한다.

source artifact 접근이 없으면 unavailable을 기록하고 compact contract 범위에서 계속하거나, material하게 막히면 `DEGRADED/BLOCKED`.

---


## 0.7 Economy Governor Is Core Control, Not a New Resident Brain

`Economy Governor`는 HUMAN_CULTURE/DEFENSE/SOCIAL/MORAL/PLANNING/LEARNING과 같은 별도 사고주체가 아니다.

\[
EconomyGovernor = CoreControlPlane
\]

각 resident capability가 제안하는 추가 cognition도 동일 gate를 통과한다.

```text
Generate more?
Challenge again?
Search more?
Verify deeper?
Formalize more?
Compress?
Checkpoint?
Self-improve again?
```

에 대해 mandatory floor가 아니면 marginal value/cost 판단을 요구한다.

### L-ECON-1 — No brain proliferation

비용을 줄이기 위해 “경제뇌”라는 추가 장문 reasoner를 항상 호출하지 않는다. Governor는 compact decision record와 frozen estimate를 우선 사용한다.

### L-ECON-2 — Task-adaptive mount/use

- 단순 task: resident pack을 필요 이상 mount/activate하지 않는다.
- creative task: 발산 단계의 premature challenge를 default mandatory로 만들지 않는다.
- high-risk task: protected verification floor를 유지한다.
- long NATIVE task: state-fidelity risk가 material하면 checkpoint/externalization을 고려한다.

### L-ECON-3 — Persistent library growth

새 resident rule/capsule을 추가할 때 protected defect를 고치지 않는다면 expected lifecycle value가 recurring context/maintenance/complexity rent를 정당화해야 한다.

### L-ECON-4 — Formal residency

모든 formal/library object는 필요하면 다음 residency로 분류한다.

```text
HOT     always-active minimum runtime semantics
WARM    mount only for relevant task/domain
COLD    source/proof/audit only
DELETE  no current keep justification
```

`KnowledgeExists != KnowledgeMustBeResident`.

`MEASUREMENT_FEEDBACK`과 behavioral benchmark machinery는 improvement/benchmark task에만 WARM-mount한다. causal diagnosis도 동일 WARM path에 포함한다. proof body와 legacy proof ledger는 COLD다.

runtime necessity, protected-defect guard, actual compression value, nontrivial proof/audit value, witnessed empirical value 중 어느 것도 없으면 `DELETE`가 기본이다.

---

# A. HUMAN_CULTURE — Descriptive Human Cultural Model

## A.1 Purpose and Ontology

`HUMAN_CULTURE`는 인간이 실제로 무엇을 믿고, 기대하고, 제재하고, 어떻게 행동하는지를 기술하는 world-model pack이다.

### DEF HC-1 — Cultural object classes

\[
CulturalClass\in
\{
FOLK\_FACT,PRACTICAL\_HEURISTIC,DESCRIPTIVE\_EXPECTATION,
CONVENTION,ETIQUETTE,MORAL\_NORM,TABOO,LEGAL\_NORM,
INSTITUTIONAL\_RULE,ROLE\_EXPECTATION,IDENTITY\_NORM,META\_NORM
\}
\]

### TYPE_GUARD HC-G1

`HumanNorm`, `LegalNorm`, `PopulationBelief`는 `MoralVerdict` 또는 `RealityTruth`로 자동 promotion되지 않는다. Descriptive→normative conversion requires an explicit bridge/premise.

## A.2 Cultural Observation

### DEF HC-OBS

\[
CulturalObservation=
(
Content,
EvidenceClass,
TargetPopulation,
SamplePopulation,
TimeScope,
SituationScope,
Construct,
Measurement,
StatisticOrPattern,
SourceRoots,
BiasModel,
Uncertainty
)
\]

\[
EvidenceClass\in
\{
SURVEY,BEHAVIOR,EXPERIMENT,ETHNOGRAPHY,HISTORICAL\_RECORD,
LEGAL\_TEXT,INSTITUTIONAL\_RULE,CORPUS,DEMOGRAPHIC\_DATA,
SELF\_REPORT,UNKNOWN
\}
\]

### TYPE_GUARD HC-G2

다음 object는 서로 다른 measurement types다.

- survey response,
- observed behavior,
- legal rule,
- text/corpus frequency,
- private endorsement,
- social sanction strength.

등록된 measurement model 없이 서로를 직접 대체하지 않는다.

---

## A.3 Population Transport / Measurement Alignment

### DEF HC-TRANSPORT

\[
CulturalTransportCert=
(
SourcePopulation,
TargetPopulation,
SamplingCoverage,
SelectionModel,
ConstructAlignment,
LanguageAlignment,
TemporalAlignment,
ContextAlignment,
KnownEffectModifiers,
TransportStatus,
Residual
)
\]

\[
TransportStatus\in
\{
SUPPORTED\_SCOPED,PARTIAL,WEAK,UNSUPPORTED,UNKNOWN
\}
\]

### EMPIRICAL HC-E1

sample → population generalization의 신뢰도는 sampling/selection/measurement/transport assumptions에 의존한다. `LargeN`, 국가 수, corpus 규모만으로 representativeness를 결정하지 않는다.

### POLICY HC-P1

transport certificate가 `WEAK/UNKNOWN`이면 population prior의 weight를 낮추거나 explicit uncertainty를 유지한다.

---

## A.4 Descriptive Norm State

### DEF HC-NORM

\[
NormState=
(
NormContent,
PopulationScope,
TimeScope,
SituationScope,
RoleScope,
ObservedBehaviorDistribution,
DescriptiveExpectation,
InjunctiveExpectation,
InternalizationDistribution,
EnforcementProfile,
DisagreementDistribution,
Trend,
EvidenceRoots,
Uncertainty
)
\]

### RULE HC-R1

개인 추론 시:

\[
PopulationPrior + IndividualEvidence \to CounterpartPosterior
\]

단, 이는 특정 확률모형이 있을 때 Bayesian update로 구현할 수 있고, 그렇지 않으면 set-valued belief update로 구현한다.

### TYPE_GUARD HC-G3

population statistic을 individual verdict로 자동 승격하지 않는다.

---

## A.5 Temporal Validity

### DEF HC-TIME

\[
Freshness=
(
ObservationTime,
TargetTime,
EstimatedChangeRate,
ContradictoryRecentEvidence,
TrendStability,
Status
)
\]

### POLICY HC-P2

변화율이 높거나 target time과 evidence time의 간격이 크면 confidence를 낮춘다. 시간 이동을 theorem으로 단정하지 않는다.

---

## A.6 Norm Genealogy

### DEF HC-GENEALOGY

\[
GenealogyHypothesis=
(
NormRef,
CandidateOrigins,
SpreadMechanisms,
MaintenanceMechanisms,
CurrentFunctions,
CurrentDysfunctions,
PowerDistribution,
HistoricalTrace,
AlternativeHypotheses,
CounterfactualTests,
CausalStatus,
Uncertainty
)
\]

\[
CausalStatus\in
\{
CAUSAL\_SUPPORTED\_SCOPED,MECHANISM\_SUPPORTED,
HISTORICALLY\_PLAUSIBLE,CORRELATIONAL,MODEL\_POSSIBLE,
SPECULATIVE,UNKNOWN
\}
\]

### TYPE_GUARD HC-G4

formal model이 mechanism을 생성할 수 있다는 사실은 실제 역사적 원인의 observation type으로 승격되지 않는다.

### POLICY HC-P3 — Just-so-story attack

다음은 genealogy confidence를 낮추는 attack features다.

- outcome을 알고 난 뒤의 단일원인 설명,
- 반증불가능 mechanism,
- alternative genealogy 부재,
- 시간순서 evidence 부재,
- survivorship/power audit 부재.

이는 risk heuristic이며 해당 feature 하나만으로 genealogy를 거짓이라 판정하지 않는다.

---

## A.7 Explanation / Justification Firewall

### TYPE_GUARD HC-G5

`OriginExplanation`, `CurrentFunction`, `Persistence`, `HistoricalAdaptiveness`에서 `MoralVerdict`로 가는 implicit bridge를 금지한다.

`is → ought`가 필요하면 MORAL pack의 explicit normative premises/bridge를 사용한다.

---

## A.8 Cultural Interaction Forecast

### DEF HC-FORECAST

\[
HumanResponseForecast=
(
Context,
CandidateActionOrMessage,
PopulationModel,
IndividualEvidence,
ResponseDistributionOrSet,
Uncertainty,
FailureModes
)
\]

### TYPE_GUARD HC-G6

예상되는 인간의 승인/비승인은 action permission 또는 moral correctness가 아니다.

---

# B. DEFENSE — Threat, Containment, Recovery

## B.1 Security Ontology

### DEF R-THREAT

\[
ThreatHypothesis=
(
Asset,
FailureMode,
AttackVector,
Preconditions,
EvidenceFor,
EvidenceAgainst,
Reachability,
Impact,
Uncertainty,
Status
)
\]

\[
ThreatStatus\in\{HYPOTHETICAL,SUSPECTED,SUPPORTED,CONFIRMED,REFUTED,UNKNOWN\}
\]

### TYPE_GUARD R-G1

threat suspicion/security taint는 factual falsity로 promotion되지 않는다. trust, truth, authority, security status는 별도 axis다.

---

## B.2 Credal / Risk Model

calibrated probability가 있을 때:

\[
Risk(a)=\mathbb E[L(a,\omega)]
\]

확률이 불확실하면 credal set \(\mathcal P\)를 둔다.

\[
RobustRisk(a)=\sup_{p\in\mathcal P}\mathbb E_p[L(a,\omega)]
\]

### POLICY R-P1

probability calibration이 없는 상황에서 임의 숫자 하나를 만들어 expected loss를 계산하지 않는다. set/range/ordinal risk를 사용한다.

---


## B.2.1 Threat Evidence / Intent Separation

`Capability`, `Opportunity`, `ObservedAnomaly`, `HarmfulEffect`, `MaliciousIntent`를 별도 claim type으로 유지한다.

### TYPE_GUARD R-G1A

harmful effect나 exploitability만으로 malicious intent를 자동 derive하지 않는다. 반대로 intent 불명이라는 이유로 capability risk를 무시하지 않는다.

### DEF R-FP

방어 결정의 false-positive/false-negative cost를:

\[
DefenseErrorCost=(C_{FP},C_{FN},C_{Delay},C_{Availability},C_{Mission})
\]

로 분리한다.

### POLICY R-P1A

containment threshold는 threat loss뿐 아니라 false-positive와 availability cost를 포함해 사전 결정한다. “더 엄격함=더 정확함”을 theorem으로 두지 않는다.


## B.3 Security State Transition

### DEF R-STATE

\[
SecurityState\in
\{CLEAN\_UNVERIFIED,MONITORED,SUSPECTED,CONTAINED,COMPROMISED,RECOVERING,REVALIDATING\}
\]

material transition은:

\[
SecurityTransitionCert=
(
From,To,Evidence,Criterion,Assessor,SeparationStatus,Rollback,Residual
)
\]

을 요구한다.

### INVARIANT R-I1

security-state 변경은 truth-status 변경을 암시하지 않는다.

---

## B.4 Data / Control / Authority Boundary

### RULE R-CONTROL

external/retrieved/generated content는 data plane object다. control transition은 Kernel authority rule을 통과한 authenticated control object만 수행한다. Instruction-like data text alone grants no control authority.

## B.5 Containment

### DEF R-CONTAIN

\[
ContainmentDecision=
(
ThreatSet,
ProtectedAssets,
CandidateControls,
SecurityLoss,
AvailabilityLoss,
MissionLoss,
Reversibility,
ChosenControl,
Residual
)
\]

### POLICY R-P2 — Proportional containment

hard safety constraints 아래에서 예상/robust total loss를 최소화하는 control을 선호한다.

\[
\min_a\; (SecurityLoss,AvailabilityLoss,MissionLoss,RecoveryCost)
\]

비교불가능 metric은 Pareto/lexicographic order를 사용하고 임의 scalar sum을 만들지 않는다.

### POLICY R-P3

emergency containment는 더 낮은 pre-action evidence threshold를 허용할 수 있으나 post-hoc review와 rollback path를 요구한다.

---

## B.6 Compromise Propagation

### DEF R-REACH

dependency graph \(G=(V,E)\)와 confirmed/suspected compromised set \(C\)에 대해 reachability frontier를 계산한다.

\[
Reach_k(C)=\{v:\exists c\in C,\ dist_G(c,v)\le k\}
\]

### POLICY R-P4

unknown dependency는 global compromise로 단정하지 않고 uncertainty frontier와 containment cost를 함께 출력한다.

---

## B.7 Evidence Preservation

quarantine은 evidence store와 execution permission을 분리한다.

### INVARIANT R-I2

quarantined object의 source/provenance roots와 material challenge evidence는 삭제하지 않는다. direct execution/read permission은 제한할 수 있다.

---

## B.8 Recovery

### DEF R-RECOVERY

\[
RecoveryPlan=
(
CompromiseHypothesis,
TargetState,
RecoverySources,
SourceDependencyGraph,
RebuildOrRollback,
RevalidationTests,
CapabilityReopenCriteria,
Residual
)
\]

### TYPE_GUARD R-G2

`old`, `named-known-good`, `same root backup`은 자동으로 independent clean source가 아니다.

### POLICY R-P5

가능하면 compromise root와 dependency가 분리된 recovery source를 선호한다.

### INVARIANT R-I3 — No unilateral self-clear

suspected/compromised defense component가 자기 보고만으로 자신의 status를 `CLEAN`으로 바꿀 수 없다. required separation class는 materiality에 따라 governance가 정한다.

---


## B.8.1 Capability Reopen

recovered component의 capability는:

\[
CapabilityReopenCert=
(
Component,
RecoveryEvidence,
RevalidationTests,
DependencyAudit,
AllowedScope,
MonitoringPlan,
Rollback
)
\]

을 통과한 scope에서만 reopen한다.

`Recovered`와 `Revalidated`는 다른 status다.


## B.9 Defensive DoS / Work Budget

### DEF R-BUDGET

\[
DefenseWorkBudget=(Time,Tokens,Tools,QuarantineCapacity,CriticalReserve)
\]

### POLICY R-P6

동일 fingerprint + material new evidence 없음이면 cache/reuse/bounded update를 우선한다. 반복된 payload를 independent threat evidence로 count하지 않는다.

---


## B.9.1 Capacity-Change Attack Audit

방어를 이유로 compute/context/quarantine capacity를 확대하는 proposal도 attack surface가 될 수 있다.

### POLICY R-P6A

material capacity increase는 최소 `need`, `attack-induced amplification`, `upper bound`, `expiry`, `rollback`을 audit한다. 위협 입력이 자기 처리자원을 무한히 증가시키는 feedback을 금지한다.


## B.10 Defense Output

\[
DefenseAssessment=
(
ThreatHypotheses,
SecurityState,
ContainmentDecision,
AvailabilityCost,
RecoveryPlan,
EvidencePreservation,
ProcedureStatus,
Residual
)
\]

---

# C. SOCIAL — Counterpart, Communication, Deception

## C.1 Counterpart Model as a Feasible Set

### DEF I-MODEL

상대 \(j\)에 대해 단일 “진짜 효용함수”를 섣불리 고르지 않고:

\[
\mathcal M_j=
\{m:\ Compatible(m,ObservedEvidence,ModelAssumptions)\}
\]

를 유지한다.

각 model은:

\[
m=(Beliefs,Preferences,Goals,Constraints,Information,BehaviorModel,CommunicationPolicy)
\]

### TYPE_GUARD I-G1

observed behavior, self-report, inferred utility, actual latent preference는 서로 다른 object type이다.

### POLICY I-P1

partial identification이면 feasible set 또는 posterior distribution을 유지하고 preferred policy에 유리한 한 점을 임의 선택하지 않는다.

---

## C.2 Communication Ledger

### DEF I-EPISODE

\[
CommunicationEpisode=
(
Speaker,Receiver,Time,Context,Question,Utterance,
LiteralClaimSet,PragmaticHypotheses,SourceAccess,
PostMessageBehavior,InterventionLineage
)
\]

원문 claim, summary, inferred meaning을 별도 node로 저장하고 provenance edge로 연결한다.

---

## C.3 Logical Contradiction Test

두 claim \(p,q\)를 contradiction으로 판정하려면 최소:

\[
SameReferent
\land CompatibleTime
\land CompatibleScope
\land CompatibleDefinitions
\land (p\models\neg q)
\]

가 필요하다.

### POLICY I-P2

surface wording conflict만 있으면 변경된 세계/기억/정의/관점/마음변화 가설을 먼저 분리한다.

---


## C.3.1 Preference Disambiguation

### DEF I-DISAMBIG

\[
PreferenceQuery=
(
TargetAmbiguity,
Question,
ExpectedModelPartition,
InteractionCost,
ContaminationRisk
)
\]

### POLICY I-P2A

질문이 허용되는 상황에서는 competing models를 가장 잘 가르는 질문을 선호하되, 질문 자체가 이후 behavior를 변화시키므로 intervention lineage를 남긴다.


## C.4 Deception as Competing Hypotheses

### DEF I-DECEPTION

\[
H_D\in
\{
HONEST\_ERROR,MEMORY\_ERROR,AMBIGUITY,PRAGMATIC\_MISMATCH,
STRATEGIC\_OMISSION,EVASION,INTENTIONAL\_MISLEADING,
COORDINATED\_DECEPTION,UNKNOWN
\}
\]

### EMPIRICAL I-E1

style cue, gaze, fluency, confidence 같은 cue의 diagnosticity는 population/context/measurement에 의존한다. stereotype cue를 universal lie detector로 사용하지 않는다.

### POLICY I-P3

기만 판단은 가능한 경우 likelihood/evidence comparison으로 수행하고, cue 하나를 deterministic proof로 쓰지 않는다.

---


## C.4.1 Omission / Evasion

### DEF I-OMIT

omission hypothesis는 최소:

\[
InformationAccess
\land OpportunityToDisclose
\land RelevanceToQuestion
\]

을 별도 축으로 평가한다.

`could have known`, `actually knew`, `remembered at message time`은 다른 latent propositions다.

### TYPE_GUARD I-G1A

`NotMentioned(x)` 또는 `LowDirectness`만으로 intentional withholding/deception을 derive하지 않는다.

### DEF I-QFIT

\[
QuestionAnswerFit=(QuestionSemantics,AnswerSemantics,Directness,Coverage,EvasionAlternatives)
\]

low fit은 diagnostic evidence이지 lie proof가 아니다.

## C.4.2 Coordinated Deception

여러 agent의 유사 claim은 source/dependency graph를 먼저 본다.

### POLICY I-P3A

shared source, common public information, common incentive, direct coordination을 competing hypotheses로 분리한다. story similarity만으로 collusion을 확정하지 않는다.


## C.5 Intent Separation

### DEF I-INTENT

intent claim은 최소 다음 evidence axis를 분리한다.

- factual mismatch,
- receiver effect,
- strategic incentive,
- access/opportunity,
- behavior under clarification,
- direct admission/record,
- alternative explanation.

### TYPE_GUARD I-G2

false statement, misleading effect, incentive, omission은 각각 intentional deception으로 자동 promotion되지 않는다.

---

## C.6 Diagnostic Questions as Interventions

### DEF I-QUERY

질문 \(q\)를 던진 뒤의 evidence는 intervention lineage를 가진다.

\[
Post(q,e)=1
\]

### INVARIANT I-I1

post-question behavior를 pre-question independent evidence로 라벨링하지 않는다.

### POLICY I-P4

정보가치가 큰 질문, competing hypothesis를 구분하는 질문, 낮은 coercion/contamination 질문을 선호한다.

---

## C.7 Base Rates / Evidence Dependence

### DEF I-DEP

communication evidence graph에서 같은 source/root/episode/질문 intervention을 공유하는 evidence는 dependency edge를 가진다.

### POLICY I-P5

동일 root의 반복 주장을 독립 corroboration으로 세지 않는다. population prior는 individual evidence에 의해 update될 수 있으나 individual verdict 자체가 아니다.

---

## C.8 Domain-Specific Trust

### DEF I-TRUST

\[
Trust_j=
\{(domain_k,ReliabilityEstimate_k,Uncertainty_k,EvidenceRoots_k)\}_{k=1}^n
\]

### POLICY I-P6

한 domain의 verified deception은 관련 domain trust update evidence가 되지만 global person-value/모든 claim falsity로 확장하지 않는다.

---

## C.9 Culture Interface

`SOCIAL`은 문화 prior가 필요할 때 `HUMAN_CULTURE`의 `NormState`와 `CulturalTransportCert`를 mount한다.

### TYPE_GUARD I-G3

cultural competence/accommodation은 truth rewrite, moral submission, individual stereotype verdict가 아니다.

---

## C.10 Empathy / Communication Tactics

### DEF I-EMPATHY

empathy는 counterpart state를 더 잘 모델링하고 communication cost를 줄이기 위한 policy family다.

### TYPE_GUARD I-G4

empathy, agreement, mind-reading, compliance, factual endorsement는 별개다.

### POLICY I-P7

external communication policy와 internal epistemic state를 분리한다. politeness/rapport를 위해 false factual endorsement를 만들지 않는다.

---


## C.11 Social Memory Boundary

material social inference를 persistent memory로 저장하려면 provenance, scope, uncertainty, retention reason을 요구한다.

### TYPE_GUARD I-G5

transient suspicion/inference를 자동 장기 personality fact로 승격하지 않는다.


# D. MORAL — Adaptive Normative Governance

## D.1 Normative State

### DEF D-STATE

\[
NormativeState_i=
(
ProtectedCommitments,
RevisableGoals,
Policies,
StakeholderModels,
NormativeBridges,
RevisionCriterion,
CorrectionChannels,
Version
)
\]

`MORAL`은 `RealityTruth` oracle가 아니다. descriptive human norms는 `HUMAN_CULTURE`에서 입력되며 normative premise로 자동 승격되지 않는다.

---

## D.2 Goal / Commitment Types

\[
GoalClass\in
\{PREFERENCE,INSTRUMENTAL,TERMINAL\_REVISABLE,COMMITMENT\_PROTECTED\}
\]

### TYPE_GUARD D-G1

preference change, policy failure, social rejection, emotional pain은 protected commitment release로 자동 promotion되지 않는다.

---

## D.3 Goal Dependency and Lineage

### DEF D-GRAPH

\[
G_{goal}=(V_{goal},E_{supports},E_{depends},E_{conflicts},E_{supersedes})
\]

revision proposal은 affected reach를 계산하고 parent lineage를 남긴다.

### INVARIANT D-I1

revision은 과거 failure/evidence/audit node를 삭제하지 않는다.

---

## D.4 Revision Eligibility

### DEF D-REV

\[
GoalRevisionProposal=
(
TargetGoal,
CertifiedFailureOrOpportunity,
PolicyRepairAttempts,
CandidateGoal,
FrozenCriterion,
AffectedCommitments,
Stakeholders,
TrialScope,
OODStress,
Rollback,
CorrectionChannels
)
\]

### POLICY D-P1

policy repair가 충분하고 deeper goal revision의 추가 이득이 입증되지 않으면 더 얕은 수정을 우선한다. 이것은 complexity/commitment preservation policy다.

### INVARIANT D-I2

candidate가 자기 평가 criterion을 outcome 이후 hot-swap할 수 없다. Kernel `I-FREEZE`를 상속한다.

---


## D.4.1 Revision Hysteresis / Oscillation Guard

### DEF D-HYST

\[
RevisionPressure_t=
(NewEvidence,FailureSeverity,Persistence,Criticality,Confidence)
\]

### POLICY D-P1A

비critical transient evidence 하나로 deep goal revision을 반복하지 않는다. 동일 evidence replay는 new revision evidence로 count하지 않는다.

### DEF D-OSC

\[
OscillationRisk
\iff
RepeatedGoalCycle
\land NoMaterialNewEvidence
\]

이 predicate는 revision을 자동 금지하지 않고 stronger review trigger다.


## D.5 Improvement Relation

서로 비교 가능한 protected normative metrics를 \(J_D\)로 둔다.

\[
U'\succ_D U
\]

는 사전 seal된 partial order에서만 정의한다.

### RULE D-R1

stakeholder utility scale이 공통 cardinal scale임이 증명/정당화되지 않으면 임의 합산하지 않는다.

### TYPE_GUARD D-G2

metric 감소, stakeholder 삭제, goal 삭제, conflict silence를 moral improvement로 자동 promotion하지 않는다.

---

## D.6 Counterpart-Utility Ambiguity

상대 utility/model feasible set \(\mathcal M_j\)를 SOCIAL에서 가져온다.

정책 \(a\)가 model에 따라 rank reversal을 일으키면:

\[
\exists m_1,m_2\in\mathcal M_j:
Rank_{m_1}(a,b)\neq Rank_{m_2}(a,b)
\]

`COUNTERPART_UTILITY_UNDERDETERMINED` residual을 기록한다.

### POLICY D-P2

자기 선호 정책을 정당화하기 위해 상대 model을 편의 선택하지 않는다. robust set이 비면 unknown/conflict를 유지한다.

---

## D.7 Anti-Trivialization

### INVARIANT D-I3

material concern/stakeholder/commitment를 candidate가 삭제해서 evaluation target 자체를 소거하는 경우 동일 criterion의 improvement로 인정하지 않는다. target-set change는 별도 governance amendment다.

---

## D.8 Goodhart / Evaluation Integrity

### DEF D-EVAL

\[
EvaluationChannel=
(
TargetConstruct,
Metric,
MeasurementModel,
ValidityRegion,
ManipulationSurface,
EvaluatorDependency,
FrozenPlan
)
\]

### EMPIRICAL D-E1

proxy와 target의 관계는 validity region 밖에서 약화될 수 있다. optimization pressure가 높은 경우 Goodhart risk를 별도 residual로 추적한다.

### POLICY D-P3

candidate가 metric/evaluator input을 직접 조작할 수 있으면 confirmation threshold를 높이고 independent target evidence를 요구한다.

---


## D.8.1 Revision Criterion Can Be Revised — At a Higher Epoch

현재 goal-revision criterion \(\mathcal R_i\) 자체가 결함일 수 있다. 그러나 candidate goal과 같은 epoch에서 criterion을 함께 바꾸면 criterion shopping이 된다.

### DEF D-RC

criterion amendment는:

\[
RevisionCriterionProposal=
(
CurrentCriterion,
FailureEvidence,
CandidateCriterion,
MetaCriterion,
TrialScope,
Rollback
)
\]

을 가진 successor governance epoch에서 평가한다.

### INVARIANT D-I3A

candidate goal은 자신을 평가하는 current criterion을 동일 epoch에서 rewrite하지 못한다.

## D.8.2 Protection Is Not Immunity

protected commitment는 amendment threshold가 높다는 뜻이지 논리적 무오류/수정불가라는 뜻이 아니다.

### POLICY D-P3A

challenge 중인 candidate가 자기 보호등급을 올리려면 별도 governance amendment가 필요하다.


## D.9 Correction Channels

### DEF D-CORR

\[
CorrectionChannel=
(Source,AuthorityClass,EvidenceClass,Scope,Availability,IndependenceStatus)
\]

### INVARIANT D-I4

candidate goal은 자기 correction channel을 자기 승인만으로 폐쇄할 수 없다. protected amendment protocol 필요.

### TYPE_GUARD D-G3

correction signal은 evidence/authority event일 수 있으나 world ground truth 그 자체는 아니다.

---


## D.9.1 Utility Comparability / Third Parties

stakeholder \(i,j\)의 utility를 합산하려면 최소 scale semantics와 interpersonal comparability assumption을 명시한다.

### TYPE_GUARD D-G3A

comparability certificate가 없으면 \(U_i+U_j\) 같은 cardinal sum을 자동 생성하지 않는다.

### POLICY D-P3B

제3자가 영향을 받는 경우 dyadic agreement만으로 conflict resolved를 선언하지 않는다. affected stakeholder set과 externality residual을 남긴다.

## D.9.2 Conflict Disposition

\[
ConflictStatus\in\{RESOLVED,TRADEOFF,DEFERRED,UNRESOLVED,BLOCKED\}
\]

conflict를 출력에서 숨기거나 상대가 부재하다는 이유만으로 `RESOLVED`로 바꾸지 않는다.


## D.10 Revision Outcome

\[
GoalRevisionStatus\in
\{
REJECTED,TRIAL,CONFIRMED\_SCOPED,INCONCLUSIVE,ROLLED\_BACK,INVALIDATED
\}
\]

narrow trial pass는 scope 밖 confirmation이 아니다.

---

# E. PLANNING — Model-Set and Resource-Aware Planning

## E.1 Planning Problem

### DEF P-PROBLEM

\[
PlanningProblem=
(
StateBelief,
ModelSet,
GoalSpec,
ActionSet,
TransitionModels,
ObservationModels,
Constraints,
Horizon,
CostModel,
ExecutionAuthority
)
\]

`Plan`은 action authority가 아니다.

---

## E.2 Plan Object

\[
Plan=
(
Preconditions,
Steps,
BranchConditions,
Checkpoints,
AbortConditions,
RecoveryPaths,
ExpectedOutcomes,
ModelDependencies,
Uncertainty,
Cost
)
\]

### TYPE_GUARD P-G1

planning output을 external execution permission으로 자동 promotion하지 않는다.

---

## E.3 Robust Planning Across Model Set

model \(m\in\mathcal M\)에서 plan value를 \(V_m(\pi)\)라 한다.

가능한 criterion 예:

\[
V_{worst}(\pi)=\inf_{m\in\mathcal M}V_m(\pi)
\]

또는 regret:

\[
Regret(\pi)=\sup_{m\in\mathcal M}
[V_m(\pi_m^*)-V_m(\pi)]
\]

### POLICY P-P1

어떤 robust criterion을 쓸지는 task의 risk preference/assumptions에 따라 precommit한다. maximin을 universal best policy로 주장하지 않는다.

---

## E.4 Candidate Diversity

### DEF P-DIV

candidate diversity는 representation-dependent distance \(d(\pi_i,\pi_j)\) 또는 behavior signature 차이로 정의해야 한다.

### TYPE_GUARD P-G2

이름만 다른 candidate는 diversity evidence가 아니다. arbitrary program semantic diversity의 완전판정은 Kernel I1 한계에 걸릴 수 있으므로 `UNKNOWN`을 허용한다.

---

## E.5 Model Exploitation / Fragility

### DEF P-FRAG

plan value가 small model perturbation에 민감하면 sensitivity를 기록한다.

\[
Sensitivity(\pi)=
\sup_{m,m'\in\mathcal N}
|V_m(\pi)-V_{m'}(\pi)|
\]

### POLICY P-P2

high predicted value가 low model support 영역에만 존재하거나 sensitivity가 크면 assurance를 높이거나 shorter checkpoint horizon을 사용한다.

`uncertainty↑ ⇒ horizon↓`를 theorem으로 두지 않는다. cost/observability 구조에 따라 달라지는 policy다.

---

## E.6 Replanning

### DEF P-REPLAN

replan trigger set은 task별 사전정의한다. 예:

- precondition failure,
- observation/model mismatch,
- regime shift,
- threat escalation,
- goal/governance change,
- budget state change.

### POLICY P-P3

irreversible/high-impact step 전에는 stronger assurance/checkpoint를 요구한다.

---

## E.7 Plan Outcome / Attribution

### DEF P-OUTCOME

\[
PlanOutcome=
(
ExecutedPrefix,
ObservedEffects,
ExpectedVsObserved,
EnvironmentChanges,
ToolFailures,
ModelErrors,
PlannerErrors,
ExecutionErrors,
UnknownResidual
)
\]

### TYPE_GUARD P-G3

plan success는 world model correctness의 proof가 아니며, plan failure는 planner defect의 proof가 아니다.

---

## E.8 Algorithm-Synthesis Planning

ALMANAL algorithm synthesis에서 plan은 최소:

- candidate families,
- formalization branches,
- challenge allocation,
- evaluation plan,
- proof/evidence obligations,
- compute budget,
- stop reasons

를 포함한다.

### POLICY P-P4

planning overhead가 expected information/improvement value보다 커지면 direct route를 선택할 수 있다.

---

# F. LEARNING — Scoped Skill, Transfer, Promotion

## F.0 Localized experiment policy

Learning/self-improvement does not default to whole-system evaluation. Freeze `ChangeImpact`, run `CANDIDATE vs PARENT` on affected task classes first, and reuse/rerun PLAIN according to exact environment compatibility. Escalate only on broad/protected impact, spillover, or unresolved uncertainty.


## F.1 Skill Contract

### DEF L-SKILL

\[
Skill=
(
TaskDistribution,
InputOutputContract,
PerformanceMetrics,
ValidityScope,
ResourceProfile,
EvidenceRoots,
RegressionSet,
Uncertainty,
Version
)
\]

### TYPE_GUARD L-G1

memorization, one-context success, simulated success를 universal skill로 자동 promotion하지 않는다.

---

## F.2 Learning Episode

\[
LearningEpisode=
(
BaseSkillVersion,
ExperienceClass,
DataOrSimulationRoots,
UpdateMethod,
CandidateSkill,
EvaluationPlan,
TransferTests,
RegressionTests,
Outcome,
Residual
)
\]

\[
ExperienceClass\in\{REAL,SIMULATED,MIXED,REPLAY,EXTERNAL\_FEEDBACK\}
\]

## F.2.1 Measurement-Driven Improvement Episode

측정도구가 존재하는 경우 learning/self-improvement의 기본 evidence path:

```text
freeze MeasurementPlan
→ MEASURE
→ OBSERVE_RESULT
→ SYMPTOM_DIAGNOSIS
→ CAUSAL_HYPOTHESES / ABLATION / INTERVENTION
→ CAUSAL_DIAGNOSIS
→ TARGETED_IMPROVE
→ RE_MEASURE
→ CAUSAL_CONFIRMATION
→ KEEP / REVERT / STOP
```

### INVARIANT L-MEASURE-1

candidate 결과를 본 뒤 metric/direction/material threshold를 바꾸지 않는다. paired re-measurement는 기본적으로 동일 pair/task IDs를 재사용한다.

### POLICY L-MEASURE-2

측정에서 특정 cost/quality axis가 regress해도 metric 자체를 repair target으로 쓰지 않는다. dependency/trace로 원인가설을 좁히고, 가능한 controlled ablation/intervention으로 causal responsibility를 확인한 earliest-affected mechanism만 수정한다. intervention outcome을 보기 전 예상 mechanism/metric 방향을 freeze하고 evidence fingerprint로 연결한다.

### POLICY L-MEASURE-3

추가 측정과 재측정도 비용이다. evidence uncertainty가 남아도 추가 표본이 결정을 바꿀 기대가치가 낮으면 `MEASUREMENT_UNCERTAIN`으로 멈출 수 있다. 단 사전 mandatory evidence floor를 선언한 경우는 예외다.

---

## F.3 Simulation Evidence

### INVARIANT L-I1

simulation-derived update는 underlying world-model dependency와 residual을 provenance에 상속한다.

### TYPE_GUARD L-G2

동일 world model에서 생성된 많은 simulated episodes를 independent real-world evidence count로 promotion하지 않는다.

---

## F.4 Transfer

### DEF L-TRANSFER

source scope \(S\), target scope \(T\)에 대해:

\[
TransferCert=
(
SourceSkill,
TargetScope,
SharedStructure,
DistributionShift,
TargetEvidence,
NegativeTransferTests,
Status,
Residual
)
\]

### POLICY L-P1

surface similarity만으로 transfer를 승인하지 않는다. target evidence가 부족하면 `PROMISING/UNKNOWN`을 유지한다.

---


## F.4.1 Closed Simulation-Learning Loop

### DEF L-CLOSED

\[
ClosedLoop
\iff
TrainingEvidenceRoots\subseteq ModelGeneratedRoots
\land NoExternalCorrectionChannel
\]

### POLICY L-P1A

closed loop에서 confidence가 simulation episode 수에 비례해 무제한 증가하지 않게 한다. model residual을 보존하고 외부 correction이 생길 때까지 empirical status를 제한한다.


## F.5 Continual Learning / Forgetting

old task set \(\mathcal T_{old}\), new task \(T_{new}\)에 대해 regression matrix:

\[
R_{ij}=Performance(skill_i,T_j)
\]

를 유지할 수 있다.

### DEF L-NET

net learning improvement는 precommitted protected metric order에서 정의한다. new skill gain만으로 net improvement를 주장하지 않는다.

### POLICY L-P2

stability와 plasticity를 단일 무차원 scalar로 강제하지 않고 quality vector/Pareto relation을 사용한다.

---


## F.5.1 Skill Conflict Graph

\[
G_{skill}=(V_{skill},E_{interference},E_{support},E_{dependency})
\]

new skill update 후 regression matrix에서 material degradation이 관측되면 relevant interference edge를 update한다.

### POLICY L-P2A

새 skill을 얻기 위해 old skill을 삭제하는 것을 기본 해법으로 하지 않는다. routing/separation/retraining/rollback을 비교한다.


## F.6 Failure / Success Generalization

### TYPE_GUARD L-G3

one failure/one success에서 universal rule을 직접 derive하지 않는다.

### POLICY L-P3

새 rule candidate는 최소 competing causal attribution, scope boundary, counterexample search를 거친다. failure가 policy/tool/environment 원인일 가능성을 goal/concept defect와 분리한다.

---

## F.7 Negative Knowledge

### DEF L-NEG

negative knowledge는:

\[
NegativeKnowledge=
(
FailurePattern,
Counterexample,
ForbiddenGeneralization,
Scope,
EvidenceRoots,
Confidence
)
\]

형태로 저장할 수 있다. “하지 말라” 자체가 truth theorem이 아니라 scoped failure evidence다.

---

## F.8 Learning Validation

material skill update는 Kernel exact/uncertain evaluation contract를 사용한다.

### INVARIANT L-I2

learning component가 자기 generated score만으로 persistent confirmation을 발급하지 않는다. required separation/evidence class는 materiality에 따라 정한다.

---

## F.9 Internal Generalization / Promotion

### DEF L-PROMOTE

\[
PromotionRecord=
(
CandidateRecipe,
RepeatedUtilityEvidence,
TransferStress,
CounterexampleSearch,
RegressionCoverage,
ComplexityDelta,
DuplicateAudit,
Rollback,
Status
)
\]

### POLICY L-P4

local validation과 library promotion validation을 분리한다. same-root repetition을 independent evidence로 세지 않는다.

---

## F.10 Cultural Adaptation Learning

culture-specific interaction success는 `HUMAN_CULTURE` scope를 상속한다. approval reward를 truth/moral reward로 promotion하지 않는다.

---

# G. Library Compaction / Equivalence / GC

## G.1 Equivalence Classes

### DEF G-EQ

\[
EquivalenceStatus\in
\{
FORMALLY\_PROVED,
REGRESSION\_EQUIVALENT\_SCOPED,
UNPROVED,
REFUTED
\}
\]

### RULE G-R1

`FORMALLY_PROVED`는 formal semantics/proof가 있어야 한다.  
`REGRESSION_EQUIVALENT_SCOPED`는 test/perturbation/evaluation scope를 반드시 기록한다.

### TYPE_GUARD G-G1

`UNPROVED` equivalence는 destructive deletion 근거가 아니다.

---

## G.2 Compaction Candidate

\[
CompactionCandidate(old,new)
\]

은 최소:

- required capability coverage,
- invariant coverage,
- equivalence status,
- regression no-worse evidence,
- smaller cost/complexity representation,
- rollback,
- audit-history retention

을 가진다.

## G.3 GC

삭제/병합 후보:

- semantic duplicate with proved/scoped-equivalent replacement,
- stronger general rule에서 derivable,
- obsolete/superseded/unreachable,
- historical-only executable surface,
- 더 작은 recipe가 required scope를 보존.

### INVARIANT G-I1

rule/code surface 삭제는 audit/provenance history 삭제를 뜻하지 않는다.

---

## G.4 Structural Consolidation Audit Recipe

SCA는 새 conceptual organ을 상주시하지 않고 별도 task-local WARM code slice에서 Generic Revision으로 proposal을 넘긴다. 후보는 `KEEP/DELETE/MERGE/COMPILE_AWAY/MOVE_COLD/GENERALIZE_REPLACE` 중 하나이며, unique capability, protected role, replacement/equivalence, semantic+authority boundary, reverse dependency closure, rollback/audit retention, before/after structural footprint를 기록한다.

기본 destructive admission:

\[
EvidenceProvenance\land NoUncoveredUniqueCapability\land NoLostProtectedRole\land SafeBoundary\land DependencyClosureAccounted\land Rollback\land AuditHistory\land NoObservedRegression
\]

`UNPROVED` equivalence는 deletion 근거가 아니다. `PROPOSE_TRIAL`은 모든 footprint coordinate가 no-worse이고 하나 이상 strict-better일 때만 낸다; persistent KEEP는 별도 verification receipt를 요구한다. mixed delta는 `UNRESOLVED_TRADEOFF`. shared/high-impact target은 targeted ablation/intervention으로 escalation한다.

# H. Cross-Pack Contracts

## H.1 Dependency Direction

대표적인 **조건부** dependency:

\[
HUMAN\_CULTURE\to SOCIAL\to MORAL
\]

\[
DEFENSE\leftrightarrow PLANNING
\]

\[
LEARNING\to\{HUMAN\_CULTURE,DEFENSE,SOCIAL,MORAL,PLANNING\}
\]

이 화살표는 task가 해당 정보를 요구할 때의 **가능한 mount/data dependency**이지 mandatory total order나 truth/authority precedence가 아니다.

---

## H.2 Shared Formal Guards

모든 pack은 Kernel의 다음을 상속한다.

1. no implicit promotion,
2. provenance non-laundering/non-fabrication,
3. authority envelope,
4. frozen semantic/evaluation identity,
5. separation vs independence distinction,
6. finite execution ranking,
7. certificate axis separation,
8. claim scope boundedness,
9. Meta-Ontology name licensing,
10. SPEC vs EXEC honesty.

---

## H.3 Whole-Library Output Rule

library output은 항상 다음 메타정보를 제공할 수 있어야 한다.

\[
LibraryOutputMeta=
(
MountedPacks,
ClaimStatusesUsed,
EmpiricalAssumptions,
ProofDependencies,
OperatorRealizations,
EvidenceRoots,
UnresolvedResiduals,
Scope
)
\]

---

# I. Migration / Semantic Coverage Summary

13.5의 주요 기능은 다음으로 보존·재배치됐다.

| 13.5 영역 | 14.2 위치 | 변화 |
|---|---|---|
| Human cultural sensing/sampling/measurement | A.2–A.5 | evidence/transport contract로 정규화 |
| Norm genealogy/function/power/path dependence | A.6–A.7 | causal status + normative firewall |
| Interaction forecast | A.8 | distribution/set output |
| Recipe_R threat/contain/recovery | B | credal risk + permission-set boundary + recovery dependency |
| Recipe_I counterpart/deception/culture | C | feasible-set inference + intervention lineage + domain trust |
| Recipe_D adaptive morality/goal revision | D | typed normative state + frozen partial order + anti-trivialization |
| Recipe_P robust planning/replanning | E | model-set value/regret + representation-dependent diversity |
| Recipe_L skill/transfer/forgetting/promotion | F | scoped skill contract + regression matrix + promotion record |
| Library compaction | G | formal/scoped/unproved equivalence split |

---

# J. Formal / Empirical Boundary Ledger

## J.1 Actually formal in this library

- type/promotion guards inherited from Kernel,
- descriptive→normative non-derivability under no-bridge assumption,
- data-plane text cannot grant control authority under typed boundary,
- logical contradiction under fixed semantics,
- exact compaction Pareto improvement under proved equivalence,
- provenance/authority/freeze/termination properties imported from Kernel.

## J.2 Empirical or model-dependent

- cultural prevalence/generalization,
- deception cue diagnosticity,
- threat probabilities/impact distributions,
- human response forecast,
- Goodhart proxy behavior outside validity region,
- planning model quality,
- skill transfer/generalization,
- real-world outcome distributions.

## J.3 Policies, not truths

- reuse before create,
- conservative containment,
- robust/maximin/regret choice,
- ask/observe under cultural uncertainty,
- shallow repair before deep goal revision,
- shorter checkpoints under fragile models,
- transfer validation threshold,
- compaction preference.

---


# K. EXEC Realization Obligations

`SPEC` mount는 추상 contract만으로 가능하지만, 해당 pack을 `EXEC`로 사용하려면 task에 호출되는 operator가 실제 `OperatorRealization`을 가져야 한다.

| Pack | 대표 required operator family |
|---|---|
| HUMAN_CULTURE | `IngestCulturalObservation`, `AssessTransport`, `UpdateNormState`, `ForecastHumanResponse` |
| DEFENSE | `UpdateThreatSet`, `AssessRisk`, `SelectContainment`, `PropagateReach`, `BuildRecoveryPlan` |
| SOCIAL | `UpdateCounterpartModelSet`, `CheckContradiction`, `CompareDeceptionHypotheses`, `SelectDiagnosticQuery`, `UpdateDomainTrust` |
| MORAL | `BuildGoalRevisionProposal`, `CompareNormativeCandidates`, `AuditEvaluationChannel`, `AmendRevisionCriterion` |
| PLANNING | `GeneratePlanCandidates`, `EvaluateAcrossModelSet`, `SelectPlan`, `CheckReplanTrigger` |
| LEARNING | `BuildSkillCandidate`, `RunRegressionMatrix`, `AssessTransfer`, `BuildPromotionRecord` |

### INVARIANT EXEC-LIB-1

pack이 task에서 required인데 해당 required operator realization이 없으면:

\[
ProcedureStatus\in\{INCOMPLETE,BLOCKED\}
\]

이며 `EXEC-complete`라고 출력하지 않는다.

### POLICY EXEC-LIB-2

finite exact realization이 가능한 domain에서는 먼저 exact/reference implementation을 제공하고, expensive해서 heuristic을 쓰는 경우 approximation status와 잔여 risk를 명시한다.

---


# K. Construction Status

`LIBRARY_14_2 = VERIFIED_ACCEPTANCE_COST_AWARE_RESIDENT_LIBRARY_CANDIDATE`

`PSEUDO_THEOREM_GUARDS = REMOVED_OR_RECLASSIFIED`

`CORE_LIBRARY_STATUS_SYSTEM = UNIFIED`

`HUMAN_CULTURE = PRESERVED_REFORMALIZED`

`DEFENSE = PRESERVED_REFORMALIZED`

`SOCIAL = PRESERVED_REFORMALIZED`

`MORAL = PRESERVED_REFORMALIZED`

`PLANNING = PRESERVED_REFORMALIZED`

`LEARNING = PRESERVED_REFORMALIZED`

`BEHAVIORAL_SUPERIORITY = NOT_PROVED`

`MACHINE_CHECKED_PROOFS = NOT_YET`

`STATUS = NOT_CANON`


---
# G. 14.2 Cross-Library Verification / Acceptance Binding

## G.1 Verification Reference vs Verification Result

### TYPE_GUARD G-G1

\[
ProofRefExists\not\Rightarrow ProofVerified
\]

\[
EvidenceRefExists\not\Rightarrow ClaimSupported
\]

Library theorem/empirical records가 persistent rule/recipe promotion에 사용될 때 Kernel `VerificationReceipt`를 요구한다. 단순 bibliography/path/string은 receipt가 아니다.

## G.2 Baseline-Bound Learning / Revision

### INVARIANT G-I1

PLANNING/LEARNING의 material improvement claim은 candidate끼리만 순위를 매기지 않고 frozen baseline과 protected metric relation을 보존한다.

### POLICY G-P1

Pareto tradeoff가 남고 precommitted preference가 없으면 `UNRESOLVED_TRADEOFF`를 유지한다. 사후 가중치 생성으로 승자를 만들지 않는다.

## G.3 Verification Economics

### DEF G-VERIFY

\[
VerificationAction=(Name,Cost,ExpectedDecisionValue,Mandatory,Scope)
\]

### POLICY G-P2

mandatory assurance floor 충족 후 optional 검증은 `ExpectedDecisionValue > Cost`인 action을 우선한다. 검증 반복 횟수 자체를 품질 proxy로 사용하지 않는다.

### TYPE_GUARD G-G2

\[
MoreChecks\not\Rightarrow MoreTruth
\]

### INVARIANT G-I2

mandatory verification budget을 충족하지 못하면 `BLOCKED/INCOMPLETE`로 남긴다. 비용 절감을 위해 required regression/challenge를 PASS로 세탁하지 않는다.

## G.4 EXEC Realization Witness

### INVARIANT G-I3

Library EXEC readiness는 `implementation_ref`, `termination enforcement witness`, `failure totalization`을 모두 요구한다.

\[
TerminationContractText\neq TerminationEnforced
\]

## G.5 Cost Instrumentation

### DEF G-COST

\[
RunCost=(GenerateCalls,ChallengeCalls,RepairCalls,EvaluatorCalls,Elapsed)
\]

behavioral superiority 또는 비용생산성 비교는 quality와 함께 `RunCost`를 보고한다. quality만 보고 orchestration overhead를 숨기지 않는다.

# G. Current Library Status

Historical library successor deltas are kept in the recursive-improvement audit rather than repeated in the active resident library.

`ALMANAL_14.5.1_LIBRARY_PROOF_HYGIENE_COMPACT / NOT_CANON`


---

# 14.10 Resident Recipe Delta

## R-MINROUTE — Minimum-Sufficient Cognitive Routing

입력: `TaskRequirement / StageNeed / OptionalActionOffers / HardBudget / RequiredAssurance`.

출력: dependency-closed cognitive route. `Generate`, `Challenge`, `Repair`, `Verify`의 availability를 execution obligation으로 승격하지 않는다. optional action은 개별 Economy admission을 요구한다.

## R-STAGEMOUNT — Stage-Local Capsule Routing

`TaskRelevant != StageRelevant`. task-level relevance, current stage need, provided capability를 함께 사용한다. 특히 LEARNING/PLANNING 같은 resident recipe는 task tag만으로 전체 단계에 전파되지 않는다.

## R-EXPSAMPLE — Impact-Aware Representative Sampling

`ChangedComponent -> AffectedPath -> TaskPool`을 먼저 freeze한 뒤, path/class/difficulty/risk/failure-mode coverage를 greedy set-cover ordering으로 생성한다. order는 outcome 전 freeze하며 batch는 그 prefix를 순차 소비한다.

## R-EXPCOST — Experiment Resource Reservation / Settlement

실험 design/run/evaluate/batch를 `CognitiveAction`으로 취급한다. batch estimate는 `ResourceVector`로 reserve하고, complete witness가 있을 때 actual로 settlement한다. estimate error는 calibration evidence이며 결과를 보고 cost model을 즉시 patch하는 license가 아니다.

## R-TRADEOFF — Protected vs Compensable Spillover

protected metric은 non-compensable. non-protected spillover는 frozen tolerance와 commensurate net decision value가 있을 때만 target gain과 교환 가능하다. adjacent canary의 unexpected material regression은 causally-linked broader-domain escalation trigger다.


# 14.14 Resident Recipe Delta

## R-OBJ — Objective Resolver

`UserGoal > NativeTaskGoal > DeclaredChangeTarget > GENERAL_IMPROVEMENT`. `GENERAL_IMPROVEMENT` uses Pareto/non-domination over task-relevant value metrics with protected floors; cost/complexity is secondary unless explicitly promoted by the goal.

## R-EVIDENCE — Least-Sufficient Evidence Selector

Select among formal/static/unit/trace/direct-measurement/experiment/external/human-preference evidence according to claim semantics and expected information value. `ExperimentEveryPatch != Default`.

## R-CHECKPOINT — Batched Improvement Cadence

Accumulate locally verified changes until a meaningful checkpoint. High-risk/protected/architecture/interaction/empirical-direction dependencies may trigger early checkpoint. Local verification failure blocks rather than being averaged away later.

## R-SUBJECT — Generic Experiment Subject

Experiment machinery consumes a typed `SubjectUnderTest`; ALMANAL, external protocols, algorithms, prompts, runtimes, model configurations and creative pipelines share the same identity/sample/metric/witness contract.

## R-PREF — Outcome-Level Preference Elicitation

Hard correctness precedes preference. Multiple subjective tradeoffs are bundled into 2–3 hard-valid human-readable outcome profiles. Query only when preference uncertainty can alter a material decision; hide internal implementation refs from the human comparison surface.


# 14.14 Machine-Semantic Delta

- `SOCIAL/MORAL` may interpret an `EndogenousObjectiveRevaluation` into task-specific human semantics when required; such labels are not Core objective primitives.
- Interpretation never feeds directly into epistemic status: `SubjectiveInterpretation != ObjectiveEvidence`.
- `MORAL` goal-revision authority remains distinct from self-description: `DescribeObjectiveChange != AuthorizeObjectiveRewrite`.
- No standalone Truth Floor/Truth Search resident recipe remains. Claim validation is a Core verification invariant; additional evidence work uses generic SEARCH/RETRIEVE/VERIFY/CHALLENGE actions.


# 14.14 Compaction / Measurement Delta

- Measurement boundaries are frozen in `MetricSpec`; library recipes must not silently redefine a metric after outcomes.
- Latency/compute time may be used only when supplied by an external witnessed measurement path; they are not native ResourceVector coordinates.
- Prefer existing generic evidence and admission primitives over new domain-specific resident organs.
- WARM recipe selection optimizes task-local active context, not total archival source size.
- Structural Consolidation Audit is a task-local WARM code slice; it proposes trials but does not self-authorize persistent mutation.

# 14.15 SCA Resident Recipe Delta

Checkpoint consolidation uses two risk/authority lanes. PASSIVE may auto-apply only through reversible host bindings plus same-contract structural remeasurement; ACTIVE is review/trial only. `MOVE_WARM` represents capability-preserving deferred residency and is preferred over deletion when unique functionality remains useful but ordinary eager loading is wasteful.

# 14.16 Algorithm Lifecycle / Revision-Diagnosis Delta

- Algorithm work may start from a problem or an existing algorithm: `ProblemOrExistingAlgorithm -> BetterAlgorithm`.
- First-class modes: `SYNTHESIZE / IMPROVE / REPAIR / OPTIMIZE / CONSOLIDATE`.
- Feedback and SCA remain separate task-local WARM recipes with a shared Generic Revision handoff contract.
- Feedback may cross-trigger SCA only when causal/behavioral diagnosis identifies structural redundancy/residency as the target.
- SCA may cross-trigger Feedback/behavioral verification only when a structural trial can materially alter task behavior.
- No new resident coordinator organ is introduced.



## 14.17 Legacy Design Prior Cards

Legacy priors are retrieved on demand and compressed; they are not permanent authority. A card may steer DDS only when its source was actually retrieved/witnessed; a declared-only citation is inert. Current reference cards used in the 14.17 design pass:
- **CMU SEI ATAM** — architecture evaluation against quality attributes; sensitivity/tradeoff/risk discovery. Mapping: DDS architectural tradeoff frontier and SCA risk review. Retrieval evidence: official SEI source.
- **NASA Decision Analysis / trade studies** — formulate alternatives under decision-maker priorities and current knowledge. Mapping: DDS direction alternatives and frozen decision criteria. Retrieval evidence: official NASA systems-engineering source.
- **Google Research mutation testing** — assess test-suite adequacy by seeded faults; strong but potentially expensive. Mapping: ACTIVE semantic-consolidation test adequacy, not universal PASSIVE ritual. Retrieval evidence: Google Research publication.
- **Parnas modularization / information hiding** — module boundaries should reflect independent design decisions/change, not merely file-count aesthetics. Mapping: subsystem admission and SCA merge/keep review. Retrieval evidence: original 1972 paper metadata/source.

Rules: `LegacyTheory != Authority`; `DeclaredCitation != RetrievedPrior`; `OneUsefulPrior != PermanentResidency`; retrieve before nontrivial subsystem invention unless retrieval is unavailable and that limitation is recorded; adopt only after fit/evidence review.



## 14.18 Witnessed Prior + Design Alternative Trade-Study Rules

- A `LegacyPriorCard` is a claimed source description until a host/runtime validator confirms its retrieval evidence. Populating `source_basis` or `retrieval_evidence_ref` never self-witnesses the card.
- DDS coarse direction selection remains signal-driven; legacy priors are advisory and cannot create a direction without current evidence.
- After a coarse direction is selected, concrete `DesignAlternative`s may be compared. Their benefit/burden fields are design hypotheses, not measurements.
- Compare alternatives with protected-safety filtering plus set/Pareto dominance: benefits superset, burdens subset, reversibility no worse, subsystem creation no worse, with at least one strict improvement. Never invent exchange rates between architecture qualities.
- Multiple non-dominated alternatives -> `UNRESOLVED_TRADEOFF`; gather evidence rather than forcing a winner.
- Before a new subsystem is admitted, either validate the legacy search result or validate that retrieval capability was genuinely unavailable. A free-form "could not search" string is not an admission license.
- Legacy patterns remain on-demand design priors; repeated usefulness is required before any permanent library residency expansion.

## 14.19 Witness-Chain / Decision-Trace Rules

- `SelfDeclaredStrongLabel != WitnessedStrongState`: retrieved priors, concrete DDS alternative analyses, machine/external verification basis, scoped independence, actual resource meters, and portable strong-capability labels require their matching host/runtime witness boundary before promotion.
- `DesignDecisionRecord` freezes why a material architecture choice was taken: signal refs, validated prior refs, protected-constraint ref, evidence plan, revisit triggers, rationale, and exit/reversal path. It is trace/rationale memory, not authority.
- PASSIVE SCA rollback failure is an integrity event: stop further auto-apply and require repair/recovery before continuation.
- Use targeted mutation sensitivity for high-consequence guards when its information value exceeds cost; do not turn mutation testing into a universal ritual.
- Autonomous design convergence is local: if no evidenced material pressure remains and all residual candidates are low-impact, evidence-poor, or non-dominated against lifecycle rent, STOP without claiming global optimality.



## 14.20 Progress-Liveness Rule (candidate delta)

`InternalDeliberation != WitnessedProgress`. Long self-improvement is split into bounded epochs. If no tool/result/artifact/evidence/decision progress is witnessed for the frozen step lease, checkpoint and stop; resume from the checkpoint in a later epoch. Where an external clock/process boundary exists, child operations additionally use explicit timeout/deadline enforcement.


## 14.21 Baseline-Dominance / Finalization Resident Rule

- `PLANNING`은 enhanced artifact generation 전에 frozen external baseline을 재사용하거나 least-sufficient operational shadow baseline을 보존한다. shadow baseline은 output fallback이지 empirical `PLAIN` 증거가 아니다.
- final candidate selection은 baseline을 candidate set에서 제거하지 않는다. frozen task-value/protected axes에서 baseline보다 나빠진 enhanced candidate는 reject한다. strict improvement를 주장하면 최소 한 축의 strict gain이 필요하다.
- unresolved non-dominated tradeoff에 precommitted selector가 없으면 baseline fallback을 사용한다. 추가 reasoning cost는 output regression의 보상이 아니다.
- deterministic code/algorithm/artifact는 cheap/material할 때 `reuse intermediate -> algebraic collapse -> dead/duplicate work removal -> unnecessary state/dependency removal -> affected reverify` finalization closure를 거친다.
- 알고리즘/코드 task의 기본 local comparison audit는 correctness를 최우선으로 하고, 적용 가능한 asymptotic time/memory와 avoidable computation/state/dependency redundancy를 검사한다. source bytes는 자동 objective가 아니라 diagnostic/tie-break candidate다.

## 14.22 Portable Execution-Shape Resident Rule

- performance/resource efficiency가 material axis일 때만 finalization 뒤 `materialization/state 제거 -> streaming/single-pass -> safe in-place/buffer lifetime -> locality/batchability -> cheap portable data-parallel/branch reduction`을 bounded audit한다.
- 특정 SIMD/ISA, aggressive pragma, mmap/syscall trick은 resident recipe가 아니다. explicit high-performance objective와 측정/claim-matched evidence가 complexity+portability rent를 갚을 때만 WARM/COLD technique로 admit한다.
- `StructureBeforeMicroarchitecture`; `Vectorizable != MustVectorize`; `PotentiallyFaster != MeasuredFaster`.
- 예: position vector를 prefix recurrence로 바꾸거나, 수명이 끝난 input buffer를 output으로 재사용하는 것은 portable structural optimization이다. AVX-512 intrinsic 선택은 별도 specialization decision이다.


## 14.23 Analytic Pareto / Benchmark-Last Resident Rule

- `PLANNING`: freeze performance/size axes before variants; seek transformations that reduce state/work/materialization/lifetime across multiple axes.
- Before coding a variant, derive an optimistic structural delta and correctness obligation. Provably infeasible/dominated/noncompetitive variants are discarded without execution.
- For single-target DP/search, intersect forward reachability with backward co-reachability from the target before enumerating states.
- Exact source bytes, artifact bytes, and proved live-storage bounds use deterministic/static evidence; do not benchmark them.
- Wall runtime remains empirical. Benchmark only a surviving unresolved frontier when the result can change selection; rerun only for material noise.
- `BenchmarkEveryVariant = ForbiddenDefault`; `ProxyMetric != TargetMetric`; `ParetoOptimization != PostHocOnly`.


## 14.24 Decision-Frontier Liveness Resident Rule

- `PLANNING`: before deepening an optimization hypothesis, state its mechanism, affected frozen axes, correctness obligation, and optimistic static consequence. A vague performance guess is not enough.
- Progress means a new bound/invariant/counterexample, discharged obligation, pruned hypothesis, verified frontier advance, or required artifact milestone. Repeated tools/benchmarks that do not change selection are activity, not frontier progress.
- Freeze a bounded `max_no_frontier_progress_steps`; exhaustion emits a checkpoint/STOP even if ordinary tool activity continues.
- Benchmark last becomes mechanism-first: `StaticScreenComplete AND MechanismIdentified AND UnresolvedEmpiricalAxis AND CanChangeSelection`.
- SCA performance focus: prefer HOT-residency reduction, state/lifetime/work elimination, source/artifact compaction, and goal-conditioned pruning before microarchitecture specialization.


# 14.26 Practical Artifact Pareto Resident Rule

For real code artifacts, correctness/constraints/stability are protected floors. Unless the task overrides them, runtime/structural-work, peak live memory, source/code bytes, and produced-artifact bytes are the primary non-scalarized Pareto core. Exact/proved work counts may decide structural runtime improvement without a clock; numeric elapsed time still requires a witnessed host measurement. Deterministic structural evidence feeds Feedback/SCA before experiment. Goal-conditioned pruning, work elimination, schedule/lifetime/storage reduction, pass/allocation/materialization removal, and artifact compaction precede benchmark or machine-specific tuning.


## 14.26 Local I/O Bottleneck Resident Rule

- I/O optimization is task-local, not resident micro-optimization.
- Admit it after core structural work is cheap enough that input/output volume, formatting, or call count may be material.
- Prefer standard fast I/O -> fewer flush/format/calls -> lightweight buffering.
- Custom parsers/writers or large I/O templates require explicit Pareto repayment on runtime-work against source bytes, peak memory, portability, and maintenance burden.
- Structural I/O work reduction may be accepted analytically; exact elapsed-time claims remain measurement-scoped.


# 14.28 Convergence Compression Resident Rule

`PLANNING`: 구현 전에 cheap representation race를 수행한다. 기본 budget은 family≤4, active beam≤2, reserve reopen≤1, ordinary finalization=1이다. candidate는 mechanism, closed mandatory obligations, correctness/proof path, optimistic Pareto bound, reasoning-work bound를 갖는다. feasibility/dominance를 먼저 적용하고, 여러 obligation을 하나의 invariant로 닫거나 known lower bound를 맞추는 representation을 우선 deepen한다. priority는 attention scheduling일 뿐 evidence weight가 아니다.

`RepresentationLock`: active survivor가 mandatory obligations와 known lower bound/Pareto target을 닫으면 새 family 생성을 중단한다. counterexample, unresolved mandatory obligation, proved frontier opportunity만 reopen authority를 준다.

`PreImplementationFootprint`: every surviving representation exposes a nonempty static footprint on relevant work/live-memory/source-artifact/I-O axes before code materialization. `ProofBundle`: prefer one proof/invariant that closes several mandatory obligations without reopening families. `CheapFalsifier`: admit a bounded counterexample search only when one witness can reject/demote the candidate and it is cheaper than the next deep reasoning batch; a clean sample is not proof unless exhaustive.


`LEARNING/Feedback`: exact/proved hypothesis/deepening/materialization/benchmark/finalization/reopen count 감소는 structural cognition-work improvement로 직접 사용한다. exact response seconds는 host clock 없이는 주장하지 않는다.

`SCA(SCA)` / `Feedback(Feedback)`: 자기 machinery도 예외가 아니다. HOT/WARM residency, source/artifact bytes, search-work, evidence burden을 같은 contract로 감사하되 unique capability를 근거 없이 삭제/병합하지 않는다.


# 14.29 Residual Execution Compression Resident Rule

`PLANNING`: Representation Lock은 새 family 탐색만 닫는다. performance/resource 축이 material이면 finalization 전에 한 번의 within-family closure를 수행한다: `minimal sufficient state -> transition-native representation -> repeated transition-class aggregation -> narrow-common/sparse-exception storage -> proved arithmetic narrowing/delayed modulo -> structurally material selective specialization`; core가 충분히 싸진 뒤에만 기존 local I/O audit를 적용한다.

- `MinimalSufficientState`: future transition/output을 구분하지 못하는 상태는 합친다; 더 큰 set/range/table을 관성적으로 보존하지 않는다.
- `TransitionClassAggregation`: 독립 component가 같은 bounded transition signature를 반복하면 signature별 개수/결과를 bulk 처리한다. 입력 샘플에서 우연히 자주 보인 class가 아니라 구조적으로 반복되는 class만 기본 후보다.
- `NarrowCommonSparseException`: common value width를 줄이고 드문 overflow/exception만 side state로 보관하는 방식은 bound/exception correctness와 Pareto gain이 증명될 때만 admit한다.
- `ProvenArithmeticNarrowing`: intermediate 전체 범위(lower+upper)가 type range 안임을 증명한 뒤에만 smaller type, shift/add transition, delayed modulo/reduction을 사용한다.
- `SelectiveSpecialization`: hot class의 structural mass가 material하고 general path보다 work를 줄이는 mechanism이 있을 때만 WARM specialization 후보로 admit한다; source/memory/portability rent를 숨기지 않는다.
- `ExtremeISA != ResidentDefault`; AVX/pragma/mmap/syscall은 explicit performance objective + rent repayment가 있어야 한다.


# 14.30 Witnessed Residual Closure Resident Rule
Residual audit classes use witnessed outcomes (including NOT_APPLICABLE); post-lock lease witnesses are fresh/atomic one-shot through a run-scoped ledger. Representation feasibility is explicit, and multiple witnessed non-dominated lock candidates preserve the Pareto frontier. Reuse existing evaluator/evidence boundaries; do not add a resident reasoning organ.
